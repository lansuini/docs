<?php
/**
 * vegas2.0
 *
 * @auth *^-^*<dm>
 * @copyright XLZ CO.
 * @package
 * @date 2017/4/7 15:04
 */

use Utils\Admin\Action;
use Utils\GeoIP;
use Logic\Admin\AdminToken;
use Respect\Validation\Validator as v;
return new class extends Action {
    const TITLE = "文档编写中";
    const HINT = "开发的技术提示信息";
    const DESCRIPTION = "文档编写中";
    const TYPE = "text/json";


    public function run() {

        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $settings = (new \Logic\Set\Datas($this->ci))->getGlobalSet();
        $IP_limit = isset($settings['base']['IP_limit']) ? $settings['base']['IP_limit'] : \Logic\Set\SetConfig::DATA[$key]['base']['IP_limit'];
        if($IP_limit){
            $geoipObject = new GeoIP();
            $path = __DIR__ .'../../../../../../../repo/lib/service/GeoIP.dat';
            $gi = $geoipObject->geoip_open($path,GEOIP_STANDARD);
            $country_code = $geoipObject->geoip_country_code_by_addr($gi, \Utils\Client::getIp());
            $country_name = $geoipObject->geoip_country_name_by_addr($gi, \Utils\Client::getIp());
            $geoipObject->geoip_close($gi);

            if($country_code == 'CN' || $country_name == 'China'){
                return $this->lang->set(10044);
            }
        }

        $validation = $this->validator->validate($this->request, [
            'token' => v::noWhitespace()->length(32, 32)->setName('验证码'),
            'code' => v::noWhitespace()->length(4, 6)->setName('验证码'),
            'username' => v::noWhitespace()->length(4, 16)->setName('用户名'),
            'password' => v::noWhitespace()->length(6, 32)->setName('密码'),
        ]);
        if (!$validation->isValid()) {
            return $validation;
        }
        $params = $this->request->getParsedBody();

        $val = (new \Logic\Captcha\Captcha($this->ci))->validateImageCode($params['token'],$params['code']);
        if(!$val)
            return $this->lang->set(10045);

        $jwt = new AdminToken($this->ci);
        $jwtconfig = $this->ci->get('settings')['jsonwebtoken'];
        $digital = intval($jwtconfig['uid_digital']);
        $token = $jwt->createToken($params,$jwtconfig['public_key'],$jwtconfig['expire'],$digital);
        return $token;
    }
};
