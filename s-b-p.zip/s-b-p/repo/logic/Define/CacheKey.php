<?php
/**
 * Created by PhpStorm.
 * User: tyleryang
 * Date: 2018/3/21
 * Time: 10:28
 */
namespace Logic\Define;
/**
 * Class CacheKey
 * 缓存key定义 前缀定义类
 * @package Logic\Define
 */
class CacheKey {

    /**
     * key
     * @var array
     */
    public static $perfix = [
        
        // 密码错误校验前缀
        'pwdErrorLimit' => 'loginpwd_wrong_times_',

        // 全局配置
        'global' => 'system.config.global',

        // 注册
        'registerUser' => 'system.config.reg.user',

        // 第三方客服
        '3thService' => 'system.config.third.service',

        // 用户登录token
        'token' => 'token_',

        // 热门彩期
        'hotLottery' => 'curperiod_hot_all_',

        // 热门彩期
        'hotLotteryNext' => 'nextperiod_hot_all_',

        // 首页缓存
        'appHomePage' => 'app_home_page',

        // notice h5list
        'noticeH5list' => 'notice_h5_list',

        // banner
        'banner' => 'banner',

        // 彩种
        'simpleList' => 'lottery_list_',

        // 开奖列表
        'appLotteryList' => 'app_lottery_list',

        // 玩法结构
        'lotteryPlayStruct' => 'lottery_play_struct_',

        // 玩法结构版本
        'lotteryPlayStructVer' => 'lottery_play_struct_ver_',

        // 厅
        'hall' => 'hall_',

        // 厅消息
        'hallMessage' => 'hall_message_',

        // pusherio
        'pusherioHistory' => 'pusherio_history_',

        // 彩期缓存
        'prizeLotteryInfo' => 'prize_lottery_info_',

        // 当前彩期 hash
        'currentLotteryInfo' => 'current_lottery_info',

        // 彩期列表 hash
        'lotteryInfoHistoryList' => 'lottery_info_history_list',

        // 下一期 hash
        'nextLotteryInfo' => 'next_lottery_info',

        // 彩期期数 hash
        'lotteryPeriodCount' => 'lottery_info_period_count',

        // 结算信息 集合
        'prizeOpenSettle' => 'prize_open_settle_',

        // 追号通知 集合
        'prizeChase' => 'prize_chase_',

        // 彩果结果同步 集合
        'prizeRsync' => 'prize_rsync_',

        // 最后一期结果hash
        'prizeLastPeriods' => 'prize_last_periods',

        // 追号期数100条hash
        'chaseLotteryInfo' => 'chase_lottery_info',

        // 平台结果缓存 
        'commonLotteryPeriod' => 'common_lottery_period_',

        // 平台开奖结果集合
        'commonLotteryPeriodSet' => 'common_lottery_period_set',

        // 结算防重复
        'settleNotify' => 'settle_notify_',

        // 返水防重复(集合)
        'runRebet' => 'run_rebet',

        // 图形验证码前缀
        'authVCode' => 'auth_vcode:',

        // 短信通知码
        'captchaRefresh' => 'cache_refresh_',

        // 短信通知码
        'captchaText' => 'cache_text_',

        // prizeServer 防多开
        'prizeServer' => 'prize_server',

        // spiderServer 防多开
        'spiderServer' => 'spider_server',

        // 本地测试开奖
        'spiderServerTest' => 'spider_server_test',

        // 本地测试开奖彩期数据
        'spiderServerLotteryTest' => 'spider_server_lottery_test',

        // 活动缓存
        'activeList' => 'activeList_',

        // ip流水防护
        'protectByIP' => 'protect_ip',

        // 用户流水防护
        'protectByUser' => 'protect_user',

        // 试玩IP验证
        'tryToPlay' => 'trytoplay:',

        // LEBO
        'LeboSecurity' => 'lebo_security',

        // PT
        'PtOpenId' => 'pt_openid:',

        // FG
        'FgOpenId' => 'Fg_openid:',

        // MW
        'MwDomain' => 'gapi_mw:domain',

        // HB
        'HbToken' => 'gapi_hb:',

        // HB list
        'HbList' => 'gapi_hb_list',

        // AG
        'AgUser' => 'ag_user:',

        // AG
        'AgLoginSet' => 'ag_login',

        // AG
        'AgLogin' => 'ag_login_',

        // userSafety
        'userSafety' => 'user_satety_',

        // socketiokey mess
        'socketioMessage' => 'socketio_message',

        // 提现密码修改限制
        'fundsPass' => 'account_wallet_password_',
        
        // 平台彩种停售标识
        'commonLotterySaleStatus' => 'common_lottery_sale_status_',

        // findpass
        'findPass' => 'find_pass_',

        // 用户在状在线最后时间
        'userOnlineLastTime' => 'user_online_last_time',

        // 用户禁用状态
        'userRejectLoginStatus' => 'user_reject_login_status',

        // chatLotteryRoomHash
        'chatLotteryRoomHash' => 'chat_lottery_room_hash',

        'agGames' =>'jobs_ag_games',

        'agPlayTypes'=>'jobs_ag_play_types',

        'partners'=>'jobs_partners',

        'agLastId'=>'jobs_ag_last_id',

        'leboLastTime'=>'jobs_lebo_lasttime',

        'sabaLastPagekey'=>'jobs_saba_last_pagekey',

        'fgGames'=>'jobs_fg_game_list',

        'ptGames'=>'jobs_pt_game_list',

        'fgLastId'=>'jobs_fg_last_id',

        'fgLastPage'=>'jobs_fg_last_page',

        'ptLastId'=>'jobs_fg_last_id',

        'sabaGames'=>'jobs_saba_games',

        'sabaPlayTypes'=>'jobs_saba_play_types',

        'bkgeOrder3thTime'=>'jobs_bkge_order3th_time',

        'lotteryHomePageData'=>'lottery_homepage_data',

        'requestCreateOrderList'=>'request_create_order_list',

        'callbackOrderList'=>'callOrderList',
    ];

}