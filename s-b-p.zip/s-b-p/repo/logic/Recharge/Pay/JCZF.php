<?php
/**
 * 金咖支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JCZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'tradeNo' => $this->orderID,
            'payType' => $this->payType,
            'orderPrice' => sprintf("%.2f", $this->money),
            'merchantId' => $this->partnerID,
            'productName' => '商品购买',
            'remark' => '商品购买',
            'productName' => 'YF_GOODS',
            'backurl' => $this->notifyUrl,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    public function parseRE()
    {
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        if (isset($data['s'])) {
            unset($data['s']);
        }

        $orderId = str_replace("jkcs_", "", $data['tradeNo']);
        $res = [
            'status' => 0,
            'order_number' => $orderId,
            'third_order' => $data['orderNo'],
            'third_money' => $data['orderAmt'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if ($data['code'] != 200) {
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign
        if ($data['sign'] != $this->_sign($data, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    /**
     * 生成签名
     */
    private function _sign($pieces, $key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $keys => $value) {
            if ($value != '' && $value != null && $keys != 'sign' && $keys != 'backurl') {
                $string = $string . $keys . '=' . $value . '&';
            }
        }
        $string = $string . 'key=' . $key;
        $sign = strtoupper(md5($string));
        return $sign;
    }

}