<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 快付通
 */
class KFTZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'Amount' => $this->money * 100,
            'NotifyUrl' => $this->notifyUrl,
            'OrderNo' => $this->orderID,
            'Remark' => '备注',
            'ProductName' => $this->orderID,
//            'HubpayCode' => $this->payType,
            'PayType' => $this->payType,//支付类型 0=支付宝（默认）1=微信 3=网关  【根据商户开通的通道填写】
            'PayMode' => 1,//0=扫码(默认） 1=H5  【根据商户开通的通道填写】
            'TimeStamp' => time(),
            'NonceStr' => $this->NonceStr(),
            'AppId' => $this->partnerID,
        ];

        //有传入mode情况
        if (strpos($this->payType, '|')) {
            $args = explode('|', $this->payType);
            if (sizeof($args) == 2) {
                $data['PayType'] = $this->payType = $args[0];
                $data['PayMode'] = $args[1];
            }
        }

        //不参与签名字段
        $pub_params = [
            'Signature' => $this->getSign($data, $this->key)
        ];

        $this->parameter = array_merge($pub_params, $data);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['ret']) && $re['ret'] == 0 && isset($re['data'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = $re['msg'] ?? 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['Qrcode'] ?? $re['data']['PayUrl'];
        } else {
            $this->return['code'] = $re['ret'] > 0 ? $re['ret'] : 23;
            $this->return['msg'] = '快付通支付：' . $re['msg'] ?? '请求失败';
            $this->return['way'] = $this->data['return_type'];
        }
    }

    //生成数字和字母组合随机数
    public function NonceStr($length = 16)
    {
        $returnStr = '';
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for ($i = 0; $i < $length; $i++) {
            $returnStr .= $pattern{mt_rand(0, 61)};
        }
        return $returnStr;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($arr, $AppSecret)
    {
        unset($arr['Signature']);
        unset($arr['AppSecret']);

        //按照键名字典排序
        ksort($arr);
        //生成URL格式的字符串
        //http_build_query()中文自动转码需要处理下
        $str = http_build_query($arr) . "&AppSecret=" . $AppSecret;
        $str = trim(urldecode($str));
        return strtoupper(md5($str));
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['OrderNo']) || !isset($data['OutTradeNo']) || !isset($data['PayAmount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $data['OrderNo'],
            'third_order' => $data['OutTradeNo'],
            'third_money' => $data['PayAmount'] / 100,
        ];

        if ($data['TradeStatus'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }

    private function _verifySign($data, $config)
    {
        $returnSign = $data['Signature'];
        $sign = $this->getSign($data, $config['key']);
        return $sign == $returnSign;
    }

}