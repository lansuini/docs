<?php
/**
 * 快捷通
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class KJTZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {

        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }
    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'amount' => sprintf("%.2f", $this->money),
            'applyDate' => date('Y-m-d H:i:s', time()),
            'channelType' => (string)$this->payType,//支付类型，bank_data
            'merchantId' => (string)$this->partnerID,//商户号
            'notifyUrl' => $this->notifyUrl,//页面跳转返回地址
            'tradeNo' => (string)$this->orderID,//商户订单号
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;
        //var_dump($this->parameter);exit();
    }

    /**
     * 发起请求
     */
    public function parseRE()
    {
        $data = json_decode($this->re,true);

        if (isset($data['code']) && $data['code']==1){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['data'];
        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = $data['info'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . '&key=' .$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['merchantId']) || !isset($data['amount']))
        {
            return false;
        }
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['tradeNo'],//商户订单号
            'third_order' => $data['orderId'],//系统订单号
            'third_money' => $data['amount'],//支付金额
            'error' => '',
        ];

        if ($data['returnCode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }
        //按规则验签
        $result = $this->returnVail($data, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    public function returnVail($params, $pubkey)
    {
        $signstr = $params['sign'];
        //按签名规则排序数组
        $order_sign_params = [
            'amount' => $params['amount'],
            'dateTime' => $params['dateTime'],
            'merchantId' => $params['merchantId'],
            'orderId' => $params['orderId'],
            'returnCode' => $params['returnCode'],
            'tradeNo' => $params['tradeNo']
        ];
        $sign = $this->_sign($order_sign_params, $pubkey);
        return $sign == $signstr;
    }

}