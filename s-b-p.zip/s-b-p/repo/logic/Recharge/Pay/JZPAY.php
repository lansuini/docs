<?php
/**
 * 金砖支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/14
 * Time: 9:47
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class JZPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'mch_code' => $this->partnerID,
            'pay_type' => (string)$this->payType,
            'mch_trade_no' => (string)$this->orderID,
            'timespan' => time(),
            'amount' => sprintf("%.2f", $this->money),
            'notify_url' => $this->notifyUrl,
            'return_url' => $this->returnUrl
        ];
        $pub_params['sign'] = $this->_sign($pub_params,$this->key);
        //var_dump($pub_params);exit();
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if (isset($re['success']) && $re['success']){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $re_data = $re['data'];
            $this->return['str'] = $re_data['url'];
        }else{
            $this->return['code'] = $re['status'];
            $this->return['msg'] = $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['mch_trade_no'],
            'third_order' => $parameters['trade_no'],
            'third_money' => $parameters['pay_amount'],
        ];
        $config = Recharge::getThirdConfig($parameters['mch_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['expire_time'] < time()){
            $res['status'] = 0;
            $res['error'] = '订单支付时间已过期';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['mch_trade_no'];
            $return_money = $parameters['pay_amount'];
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            if (!empty($val)){
                $string[] = $key.'='.$val;
            }
        }
        $params = join('&',$string);
        $sign_str = $params.'&key='.$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}