<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 诚信支付2
 */
class CHENXIN2 extends BASES
{

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $data = array(
            'merchNo' => $this->partnerID,
            'orderNo' => $this->orderID,
            'amount' => sprintf('%.2f', $this->money), //保留两位小数
            'currency' => 'CNY',
            'outChannel' => $this->payType,
            'bankCode' => 'ICBC',//当支付类型为网关支付时，需要传
            'title' => "充值",
            'product' => "消费",
            'memo' => 'vip',
            'returnUrl' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,
            'reqTime' => date("Ymdhms"),
            'userId' => $this->uid,
        );

        $this->parameter = $this->buildApi($data);
        //方便查看日志，把参数合并下
        $this->parameter = array_merge($this->parameter, $data);
    }

    private function buildApi($params)
    {
        $data_json = json_encode($params, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $pubKey = $this->_getPublicKey($this->pubKey);
        $cryptos = "";
        foreach (str_split($data_json, 117) as $value) {
            openssl_public_encrypt($value, $encryptDatas, $pubKey);
            $cryptos .= $encryptDatas;
        }
        $context = base64_encode($cryptos);

        $privateKey = $this->_getPrivateKey($this->key);
        openssl_sign($cryptos, $sign, $privateKey, OPENSSL_ALGO_MD5);
        $sign = base64_encode($sign);

        return array('sign' => $sign,
            'context' => $context,
            'encryptType' => 'RSA',
        );
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }


    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == '0' && !empty($re['context'])) {
            $data_json = $this->decodeContext($re['context']);
            $data = json_decode($data_json, true);

            if ($data) {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->showType;
                $this->return['str'] = $data['code_url'];
            } else {
                $this->return['code'] = 886;
                $this->return['msg'] = '解析返回参数失败';
                $this->return['way'] = $this->showType;
            }
        } else {
            $msg = $re['msg'];
            $this->return['code'] = 886;
            $this->return['msg'] = 'CHENXIN2:' . $msg;
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    private function decodeContext($content)
    {
        $pi_key = $this->_getPrivateKey($this->key);
        $crypto = "";
        foreach (str_split($this->urlsafe_b64decode($content), 128) as $chunk) {
            openssl_private_decrypt($chunk, $decryptData, $pi_key);
            $crypto .= $decryptData;
        }
        return $crypto;
    }

    public function returnVerify($data)
    {

        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['orderNo']) || !isset($data['code']) || !isset($data['context'])) {
            $res['status'] = 0;
            $res['error'] = '非法数据';
            return $res;
        }

        $sign = $data['sign'];
        $successCode = $data['code'];
        $context = $data['context'];
        $orderNumber = $data['orderNo'];

        if ($successCode != 0) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($orderNumber);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        $this->pubKey = $config['pub_key'];
        $this->key = $config['key'];

        //解密
        $data_json = $this->decodeContext($context);
        $data = json_decode($data_json, true);

        if (!$data) {
            $res['status'] = 0;
            $res['error'] = '解密失败';
            return $res;
        }

        $res = [
            'status' => 0,
            'order_number' => $orderNumber,
            'third_order' => $data['businessNo'],
            'third_money' => $data['realAmount'],
            'error' => '',
        ];

        if ($data['orderState'] != 1) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $pubKey = $this->_getPublicKey();
        $flag = (bool)openssl_verify($this->urlsafe_b64decode($context), $this->urlsafe_b64decode($sign), $pubKey, OPENSSL_ALGO_MD5);//验证签名

        if (!$flag) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }
}
