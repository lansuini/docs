<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

/**
 * 第三方支付 - 金发支付
 */
class JINF extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'version' => '1.0',
            'mer_id' => $this->partnerID,
            'order_id' => $this->orderID,
            'price' => $this->money * 100,
            'notify_url' => $this->notifyUrl,
            'pay_type' => $this->payType,
            'randomid' => Utils::msectime()
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re && $re['code'] == '00') {
            $dataInfo = $re['data'];
            $data = json_decode($dataInfo, true);
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['qrcode_url'];
        } else {
            $msgS = str_replace("\\\\", "", $re['message']);//去除转义问题
            $this->return['code'] = 99;
            $this->return['msg'] = $this->unicodeDecode($msgS);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    function unicodeDecode($unicode_str)
    {
        $json = '{"str":"' . $unicode_str . '"}';
        $arr = json_decode($json, true);
        if (empty($arr)) return '';
        return $arr['str'];
    }


    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['order_id'],
            'third_order' => $data['pay_order'],
            'third_money' => $data['price'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['order_id']);

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        if (array_key_exists('s', $data)) {
            unset($data['s']);
        }
        unset($data['sign']);
        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string .= 'key=' . $key;
        $sign = strtolower(md5($string));
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {
        $piecesArr['pay_order'] = $pieces['pay_order'];
        $piecesArr['order_id'] = $pieces['order_id'];
        $piecesArr['price'] = $pieces['price'];
        $piecesArr['pay_type'] = $pieces['pay_type'];
        $piecesArr['code'] = $pieces['code'];
        $piecesArr['timestamp'] = $pieces['timestamp'];
        $sign = $this->_sign($piecesArr, $key);

        return $thirdSign == $sign;
    }
}