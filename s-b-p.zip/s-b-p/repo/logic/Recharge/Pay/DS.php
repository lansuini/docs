<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Curl;

/**
 * 第三方支付 - DS银联支付
 */
class DS extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->getPay();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'instId' => $this->data['app_id'],
            'mercId' => $this->partnerID,
            'mercOrderId' => $this->orderID,
            'txnDate' => date('Ymd'),
            'txnTime' => date('His'),
            'txnAmt' => $this->money * 100
        ];

        $str=$this->parameter['instId'].$this->parameter['mercId'].$this->parameter['mercOrderId'].$this->parameter['txnDate'].$this->parameter['txnTime'].$this->parameter['txnAmt'].$this->key;
        $this->parameter['md5value'] = strtoupper(md5($str));
        $this->parameter['notifyUrl'] = $this->notifyUrl;
        $this->parameter['productName'] = 'GOODS';
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re && $re['RSPCODE'] == '000000') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $urlParams = parse_url($re['RSPDATA']);
            if($urlParams['query']){
                $params = $this->convertUrlQuery($urlParams['query']);
                $query = '';
                foreach ($params as $k=>$param){
                    $query .= $k.'='.$param . '&';
                }
                $query = substr($query,0,strlen($query)-1);
                $url = $urlParams['scheme'] . '://' . $urlParams['host'];
                if($urlParams['port']){
                    $url = $url .':'.$urlParams['port'];
                }
                $url = $url .$urlParams['path'].'?'.$query;
            }else{
                $url = $re['RSPDATA'];
            }
            $this->return['str'] = $url;
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'DS银联:' . $re['RSPMSG'] ?? '未知异常';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }

    }

    public function convertUrlQuery($query)
    {
        $queryParts = explode('&', $query);
        $params = array();
        foreach ($queryParts as $param) {
            $item = explode('=', $param);
            $params[$item[0]] = $item[1];
        }
        return $params;
    }

    public function getPay()
    {
        $data_string = json_encode($this->parameter, JSON_UNESCAPED_UNICODE);
        $data_string = str_replace("\\/", "/", $data_string);//去除转义问题
        $this->payUrl .= '=' . $data_string;
        $this->re = CURL::get($this->payUrl, $this->cacertURL);
    }


    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['mercOrderId'],
            'third_order' => $data['logno'],
            'third_money' => $data['txnAmt'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['mercOrderId']);
        // var_dump($data);exit;
        if (strtolower($data['txnStatus']) != 's') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $sign = $data['md5value'];
        if (array_key_exists('s', $data)) {
            unset($data['s']);
        }
        unset($data['md5value']);

        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }


    /**
     * 验证sign
     */
    private function _verifySign($data, $key, $thirdSign)
    {

        $sign = strtoupper(md5($data['mercId']. $data['mercOrderId'].$data['txnDate'].$data['txnStatus'].$key));

        return $thirdSign == $sign;
    }
}