<?php
/**
 * 龙鑫支付
 * Created by Hans.
 * Date: 2019/6/1
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class LONGXZF extends BASES
{

    public function start()
    {
        $this->initParams();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        //参与签名字段及排序
        $pub_params = [
            'version' => '1.0',
            'customerid' => (string)$this->partnerID,
            'total_fee' => number_format($this->money, 2, '.', ''),
            'sdorderno' => $this->orderID,
            'notifyurl' => $this->notifyUrl,
            'returnurl' => $this->returnUrl,
        ];
        //生成签名
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);

        //以|分割 支付类型和支付模式
        if (strpos($this->payType, '|') == false) {
            //响应结果
            $pub_params['paytype'] = $this->payType;
        } else {
            $type_array = explode('|', $this->payType);
            $pay_type = $type_array[0];
            $pay_model = $type_array[1];

            //在线网银bank,微信扫码weixin,微信WAPwxh5,支付宝WAPali_dwap,支付宝扫码ali_dpc
            $pub_params['paytype'] = $pay_type;
            //1: 银行转账 2：支付宝转红包, 3:口令支付,4:钉钉 5：点点虫 6:旺信红包 8：撩呗红包 9:支付宝通码 默认 2 红包转账
            $pub_params['pay_model'] = $pay_model;
        }

        $this->parameter = $pub_params;
    }

    private function parseRE()
    {
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        //组装前端Form数据
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';


        //响应结果
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();

        if (!isset($parameters['postdata'])) {
            $res['status'] = 0;
            $res['error'] = '验签失败，缺少postdata内容';
            return $res;
        }

        $parameters = json_decode($parameters['postdata'], true);
        $order_number = $parameters['sdorderno'];
        $res = [
            'status' => 0,
            'order_number' => $order_number,
            'third_order' => $parameters['sdpayno'],
            'third_money' => $parameters['total_fee'],
        ];

        if ($parameters['status'] != 1) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        //支付结果成功，进行验签流程
        if (isset($parameters['s']))
            unset($parameters['s']);

        $config = Recharge::getThirdConfig($order_number);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }
        $return_money = $parameters['total_fee'];

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . '&' . $tkey;
        $sign = md5($sign_str);
        return strtolower($sign);
    }

    public function returnVail($params, $tkey)
    {
        //按签名规则排序数组
        $order_sign_params = [
            'customerid' => $params['customerid'],
            'status' => $params['status'],
            'sdpayno' => $params['sdpayno'],
            'sdorderno' => $params['sdorderno'],
            'total_fee' => $params['total_fee'],
            'paytype' => $params['paytype']
        ];
        $return_sign = $params['sign'];
        $sign = $this->_sign($order_sign_params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }

}