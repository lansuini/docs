<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 客付通支付
 */

class KFT extends BASES
{
    protected $param;

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        date_default_timezone_set('Asia/Shanghai');
        $str=explode('_',$this->data['bank_data']);
        $this->param = [
            'funCode' => $str[0],
            'platMerId' => $this->partnerID,
            'amt' => $this->money*100,
            'tradeTime' => time(),
            'platOrderId' => $this->orderID,
            'notifyUrl' => $this->notifyUrl,
            'body' => 'GOODS',
            'payMethod' => $str[1],
            'subject' => 'GOODS',
            'funName' => '',
            'orderTime' => '',
        ];
        $this->param['sign'] = $this->_sign($this->param,$this->key);
        $this->parameter['reqJson']=json_encode($this->param,JSON_UNESCAPED_UNICODE);
    }


    public function parseRE()
    {
//print_r($this->re);exit;
        $result = json_decode($this->re,true);
        if ($result['retCode'] && $result['retCode'] =="0000") {
            $this->return['code'] = 0;
            $this->return['msg']  = 'success';
            $this->return['way']  = $this->data['return_type'];;
            $this->return['str']  = $result['codeUrl'];
        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = 'KFT: ' . $result['retMsg'];
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['platOrderId'],
            'third_order'  => $parameters['outTradeNo'],
            'third_money'  => $parameters['orderAmt']/100,
            'error' => '',
        ];

        if ($parameters['tradeState']!='TRADE_SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['platOrderId']);
        if (!$config) {
            $res['status'] = 0;
            $res['error']  = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $parameters['sign'],$config['key']);
        if ($result) {
            $this->updateMoney($res['order_number'],$res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$key)
    {
        ksort($pieces);
        $string = '';
        foreach($pieces as $k => $v) {
            //  字符串0  和 0 全过滤了，所以加上
            if(!empty($v) || $v === 0  || $v === "0" ) {
                $string .= $k . "=" . $v . "&";
            }
        }
        $string = $string.'key='.$key;
        //var_dump($string);exit;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$re_sign,$key)
    {
        unset($params['sign']);
        $sign = $this->_sign($params,$key);
        if ($sign == $re_sign){
                return true;
        }
        return false;
    }
}