<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 稻田支付
 */
class DAOTIANPAY extends BASES
{

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();       // 数据初始化
        $this->basePost();        // POST请求
        $this->parseRE();         // 处理结果
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //组装数组
    public function initParam()
    {

        $this->parameter['fxid'] = $this->partnerID;           //商务号
        $this->parameter['fxddh'] = $this->orderID;             //商户订单号
        $this->parameter['fxdesc'] = time();                     //商品名称
        $this->parameter['fxfee'] = $this->money;           //支付金额
        $this->parameter['fxattch'] = $this->data['bank_data'];   //附加信息
        $this->parameter['fxnotifyurl'] = $this->notifyUrl;           //异步通知地址
        $this->parameter['fxbackurl'] = $this->returnUrl;           //同步通知地址
        $this->parameter['fxpay'] = $this->data['bank_data'];   //请求类型 【支付宝wap：zfbwap】
        $this->parameter['fxsign'] = $this->sign();              //签名
        $this->parameter['fxip'] = $this->clientIp;      //支付用户IP地址
    }

    //生成签名  【md5(商务号+商户订单号+支付金额+异步通知地址+商户秘钥)】
    public function sign()
    {
        $str = $this->partnerID . $this->orderID . $this->money . $this->notifyUrl . $this->key;
        return md5($str);

    }

    //处理结果
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['status']) && $re['status'] == 1) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $content = $re['payurl'];
            if ($this->showType == 'sdk' && !empty($re['sdk_url'])) {
                $content = $re['sdk_url'];
                if (!strpos($content, "&")) {//没有字符串&分隔符号，说明必须解码一次
                    $content = urldecode($content);
                }
            }
            $this->return['str'] = $content;
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'DAOTIANPAY:' . $re['error'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }

    }

    //回调数据校验
    /*
     * 签名【md5(订单状态+商务号+商户订单号+支付金额+商户秘钥)】
     * */
    public function returnVerify($parameters = array())
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if ($parameters['fxstatus'] != 1) {
            $res['status'] = 0;
            $res['error'] = "等待订单支付成功";
            return $res;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['fxddh'],
            'third_order' => $parameters['fxorder'] ?? '',
            'third_money' => $parameters['fxfee'],
            'error' => ''
        ];

        $config = Recharge::getThirdConfig($parameters['fxddh']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        // 签名
        $str = $parameters['fxstatus'] . $parameters['fxid'] . $parameters['fxddh'] . $parameters['fxfee'] . $config['key'];
        $sign = strtolower(md5($str));
        $tenpaySign = strtolower($parameters['fxsign']);

        // 延签
        if ($sign != $tenpaySign) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        $order_number = $parameters['fxddh'];
        $return_money = $parameters['fxfee'];

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

}
