<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 *
 * 豪支付
 */
class HAOPAY extends BASES
{

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }

        return $money_real[$index];
    }

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            // 回调中没有返回支付金额参数，如果是PDD方式的金额有不等映射，先进行金额修改
            if ($this->money != $request_money) {
                \DB::table('order')->where('order_number', $this->orderID)->update(['order_money' => (int)$request_money]);
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $version = "2.0"; //版本号
        $action = "SdkQuickQrPay"; //接口
        $orgNo = $this->data['app_id']; //机构号
        $merNo = $this->partnerID;//商户ID
        $key = $this->key;//密钥

        //参与签名字段
        $data = [
            'orderType' => "10",
            'amount' => $this->money * 100,
            'linkId' => $this->orderID,
            'payType' => $this->payType, //支付类型
            'notifyUrl' => $this->notifyUrl,
            'pageUrl' => $this->notifyUrl,
            'goodsName' => "GOODS",
        ];

        $aesKey = $this->data['token']; //AesKey
        $aesData = $this->encrypt(json_encode($data, JSON_UNESCAPED_SLASHES), $aesKey);
        $aesData = strtoupper($aesData);
        $pv = $this->privEncrypt($aesKey);

        $signData = $version . $orgNo . $merNo . $action . $aesData . $key;
        $sign = md5($signData);


        unset($data);
        $data = [
            'version' => $version,
            'merNo' => $merNo,
            'orgNo' => $orgNo,
            'action' => $action,
            'data' => $aesData,
            'encryptkey' => $pv,
            'sign' => $sign,
        ];

        $this->parameter = $data;
    }


    public static function encrypt($input, $key)
    {
        $blockSize = @mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB);
        $paddedData = static::pkcs5_pad($input, $blockSize);
        $ivSize = @mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB);
        $iv = @mcrypt_create_iv($ivSize, MCRYPT_RAND);
        $encrypted = @mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $paddedData, MCRYPT_MODE_ECB, $iv);
        return bin2hex($encrypted);
    }

    public static function decrypt($sStr, $key)
    {
        $decrypted = @mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, hex2bin($sStr), MCRYPT_MODE_ECB);
        $dec_s = strlen($decrypted);
        $padding = ord($decrypted[$dec_s - 1]);
        $decrypted = substr($decrypted, 0, -$padding);
        return $decrypted;
    }

    private static function pkcs5_pad($text, $blocksize)
    {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    /**
     * 私钥加密
     * @param string $data
     * @return null|string
     */
    public function privEncrypt($data = '')
    {
        if (!is_string($data)) {
            return null;
        }

        return openssl_private_encrypt($data, $encrypted, $this->_getPrivateKey($this->pubKey)) ? base64_encode($encrypted) : null;
    }

    /**
     * 私钥解密
     * @param string $encrypted
     * @return null
     */
    public function privDecrypt($encrypted = '')
    {
        if (!is_string($encrypted)) {
            return null;
        }
        return (openssl_private_decrypt(base64_decode($encrypted), $decrypted, $this->_getPrivateKey($this->pubKey))) ? $decrypted : null;
    }


    public function parseRE()
    {
        $re = json_decode($this->re, true);
        $data = $re['data'];
        $encryptkey = $re['encryptkey'];
        $akey = $this->privDecrypt($encryptkey);
        $resq = json_decode($this->decrypt($data, $akey), true);
        if (isset($re['data']) && $resq['code'] == "0100") {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $resq['qr_code'];
            if ($this->return['way'] == 'code')
            {
                $this->return['str'] =  $this->jumpURL.'?method=HTML&html='.urlencode(base64_encode($resq['qr_code']));
            }
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '豪支付：' . (isset($re['data']) ? $resq['msg'] : '第三方下单失败');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['linkId'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $data['linkId'],
            'third_order' => $data['orderNo'],
            'third_money' => "",
            'error' => '',
        ];

        if ($data['orderStatus'] != "0000") {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        // 回调中没有返回支付金额参数，从config中查询的金额填入
        $res['third_money'] = $config['order_money'];
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    private function _verifySign($data, $key)
    {
        $oldSign = $data['sign'];
        unset($data['sign']);
        $newSign = $data['orderNo'] . $data['orderStatus'] . $key;
        return $oldSign == md5($newSign);
    }

}