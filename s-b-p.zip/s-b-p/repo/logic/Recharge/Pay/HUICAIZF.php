<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Psr\Http\Message\ServerRequestInterface;

/**
 * 汇才支付
 */
class HUICAIZF extends BASES
{
    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //初始化参数
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            'merchant' => $this->partnerID,
            'paymentType' => $this->payType,
            'callback' => $this->notifyUrl,
            'username' => $this->uid,
            'paymentReference' => $this->orderID,
            'amount' => sprintf("%.2f", $this->money),
        );
        $this->parameter['sign'] = $this->sytMd5New($this->parameter, $this->key);
    }

    public function sytMd5New($pieces, $key)
    {
        unset($pieces['sign']);
        ksort($pieces);
        $string = '';
        foreach ($pieces as $keys => $value) {
            if ($value != '' && $value != null) {
                $string .= $keys . '=' . $value . '&';
            }
        }
        $string = rtrim($string, '&') . '&key=' . $key;
        $sign = md5($string);
        return strtoupper($sign);
    }

    //返回参数
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        $data = $re['data'];
        if (isset($re['success']) && $re['success'] == true) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $data['redirect'];
        } else {
            $this->return['code'] = 39;
            $this->return['msg'] = 'HUADONGZF:' . (isset($re['message']) ? $re['message'] : '未知错误');
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    //签名验证
    public function returnVerify($pieces)
    {

        if (!isset($pieces['paymentReference'])) {
            $res['status'] = 0;
            $res['error'] = '非法数据';
            print_r('ss');exit;
            return $res;
        }

        $res = [
            'status' => 0,
            'order_number' => $pieces['paymentReference'],
            'third_order' => $pieces['reference'],
            'third_money' => $pieces['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($pieces['paymentReference']);
        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($pieces['success'] != true) {
            $res['error'] = '失败！';
            return $res;
        }

        if (!self::retrunVail($pieces['sign'], $pieces, $config)) {
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    public function retrunVail($sign, $pieces, $config)
    {
        unset($pieces['sign']);
        return $sign == $this->sytMd5New($pieces, $config['key']);
    }


}