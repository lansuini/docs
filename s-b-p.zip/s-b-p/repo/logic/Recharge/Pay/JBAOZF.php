<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 金bao支付
 */
class JBAOZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        //参与签名字段
        $data = [
            'appid' => $this->partnerID,
            'pay_type' => $this->payType,
            'amount' => sprintf('%.2f',$this->money),
            'callback_url' => $this->notifyUrl,
            'success_url' => $this->returnUrl,
            'error_url' => $this->returnUrl,
            'out_trade_no' => $this->orderID,
            'out_uid' => $this->uid,
        ];

        //不参与签名字段
        $pub_params = [
            'sign' => $this->getSign($data, $this->key)
        ];
        $this->parameter = array_merge($data, $pub_params);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        // 去空
        $data = array_filter($pieces);
        //签名步骤一：按字典序排序参数
        ksort($data);
        $string_a = http_build_query($data);
        $string_a = urldecode($string_a);
        //签名步骤二：在string后加入KEY
        $string_sign_temp = $string_a . "&key=" . $api_key;
        //签名步骤三：MD5加密
        $sign = md5($string_sign_temp);
        // 签名步骤四：所有字符转为大写
        $result = strtoupper($sign);

        return $result;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 200) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['qrcode'];
            if ($this->payType == 'code') {
                $this->return['str'] = $this->qrcodeUrl . $re['data']['qrcode'];
            }
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '金宝支付：' . (isset($re['msg']) ? $re['msg'] : (isset($this->re) ? $this->re : '请求失败，检查下单域名是否正确'));
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['out_trade_no']) || !isset($data['out_trade_no']) || !isset($data['amount'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['out_trade_no'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        if ($data['callbacks'] != 'CODE_SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/index/getorder';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '4') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['key']);
        return $sign == $signOld;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "appid" => $partnerID,
            "out_trade_no" => $orderNumber,
        ];
        $params['sign'] = $this->getSign($params, $tkey);
        $this->payUrl = $queryUrl;
        $this->parameter = $params;
        $this->logCurlFunc($orderNumber, $this->post());
        $re = json_decode($this->re);
        if (isset($re['data']['status'])) {
            return $re['data']['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }


}