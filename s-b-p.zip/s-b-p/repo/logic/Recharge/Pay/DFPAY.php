<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 东方闪付支付
 */
class DFPAY extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }
    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }
    //初始化参数
    public function initParam()
    {
        $parameter = [
            'parter' => $this->partnerID,
            'type' => (string)$this->payType,
            'value' => sprintf("%.2f", $this->money),
            'orderid' => (string)$this->orderID,
            'callbackurl' => $this->notifyUrl,
        ];
        //秘钥存入
        $parameter['sign'] = $this->_sign($parameter, $this->key);
        $this->parameter = $parameter;
    }


    //返回参数
    public function parseRE()
    {
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' . $this->arrayToURL();
    }

    //签名验证
    public function returnVerify($result)
    {

        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);
        $res = [
            'status' => 0,
            'order_number' => $result['orderid'],
            'third_order' => $result['sysorderid'],
            'third_money' => $result['ovalue'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($result['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if (!isset($result['opstate']) || $result['opstate'] != 0){
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }
        $signResult = $this->returnVail($result, $config['key']);
        if (!$signResult) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $string = 'orderid='.$params['orderid'].'&opstate='.$params['opstate'].'&ovalue='.$params['ovalue'].$tkey;
        $sign = md5($string);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        $string = "";
        foreach ($params as $key=>$val)
        {
            $string = $string?$string."&".$key."=".$val:$key."=".$val;
        }
        $string = $string.$tKey;

        $sign = md5($string);
        return $sign;
    }
}