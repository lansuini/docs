<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 人人付
 * @author lavenkin
 */
class JLZF extends BASES
{

    //与第三方交互
    public function start()
    {

        $this->initParam();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = [
            'goods' => 'GOODS',
            'notify_url' => $this->notifyUrl,
            'param' => $this->orderID,
            'price' => $this->money,
            'return_url' => $this->returnUrl,
            'seller' => $this->partnerID,
            'type' => $this->payType,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['sign_type'] = "MD5";
    }

    private function _sign($pieces, $tkey)
    {
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($key != 'sign') {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);

        $sign_str = $params . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    public function parseRE()
    {
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' . $this->arrayToURL();
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);


        $res = [
            'status' => 0,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['trade_no'],
            'third_money' => $data['money'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }


        if ($data['trade_status'] != 'TRADE_SUCCESS') {
            $res['error'] = '未支付';
            return $res;
        }


        $tmp = [
            'money' => $data['money'],
            'name' => $data['name'],
            'out_trade_no' => $data['out_trade_no'],
            'pid' => $data['pid'],
            'trade_no' => $data['trade_no'],
            'trade_status' => $data['trade_status'],
            'type' => $data['type']
        ];

        if ($data['sign'] != $this->_sign($tmp, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
