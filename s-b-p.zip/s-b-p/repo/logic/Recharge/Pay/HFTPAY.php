<?php
/**
 * 恒丰泰支付
 * @author Taylor 2019-04-23
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HFTPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'version' =>'2',//版本号
            'merchant_number' => $this->partnerID,//商户号
            'cash' => sprintf("%.2f", $this->money),//充值金额，以元为单位
            'server_url'=>$this->notifyUrl,//异步通知
            'brower_url' => $this->returnUrl,//页面回调
            'order_id' => $this->orderID,//订单号
            'order_time' => time(),//订单时间
            'pay_type' => $this->payType,//支付类型，查看商户后台，支付通道--类型--值: 1.支付宝扫码;2.支付宝H5;3.微信扫码;4.微信H5; 5.银联扫码;6.网关;7.快捷;8.固码
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;
    }

    public function _httpPost($referer = null){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->payUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, '123');
        if(is_array($this->parameter)){
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($this->parameter));
        }else{
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->parameter);
        }
        if($referer)
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->curlError = curl_error($ch);
        $this->re = $response;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE(){
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        if(isset($data['s'])){
            unset($data['s']);
        }
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['order_id'],//商户订单号
            'third_order' => $data['order_id'],//系统订单号
            'third_money' => $data['cash'],//支付金额，以元为单位
            'error' => '',
        ];

        if ($data['status'] != '2') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key=>$val)
        {
            $string = $string ? $string.'&'.$key.'='.$val : $key.'='.$val;
        }
        $string .= '&key='.$tkey;
        $sign = md5($string);
        return strtolower($sign);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}