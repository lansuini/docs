<?php
/**
 * 长城云
 * @author Taylor 2019-04-30
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class CCYUN extends BASES {

    //与第三方交互
    public function start(){
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam(){
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            //基本参数
            'app_id' => $this->partnerID,//商户号
            'order_no' => $this->orderID,//商户订单号
            'pay_amt' => number_format($this->money,2,'.',''),//订单金额为元，精确到小数点后两位
            'pay_cur' => 'CNY',//支付货币
            'goods_name' => 'VIP'.$this->orderID,//商品名称
            'goods_num' => rand(1, 9),//商品数量
            'goods_cat' => 'etc',//商品种类
            'goods_desc' => 'shop etc',//商品描述
            'return_url' => $this->returnUrl,//同步通知URL
            'notify_url' => $this->notifyUrl,//异步通知URL
            'user_id' => $this->uid,//用户在平台的用户id
            'username' => $this->uid,//用户在平台的用户名
            'pay_type' => $this->payType,//支付类型
            'ts' => time(),//unix格式时间戳
        );
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 生成sign
     */
    private function _sign($p, $tkey)
    {
        $sign = md5("app_id={$p['app_id']}notify_url={$p['notify_url']}order_no={$p['order_no']}pay_amt={$p['pay_amt']}pay_cur={$p['pay_cur']}pay_type={$p['pay_type']}return_url={$p['return_url']}{$p['ts']}{$tkey}");//MD5加密串
        return $sign;
    }

    public function parseRE(){
        //使用表单提交的方式
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 返回地址验证
     * [status=1 通过  0不通过,
     * order_number = '订单',
     * third_order = 第三方订单,
     * third_money ='金额',
     * error'='未有该订单/订单未支付/未有该订单']
     * @param
     * @return boolean
     */
    public function returnVerify($data) {
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['order_no'],//商户订单号
            'third_order' => $data['order_no'],//系统订单号
            'third_money' => $data['pay_actual_amt'],//支付金额
            'error' => '',
        ];

        if ($data['is_success'] != 1) {//1：成功，0：失败
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($p, $tkey)
    {
        $sign = md5("app_id={$p['app_id']}is_success={$p['is_success']}order_no={$p['order_no']}pay_actual_amt={$p['pay_actual_amt']}{$p['ts']}{$tkey}");
        if ($sign == $p['sign']){
            return true;
        }
        return false;
    }
}
