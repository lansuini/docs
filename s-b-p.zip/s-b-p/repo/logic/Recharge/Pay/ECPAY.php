<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * ECPAY
 * @author lavenkin
 */
class ECPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->parameter = [
            'merchantNo' => $this->partnerID,
            'tradeType' => $this->payType,
            'timeStamp' => time(),
            'orderNo' => $this->orderID,
            'amount' => $this->money,
            'tradeDesc' => 'vip',
            'notifyUrl' => $this->notifyUrl,
            'mark' => 'GOODS',
        ];

        $this->parameter['sign'] = $this->getSign($this->parameter, $this->key);
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $key . $val;
        }
        $string = base64_encode($string) . $api_key;
        $sign = md5($string);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['code'] == '1') {
            $this->return['code'] = 0;
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];

            if (starts_with($re['jumpUrl'], "http")) {
                $this->return['str'] = $re['jumpUrl'];
            } else {
                $this->return['str'] = $this->jumpURL . '?method=HTML&html=' . urlencode(base64_encode($re['jumpUrl']));
            }
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'ECPAY：' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        if (!isset($data['outTradeNo']) || !isset($data['tradeNo']) || !isset($data['amount'])) {
            return false;
        }
        unset($data['s']);
        $res = [
            'status' => 1,
            'order_number' => $data['outTradeNo'],
            'third_order' => $data['tradeNo'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        if ($data['tradeStatus'] != 2) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($data['outTradeNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['key']);
        return $sign == $signOld;
    }


}