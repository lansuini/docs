<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;


/**
 * KG支付
 * @author david
 */


class KGZF extends BASES {
    //与第三方交互
    public function start(){
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }
    //组装数组
    public function initParam(){

/*        $this->notifyUrl = str_replace("\\",'/',$this->notifyUrl);
        $this->notifyUrl = str_replace("//",'/',$this->notifyUrl);*/
        $this->parameter = array(
            'HashKey'=> $this->key,
            'HashIV' => $this->pubKey,
            'MerTradeID' => $this->orderID,
            'MerProductID' => 'goodskg00001',
            'MerUserID' => 'userkg',
            'Amount' => number_format((int) $this->money,2,'.',''),
            'TradeDesc' => 'ItemDesc',
            'ItemName' => 'ItemName',
            'USER_CLIENT_IP' => '103.196.124.252',
            //'Validate' => 'RSA',
            'NotifyUrl' => $this->notifyUrl,
            "ReturnQRCode"    => "1"
        );
        $this->parameter['Validate'] = md5($this->partnerID.$this->key.$this->parameter['MerTradeID'].$this->parameter['MerProductID'].$this->parameter['MerUserID'].$this->parameter['Amount']);
    }

    public function parseRE(){
        $re = json_decode($this->re,true);
        if($re['retcode'] == 1){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['QRCodeURL'];
        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = 'KGZF:'.$this->re ;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }
    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($input) {
        //RechargeLog::addLogByTxt(['log_321' => '', 'desc' =>$input], 'log_callback_new');
        // var_dump($input);exit;
        $res = [
            'status' => 1,
            'order_number' => $input['MerTradeID'],
            'third_order' => $input['MerTradeID'],
            'third_money' => $input['Amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($input['MerTradeID']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        $ValidateStr = "ValidateKey=". $config['partner_id']. "&HashKey=". $config['key']. "&RtnCode=". $_POST["RtnCode"]. "&TradeID=". $_POST["MerTradeID"]."&UserID=". $_POST["MerUserID"]."&Money=". $_POST["Amount"];
        $Validate = md5($ValidateStr);
        if($input["Validate"]!=$Validate){
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        if ($input['RtnCode'] != 1) {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        // var_dump($res);exit;
        return $res;

    }
}
