<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 捷支付
 */
class JPAY extends BASES
{
    const CHAR_SET = "UTF-8";
    const RSA_ALGORITHM_KEY_TYPE = OPENSSL_KEYTYPE_RSA;
    const RSA_ALGORITHM_SIGN = OPENSSL_ALGO_MD5;

    protected $public_key;
    protected $private_key;
    protected $key_len;

    /**
     * 生命周期
     */
    public function start()
    {
        $this->construct($this->key,$this->pubKey);
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $newOrderReq['userOrderId']= $this->orderID;
        $newOrderReq['productName']='GOODS';
        $newOrderReq['money']= $this->money * 100;
        $newOrderReq['time']= $this->getMillisecond();
        $newOrderReq['type']= $this->payType;
        $newOrderReq['notifyUrl']= $this->notifyUrl;


        $newOrderJsonData = json_encode($newOrderReq);
        $newOrderEncryptData = $this->publicEncrypt($newOrderJsonData);
        $this->parameter['userName'] = $this->partnerID;
        $this->parameter['data']     = $newOrderEncryptData;

    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);

        if ($re['code'] != 'success') {
            $this->return['code'] = 23;
            $this->return['msg'] = '捷支付：' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS:' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['order']['payUrl'];
        }
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $orderInfo=$data['orderInfo'];
        $sign=$data['sign'];

        $orderJson=base64_decode($orderInfo);
        $data=json_decode($orderJson, true);


        if(!isset($data['userOrderId'])){
            $res['status'] = 0;
            $res['error'] = "非法数据";
            return $res;
        }

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['userOrderId'],//商户订单号
            'third_order' => $data['userUid'],     // 交易号
            'third_money' => $data['money'] / 100, //实际支付金额，以fen为单位
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($data['userOrderId']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if ($data['status'] != 5) {
            $res['error'] = '未支付';
            $res['status'] = 0;
            return $res;
        }

        ksort($data);
        $signStr = "";
        $flag=0;
        foreach ($data as $key => $val) {
            if($val===""){
                continue;
            }
            if($flag===1){
                $signStr = $signStr."&";
            }
            $signStr = $signStr.$key."=".$val;
            $flag=1;
        }

        if (!$this->verify($signStr, $sign,$config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }


    public function construct($pub_key, $pri_key = null)
    {

        $this->public_key = $this->format_secret_key($pub_key,'pub');
        $this->private_key = $this->format_secret_key($pri_key,'pri');

        $pub_id = openssl_get_publickey($this->public_key);
        $this->key_len = openssl_pkey_get_details($pub_id)['bits'];
    }


    public function format_secret_key($secret_key, $type){
        //64个英文字符后接换行符"\n",最后再接换行符"\n"
        $key = (wordwrap($secret_key, 64, "\n", true))."\n";
        //添加pem格式头和尾
        if ($type == 'pub') {
            $pem_key = "-----BEGIN PUBLIC KEY-----\n" . $key . "-----END PUBLIC KEY-----\n";
        }else if ($type == 'pri') {
            $pem_key = "-----BEGIN RSA PRIVATE KEY-----\n" . $key . "-----END RSA PRIVATE KEY-----\n";
        }else{
            echo('公私钥类型非法');
            exit();
        }
        return $pem_key;
    }

    /*
 * 公钥加密
 */
    public function publicEncrypt($data)
    {
        $encrypted = '';
        $part_len = $this->key_len / 8 - 11;
        $parts = str_split($data, $part_len);

        foreach ($parts as $part) {
            $encrypted_temp = '';
            openssl_public_encrypt($part, $encrypted_temp, $this->public_key,OPENSSL_PKCS1_PADDING);
            $encrypted .= $encrypted_temp;
        }
        return base64_encode($encrypted);
    }

    /*
      * 数据签名验证
      */
    public function verify($data, $sign,$key)
    {

        $key = $this->format_secret_key($key,'pub');

        $signature = base64_decode($sign);

        $pub_id = openssl_get_publickey($key);

        $result = openssl_verify($data, $signature, $pub_id, self::RSA_ALGORITHM_SIGN);//openssl_verify 验签成功返回 1，失败 0，错误返回 -1

        return $result;
    }

    function getMillisecond() {
        list($s1, $s2) = explode(' ', microtime());
        return (float)sprintf('%.0f', (floatval($s1) + floatval($s2)) * 1000);
    }
}