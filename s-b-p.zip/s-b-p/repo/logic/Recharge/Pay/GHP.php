<?php
/**
 * 广汇支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/1
 * Time: 9:37
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;


class GHP extends BASES {

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        date_default_timezone_set('Asia/Shanghai');
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/return_url.php';
        $this->parameter = [
            'requestId'     =>  $this->orderID.mt_rand(11111,99999),
            'orgId'         =>  $this->data['app_id'],
            'productId'     =>  '0100',
            'timestamp'     =>  date('YmdHis',time()),
        ];
        $busMap=array(
            'merno'         =>  $this->partnerID,
            'bus_no'        =>  $this->payType,
            'amount'        =>  (string)($this->money*100),//交易金额-单位分
            'goods_info'    =>  $this->orderID,
            'order_id'      =>  $this->orderID,
            'return_url'    =>  $this->returnUrl,
            'notify_url'    =>  $this->notifyUrl,
        );
        $this->parameter['businessData']=json_encode($busMap);
        $this->parameter['signData'] = $this->_sign($this->parameter,$this->key);
        //var_dump($this->parameter);exit();
    }

    public function parseRE()
    {
        $re = json_decode($this->re,true);
        //var_dump($re);exit;
        if ($re['respCode'] == "00" && $re['key']=="05") {
            $url = json_decode($re['result'],true);
            $this->return['code'] = 00;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $result = json_decode($re['result']);
            $this->return['str'] = $result['url'];
        } else {
            $this->return['code'] = $re['key'];
            $this->return['msg'] = 'GHP：' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
        //var_dump($this->return);exit;
    }

    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['order_id'],
            'third_order' => $parameters['plat_order_id'],
            'third_money' => $parameters['amount']/100,
        ];
        $config = Recharge::getThirdConfig($parameters['order_id']);

        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        // var_dump($config);exit;
        //校验sign
        $result = $this->_verifySign($parameters,$config['key']);
        if ($result) {
            $res['status'] = 1;
        }else{
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }

        return $res;
    }

    /**
     * 生成签名
     */
    private function _sign($params,$tkey)
    {
        ksort($params);
        $string='';
        foreach ($params as $key=>$val)
        {
            if ($val){
                $string = $string?$string.'&'.$key.'='.$val:$key.'='.$val;
            }
        }
        $string .= $tkey;
        $sign = md5($string);
        return $sign;
    }

    /**
     * 验证签名
     */
    private function _verifySign($params,$key)
    {
        $return_sign = $params['sign_data'];
        unset($params['sign_data']);
        $sign = $this->_sign($params,$key);
        if ($sign == $return_sign){
            return true;
        }
        return false;
    }

}