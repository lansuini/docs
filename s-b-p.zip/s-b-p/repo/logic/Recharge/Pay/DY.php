<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/19
 * Time: 10:09
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

class DY extends BASES
{
    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = [
            //基本参数
            'service' => $this->data['bank_data'],
            'mch_id' => $this->partnerID,
            'out_trade_no' => $this->orderID,
            'goods_desc' => 'goods',
            'total_fee' => $this->money * 100,
            'fee_type' => 'CNY',
            'mch_create_ip' => Client::getClientIp(),
            'notify_url' => $this->notifyUrl,
            'nonce_str' => time(),
        ];
        $this->parameter['sign'] = $this->sytMd5($this->parameter);
        $this->parameter = $this->toXml($this->parameter);
    }

    public function sytMd5($pieces)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $keys => $value) {
            if ($value != '' && $value != null) {
                $string = $string . $keys . '=' . $value . '&';
            }
        }

        $string = $string . 'key=' . $this->key;

        $sign = strtoupper(md5($string));

        return $sign;
    }


    //返回参数
    public function parseRE()
    {

        //扫码支付
        if ($this->showType == 'code') {

            $re = $this->parseXML($this->re);

            if ($re['result_code'] != 0) {
                $this->return['code'] = $re['retCode'] ?? 5;
                $this->return['msg'] = 'dy:' . $re['result_msg'];
                $this->return['way'] = $this->showType;
                $this->return['str'] = '';

                return;
            }

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['code_url'];

            return;
        }

        //WAP支付
        if ($this->showType == 'jump') {

            $result = $this->re;
//            var_dump($result);
//            die;
            $resultXML = $this->parseXML($this->re);

            if (!($form = preg_match('/form/', $result)) && (!$resultXML || $resultXML['err_code'] != 0)) {
                $this->return['code'] = 23;
                $this->return['msg'] = 'DY：支付错误，请联系客服。';
                $this->return['way'] = $this->showType;
                $this->return['str'] = null;

                return;
            }

            if ($form) {
                preg_match('/method=\'([^\']+)\'/', $result, $method);
                preg_match('/action=\'([^\']+)\'/', $result, $url);
                preg_match_all('/<input type=\'hidden\' name=\'([^\']+)\' value=\'([^\']+)\'\/>/', $result, $matches);

                $method = strtoupper($method[1]);
                $url = $url[1];
                $data = [];
                foreach ($matches[1] as $index => $match) {
                    $data[$match] = $matches[2][$index];
                }

                $this->parameter = $data;
                $this->parameter = $this->arrayToURL();


                if ($method == 'GET') {
                    $this->jumpURL = $url;
                } else if ($method == 'POST') {
                    $this->parameter .= '&url=' . $url;
                    $this->parameter .= '&method=POST';
                }

                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->showType;
                $this->return['str'] = $this->jumpURL . '&' . $this->parameter;
            } else {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->showType;
                $this->return['str'] = $resultXML['code_url'];
            }
        }
    }

    //签名验证
    public function returnVerify($pieces)
    {
        $res = [
            'status' => 1,
            'order_number' => $pieces['out_trade_no'],
            'third_order' => '',
            'third_money' => 0,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($pieces['out_trade_no']);
        if(!$config){
            $res['status']=0;
            $res['error']='订单不存在';
        }
        //result_code
        if(!self::returnVail($pieces,$config)){
            $res['status']=0;
            $res['error']='验签失败！';
        }else{
            $res['status']=1;
        }

    }

    public function returnVail($pieces,$config){
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $value) {
            if ($value != '' && $value != null && $key != 'sign') {
                $string = $string . $key . '=' . $value . '&';
            }
        }
        $string = $string . 'key=' . $config['pub_key'];

        $mySign = strtoupper(md5($string));

        return trim($pieces['sign']) == $mySign;
    }
}