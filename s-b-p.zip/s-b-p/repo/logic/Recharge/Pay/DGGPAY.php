<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 顶呱呱
 */
class DGGPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $sign_data = [
            'Amount' => $this->money * 100,
            'MerId' => $this->partnerID,
            'MerOrderNo' => $this->orderID,
            'MerOrderTime' => date("YmdHis"),
        ];
        $data = [
            'PayType' => $this->payType, //支付类型 alipay:支付宝； alipay_sm:支付宝扫码； wxpay:微信支付； wxpay_sm:微信扫码； qqpay:QQ钱包； jdpay:京东钱包； uppay：银联云闪付； quick：银联快捷
            'NotifyUrl' => $this->notifyUrl,
            'Version' => "2.1",
        ];

        $data['Sign'] = $this->getSign($sign_data, $this->key);
        $this->parameter = array_merge($sign_data, $data);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $val . '|';
        }
        $string .= $api_key;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['data']) && $re['code'] == 'success') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $url = $this->data['return_type'] == 'code' ? $re['data']['QrcodeUrl'] : $re['data']['PayUrl'];
            $this->return['str'] = $url;
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'DGGPAY：' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['MerOrderNo']) || !isset($data['PayOrderNo']) || !isset($data['AmountReal'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['MerOrderNo'],
            'third_order' => $data['PayOrderNo'],
            'third_money' => $data['AmountReal'] / 100,
            'error' => '',
        ];

        if ($data['PayStatus'] != 'success') {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['Sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['Sign']);
        $sign_data = [
            'Amount' => $data['Amount'],
            'AmountReal' => $data['AmountReal'],
            'Fee' => $data['Fee'],
            'MerId' => $data['MerId'],
            'MerOrderNo' => $data['MerOrderNo'],
            'MerOrderTime' => $data['MerOrderTime'],
            'PayStatus' => $data['PayStatus'],
            'BalanceTime' => $data['BalanceTime'],
        ];
        $sign = $this->getSign($sign_data, $config['key']);
        return $sign == $signOld;
    }


}