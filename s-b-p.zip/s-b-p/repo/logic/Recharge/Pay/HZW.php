<?php
/**
 * 海贼王支付
 * Date: 2019/6/1
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;

class HZW extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->basePost();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'pay_memberid' => (string)$this->partnerID,
            'pay_orderid' => (string)$this->orderID,
            'pay_applydate' => date('Y-m-d H:i:s', time()),
            'pay_bankcode' => (string)$this->payType, //bank_data
            'pay_notifyurl' => $this->notifyUrl,
            'pay_callbackurl' => $this->returnUrl,
            'pay_amount' => $this->money,
        ];
        $pub_params['pay_md5sign'] = $this->_sign($pub_params, $this->key);
        $pub_params['pay_productname'] = 'Goods';
        $this->parameter = $pub_params;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
//        //使用redis保存信息的跳转页面
//        $this->buildGoOrderUrl();
//        $this->return['code'] = 0;
//        $this->return['msg'] = 'SUCCESS';
//        $this->return['way'] = $this->showType;
//        $this->return['str'] = $this->goPayUrl;
        $re = json_decode($this->re, true);
        if (!empty($re['data']) && $re['code'] == '200') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            //type=sdk data返回sdk串，type=form data返回html表单， 没有type参数data返回就是url。
            if ($re['type'] == 'form') {
                $this->return['str'] = $this->jumpURL . '?method=HTML&html=' . base64_encode($re['data']);
            } else {
                $this->return['str'] = $re['data'];
            }
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'HZW：' . (!empty($re['data']) && is_string($re['data']) ? $re['data'] : (!empty($re['msg']) ? $re['msg'] : $this->re));
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderid']) || !isset($parameters['transaction_id']) || !isset($parameters['amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['orderid'],
            'third_order' => $parameters['transaction_id'],
            'third_money' => $parameters['amount'],
        ];

        if ($parameters['returncode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['orderid']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        $arr = parse_url($config['payurl']);
        if (empty($url)) {
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/Pay_Trade_query.html';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null) {
            if ($success != 'SUCCESS') {
                $res['status'] = 0;
                $res['error'] = '查询第三方订单返回状态:' . $success;
                //盗刷问题，查单订单状态不对，直接关闭订单
                $update = [
                    'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                    'status' => 'failed',
                ];
                \DB::table('order')->where('order_number', $res['order_number'])->update($update);
                return $res;
            } else {
                //订单状态对了，因这个第三方系统盗刷问题，再检查查单的域名是否有在白名单
                //其它的支付不用这么详细
                if (isset($arr['host']) && !empty($config['ip_black'])) {
                    $host_ip = gethostbyname($arr['host']);

                    $data = [
                        'order_number' => $res['order_number'],
                        'date' => date('Y-m-d H:i:s'),
                        'host' => $arr['host'],
                        'ip' => $host_ip,
                        'ip_black' => implode(",", $config['ip_black']),
                    ];
                    //保存ip等信息，便于检查盗刷
                    RechargeLog::addElkLogByTxt($data);
                }
            }

        }

        $order_number = $parameters['orderid'];
        $return_money = intval($parameters['amount']);

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($val != null && $val != '') {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);
        $sign_str = $params . '&key=' . $tkey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }

    public function returnVail($data, $pubkey)
    {
        $signstr = $data['sign'];
        unset($data['sign']);
        $sign = $this->_sign($data, $pubkey);
        return $sign == $signstr;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "pay_memberid" => $partnerID,
            "pay_orderid" => $orderNumber,
        ];

        $params['pay_md5sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['trade_state'])) {
            return $re['trade_state'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}