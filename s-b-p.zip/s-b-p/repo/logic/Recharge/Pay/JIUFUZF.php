<?php
/**
 * 玖付支付
 * Created by PhpStorm.
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JIUFUZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'partner' => intval($this->partnerID),
            'service' => (string)$this->payType,
            'tradeNo' => (string)$this->orderID,
            'amount' => sprintf("%.2f", $this->money),
            'notifyUrl' => $this->notifyUrl,
            'extra' => 'goods',
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['outTradeNo']) || !isset($parameters['amount']) || !isset($parameters['status'])) {
            return [
                'status' => 0,
                'error' => "参数错误",
            ];
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['outTradeNo'],
            'third_order' => $parameters['outTradeNo'],
            'third_money' => $parameters['amount'],
        ];

        if ($parameters['status'] != 1) {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['error'] = '支付失败';
            return $res;
        }

        if ($parameters['sign'] != $this->_sign($parameters, $config['key'])) {
            $res['error'] = '验证签名失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/orderQuery';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1') {
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "partner" => $partnerID,
            "service" => '10302',
            "outTradeNo" => $orderNumber,
        ];

        $params['sign'] = $this->_sign($params, $tkey);


        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->get();

        $re = json_decode($this->re, true);

        if (isset($re['status'])) {
            return $re['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $privateKey)
    {
        $string = [];
        ksort($pieces);
        foreach ($pieces as $key => $val) {
            if ($key != "sign" && !empty($val) && $key != "signType" && $key != "charset") {
                $string[] = $key . '=' . urldecode($val);
            }
        }
        $params = join('&', $string);
        $sign_str = $params . '&' . $privateKey;
        $sign = md5($sign_str);
        return strtolower($sign);
    }
}