<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 财付通
 */
class CFT extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            "merchantNo" => $this->partnerID,
            "orderNo" => $this->orderID,
            "bank" => $this->payType,
            "name" => 'VIP充值',
            "count" => '1',
            "desc" => '',
            "returnUrl" => $this->returnUrl,
            "notifyUrl" => $this->notifyUrl,
            "version" => ""
        ];
        $this->parameter['sign'] = strtoupper($this->currentMd5('key='));
    }

    /**
     *
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['payParams']['payUrl']) && $re['payParams']['payUrl']) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->data['return_type'];
            $str = $re['payParams']['payUrl'];
            $pattern = '/<form .*?action="(.*?)".*?>/is';
            preg_match($pattern, $str, $match);
            $this->return['str'] = $match[1];
        } else {
            $this->return['code'] = 9999;
            $this->return['msg'] = 'COKA: ' . $re['retMsg'] ?? "支付失败";
            $this->return['way'] = '';
            $this->return['str'] = '';
        }

    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        if(array_key_exists('s',$parameters)){
            unset($parameters['s']);
        }

        $res = [
            'status' => 1,
            'order_number' => $parameters['mchOrderNo'],
            'third_order' => $parameters['payOrderId'],
            'third_money' => $parameters['amount'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($parameters['mchOrderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!in_array($parameters['status'], [2, 3])) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }
        //校验sign
        $sign = $parameters['sign'];
        unset($parameters['sign']);
        $this->parameter = $parameters;
        $this->key = $config['key'];
        if (strtolower($sign) != $this->currentMd5('key=')) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

}