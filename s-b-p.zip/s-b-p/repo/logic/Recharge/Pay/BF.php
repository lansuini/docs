<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;


/**
 * 佰富
 * @author viva
 */


class BF extends BASES {

    static function instantiation(){
        return new BF();
    }

    //与第三方交互
    public function start(){

        $this->initParam();
        if(!$this->payUrl)
            $this->payUrl = 'http://defray.948pay.com:8188/api/smPay.action';
        $this->basePost();
        $this->parseRE();
    }
    //组装数组
    public function initParam(){

/*        $this->notifyUrl = str_replace("\\",'/',$this->notifyUrl);
        $this->notifyUrl = str_replace("//",'/',$this->notifyUrl);*/
        $this->parameter = array(
            'merchantNo'			=> $this->partnerID,
            'netwayCode' => $this->data['bank_data'],
            'randomNum'						=> (string) rand(1000,9999),
            'orderNum'						=> $this->orderID,
            'payAmount' => ($this->money*100).'',
            'goodsName' => 'goods',
            'callBackUrl' => $this->notifyUrl,
            'frontBackUrl' => $this->returnUrl,
            'requestIP' => '103.196.124.252',
        );
        ksort($this->parameter);
        $temp = str_replace('\/','/',json_encode($this->parameter));
        $this->parameter['sign'] = strtoupper(md5($temp.$this->key));
        $temp = str_replace('\/','/',json_encode($this->parameter));
        $this->parameter = array('paramData'=>$temp);;
    }
    
    public function parseRE(){
        $re = json_decode($this->re,true);
        if($re['resultCode'] === '00'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['CodeUrl'];
        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = 'BF:'.$re['resultMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }
    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($input) {
        //RechargeLog::addLogByTxt(['log_321' => '', 'desc' =>$input], 'log_callback_new');
        $tem=explode('=',$input);
        $input=json_decode($tem[1],true);
        // var_dump($input);exit;
        $res = [
            'status' => 1,
            'order_number' => $input['orderNum'],
            'third_order' => $input['orderNum'],
            'third_money' => $input['payAmount'] / 100 ?? 0,
            'error' => '',
        ];


        $config = Recharge::getThirdConfig($input['orderNum']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        $temp = $input['sign'];
        unset($input['sign']);
        ksort($input);
        $sign = strtoupper(md5(json_encode($input).$config['key']));
        if($temp!=$sign){
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        if ($input['resultCode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        // var_dump($res);exit;
        return $res;

    }
}
