<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 豪富支付
 */

class HF extends BASES 
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        date_default_timezone_set('Asia/Shanghai');
        $this->parameter = [
            'partner' => $this->partnerID,
            'amount' => $this->money,
            'request_time' => time(),
            'trade_no' => (string)$this->orderID,
            'pay_type' => (string)$this->payType, 
            'notify_url' => $this->notifyUrl,
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter);
        // $json = json_encode($this->parameter);
        // $this->curlPost($json);
        //var_dump($this->parameter);exit;
    }


    public function parseRE()
    {
        
        $result = json_decode($this->re,true);
        //var_dump($result);exit;
        if ($result && $result['is_success'] =="T") { 
            $this->return['code'] = 0;
            $this->return['msg']  = 'success';
            $this->return['way']  = $this->data['return_type'];;
            $this->return['str']  = $result['result'];
        }else{
            $this->return['code'] = $result['fail_code'];
            $this->return['msg'] = 'HF: ' . $result['fail_msg'];
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['out_trade_no'],
            'third_order'  => $parameters['trade_id'],
            'third_money'  => $parameters['amount_str'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error']  = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $parameters['sign'],$config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key=>$val)
        {
            $string = $string.$key.'='.$val.'&';
        }
        $string = $string.$this->key;
        //var_dump($string);exit;
        $sign = strtolower(md5($string));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$re_sign,$tkey)
    {
        unset($params['sign']);
        ksort($params);
        $string = '';
        foreach ($params as $key=>$val)
        {
            if($val){
                $string = $string.$key.'='.urldecode($val).'&';
            }
            
        }
        $string = $string.$tkey;
        $sign = strtolower(md5($string));
        if ($sign == $re_sign){
                return true;
        }
        return false;
    }
}