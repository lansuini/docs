<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * A码
 * @author benchan
 */
class AMA extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $this->parameter = array(
            //基本参数
            'mchid' => $this->partnerID,
            'amount' => $this->money * 100,
            'pay_type' => $this->payType,
            'notify_url' => $this->notifyUrl,
            "return_url" => $this->returnUrl,
            'trade_out_no' => $this->orderID,
            'noncestr' => time()
        );

        $this->parameter['sign'] = $this->getSign($this->parameter, $this->key);

    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re && $re['code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            if ($this->payType == 'code') {
                $this->return['str'] = $this->qrcodeUrl . $re['data']['qrcode'];
            } else {
                $this->return['str'] = $re['data']['pay_url'];
            }
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'AMA:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function getSign($params, $tKey)
    {
        $params['token'] = $tKey;
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign = md5(rtrim($string,'&'));
        return $sign;
    }


    public function returnVerify($parameters)
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['trade_out_no'],
            'third_order' => $parameters['pay_sn'],
            'third_money' => $parameters['real_amount'] / 100,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($parameters['trade_out_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if (!$this->returnVail($parameters,$config['key'],$parameters['sign'])) {
            $res['status'] = 0;
            $res['error'] = '该订单验签不通过或已完成';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    public function returnVail($params, $tkey,$thirdSign)
    {
        $sign = $this->getSign($params, $tkey);

        return $thirdSign == $sign;
    }
}
