<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\JFB\AES;
//header("Content-type:text/html;charset=utf-8");
/**
 * 第三方支付 - 聚福宝

 */

class JFB extends BASES {

	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        //$this->basePost();
        $this->_httpPost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam() 
    {
        $this->data['client_ip'] = $this->data['client_ip'] ? $this->data['client_ip'] : '127.0.0.1';
        $sign=[
            'merchantOrderNo'=>$this->orderID, 
            'amount' =>(string)$this->money,
            'payType' => '1',
            'notifyUrl' => $this->notifyUrl,
            'clientIp' => $this->data['client_ip'],
        ];
        $aes = new AES;
        $postsign = str_replace('+', '%2B', $aes->encryptString(json_encode($sign),$this->key));
        $this->parameter = [                                         		
            'merchantId' => $this->partnerID,                                   
            'sign' => $postsign,
        ];
    }

    /**
     * curl post支付请求，需要设置header
     */
    public function _httpPost(){
        $this->parameter = json_encode($this->parameter);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->payUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->parameter);
        curl_setopt($ch, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8','Content-Length:' . strlen($this->parameter)));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $response = curl_exec($ch);
        //$this->curlError = curl_error($ch);
        $this->re = $response;
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
    	if (isset($re['resultCode']) && $re['resultCode'] == 200) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data'];	
    	} else {
    		$this->return['code'] = $re['resultCode'];
            $this->return['msg'] = '聚福宝：' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
    	}
    }

    /**
     * 回调验证处理
     */
    public function returnVerify($data) 
    {
        $aes = new AES;
        $id = \DB::table('pay_channel')->where('code', 'JFB')->value('id');
        $key = \DB::table('pay_config')->where('channel_id', $id)->value('pub_key');
        //echo $key;
        $data['sign'] = urldecode($data['sign']);
        $rdata = $aes->decryptString($data['sign'],$key);
        //$rdata = substr($rdata,0,strripos($rdata, '}',2))."}";
        $data = json_decode($rdata,true);
        $orderdata = $data['data'];
        $res = [
            'status' => 1,
            'order_number' => $orderdata['merchantOrderNo'],
            'third_order' => '',
            'third_money' => $orderdata['orderAmount'],
            'error' => '',
        ];
        if (strtolower($orderdata['status']) != 'success') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }
        $config = Recharge::getThirdConfig($orderdata['merchantOrderNo']);
        if ($data['resultCode'] != 200) {
        	$res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }


        //无此订单
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        $order_number = $orderdata['merchantOrderNo'];
        $return_money = $orderdata['orderAmount'];
        $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
        $order_info = (array)$order_info;
        if (empty($order_info)){
            $res['status'] = 0;
            $res['error'] = '不存在的订单！';
        }else{
            if ($order_info['i_money'] - $return_money == 0){
                $res['status'] = 1;
            }else{
                \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                $updata = array(
                    'i_money' => (int)$return_money,
                    'i_gold' =>(int)$return_money,
                );
                \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                $res['status'] = 1;
            }
        }

        return $res;
    }

}