<?php
/**
 * 龙诚支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/2/13
 * Time: 14:06
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class LCPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        //$this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'version' => '1.0',
            'customerid' => (string)$this->partnerID,
            'total_fee' => sprintf("%.2f", $this->money),
            'sdorderno' => (string)$this->orderID,
            //'paytype' => (string)$this->payType, //bank_data
            'notifyurl' => $this->notifyUrl,
            'returnurl' => $this->returnUrl,
        ];
        //var_dump($pub_params);exit();
        $pub_params['sign'] = $this->_sign($pub_params,$this->key);
        $pub_params['paytype'] = $this->payType;
        if ($this->payType != 'weixin'){
            $pub_params['pay_model'] = 1;
        }
        $this->parameter = $pub_params;
        //var_dump($this->parameter);exit();
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
//        $this->parameter .= '&url=' . $this->payUrl;
//        $this->parameter .= '&method=GET';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['sdorderno'],
            'third_order' => $parameters['sdpayno'],
            'third_money' => $parameters['total_fee'],
        ];
        $config = Recharge::getThirdConfig($parameters['sdorderno']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != 1){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['sdorderno'];
            $return_money = intval($parameters['total_fee']);
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $params = join('&',$string);
        $sign_str = $params.'&'.$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        unset($params['remark']);
        $data = [
            'customerid' => $params['customerid'],
            'status' => $params['status'],
            'sdpayno' => $params['sdpayno'],
            'sdorderno' => $params['sdorderno'],
            'total_fee' => $params['total_fee'],
            'paytype' => $params['paytype'],
        ];
        $sign = $this->_sign($data,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}