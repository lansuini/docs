<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/19
 * Time: 10:09
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Psr\Http\Message\ServerRequestInterface;

/**
 * 汇聚支付
 * Class GF
 * @package Logic\Recharge\Pay
 */
class HJ extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = array(
            'parter' => $this->partnerID,
            'type'=>$this->data['bank_data'],
            'value' => $this->money,
            'orderid' => $this->orderID,
            'callbackurl' => $this->notifyUrl,
//            'hrefbackurl' => $this->returnUrl
        );
        $this->parameter['sign'] = $this->sytMd5New($this->parameter, $this->key);
    }



    public function sytMd5New($pieces, $key)
    {
        $md5str = "";
        foreach ($pieces as $keyVal => $val) {
            $md5str = $md5str . $keyVal.'='. $val .'&' ;
        }
        $md5str = rtrim($md5str,'&') .  $key;
//        var_dump($md5str);die;
        return md5($md5str);
    }

    //返回参数
    public function parseRE()
    {
        $this->parameter = $this->arrayToURL();

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl. '?' . $this->parameter;
    }

    //签名验证
    public function returnVerify($result)
    {
        $res = [
            'status' => 1,
            'order_number' => $result['orderid'],
            'third_order' => '',
            'third_money' => $result['ovalue'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($result['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
        }

        $sign = $result['sign'];
        unset($result['sign']);
       if(isset($result['s']))unset($result['s']);

        if (!self::retrunVail($sign, $result, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    public function retrunVail($sign, $data, $key)
    {
        $pieces['orderid']=$data['orderid'];
        $pieces['opstate']=$data['opstate'];
        $pieces['ovalue']=$data['ovalue'];
        return $sign == $this->sytMd5New($pieces, $key);
    }

}