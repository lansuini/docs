<?php
/**
 * FFpay支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/9
 * Time: 9:30
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class FFPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        if ($this->data['scene'] != 'unionpay'){

        }
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $rand = mt_rand(10,99)/100;
        $money = sprintf("%.2f", $this->money) + $rand;
        $pub_params = [
            'MerchantCode' => $this->partnerID,
            'BankCode' => (string)$this->payType,
            'OrderId' => (string)$this->orderID,
            'OrderDate' => (string)(time()*1000),
            'Amount' => sprintf("%.2f", $this->money),
            'NotifyUrl' => $this->notifyUrl,
            'Ip'=>$this->data['client_ip'],
        ];
        /*if ($this->data['scene'] == 'unionpay'){
            $pub_params['Amount'] = sprintf("%.2f", $this->money);
        }*/
        $pub_params['Sign'] = $this->_sign($pub_params,$this->key);
        //var_dump($pub_params);exit();
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if (isset($re['resultCode']) && $re['resultCode']=='200' && $re['success']){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $re_data = $re['data'];
            $str = $re_data['data']['info'];
            preg_match_all("/\'(.*?)\'/si", $str, $matches);
            if ($this->payType == 'ALIPAY_WAP')
            {
                $str = $re_data['data']['info'];
                preg_match_all("/\'(.*?)\'/si", $str, $matches);
                $this->return['str'] = $matches[1][0];
            }
            else{
                $this->return['str'] = $re_data['data']['info'];
            }
        }else{
            $this->return['code'] = $re['resultCode'];
            $this->return['msg'] = $re['resultMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['OrderId'],
            'third_order' => $parameters['OutTradeNo'],
            'third_money' => $parameters['Amount'],
        ];
        $config = Recharge::getThirdConfig($parameters['OrderId']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['Status'] != 1){
            $res['status'] = 0;
            $res['error'] = '订单支付状态为失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['OrderId'];
            $return_money = intval($parameters['Amount']);
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $params = join('&',$string);
        $sign_str = $params.'&Key='.$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['Sign'];
        unset($params['Sign']);
        foreach ($params as $k=>$val)
        {
            if (empty($val)){
                unset($params[$k]);
            }
        }
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}