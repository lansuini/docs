<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 滴滴支付
 */
class DIDIZF extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = array(
            //基本参数
            'merchant' => $this->partnerID,
            'money' => $this->money,
            'mark' => $this->orderID,
            'returnUrl' => $this->notifyUrl,
        );

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['username'] = $this->uid;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (!isset($re['result'])) {
            $this->return['code'] = 90;
            $this->return['msg'] = '请求失败';
            $this->return['way'] = $this->data['return_type'];
            return;
        }

        if ($re['result'] == true && isset($re['url'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['url'];
        } else {
            $this->return['code'] = 99;
            $this->return['msg'] = '滴滴支付:' . $re['msg'] ?? '未知异常';
            $this->return['way'] = $this->data['return_type'];
        }
    }

    public function _sign($params, $key)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != null && $v != '') {
                $string = $string . $v;
            }
        }
        $str = $string . $key;
        return strtolower(md5($str));
    }


    public function returnVerify($input)
    {
        global $app;
        $input = $app->getContainer()->request->getParams();
        unset($input['s']);

        $res = [
            'status' => 0,
            'order_number' => $input['mark'],
            'third_order' => $input['account'],
            'third_money' => $input['money'],
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if (!$this->returnVail($input, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '该订单验签不通过';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    public function returnVail($result, $key)
    {
        $returnSign = $result['sign'];
        unset($result['sign']);
        $sign = $this->_sign($result, $key);
        return $sign === $returnSign;
    }

}
