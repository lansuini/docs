<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 聚宝
 * @author lavenkin
 */
class JUBAO extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $tmp = explode('-',$this->payType);
        $this->parameter = [
            'mechno' => $this->partnerID,
            'payway' => $tmp[0],
            'paytype' => $tmp[1],
            'amount' => $this->money * 100,
            'timestamp' => time(),
            'orderno' => $this->orderID,
            'body' => 'GOODS',
            'orderip' => $this->clientIp,
            'returl' => $this->returnUrl,
            'notifyurl' => $this->notifyUrl,
        ];


        $this->parameter['sign'] = strtoupper($this->currentMd5("key="));

    }

    public function parseRE()
    {
        if(in_array($this->parameter['paytype'],['SCANPAY','SCAN_PAY','JD_SCAN','UN_SCANPAY'])) {
            $re = json_decode($this->re, true);
            if (isset($re['data']['payUrl']) && $re['data']['payUrl']) {
                $this->return['code'] = 0;
                $this->return['msg'] = 'success';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = $re['data']['payUrl'];
            } else {
                $this->return['code'] = 23;
                $this->return['msg'] = 'JUBAO：' . $re['message'] ?? '通道返回有误';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }else {
            $this->parameter['returl'] = urlencode($this->parameter['returl']);
            $this->parameter['notifyurl'] = urlencode($this->parameter['notifyurl']);
            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . $this->payUrl;
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        }
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($parameters) 
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['extra'],
            'third_order' => $parameters['transactionid'],
            'third_money' => $parameters['totalfee'] / 100,
            'error' => '',
        ];

        if ($parameters['tradestate'] != 100) {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['extra']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        //校验sign
        $sign = $parameters['sign'];
        unset($parameters['sign']);
        unset($parameters['s']);
        ksort($parameters);
        $str = '';
        foreach ($parameters as $key=>$val){
            $str .= $key.'='.$val.'&';
        }
        $str .= 'key='.$config['key'];
        if (strtolower($sign) != strtolower(md5($str))) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }
}
