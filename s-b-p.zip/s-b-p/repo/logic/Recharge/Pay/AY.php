<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - 傲游支付
 */
class AY extends BASES
{

    public function start()
    {
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'pay_amount' => $this->money * 100,
            'pay_applydate' => date('Y-m-d H:i:s'),
            'pay_bankcode' => $this->data['bank_data'],
            'pay_callbackurl' => $this->returnUrl,
            'pay_memberid' => $this->partnerID,
            'pay_notifyurl' => $this->notifyUrl,
            'pay_orderid' => $this->orderID,
        ];

        $this->parameter['pay_md5sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        if ($this->data['return_type'] == 'code') {
            $this->basePost();
            $re = json_decode($this->re, true);
            if ($re && $re['returncode'] == '200') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = $re['url'];
            } else {
                $this->return['code'] = 99;
                $this->return['msg'] = '傲游:' . $re['msg'] ?? '未知异常';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        } else {
            foreach ($this->parameter as &$item) {
                $item = urlencode($item);
            }
            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . urlencode($this->payUrl);
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        }

    }


    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['orderid'],
            'third_order' => $data['transaction_id'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderid']);
        // var_dump($data);exit;
        if ($data['returncode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        if (array_key_exists('s', $data)) {
            unset($data['s']);
        }
        if (array_key_exists('attach', $data)) {
            unset($data['attach']);
        }
        unset($data['sign']);

        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);

        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string .= 'key=' . $key;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {

        $sign = $this->_sign($pieces, $key);

        return $thirdSign == $sign;
    }
}