<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - 超新星支付
 */
class CXX extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'mch_no' => $this->partnerID,
            'app_id' => $this->data['app_id'],
            'trade_type' => $this->data['bank_data'],
            'total_fee' => $this->money * 100,
            'nonce_str' => mt_rand(time(), time() + rand()), //随机字符串，不长于 32 位
            'body' => 'GOODS',
            'notify_url' => $this->notifyUrl,
            'front_url' => $this->returnUrl,
            'out_trade_no' => $this->orderID
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re && $re['return_code'] == '0000') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            if($this->data['return_type']=='code'){
                $this->return['str'] = urldecode($re['pay_info']);
            }
            else if ($this->showType == 'sdk')
            {
                $this->return['str'] = urldecode($re['orderStr']);
            }
            else{
                $this->return['str'] =$re['pay_info'];
            }

        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = '超新星:' . $re['return_msg'] ?? '未知异常';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['thd_trans_no'],
            'third_money' => $data['total_fee'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['out_trade_no']);
        // var_dump($data);exit;
        if ($data['trade_status'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        if (array_key_exists('s', $data)) {
            unset($data['s']);
        }
        unset($data['sign']);

        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);

        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string .= 'key=' . $key;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {

        $sign = $this->_sign($pieces, $key);

        return $thirdSign == $sign;
    }
}