<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - 龙支付
 */
class LONG extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'out_trade_no' => $this->orderID,
            'money' => $this->money,
            'type' => $this->data['bank_data'],
            'pid' => $this->partnerID,
            'name' => $this->uid,
        ];

//        $this->parameter['sign'] = md5(md5(implode('',$this->parameter)).$this->key);
        $this->parameter['notify_url'] = urlencode($this->notifyUrl);
        $this->parameter['return_url'] = urlencode($this->returnUrl);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $this->parameter['method'] = 'POST';
        $this->parameter['url'] = urlencode($this->payUrl);
        $this->parameter = $this->arrayToURL();

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->data['return_type'];
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['out_trade_no'],
            'third_money' => $data['money'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['out_trade_no']);
        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        if ($data['trade_status'] != 'TRADE_SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '订单号未支付';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        $tmp = [
            'out_trade_no' => $data['out_trade_no'],
            'money' => $data['money'],
            'type' => $data['type'],
            'pid' => $data['pid'],
            'name' => $data['name'],
        ];
        if ($sign != md5(md5(implode('',$tmp)).$config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

}