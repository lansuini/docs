<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 豆豆
 * @author lavenkin
 */
class DD extends BASES 
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'partner_id' => $this->partnerID,
            'service' => 'com.order.Unified.Pay',
            'sign_type' => 'RSA',
            'rand_str' => md5(time() . mt_rand(0,1000)),
            'version' => 'v1',
            'merchant_no' => $this->data['app_id'],
            'merchant_order_sn' => $this->orderID,
            'paychannel_type' => $this->data['bank_data'],
            'trade_amount' => (int) $this->money * 100,
            'merchant_notify_url' => $this->notifyUrl,
            'ord_name' => 'Golds',
            'interface_type' => 1,
            'merchant_return_url' => $this->returnUrl,
            'client_ip' => $this->clientIp,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter);

        // var_dump($this->parameter);exit;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);

        if (isset($re['errcode']) && $re['errcode'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['data']['out_pay_url'];
        } else {
            $re['message'] = $re['msg'] ?? '第三方未知错误';
            $this->return['code'] = 886;
            $this->return['msg'] = 'DD:' . $re['message'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    /**
     * 生成sign
     */
    private function _sign($pieces)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $k => $v){
            if ($v != '' && $v != null && $k != 'sign'){
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $string = substr($string, 0, strlen($string) - 1);
        // var_dump($string);exit;
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\r\n";
        foreach (str_split($this->key, 64) as $str) {
            $private_key = $private_key . $str . "\r\n";
        }
        $private_key = $private_key . "-----END RSA PRIVATE KEY-----";

        $sign = '';
        if ($res = openssl_get_privatekey($private_key)) {
            // $sign = $this->rsaEncryptStr($string, $private_key);
            openssl_sign($string, $sign, $res);

            openssl_free_key($res);

            $sign = base64_encode($sign);
        }
 
        return $sign;
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($parameters) 
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['merchant_order_sn'],
            'third_order' => $parameters['merchant_no'],
            'third_money' => $parameters['trade_amount'] / 100 ?? 0,
            'error' => '',
        ];

        if ($parameters['pay_status'] != 1) {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['merchant_order_sn']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $publicKeyString = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($config['pub_key'], 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";

        if (! $this->_verifySign($parameters, $publicKeyString, $parameters['sign'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        return $res;
    }

    /**
     * 验证sign
     */
    private function _verifySign($data, $pubkey, $sign) 
    {
        ksort($data);
        $arg = '';
        foreach($data as $key => $val) {
            if ($key == 'sign' || $val == '')
                continue;

            $arg .= $key.'='.$val.'&';
        }
        //去掉最后一个&符号
        $arg = substr($arg, 0, strlen($arg) - 1);

        // var_dump($arg);exit;
        //如果带有反斜杠 则转义
        if (get_magic_quotes_gpc()) $arg = stripslashes($arg);
        $res = openssl_get_publickey($pubkey);
        $result = (bool) openssl_verify($arg, base64_decode(urldecode($sign)), $res);
        // var_dump($result);exit;
        openssl_free_key($res);

        return $result;
    }

}
