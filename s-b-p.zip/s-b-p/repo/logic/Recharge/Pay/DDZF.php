<?php
/**
 * 点点支付
 * Created by Hans.
 * Date: 2019/6/1
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class DDZF extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
//        $this->basePost();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
//生成签名
        $data = array();
        $data['pid'] = $this->partnerID;
        $data['version'] = '1.0';
        //商品名称
        $data['name'] = 'goods';

        //支付金额(元)
        $data['money'] = $this->money;

        //支付通道 alipay2:支付宝、wechat2:微信、transfer:银行卡直充
        $data['type'] = $this->payType;

        //商户订单号
        $data['out_trade_no'] = $this->orderID;

        //商户用户ID(必选，商户用户唯一标识(即玩家id，标识来自哪个玩家的订单，商户要是觉得不安全，可加密)（注意：如果没有请与我沟通）
        $data['out_user_id'] = $this->uid;

        //第4方商户ID (可选，商户通道要是存在中间层，需要该参数，避免out_user_id重复，商户要是觉得不安全，可加密)
//        $data['out_pid4'] = $_REQUEST['out_pid4'];

        //商户手机号(可选，通道匹配使用，存在该字段成功率更高，商户为了安全可隐藏中间4位 如：138****3800)
//        $data['out_phone'] = $_REQUEST['out_phone'];


        //异步通知地址(POST方式发起)
        $data['notify_url'] = $this->notifyUrl;
        //同步跳转地址(GET方式发起)
        $data['return_url'] = $this->returnUrl;
        //签名
        $data['sign'] = $this->getSign($data,$this->key);
        //注意：out_phone, out_pid4是可选参数，要是没有就不传，不要写个固定错误的值
        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['out_trade_no']) || !isset($parameters['trade_no']) || !isset($parameters['pay_money'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['trade_no'],
            'third_money' => $parameters['pay_money'],
        ];

        if ($parameters['status'] != '1') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $sign = $parameters['sign'];
        $getSign = $this->getSign($parameters,$config['key']);
        if ($getSign != $sign) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/hoPpyaCXnAaaDTfAp7yyAQkGXeoHSazZ';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $order_number = $parameters['out_trade_no'];
        $return_money = intval($parameters['pay_money']);

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    /**
     * @param: $array为待签名数组。
     * @param: $key为商户密钥。
     * @return 签名结果
     */
    function getSign($array = array(), $key2,$sign_type = 'MD5'){
        ksort($array);
        foreach ($array as $key => $value){
            if($array[$key] == '' || $key == 'sign' || $key == 'sign_type' || $key == 'key' || $key == 's' || $key == 't'){
                unset($array[$key]);
            }
        }
        $str = $this->createLinkstring2($array);
        switch ($sign_type){
            case 'md5':
            case 'MD5':
                return md5($str.$key2);
                break;
            default:
                return md5($str.$key2);
                break;
        }
    }

    /**
     * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
     * @param $para 需要拼接的数组
     * return 拼接完成以后的字符串
     */
    function createLinkstring2($para) {
        $arg  = "";
        foreach ($para as $key => $value){
            $arg .= $key."=".$value."&";
        }
        //去掉最后一个&字符
        $arg = substr($arg,0,count($arg)-2);

        //如果存在转义字符，那么去掉转义
        if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}

        return $arg;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            'version' => '1.0',
            "pid" => $partnerID,
            "out_trade_no" => $orderNumber,
        ];

        $params['sign'] = $this->getSign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['status'])) {
            return $re['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}