<?php
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 华夏支付
 */
class HUAXIAPAY extends BASES
{
    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $data=array(
            'requestId'		=>	substr($this->orderID.$this->data['app_id'],0,30),//最长32位
            'orgId'			=>	$this->data['app_id'],//机构号
            'productId'		=>	$this->data['action'] ? $this->data['action'] : '0100',//0100	扫码支付D0，9701	订单查询
//            'dataSignType'	=>	'1',//正式
            'timestamp'		=>	date('YmdHis',time())
        ); //验证数据结构

        $busMap = array(
            'merno'=>$this->partnerID,//平台进件返回商户号
            'bus_no'=>$this->data['bank_data'],//业务编号
            'amount'=>(string)($this->money*100),//交易金额，单位分
            'goods_info'=>$this->orderID,//商品名称
            'clientip'=>$this->data['client_ip'],
            'order_id'=>$this->orderID,//商户自定义订单号
            'return_url'=>$this->returnUrl,//前端跳转回调地址
            'notify_url'=>$this->notifyUrl,//后台通知回调地址
        );
        $businessData = json_encode($busMap);
//        $businessData = urlencode($this->des_encrypt($businessData, $this->key));
        $data['businessData'] = $businessData;
        $data['signData']=$this->sign($data);
        $this->parameter = $data;
//        print_r($busMap);
//        print_r($data);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //生成支付签名
    public function sign($data)
    {
        ksort($data);
        $b = '';
        $lastvalue=end($data);
        foreach($data as $key=>$value){
            if($value==$lastvalue){
                $b .= $key .'=' .$value;
            }else{
                $b .= $key .'=' .$value.'&';
            }
        }
        $b .= $this->data['pub_key'];
        $signData = md5($b);
        $signData = strtoupper($signData);
        return $signData;
    }

    //发起请求，返回参数
    public function parseRE()
    {
//        print_r($this->re);exit;
        $re = json_decode($this->re, true);
        if (in_array($re['key'], ['00', '05']) && !empty($re['result'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            $url = json_decode($re['result'], true);
            $this->return['str'] = $url['url'];//支付地址
        } else {
            $this->return['code'] = 8;
            $msg = $re['msg'] ?? $re['respMsg'] ?? '未知错误';
            $this->return['msg'] = 'HUAXIAPAY:' . $msg;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function des_encrypt($data,$tkey){
        return openssl_encrypt($data, 'des-ecb', $tkey);
    }

    public function des_decrypt($data, $tkey)
    {
        return openssl_decrypt($data, 'des-ecb', $tkey);
    }

    //异步回调的签名验证
    public function returnVerify($pieces)
    {

        $res = [
            'status' => 0,
            'order_number' => $pieces['order_id'],//商户系统内部订单号
            'third_order' => $pieces['plat_order_id'],//支付系统流水号
            'third_money' => $pieces['amount']/100,//订单金额，分
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($pieces['order_id']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if($pieces['trade_status'] != '0'){
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        if (self::retrunVail($pieces, $config['pub_key'])) {
            $this->updateMoney($res['order_number'], $res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    //验签
    public function retrunVail($data, $md5Key)
    {
        $sys_sign = $data['sign_data'];
        $data['trade_date'] = urldecode($data['trade_date']);
        unset($data['sign_data']);
        ksort($data);
        $lastvalue = end($data);
        $b = '';
        foreach($data as $key=>$value){
            if($value == $lastvalue){
                $b .= $key .'='.$value;
            }else{
                $b .= $key .'='.$value.'&';
            }
        }
        $b .= $md5Key;
        $signData = md5($b);
        if($signData == $sys_sign){
            return true;
        }else{
            return false;
        }
    }

}