<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - hashpay
 * @author Lavenkin
 * @date 2018-08-07
 */


class HASHPAY extends BASES {

	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        // $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam() 
    {
        $this->parameter = [
            'pickupUrl' => 'http://faqugames.com',                                           		
            'receiveUrl' => $this->notifyUrl,                                   
            'signType' => 'MD5',                                       
            'orderNo' => $this->orderID,
            'orderAmount' => (int)$this->money,
            'orderCurrency' => 'CNY',
            'customerId' => $this->partnerID,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $this->parameter['method'] = 'POST';
        $this->parameter['url'] = $this->payUrl;
    	$this->parameter = $this->arrayToURL();

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->data['return_type'];
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     */
    public function returnVerify($data) 
    {
        $res = [
            'status' => 1,
            'order_number' => $data['orderNo'],
            'third_order' => $data['transactionId'],
            'third_money' => $data['orderAmount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderNo']);
        // var_dump($data);exit;
        if ($data['status'] != 'success') {
        	$res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        //无此订单
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        if (! $this->_verifySign($data, $config['key'], $data['sign'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($data)
    {
        $string = '';
        foreach ($data as $v) {
            $string .= $v;
        }
        $string .= $this->key;
        $sign = md5($string);

        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($data, $key, $thirdSign)
    {
    	$string = '';
        foreach ($data as $v) {
            $string .= $v;
        }
        $string .= $key;
        $sign = md5($string);

        return $thirdSign == $sign;
    }
}