<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 发家支付 /COD
 * @author lavenkin
 */
class FAJIA extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $parameter = [
            'return_type' => 'json',
            'api_code' => $this->partnerID,
            'is_type' => $this->data['bank_data'],
            'price' => sprintf("%.2f", $this->money),
            'order_id' => $this->orderID,
            'return_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
            'mark' => 'GOODS',
            'time' => time(),
        ];

        $parameter['sign'] = $this->getSign($parameter, $this->key);

        $sign_data = json_encode($parameter);
        $this->parameter['data'] = openssl_encrypt($sign_data, 'AES-128-ECB', $this->pubKey, 0, '');
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            if ($val != null && $val != '') {
                $string = $string . $key . '=' . $val . '&';
            }
        }
        $string = $string . 'key=' . $api_key;
        $sign = md5($string);
        return $sign;
    }

    public function parseRE()
    {

        $re = json_decode($this->re, true);

        if (isset($re['returncode']) && $re['returncode'] == 'SUCCESS') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];

            $this->return['str'] = $re['data']['payurl'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '发家支付：' . $re['returnmsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
//        global $app;
//        $data = $app->getContainer()->request->getParams();
//        unset($data['s']);

        if (!isset($data['api_code']) || !isset($data['data'])) {
            return false;
        }

        $order_number = (array)\DB::table('order')->leftJoin('passageway AS p', 'order.passageway_id', '=', 'p.id')
            ->leftJoin('pay_config AS c', 'p.pay_config_id', '=', 'c.id')
            ->where('c.partner_id', $data['api_code'])->where('order.status', '=', 'pending')->first(['order_number']);


        $config = Recharge::getThirdConfig($order_number['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        $data = json_decode(openssl_decrypt(urldecode($data['data']), 'AES-128-ECB', $config['pub_key']), true);
        $res = [
            'status' => 0,
            'order_number' => $data['order_id'],
            'third_order' => $data['paysapi_id'],
            'third_money' => $data['real_price'],
            'error' => '',
        ];

        if (!$data) {
            $res['status'] = 0;
            $res['error'] = '解密失败';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        if ($data['code'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单状态异常！'.$data['code'];
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/interface/order_query';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key'], $config['pub_key']);
        //查询第三方有结果
        if ($success != null && $success != '1') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
//        var_dump($res);die;
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        unset($data['messages']);
        $sign = $this->getSign($data, $config['key']);

        return $sign == $signOld;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey, $pubKey)
    {
        $params = [
            'api_code' => $partnerID,
            "order_id" => $orderNumber,
        ];

        $params['sign'] = $this->getSign($params, $tkey);
        $sign_data = json_encode($params);
        $this->parameter['data'] = openssl_encrypt($sign_data, 'AES-128-ECB', $pubKey, 0, '');

        $this->payUrl = $queryUrl;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);
        if (isset($re['data'][0]['status'])) {
            return $re['data'][0]['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }
}