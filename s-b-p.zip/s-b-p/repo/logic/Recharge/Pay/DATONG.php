<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 大同支付
 */
class DATONG extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'ver' => '1.0',
            'userid' => $this->partnerID,
            'amount' => $this->money,
            'order_no' => $this->orderID,
            'notifyurl' => $this->notifyUrl,
            'returnurl' => $this->returnUrl,
        ];

        //不参与签名字段
        $pub_params = [
            'type' => $this->payType,
            'client' => 'wp', //手机端:wp，电脑端pc
            'sign' => $this->getSign($data, $this->key)
        ];
        $this->parameter = array_merge($data, $pub_params);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $key . '=' . $val . '&';
        }

        $string .= $api_key;
        $sign = md5($string);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['url']) && $re['errcode'] == '0') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];

            $use_type = $re['use_type'];

            if ($use_type == 1) {
                $this->return['str'] = $re['url'];
            } elseif ($use_type == 2) {
                $scene = $this->data['scene'];
                $notice = '';
                if ($scene == 'alipay' || $scene = 'wx') {
                    $notice = "请打开" . ($scene == 'alipay' ? "支付宝" : "微信") . "扫描下方二维码";
                }
                $this->return['str'] = $this->getGuideQRURL($re['url'], $re['money'], $notice, 0);
            } elseif ($use_type == 3) {
                $this->return['str'] = $this->jumpURL . '?method=IMG&img=' . $re['url'];
            } elseif ($use_type == 4) {
                $this->return['str'] = $this->jumpURL . '?method=HTML&html=' . base64_encode($re['url']);
            }

        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '大同：' . (isset($re['msg']) ? $re['msg'] : (isset($this->re) ? $this->re : '请求失败,请检查下单地址'));
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['sdorderno']) || !isset($data['sdpayno']) || !isset($data['total_fee'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['sdorderno'],
            'third_order' => $data['sdpayno'],
            'third_money' => $data['total_fee'],
            'error' => '',
        ];

        if ($data['status'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/apiorderquery';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != 1) {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign_data = [
            'customerid' => $data['customerid'],
            'status' => $data['status'],
            'sdpayno' => $data['sdpayno'],
            'sdorderno' => $data['sdorderno'],
            'total_fee' => $data['total_fee'],
            'paytype' => $data['paytype'],
        ];
        $sign = $this->getSign($sign_data, $config['key']);
        return $sign == $signOld;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "customerid" => $partnerID,
            "sdorderno" => $orderNumber,
            'reqtime' => date('YmdHis'),
        ];

        $params['sign'] = $this->getSign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['status'])) {
            return $re['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}