<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 大象支付
 * @author lavenkin
 */
class HM extends BASES
{
	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
    	$this->parameter = [
            'accountId' => $this->partnerID,
            'payType' => 1,
            'amount' => sprintf("%.2f",$this->money),
    		'orderId' => $this->orderID,
    		'notifyUrl' => $this->notifyUrl,
            'commodity'=>'GOODS',
    		'interface' => $this->payType,
    		'requestIp' => $this->clientIp,
        ];

        $this->parameter['sign'] = strtoupper($this->currentMd5('key='));
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['data']['qr_code']) && $re['data']['qr_code']) {
            $this->return['code'] = 0;
            $this->return['msg'] = $re['message'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['data']['qr_code'];

        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'HM：' . $re['message'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
    	$res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['out_trade_no'],
            'third_money' => $data['total_amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        if ($data['trade_status'] != 200) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }
        $sign = $data['sign'];
        unset($data['sign']);
        $this->parameter = $data;
        $this->key = $config['key'];
        if (strtoupper($sign) != strtoupper($this->currentMd5('key='))) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

}