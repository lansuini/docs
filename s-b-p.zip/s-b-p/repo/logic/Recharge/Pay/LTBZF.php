<?php


namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 *
 * Class 联通宝
 * @package Logic\Recharge\Pay
 */
class LTBZF extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = array(
            'parter' => $this->partnerID,
            'type' => $this->data['bank_data'],
            'value' => sprintf('%.2f', $this->money),
            'orderid' => $this->orderID,
            'callbackurl' => $this->notifyUrl,
        );
        $this->sort = false;
        $this->parameter['sign'] = md5($this->arrayToURL() . $this->key);
        $this->parameter['hrefbackurl'] = $this->returnUrl;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //返回参数
    public function parseRE()
    {
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' . $this->arrayToURL();
    }

    //签名验证
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();

        if (!isset($result['orderid']) || !isset($result['ovalue']) || !isset($result['opstate'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $result['orderid'],
            'third_order' => $result['orderid'],
            'third_money' => $result['ovalue'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($result['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($result['opstate'] != 0) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }
        $this->parameter = [
            'orderid' => $result['orderid'],
            'opstate' => $result['opstate'],
            'ovalue' => $result['ovalue'],
        ];
        $this->sort = false;
        if ($result['sign'] == md5($this->arrayToURL() . $config['key'])) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }

        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/payway/search.ashx';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);

        //查询第三方有结果
        if ($success != null && $success != 0) {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "parter" => $partnerID,
            "orderid" => $orderNumber,
        ];

        $params['sign'] = md5("parter=" . $partnerID . "&orderid=" . $orderNumber . $tkey);
        $this->payUrl = $queryUrl;
        $this->parameter = $params;
        $this->get();
        $re = $this->str2arr($this->re);

        if (isset($re['opstate'])) {
            return $re['opstate'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

    function str2arr($str, $sp = "&", $kv = "=")
    {
        if (empty($str)) {
            return null;//下单请求失败
        }
        $arr = str_replace(array($kv, $sp), array('"=>"', '","'), 'array("' . $str . '")');
        eval("\$arr" . " = $arr;");
        return $arr;
    }


}