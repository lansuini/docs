<?php
/**
 * 云成支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2018/12/16
 * Time: 10:36
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class FEIERZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'pay' => $this->payType,
            'Price' => sprintf("%.2f", $this->money),
            'admin_name' => $this->partnerID,
            'callback' => $this->notifyUrl,
            'ok_callback' => $this->returnUrl,
            'pay_user' => $this->orderID,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ( isset($re['code']) && $re['code'] == '200') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            $this->return['str'] =  $this->data['return_type'] == 'code' ? $re['data']['erweima'] : $re['data']['url'];//支付地址
        } else {
            $this->return['code'] = 8;
            $this->return['msg'] = 'XSTZF:' . (isset($re['msg']) ? $re['msg'] : '');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['admin_name']) || !isset($parameters['pay_user']) || !isset($parameters['Price'])) {
            return [
                'status' => 0,
                'error' => "参数错误",
            ];
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['pay_user'],
            'third_order' => $parameters['ddh'],
            'third_money' => $parameters['Price'],
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['error'] = '支付失败';
            return $res;
        }

        if ($parameters['sign'] != $this->_sign($parameters, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }


    /**
     * 生成sign
     */
    private function _sign($pieces, $privateKey)
    {
        $sign1 = md5($privateKey . $pieces['Price']);
        $sign = md5($sign1 . $pieces['admin_name'] . $pieces['pay'] . $pieces['pay_user']);
        return $sign;
    }
}