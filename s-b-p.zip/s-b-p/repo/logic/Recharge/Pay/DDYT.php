<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 鼎鼎代收
 */
class DDYT extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'merchantUsername' => $this->partnerID,
            'outerTradeNo' => $this->orderID,
            'type' => '2',
            'realName' => '',
            'cardNo' => '',
            'bankName' => '',
            'bankAddr' => '',
            'amount'    => sprintf("%.2f", $this->money),//元
            'callbackUrl' => $this->notifyUrl,
        ];

        $data['sign'] = $this->_sign($data, $this->key);
        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 下单签名  strtoupper 大写
     */
    public function _sign($data, $api_key)
    {
        //ksort($data);
        $string = '';
        foreach ($data as $key => $val) {
            $string .= $key . '=' . (string)$val . '&';
        }
        $string .= 'key='.$api_key;
        $sign = strtoupper(md5($string));
        //echo $string;echo "\n";echo $sign;die();
        return ($sign);
    }

    //验证签名 outerTradeNo=20000044000000008&payAt=2021-05-19 19:59:39&payStatus=1&amount=10.00&key=
    public function _sign2($data, $api_key)
    {
        //ksort($data);
        $string = "outerTradeNo=".$data['outerTradeNo'];
        $string .= "&payAt=".$data['payAt'];
        $string .= "&payStatus=".$data['payStatus'];
        $string .= "&amount=".sprintf("%.2f", $data['amount']);
        $string .= '&key='.$api_key;
        $sign = (md5($string));

        //echo $string;echo "\n";echo $sign;die();
        return ($sign);
    }


    public function returnVail($data, $pubkey)
    {
        $signstr = $data['sign'];
        unset($data['sign']);
        //echo $signstr."\n";
        $sign = $this->_sign2($data, $pubkey);
        return $sign == $signstr;
    }


    public function parseRE()
    {

        $re = json_decode($this->re, true);
        //print_r($re);die();
        if (isset($re['success']) && $re['success'] && isset($re['result']['payH5Url'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['result']['payH5Url'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'DDYT：' . (isset($re['message']) ? $re['message'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }

    }

    public function returnVerify($parameters)
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        //var_dump($parameters);die();
        if (!isset($parameters['outerTradeNo']) || !isset($parameters['amount'])) {
            return false;
        }
        header( 'Content-Type: application/json; charset=utf-8; ');
        $res = [
            'status' => 0,
            'order_number' => $parameters['outerTradeNo'],
            'third_order' => $parameters['tradeNo'],
            'third_money' => $parameters['amount'] ,
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->returnVail($parameters,$config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        if ($parameters['payStatus'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单处理中或失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $flag = $this->getQuery($res,$config);
        if($flag !== false){
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $flag;
            return $res;
        }

        $this->updateMoney($res['order_number'], intval($res['third_money'] ));
        $res['status'] = 1;
        return $res;
        //echo '<<<';
        //print_r($res);die();
    }




    //查询订单
    public function getQuery($res,$config){

        //$success = $this->queryOrder($config['payurl'], $res['order_number'], $res['third_order'], $config['partner_id'], $config['key']);
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/order/query';
        }

        //确认已支付状态
        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        if ($success != null && $success != 3 ) {
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $success;
        }
        return false;
    }

    //请求查询
    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            'merchantUsername' => $partnerID,
            "outTradeNo" => $orderNumber,
        ];

        $params['sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->get());
        $re = json_decode($this->re, true);

        //echo '>>>>';print_r($re);die();
        if (isset($re['result']['status'])) {
            return $re['result']['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }




}