<?php
/*
 * 久易支付
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/11
 * Time: 15:52
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;

class JYPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $types = explode('|',$this->payType);
        $service = $types[0];
        $way = $types[1];
        $parameter = [
            'mch_id' => $this->partnerID,
            'out_trade_no' => (string)$this->orderID,
            'body' => 'goods',
            'callback_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
            'total_fee' => $this->money,
            'service' =>$service,
            'way' => $way,
            'format' => 'json',
            'mch_create_ip' => $this->clientIp,
        ];
//        print_r(json_encode($parameter));exit;
        $signStr = $parameter['mch_id'].$parameter['out_trade_no'].$parameter['callback_url'].$parameter['notify_url'].$parameter['total_fee'].$parameter['service'].$parameter['way'].$parameter['format'].$this->key;
        $parameter['sign'] = md5($signStr);
        $this->parameter = $parameter;
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if(isset($re['success']) && $re['success'] == true){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['pay_info'];
        }else{
            $this->return['code'] = 888;
            $this->return['msg'] = 'JYPAY:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        if (!isset($parameters['out_trade_no'])||!isset($parameters['total_fee']))
        {
            return;
        }
        $res = [
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['ordernumber'],
            'third_money' => $parameters['total_fee'],
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['result_code'] != '0'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $this->updateMoney($res['order_number'],$res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }


    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $signStr = $params['mch_id'].$params['time_end'].$params['out_trade_no'].$params['ordernumber'].$params['transtypeid'].$params['transaction_id'].$params['total_fee'].$params['service'].$params['way'].$params['result_code'].$tkey;
        $sign = strtoupper(md5($signStr));
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}