<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * HUAWEIPAY
 * 华为支付
 */
class HUAWEIPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
            //回调不带金额参数，这里先修改，上分直接按金额上分
            \DB::table('order')->where('order_number', $this->orderID)->update(['order_money' => $this->money]);
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $data = [
            'platform_key' => $this->partnerID,
            'money' => $this->money,
            'platform_oid' => $this->orderID,
            'is_h5' => 1,
        ];
        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $key . '=' . $val . '&';
        }

        $string = rtrim($string, '&');
        $string .= $api_key;
        $sign = md5($string);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['result']) && $re['statusCode'] == 1) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['result']['jumpUrl'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'HUAWEIPAY：' . (isset($re['message']) ? $re['message'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['platform_oid']) || !isset($data['sign'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['platform_oid'],
            'third_order' => $data['platform_oid'],
//            'third_money' => $data['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //没有回调金额，直接用下单金额
        $res['third_money'] = $config['order_money'];

        if (!isset($data['timestamp'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败:未获取到timestamp';
            return $res;
        }

        if (!$this->_verifySign($data['sign'], $data['timestamp'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function updateMoney($order_number, $money)
    {
        if ($money <= 0) return true;
        $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no', (string)$order_number)->first(['i_order_no', 'i_money', 'i_uid']);
        $order_info = (array)$order_info;
        if ($order_info == null)
            return true;

        if ($order_info && ($order_info['i_money'] - $money == 0)) {
            return true;
        }

        //如果回调金额+10 还大于订单金额两倍时，说明是异常上分，上分按订单金额来上分
//        if($money > $order_info['i_money'] * 2){
//            return true;
//        }

        \DB::table('order')->where('order_number', $order_number)->update(['order_money' => (int)$money]);
        $updata = array(
            'i_money' => (int)$money,
            'i_gold' => (int)$money,
        );
        \DB::connection('jlmj_config')->table('order_place')->where('i_order_no', $order_number)->update($updata);
        return true;
    }

    private function _verifySign($signOld, $timestamp, $config)
    {
        //【商户key + 金额 + 订单生成时间】
        $signOrgStr = $config['partner_id'] . sprintf("%.2f", $config['order_money']) . $timestamp;
        $decryptStr = $this->pubKeyDecrypt($signOld, $config['key']);
//        var_dump($signOrgStr);
//        var_dump($decryptStr);
        return $decryptStr == $signOrgStr;
    }

    public function pubKeyDecrypt($encrypted, $pubKeyStr)
    {
        $decode64 = $this->urlsafe_b64decode($encrypted);
        if (starts_with($pubKeyStr, '-----BEGIN PUBLIC KEY')) {
            $pub_key = openssl_pkey_get_public($pubKeyStr);
        } else {
            $pub_key = $this->_getPublicKey($pubKeyStr);
        }
        //4096位公钥
        foreach (str_split($decode64, 512) as $chunk) {
            openssl_public_decrypt($chunk, $decryptData, $pub_key);
            $crypto .= $decryptData;
        }
        return $crypto;
    }


}