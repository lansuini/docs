<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 来财
 */
class LAICAI extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'appId' => $this->partnerID,
            'appUserId' => $this->uid,//会员标识
            'handleType' => '0', //0 充值(string)
            'mchGoodName' => 'Goods',
            'mchGoodDescript' => $this->money,
            'mchOrderId' => $this->orderID,
            'digitalCoinType' => '1',//目前只有 1，代表人民币CNY(string)
            'digitalCoinFee' => $this->money,
            'notifyURL' => $this->notifyUrl,
            'payType' => $this->payType, //支付类型  2.支付宝pdd 3.支付宝扫码 5.微信pdd 6.微信扫码 9.支付宝h5
        ];

        //不参与签名字段
        $pub_params = [
            'sign' => $this->getSign($data, $this->key)
        ];
        $this->parameter = array_merge($data, $pub_params);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $key . '=' . $val . '&';
        }

        $string .= 'appSecret=' . $api_key;
        $sign = md5($string);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['data']['qrcode_url']) && $re['code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['qrcode_url'];
            if ($this->data['return_type'] == 'sdk' )
            {
                $content = $re['data']['order_string'];
                if (strpos($content, "%") && !strpos($content, "&")) {
                    $content = urldecode($content);
                }
                $this->return['str'] = $content;

            }
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'laicai：' . (isset($re['msg']) ? $re['msg'] : (isset($this->re) ? $this->re : '请求失败，检查下单域名是否正确'));
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['mchOrderId']) || !isset($data['otOrderId']) || !isset($data['digitalCoinFee'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['mchOrderId'],
            'third_order' => $data['otOrderId'],
            'third_money' => $data['digitalCoinFee'],
            'error' => '',
        ];

        if ($data['state'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['key']);
        return $sign == $signOld;
    }


}