<?php
/**
 * 畅支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/3
 * Time: 15:46
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class CPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        date_default_timezone_set('Asia/Shanghai');
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'sign_type' => 'md5',
            'mch_id' => $this->partnerID,
            'mch_order' => $this->orderID,
            'amt' => $this->money * 1000,
            'remark' => '充值',
            'created_at' => time(),
            'client_ip' => $this->clientIp,
            'notify_url' => $this->notifyUrl,
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter,$this->key);

//        var_dump($this->parameter);exit();
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        $data = $re['data'];
        if ($re && $re['code'] == '1') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];

            if ($this->payType == 'wx') {
                $this->return['str'] = $this->qrcodeUrl . $data['jump_url'];
            }
            else
            {
                if ($this->showType == 'code') {
                    $this->return['str'] = $this->qrcodeUrl . $data['jump_url'];
                } else {
                    $this->return['str'] = $data['jump_url'];
                }
            }
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'CPAY:' . $re['msg'] ?? '未知异常';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $parameters['mch_order'],//商户订单号
            'third_order' => $parameters['mch_order'],//平台流水号
            'third_money' => $parameters['amt']/1000,//支付金额，以厘为单位
            'error' => '',
        ];

        if ($parameters['status'] != '2') {
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($parameters,$config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        $pieces['mch_key'] = $tkey;
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $sign_str = join('&',$string);
        return md5($sign_str);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $re_sign = $params['sign'];
        $params['mch_key'] = $tkey;
        unset($params['sign']);
        ksort($params);
        reset($params);
        $string = [];
        foreach ($params as $key=>$val)
        {
            $string[] = $key.'='.urldecode($val);
        }
        $params_str = join('&',$string);

        $sign = md5($params_str);
        if ($sign == $re_sign){
            if ($params['trade_status'] == 0){
                return true;
            }
            return false;
        }
        return false;
    }
}
