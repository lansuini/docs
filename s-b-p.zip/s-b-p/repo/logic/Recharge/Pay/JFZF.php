<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 聚飞支付
 */
class JFZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $payData = [
            'merchant_id' => $this->partnerID,
            'channel' => $this->payType,
            'money' => $this->money,
            'subject' => 'goods',
            'description' => 'goods',
            'order_no' => $this->orderID,
            'notify_url' => $this->notifyUrl,
            'version' => '1',
            'param' => 'param',
        ];
        $signData = [
            'merchant_id' => $payData['merchant_id'],
            'channel' => $payData['channel'],
            'order_no' => $payData['order_no'],
            'money' => $payData['money'],
            'version' => $payData['version'],
        ];
        $payData['sign'] = $this->getSign($signData,$this->key);
        $this->parameter = $payData;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['status'] === 0) {
            //响应结果
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['data'];
        } else {
            //响应错误信息
            $this->return['code'] = 1;
            $this->return['msg'] = '聚飞支付:' . ($re['message'] ?? 'UnKnow');
            $this->return['way'] = $this->showType;
        }
    }

    public function getSign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . '&' . $tkey;
//        print_r($key);exit;
//        print_r($sign_str);exit;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!(isset($data['status']) && isset($data['order_no']) && isset($data['money']))) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $data['order_no'],
            'third_order' => $data['order_no'],
            'third_money' => $data['money'],
        ];

        if ($data['status'] != 0) {
            $res['error'] = '订单未完成';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }

    private function _verifySign($arr, $key)
    {
        $returnSign = $arr['sign'];
        unset($arr['sign']);
        $signData = [
            'money' => $arr['money'],
            'order_no' => $arr['order_no'],
            'version' => $arr['version'],
        ];
        $sign = $this->getSign($signData, $key);
        return $sign == $returnSign;
    }

}