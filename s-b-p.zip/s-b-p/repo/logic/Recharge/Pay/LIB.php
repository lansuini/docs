<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 利陛
 * @author lavenkin
 */
class LIB extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = [
            'merchantNo' => $this->partnerID,
            'orderNo' => $this->orderID,
            'currency' => 'CNY',
            'goodsTitle' => 'GOODS'.time(),
            'amount' => $this->money * 100,
            'payType' => $this->payType,
            'payTime' => date("Y-m-d H:i:s"),
            'notifyUrl' => $this->notifyUrl,
            'clientIp' => $this->clientIp,
            'timestamp' => date("YmdHis"),
        ];

        $this->parameter['sign'] = strtoupper(md5($this->arrayToURL().$this->key));
    }

    public function parseRE()
    {
        if(in_array($this->payType,['wechat','alipay','QQwallet','yl_qr'])){
            $this->post();
            $re = json_decode($this->re, true);
            if (isset($re['data']) && $re['data']['codeUrl']) {
                $this->return['code'] = 0;
                $this->return['msg'] = 'success';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = $re['data']['codeUrl'];
            } else {
                $msg = $re['errMsg'] ?? '第三方通道返回有误';
                $this->return['code'] = 23;
                $this->return['msg'] = 'LIB：' . $msg;
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }else {
            $this->parameter['clientIp'] = urlencode($this->parameter['clientIp']);
            $this->parameter['notifyUrl'] = urlencode($this->parameter['notifyUrl']);
            $this->parameter['payTime'] = urlencode($this->parameter['payTime']);
            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . $this->payUrl;
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        }
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 0,
            'order_number' => $data['orderNo'],
            'third_order' => $data['orderNo'],
            'third_money' => $data['amount'] / 100,
            'error' => '',
        ];

        if ($data['status'] != 1) {
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($data['orderNo']);
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }
        $this->parameter = [
            'merchantNo' => $data['merchantNo'],
            'orderNo' => $data['orderNo'],
            'amount' => $data['amount'],
            'status' => $data['status'],
            'transTime' => $data['transTime'],
        ];
        if (strtolower($data['sign']) != strtolower(md5($this->arrayToURL().$config['key']))) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
