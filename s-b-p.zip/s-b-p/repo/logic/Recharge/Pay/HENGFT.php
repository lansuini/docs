<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 恒丰泰
 * @author zhangli
 */
class HENGFT extends BASES
{

    //与第三方交互
    public function start()
    {

        $this->initParam();

        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = array(
            'merchant_number' => $this->partnerID,
            'order_id' => $this->orderID,
            'order_time' => time(),
            'pay_type' => $this->data['bank_data'],
            'version' => 2,
            'cash' => sprintf('%.2f', $this->money),
            'server_url' => $this->notifyUrl,
            'brower_url' => $this->returnUrl
        );
        $this->parameter['sign'] = $this->sytMd5($this->parameter, $this->key);
    }


    public function sytMd5($piecess, $key)
    {
        ksort($piecess);
        $string = '';
        foreach ($piecess as $k => $v) {
            $string .= $k . "=" . $v . "&";
        }
        $string = $string . 'key=' . $key;
        $sign = strtolower(md5($string));
        return $sign;
    }

    public function parseRE()
    {
        $this->basePost();
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == '0') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['qr_code_url'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = '恒丰泰:' . $re['msg'] ?? "未知异常";
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        $res = [
            'status' => 1,
            'order_number' => $input['order_id'],
            'third_order' => '',
            'third_money' => $input['cash'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($input['order_id']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        $sign = $input['sign'];
        $newSign = $this->getVerify($input, $config['key']);
        if ($newSign != $sign) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    public function getVerify($respData, $key)
    {
        unset($respData['sign']);
        if(isset($respData['s'])) {
            unset($respData['s']);
        }
        $signStr =$this->sytMd5($respData,$key);
        return $signStr;
    }

}
