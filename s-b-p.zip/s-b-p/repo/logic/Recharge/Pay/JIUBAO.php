<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - 新玖宝支付
 */
class JIUBAO extends BASES
{

    public function start()
    {
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'pay_amount' => $this->money,
            'pay_applydate' => date('Y-m-d H:i:s'),
            'pay_bankcode' => $this->data['bank_data'],
            'pay_callbackurl' => $this->returnUrl,
            'pay_memberid' => $this->partnerID,
            'pay_notifyurl' => $this->notifyUrl,
            'pay_orderid' => $this->orderID,
        ];

        $this->parameter['pay_md5sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
//        $result=$this->re;
//        //get请求返回表单，通过正则处理返回到系统前端处理跳转
//
//        //返回数据不是表单，就是提交错误
//        if (!preg_match('/form/', $result)) {
//            $this->return['code'] = 23;
//            $this->return['msg'] = 'JIUBAO：' . $result;
//            $this->return['way'] = $this->data['return_type'];
//            $this->return['str'] = null;
//            return;
//        }
//
//        preg_match('/method=\"([^\"]+)\"/', $result, $method);
//        preg_match('/action=\"([^\"]+)\"/', $result, $url);
//        // <input type="hidden" name="pay_memberid"  value="10069">
//        preg_match_all( '/name[\s]*?=[\s]*?([\'\"])(.*?)\1/', $result, $matchesNames);
//
//        preg_match_all( '/value[\s]*?=[\s]*?([\'\"])(.*?)\1/', $result, $matchesValue);
//
//        $method = strtoupper($method[1]);
//        $url = $url[1];
//        $data = [];
//
//        $matchesName=($matchesNames[2]);
//        unset($matchesName[0]);
//        array_merge($matchesName);
//        foreach ($matchesName as $index => $match) {
//            $data[$match] = $matchesValue[2][$index-1];
//        }
//        $this->parameter = $data;
//        $this->parameter = $this->arrayToURL();
//
//        if ($method == 'GET') {
//            //method为get是微信支付，直接返回前端进行跳转
//            $this->jumpURL = $url;
//        } else if ($method == 'POST') {
//            //method为post是支付宝，拼接参数返回前端
//            $this->parameter .= '&url=' . $url;
//            $this->parameter .= '&method=POST';
//        }
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }


    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['orderid'],
            'third_order' => $data['orderid'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderid']);
        // var_dump($data);exit;
        if ($data['returncode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        unset($data['sign']);
        unset($data['attach']);
        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);

        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string .= 'key=' . $key;
        $sign = strtoupper(sha1($string));
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {

        $sign = $this->_sign($pieces, $key);

        return strtoupper($thirdSign) == $sign;
    }
}