<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;


/**
 * 新欢快支付
 * @author zhangli
 */
class HUANPAY extends BASES
{

    //与第三方交互
    public function start()
    {

        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $reqs = array(
            'companyId' => $this->partnerID,
            'orderId' => $this->orderID,
            'productValue' => $this->money,
            'payType' => $this->data['bank_data'],
            'timestamp' => $this->msectime(),
            'notifyUrl' => $this->notifyUrl,
            'nonce' => $this->getRandstr(),
        );

        $reqs['sign'] = $this->_sign($reqs, $this->key);
        $string = [];
        foreach ($reqs as $key => $val) {
            if ($val != null && $val != '') {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);
        $this->parameter = array(
            'companyId' => $reqs['companyId'],
            'token' => base64_encode($params),
        );

    }

    public function getRandstr()
    {
        return strtolower(md5(uniqid(mt_rand(), true)));
    }

    //返回当前的毫秒时间戳
    function msectime() {
        list($msec, $sec) = explode(' ', microtime());
        $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);

        return $msectime;
    }


    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($val != null && $val != '') {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);
        $sign_str = $params . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }


    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['code'] == '200') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['autoCode'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'HUANPAY:' . $re['message'] ?? "未知异常";
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        global $app;
        $input = $app->getContainer()->request->getParams();
        unset($input['s']);

        if (!isset($input['orderId']) || !isset($input['price'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $input['orderId'],
            'third_order' => $input['billId'],
            'third_money' => $input['price'],
            'error' => '',
        ];

        if ($input['status'] != '3') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($input['orderId']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($input, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        $order_number = $input['orderId'];
        $return_money = intval($input['price']);

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    public function returnVail($data, $pubkey)
    {
        $signstr = $data['sign'];
        unset($data['sign']);
        $sign = $this->_sign($data, $pubkey);
        return $sign == $signstr;
    }
}
