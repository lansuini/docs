<?php
/**
 * 汇通
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HUITONG extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'agentNo' => $this->data['app_id'],
            'merchantNo' => $this->partnerID,
            'orderAmount' => $this->money * 100,
            'outOrderNo' => $this->orderID,
            'notifyUrl' => $this->notifyUrl,
            'callbackUrl' => $this->returnUrl,
            'productName' => 'sp',
            'acqCode' => $this->payType,
        ];
        //秘钥存入 token字段中
        $this->parameter['sign'] = md5($this->arrayToURL() . $this->key);
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
//        print_r($this->re);exit;
//        $re = json_decode(trim($this->re, chr(239) . chr(187) . chr(191)), true);
        if (isset($re['status']) && $re['status'] == 'T') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['payUrl'];

        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'HUITONG:' . $re['errMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
        $res = [
            'status' => 1,
            'order_number' => $data['outOrderNo'],
            'third_order' => $data['orderNo'],
            'third_money' => $data['orderAmount'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['outOrderNo']);
        // var_dump($data);exit;
        if ($data['orderStatus'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        unset($data['sign']);
        $this->parameter = $data;
        if (strtoupper($sign) != strtoupper(md5($this->arrayToURL() . $config['key']))) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
//        print_r($res);exit;
        return $res;
    }

}