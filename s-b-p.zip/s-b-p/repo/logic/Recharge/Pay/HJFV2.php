<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 慧捷付V2
 */
class HJFV2 extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->parameter = [
            'mer_id' => $this->partnerID,
            'bank_code' => $this->payType,
            'amount' => $this->money,
            'order_id' => $this->orderID,
            'notify_url' => $this->notifyUrl,
        ];

        $this->parameter['sign'] = $this->getSign($this->parameter, $this->key);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && isset($re['pay_url']) && $re['code'] == '20000') {
            //响应结果
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['pay_url'];
        } else {
            //响应错误信息
            $this->return['code'] = 1;
            $this->return['msg'] = 'HJFV2:' . ($re['msg'] ?? 'UnKnow');
            $this->return['way'] = $this->showType;
        }
    }

    public function getSign($arr, $api_key)
    {
        $str = sprintf("amount=%s&bank_code=%s&mer_id=%s&notify_url=%s&order_id=%s&key=%s", $arr['amount'], $arr['bank_code'], $arr['mer_id'], $arr['notify_url'], $arr['order_id'], $api_key);
        return md5($str);
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res = [
            'status' => 0,
            'order_number' => $data['order_id'],
            'third_money' => $data['amount'],
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }

    private function _verifySign($arr, $key)
    {
        $returnSign = $arr['sign'];
        $str = sprintf("amount=%s&mer_id=%s&order_id=%s&pay_state=%s&key=%s", $arr['amount'], $arr['mer_id'], $arr['order_id'], $arr['pay_state'], $key);
        $sign = md5($str);
        return $sign == $returnSign;
    }

}