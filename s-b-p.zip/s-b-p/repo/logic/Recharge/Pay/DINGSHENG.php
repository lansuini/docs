<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

//鼎盛支付SDK的第三方回调
class DINGSHENG extends BASES{
    /**
     * 生命周期
     */
    public function start(){
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data){
        global $app;
        $data = $app->getContainer()->request->getParams();
        if(isset($data['s'])) unset($data['s']);
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['out_trade_no'],//商户订单号
            'third_order' => $data['order_no'],//第三方交易号
            'third_money' => $data['total_fee'],//实际支付金额，以元为单位
            'error' => '',
        ];


        $config = Recharge::getOriginThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($data['mch_id'] != $config['partner_id']) {
            $res['error'] = '回调商户号和系统商户号不一致';
            return $res;
        }

        //签名校验
        $result = $this->verifyRsaSign($data, $config['pub_key']);
        if ($result === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateZfbMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    //更新金额
    public function updateZfbMoney($order_number, $money){
        $order_info = (array)\DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
        if ($order_info && ($order_info['i_money'] - $money == 0)){
            return true;
        }

        \DB::table('zfb_order')->where('order_number', $order_number)->update(['order_money' => (int)$money]);
        $updata = array(
            'i_money' => (int)$money,
            'i_gold' => (int)$money,
        );
        \DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_no', $order_number)->update($updata);
    }

    public function verifyRsaSign($params, $public_key){
        if (is_null($public_key)) {
            return false;
        }
//        $params['mch_id'] = 100000;//测试商户号
//        $public_key = 'SE4g9S4jTh5kYX5AW0kniNpQNLjCNeHt';//测试密钥
        $sign = $params['sign'];
        unset($params['sign']);
        $params['mch_secret'] = $public_key;
        ksort($params);
        $signPars = '';
        foreach($params as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        $sys_sign = strtoupper(md5($signPars));
        return $sign == $sys_sign;
    }
}