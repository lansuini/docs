<?php
/**
 * 大G支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class DGZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'merchant_no' => (string)$this->partnerID,
            'out_order_no' => (string)$this->orderID,
            'type' => (string)$this->payType, //bank_data
            'amount' => $this->money,
            'product_name' => 'goods',
            'return_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
            'ip' => $this->clientIp
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $data = json_decode($this->re, true);
        if (isset($data['code']) && $data['code'] == '200') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $data = $data['data'];
            if (isset($data['html']) && $data['html'] != '')
            {
                $this->return['str'] = $this->jumpURL . '?method=HTML&html=' . base64_encode($data['html']);;

            }
            else
            {
                $this->return['str'] = $data['url'];
            }
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = $data['message'];
            $this->return['way'] = $this->data['return_type'];
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['order_no']) || !isset($parameters['amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['out_order_no'],
            'third_order' => $parameters['order_no'],
            'third_money' => $parameters['amount'],
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($parameters['state'] != '1') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        if ($parameters['sign'] != $this->_sign($parameters, $config['key'])) {
            $res['error'] = '验签失败！';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        unset($params['sign']);
        $string = "";
        foreach ($params as $key => $val) {
            if ($val != '')
            {
                $string = $string ? $string . "&" . $key . "=" . $val : $key . "=" . $val;
            }
        }
        $string = $string . '&key=' . $tKey;
        $sign = strtoupper(md5(utf8_encode($string)));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        unset($params['attach']);
        foreach ($params as $key => $val) {
            $params[$key] = urldecode($val);
        }
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }
}