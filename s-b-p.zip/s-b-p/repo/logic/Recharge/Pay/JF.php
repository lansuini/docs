<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 银牛玖付
 */

class JF extends BASES 
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        //$this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        date_default_timezone_set('Asia/Shanghai');
        //$this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'downNum' => $this->partnerID,
            'payService' => (string)$this->payType, 
            'amount' => (int)($this->money*100),
            'orderDown' => (string)$this->orderID,
            'subject' => "充值",
            "version" =>"1.0",
            'notifyUrl' => $this->notifyUrl,
            'time' => date('Y-m-d H:i:s',time()),
            'clientIp' => $this->data['client_ip'],
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter);
        $json = json_encode($this->parameter);
        $this->curlPost($json);
        //var_dump($this->parameter);exit;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    
    function curlPost($referer = null)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->payUrl);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $referer);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($referer)
        ));
        $response = curl_exec($ch);
        $this->curlError = curl_error($ch);
        $this->re = $response;
    }

    public function parseRE()
    {
        //var_dump($this->re);exit;
        $result = json_decode($this->re, true);
        if ($result && $result['status'] ==1) { 
            $this->return['code'] = 0;
            $this->return['msg']  = 'success';
            $this->return['way']  = $this->data['return_type'];;
            $this->return['str']  = $result['data']['payInfo'];
        }else{
            $this->return['code'] = 9999;
            $this->return['msg'] = 'JF: ' . $result['msg'];
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $sign_res = [
            'orderStatus' => $parameters['orderStatus'],
            'orderDown' => $parameters['orderDown'],
            'orderId' => $parameters['orderId'],
            'amount' => $parameters['amount']/100,
            'time' => $parameters['time'],
        ];
        $res = [
            'status' => 1,
            'order_number' => $parameters['orderDown'],
            'third_order'  => $parameters['orderId'],
            'third_money'  => $parameters['amount']/100,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($parameters['orderDown']);
        if (!$config) {
            $res['status'] = 0;
            $res['error']  = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($sign_res, $parameters['sign'],$config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key=>$val)
        {
            $string = $string.$key.'='.$val.'&';
        }
        $string = $string.'key='.$this->key;
        //var_dump($string);exit;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$re_sign,$tkey)
    {
        ksort($params);
        reset($params);
        $string = '';
        foreach ($params as $key=>$val)
        {
            $string = $string.$key.'='.$val.'&';
        }
        $string = $string.'key='.$tkey;
        $sign = strtoupper(md5($string));
        if ($sign == $re_sign){
                return true;
        }
        return false;
    }
}