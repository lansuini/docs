<?php
/**
 * 汇旺支付
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HWZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'mercId' => (string)$this->partnerID,
            'channel' => (string)$this->payType, //bank_data
            'amount' => $this->money,
            'mercOrderId' => (string)$this->orderID,
            'pay_callbackurl' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,
            'time' => time(),
            'productName' => $this->orderID
        ];
        //var_dump($pub_params);exit();
        $pub_params['sign'] = $this->_sign($pub_params,$this->key);
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if (isset($re['code']) && $re['code']=='0'){
            $data = $re['data'];
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['qrCode'];

        }else{
            $this->return['code'] = $re['code'];
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        if (!isset($parameters['mercOrderId']))
        {
            // 非法数据
            return false;
        }

        $res = [
            'order_number' => $parameters['mercOrderId'],
            'third_order' => $parameters['orderId'],
            'third_money' => $parameters['txnAmt'],
        ];
        $config = Recharge::getThirdConfig($parameters['mercOrderId']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['orderStatus'] != 'paid'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $dStr = http_build_query($pieces);
        return md5($dStr . $tkey);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        ksort($params);
        $string = [];
        foreach ($params as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $dStr = join('&',$string);
        $sign = md5($dStr .$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}