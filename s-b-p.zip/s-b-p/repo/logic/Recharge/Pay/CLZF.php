<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 畅联支付
 */
class CLZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        /**
         * 支付宝-个码
        alipay
        支付宝-App
        alipay-app
        支付宝-现金红包
        alipay-cash-bonus
        支付宝-H5
        alipay-h5
        支付宝-转账码
        alipay-transfer-qr
        微信-个码
        wechat
        微信-手机号转账
        wechat-phone-transfer
        微博红包
        weibo-redpacket
         */
        //参与签名字段
        $data = [
            'mchId' => $this->partnerID,
            'transactionId' => $this->orderID,
            'amount' => $this->money * 100,//分
            'memo' => 'Goods',
            'channel' => $this->payType, //支付类型
            'outMemId' => $this->uid,
            'callbackUrl' => $this->notifyUrl,
            'ip' => $this->clientIp,
        ];

        //不参与签名字段
        $pub_params = [
            'sign' => $this->getSign($data, $this->key)
        ];
        $this->parameter = array_merge($data, $pub_params);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        $string = $api_key;
        ksort($pieces);
        foreach ($pieces as $key => $val) {
            if ($val !== '' && $val !== null && $key !== 'sign') {
                $string = $string . '&' . $key . '=' . $val;
            }
        }
        $sign = md5($string);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['urls']) && $re['status'] === 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['urls']['orderUrl'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '畅联：' . (isset($re['message']) ? $re['message'] : '下单失败');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['transactionId']) || !isset($data['id']) || !isset($data['userPayAmount'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['transactionId'],
            'third_order' => $data['id'],
            'third_money' => $data['userPayAmount'] / 100,
            'error' => '',
        ];

        if ($data['status'] != 3) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['key']);
        return $sign == $signOld;
    }


}