<?php
/**
 * A码支付（小辣椒）
 * @author Taylor 2019-04-30
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class LAJIAOPAY extends BASES {

    //与第三方交互
    public function start(){
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam(){
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            //基本参数
            'pid' => $this->partnerID,//商户号
            'money' => number_format($this->money,2,'.',''),//订单金额为元，精确到小数点后两位
            'out_trade_no' => $this->orderID,//商户订单号
            'channel' => $this->payType,//支付通道
            'returnUrl' => $this->notifyUrl,//异步通知URL
            'ip' => $this->clientIp,//客户ip
        );
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 生成sign
     */
    private function _sign($p, $tkey)
    {
        $sign = md5($p['pid'].$p['money'].$p['out_trade_no'].$tkey);//MD5加密串
        return $sign;
    }

    public function parseRE(){
        $re = json_decode($this->re, true);
        //{"code":200,"msg":"下单成功","redirectUrl":"http://ext.593ny.com/AlipayPrecreate/Index/71201904301624140704"}
        if ($re['code'] == 200) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            $this->return['str'] = $re['redirectUrl'];//支付地址
        } else {
            $this->return['code'] = 8;
            $this->return['msg'] = 'LAJIAO:' . (isset($re['msg']) ? $re['msg'] : '');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     * [status=1 通过  0不通过,
     * order_number = '订单',
     * third_order = 第三方订单,
     * third_money ='金额',
     * error'='未有该订单/订单未支付/未有该订单']
     * @param
     * @return boolean
     */
    public function returnVerify($data) {
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['out_trade_no'],//商户订单号
            'third_order' => $data['out_trade_no'],//系统订单号
            'third_money' => $data['payMoney'],//支付金额
            'error' => '',
        ];

        if ($data['status'] != 2) {//1未支付 2已支付 3已撤销  4超时
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($p, $tkey)
    {
        $sign = md5($p['pid'].$p['money'].$p['out_trade_no'].$tkey);//MD5加密串
        if ($sign == $p['sign']){
            return true;
        }
        return false;
    }
}
