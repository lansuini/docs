<?php
/**
 * 金掌柜支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/14
 * Time: 9:47
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class JZGZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'userId' => '1',
            'cpId' => $this->partnerID,
            'payType' => (string)$this->payType,
            'cpOrderId' => (string)$this->orderID,
            'notifyUrl' => $this->notifyUrl,
            'price' => $this->money * 100,
        ];
        $pub_params['sign'] = $this->_sign($pub_params,$this->key);
        //var_dump($pub_params);exit();
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if ($re['status'] == '200'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['payUrl'];
        }else{
            $this->return['code'] = $re['status'];
            $this->return['msg'] = $re['statusDes'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['cpOrderId'],
            'third_order' => $parameters['orderId'],
            'third_money' => $parameters['price'] / 100,
        ];
        $config = Recharge::getThirdConfig($parameters['cpOrderId']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        $signStr = 'cpOrderId=' . $pieces['cpOrderId'] . '|cpId=' . $pieces['cpId'] . '|userId=' . $pieces['userId'] . '|payType=' . $pieces['payType'] . '|notifyUrl=' . $pieces['notifyUrl'] . '|price=' . $pieces['price'] . '|key=' . $tkey;
        return md5($signStr);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $signStr = 'cpOrderId=' . $params['cpOrderId'] . '|cpId=' . $params['cpId'] . '|price=' . $params['price'] . '|orderId=' . $params['orderId'] . '|status=' . $params['status'] . '|statusDes=' . $params['statusDes'] . '|key=' . $tkey;
        $sign = md5($signStr);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}