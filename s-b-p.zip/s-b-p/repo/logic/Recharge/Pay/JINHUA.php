<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 金花支付
 */
class JINHUA extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = array(
            'user_id' => $this->partnerID,
            'channel' => $this->payType,
            'ip' => $this->clientIp,
            'order_id' => $this->orderID,
            'amount' => $this->money,
            'level' => array(0, 1, 2, 3, 4, 5),
            'notify_url' => $this->notifyUrl,
            'return_url' => '',
            'redirect' => false,//是否直接跳转
        );

        list($json, $sign) = $this->make_sign($this->key, $data);

        //不参与签名字段
        $pub_params = [
            'sign' => $sign
        ];

        //请求
        $this->make_request($this->payUrl, $json, $sign);

        $this->parameter = array_merge($data, $pub_params);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    function make_sign($api_key, $param)
    {
        $param['sign_method'] = 'sha256';

        $post = json_encode($param);
        $hash = hash('sha256', $post);
        $sign = hash('sha256', $hash . $api_key);

        return array($post, $sign);
    }

    function make_request($url, $json, $sign)
    {
        $url = $url . '?sign=' . $sign;

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($json)
            )
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $response = curl_exec($curl);
        //保存日志参数
        $this->re = $response;
    }

    public function getSign($pieces, $api_key)
    {
        $pieces['sign_method'] = 'sha256';
        $post = json_encode($pieces);
        $hash = hash('sha256', $post);
        $sign = hash('sha256', $hash . $api_key);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['ok']) && $re['ok'] == true && isset($re['data']['url'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['url'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'JINHUA：' . (isset($re['msg']) ? $re['msg'] : ($this->re ?? "请求支付失败"));
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $sign = $data['sign'];

        $body = file_get_contents('php://input');
        $data = json_decode($body, true);

        if (!(isset($data['order_id']) && isset($data['amount']))) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['order_id'],
            'third_order' => $data['order_id'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        if ($data['status'] != 5) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        $hash = hash('sha256', $body);
        $sign_check = hash('sha256', $hash . $config['key']);

        if ($sign !== $sign_check) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }


}