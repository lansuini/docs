<?php
/**
 * Blue掌Pay支付
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;
use Utils\Client;

class BLUEPAY extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->basePost();
        $this->parseRE();

    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'merchant_no' => (string)$this->partnerID,
            'order_time'=>date('YmdHis'),
            'order_money' => sprintf("%.2f", $this->money),
            'product_name'=>'GOODS',
            'pay_type_id' => (string)$this->payType, //bank_data
            'order_no' => (string)$this->orderID,
            'pay_ip'=>Client::getIp(),
//            'bank_code'=>$this->data['bank_code'],
            'redirect_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
//            'remark' =>time() * 1000,
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;
//        var_dump( json_encode($this->parameter,JSON_UNESCAPED_UNICODE));
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['returnCode']) && $re['returnCode'] == '0') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['content'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'BluePay:' . (isset($re['message']) ? $re['message'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['merchant_no']) || !isset($parameters['order_no']) || !isset($parameters['order_money'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['order_no'],
            'third_order' => $parameters['platformNo'],
            'third_money' => $parameters['order_money'],
        ];
        $config = Recharge::getThirdConfig($parameters['order_no']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        if ($parameters['platformPayStatus'] != 'success') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }


        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        $arr = parse_url($config['payurl']);
        if (empty($url)) {
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/layPayment/orderQuery';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != 'success') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($val != null && $val != '') {
                $string[] = $key . '=' . $val;
            }
        }
        $sign_str = join('&', $string).$tkey;
        return md5($sign_str);
    }

    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "merchant_no" => $partnerID,
            "order_no" => $orderNumber,
        ];

        $params['sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());
        $re = json_decode($this->re, true);
        if (isset($re['content']['platformPayStatus'])) {
            return $re['content']['platformPayStatus'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}