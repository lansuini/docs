<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 东方支付
 */
class DFZF extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        $this->initParam();
//        $this->payJson2();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $parameter = [
            'memberid' => $this->partnerID,
            'orderid' => (string)$this->orderID,
            "applydate" => time(),
            "bankcode"  => $this->payType,
            "amount"    => $this->money,
            "callbackurl" => $this->returnUrl,
            "notifyurl" => $this->notifyUrl,
            "ddlx" => '0',
        ];
        //秘钥存入
        $parameter['md5sign'] = $this->_sign($parameter, $this->key);
        $parameter['productname'] = 'goods';
        $parameter['serverReturnType'] = '1';
        $parameter['clientip'] = $this->clientIp; //玩家的IP定位地址，非商家平台的IP，获取玩家的IP定位后上传，有助于提升玩家的入款成功率;

        $this->parameter = $parameter;
    }


    //返回参数
    public function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl('json');
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    //签名验证
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);

        $res = [
            'status' => 0,
            'order_number' => $result['outtradeid'],
            'third_order' => $result['orderid'],
            'third_money' => $result['realamount'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($result['outtradeid']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if (!isset($result['returncode']) || $result['returncode'] != '000000'){
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }
        $signResult = $this->returnVail($result, $config['key']);
        if (!$signResult) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        $res['status'] = 1;
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['md5sign'];
        unset($params['md5sign']);

        $sign = $this->_sign($params, $tkey);

        if ($sign != $return_sign){
            return false;
        }
        return true;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign_str = $string.'key='.$tKey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }
}