<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * AA支付
 */
class AAPAY extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'aa_merchant' => $this->partnerID,
            'aa_amount' => (int)($this->money * 100),
            'aa_pay_type' => $this->payType,
            'aa_order_no' => $this->orderID,
            'aa_order_time' => time(),
            'aa_subject' => 'GOODS',
            'aa_notify_url' => $this->notifyUrl,
            'aa_callback_url' => $this->returnUrl,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {

        $re = json_decode($this->re, true);
//        print_r($re);exit;
        if ($re && $re['code'] == "0000") {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            if ($this->data['return_type'] == 'code') {
                $urlParams = parse_url($re['result']['qrCode']);
                if ($urlParams['query']) {
                    $params = $this->convertUrlQuery($urlParams['query']);
                    $query = '';
                    foreach ($params as $k => $param) {
                        $query .= $k . '=' . $param . '&';
                    }
                    $query = substr($query, 0, strlen($query) - 1);
                    $url = $urlParams['scheme'] . '://' . $urlParams['host'];
                    if ($urlParams['port']) {
                        $url = $url . ':' . $urlParams['port'];
                    }
                    $url = $url . $urlParams['path'] . '?' . $query;
                }else{
                    $url = $re['result']['qrCode'];
                }
                $this->return['str'] = $this->qrcodeUrl . urlencode($url);
//                $this->return['str'] = $this->qrcodeUrl . urlencode($re['result']['qrCode']);
            } else {
                $this->return['str'] = $re['result']['qrCode'];
            }
        } else {
            $this->return['code'] = $re['code'];
            $this->return['msg'] = 'AA支付:' . $re['msg'] ?? '未知异常';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    public function convertUrlQuery($query)
    {
        $queryParts = explode('&', $query);
        $params = array();
        foreach ($queryParts as $param) {
            $item = explode('=', $param);
            $params[$item[0]] = $item[1];
        }
        return $params;
    }

    /**
     * 回调验证处理
     */
    public function returnVerify($params)
    {
        $dataString = $params['notify_msg'];

        $data = json_decode($dataString, true);
        $res = [
            'status' => 0,
            'order_number' => $data['aa_orderId'],
            'third_order' => $data['aa_tranNo'],
            'third_money' => $data['aa_amount'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['aa_orderId']);
        // var_dump($data);exit;
        if ($data['trade_status'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $sign = $params['sign'];
        if (array_key_exists('s', $data)) {
            unset($data['s']);
        }
        unset($params['sign']);

        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);

        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string .= 'key=' . $key;
        $sign = sha1($string);
//        print_r($string);
//        print_r("\n");
//        print_r($sign);
//        exit;
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {
        $pieces = json_encode($pieces, JSON_UNESCAPED_UNICODE);
        $string = $pieces . '&key=' . $key;
        $sign = strtoupper(sha1($string));

        return $thirdSign == $sign;
    }
}