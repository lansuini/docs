<?php
/**
 * 捷付支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/30
 * Time: 10:03
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JFPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $rand = rand(1,10);
        $money = $this->money+($rand/100);
        $pub_params = [
            'bank_code' => '',
            'service_type' => (string)$this->payType, //bank_data
            'amount' => sprintf("%.2f", $money),
            'platform' => 'PC',
            'merchant_order_no' => (string)$this->orderID,
            'callback_url' => $this->notifyUrl,
            'merchant_user' => $this->_randSrting(),
            'risk_level' => 1,
        ];
        $this->parameter = $pub_params;
        $data = $this->_encrypData();
        //var_dump($pub_params);exit();
        $this->parameter = [
            'merchant_code' => (string)$this->partnerID,
            'data' => $data,
        ];
        $this->parameter['sign'] = $this->_sign($data,$this->key);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if ($re['status'] && $re['status'] == 1){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $re_data = $this->decrypt($re['data'],$this->key);
            $re_data = json_decode($re_data,true);
            $this->return['str'] = $re_data['transaction_url'];

        }else{
            $this->return['code'] = $re['error_code'];
            $this->return['msg'] = 'JFPAY:'.$re['error_code'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }
    //私钥解密
    public function decrypt($data,$key, $code = 'base64', $padding = OPENSSL_PKCS1_PADDING, $rev = false)
    {
        $ret = false;
        $data = base64_decode($data);
        if ($data !== false) {
            $key  = $this->_getPrivateKey($key);
            $enArray = str_split($data, 256);
            foreach ($enArray as $va) {
                openssl_private_decrypt($va,$decryptedTemp,$key);//私钥解密
                $ret .= $decryptedTemp;
            }
        }else
        {
            return false;
        }

        return $ret;
    }
    //公钥加密业务数据
    public function _encrypData()
    {
        $this->pubKey  = $this->_getPublicKey($this->pubKey);
        $openssl_encry = $this->pukOpenssl();
        return $openssl_encry;
    }

    /**
     * 整理私钥
     * @param $pkey
     * @return string
     */
    private function _getPrivateKey($pkey)
    {
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\r\n";
        foreach (str_split($pkey,64) as $str){
            $private_key = $private_key . $str ;
        }
        $private_key .=  "\r\n-----END RSA PRIVATE KEY-----";
        $key = openssl_get_privatekey($private_key);
        return $key;
    }

    /**
     * 整理公钥
     * @param $key
     * @return string
     */
    private function _getPublicKey($key)
    {
        $pubkey = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($key,64) as $str){
            $pubkey = $pubkey . $str ;
        }
        $pubkey .= "\r\n-----END PUBLIC KEY-----";
        $rekey = openssl_pkey_get_public($pubkey);
        return $rekey;
    }

    public function depositCallback($data,$key){
        $decodeStr = base64_decode($data);
        $enArray = str_split($decodeStr, 256);
        $decrypted='';
        $key = $this->_getPrivateKey($key);
        foreach ($enArray as $va) {
            openssl_private_decrypt($va,$decryptedTemp,$key);//私钥解密
            $decrypted .= $decryptedTemp;
        }
        $result=$decrypted;
        return  $result;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $data = urldecode($parameters['data']);
        //查找密钥
        $pay_info = \DB::table('pay_config')->where('partner_id',(string)$parameters['merchant_code'])->first(['key','pub_key','partner_id','channel_id']);
        $pay_info = (array)$pay_info;
        $re_data = $this->depositCallback($data,$pay_info['key']);
        if (empty($re_data)){
            $res['status'] = 0;
            $res['error'] = '订单参数解密错误';
            return $res;
        }
        $re_data = json_decode($re_data,true);
        $res = [
            'order_number' => $re_data['merchant_order_no'],
            'third_order' => $re_data['trans_id'],
            'third_money' => $re_data['amount'],
        ];
        $config = Recharge::getThirdConfig($re_data['merchant_order_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['pub_key']);
        if ($result) {
            $order_number = $re_data['merchant_order_no'];
            $return_money = intval($re_data['amount']);
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$key)
    {
        $key  = $this->_getPrivateKey($key);
        openssl_sign($pieces,$sign_info,$key,OPENSSL_ALGO_SHA1);
        $sign = base64_encode($sign_info);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $re_sign = urldecode($params['sign']);
        $tkey = $this->_getPublicKey($tkey);
        $tmp_sign=openssl_verify( (urldecode($params['data'])), base64_decode(($re_sign)), $tkey  );   //平台公钥验签
        $result=$tmp_sign;
        return  $result;
    }
    private function _randSrting()
    {
        $str="QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
        str_shuffle($str);
        $name=substr(str_shuffle($str),26,6);
        return $name;
    }
}
