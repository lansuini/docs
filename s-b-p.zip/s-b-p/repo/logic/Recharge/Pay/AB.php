<?php
/**
 * Created by PhpStorm.
 * User: benchan
 * Date: 2019/6/1
 * Time: 10:26
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
class AB extends BASES
{
    //爱贝
    public function start(){

    }

    public function returnVerify($data)
    {
        global $app;
        $notifyData = $app->getContainer()->request->getParams();
        // if(isset($data['s'])) unset($data['s']);
        // file_put_contents('/data/logs/php/test123.log', json_encode($notifyData)."\n", FILE_APPEND);
        $data = json_decode($notifyData['transdata'],true);
        $default = [
            'appid' => '5003350681',
            'payurl' => 'https://siapcn1.ipengtai.com',
            'cpvkey' => 'MIICXQIBAAKBgQCsjGvXPuMnug2J12M+gcH2jB4CyKgXp02uhwM7YTU6Oi/t7U1xSaE3+MX8/3sGe3tJSIQj+ofhA2Vx2iw8DzvtvPxtiKl9DIqhVIQYCjK1YadJvULY0I/Tsi/6VgfmAEtA0KfSBA5JiVyJcV/QQKazZCEkWL5VvIac8e02gcV80QIDAQABAoGAW3L43NWZsr5q2nlrQf+nezH73eHXJOIoy60Gy3vTqA6axHEWsEojxfR1iock/uSHDOoADsmDJoCUTWkiNJqmWZSv1hHPEm6IkifS59xsBocpM6+96nvwXH8BwJELcb8a+bcPCWgjeFkS53fSZkyDB4kZVdnpHSvgeC7tArNO4VkCQQDfocCmVa2+ZrCngR4wG9/k7lei5IxjTufJaHH7F+FOICyxytApcPEO2DwystXtNRObrWxRCaao+FIwbFe/YQgbAkEAxYXf3BVtAMoArmOw/nwM9kpIIw2x/ZZa1kNuNto9mvnaiyRoQ1NMzM3pjH4HM9hOi+95VELocINAOIZiyd51gwJBANl9XXgnUX8gLePqHerZ4SiraA2iyqn2XlQxwNBbjCJIBk+vGD2FetteD0WbSZSVjwlTY0l44l3oiz5O0BPvEUsCQQCFtyFazi5ikF1xsQ9K2BO2T4cSI91QvI516mQcQhXeajJma5khqqydIPBwKYkasd5KoS1Tu4+7Sz8YhPEvk6edAkB7E9vE7I+n1AJZoEDdTz/94vC0bsZQuPSOYkmQlTeYtj3yBZ032tpzANRW8x8z1erNL861Wxd3+NXG5jTrXrTM',
            'platpkey' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCELqzf5kvgeIyChNj8KmCSdC3pCTeWFy16KboUj2qiay/e/emPaoETAISP9BVeVH2RFaJ4Yat5L4QrnpgEGzIBc3ur/S3Ir4yI+FaueX2kPPNmbKLEHtm5FPcGpJyzZxukoAZu+CmaHi1m13mJ/wa9qoSxX10SN9dlWnSH3+mP8wIDAQAB',
        ];

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['cporderid'],//商户订单号
            'third_order' => $data['transid'],//爱贝交易号
            'third_money' => $data['money'],//实际支付金额，以元为单位
            'error' => '',
        ];
        if ($data['result'] != 0) {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        // $config = Recharge::getOriginThirdConfig($res['order_number']);
        $order = \DB::table('zfb_order')->where('order_number',$res['order_number'])->where('zfb_order.status','=','pending')->first();
        if (empty($order)) {
            $res['error'] = '该订单不存在1';
            return $res;
        }

        // $order2 = \DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_number', $res['order_number'])->first();
        // if (empty($order2)) {
        //     $res['error'] = '该订单不存在2';
        //     return $res;
        // }
        
        $pay_config = \DB::table('channel_pay_config')->where('key', 'AIBEI')->where('channel', $order->origin_id)->first();

        $pay_config = !empty($pay_config) ? json_decode($pay_config->data, true) : $default;
        // print_r($order);
        // print_r($pay_config);
        // exit;
        if (empty($pay_config)) {
            $res['error'] = '该订单不存在3';
            return $res;
        }

        // if (!$config) {
        //     $res['error'] = '该订单不存在4';
        //     return $res;
        // }

        $notifyString = http_build_query($notifyData);
        if(!$this->parseResp($notifyString, $pay_config['platpkey'], $notifyJson)) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateZfbMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功

        return $res;

    }

    //更新金额
    public function updateZfbMoney($order_number, $money){
        $order_info = (array)\DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
        if ($order_info && ($order_info['i_money'] - $money == 0)){
            return true;
        }

        \DB::table('zfb_order')->where('order_number', $order_number)->update(['order_money' => (int)$money]);
        $updata = array(
            'i_money' => (int)$money,
            'i_gold' => (int)$money,
        );
        \DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_no', $order_number)->update($updata);
    }

    public function testOrder($orderUrl,$cpvkey,$platpkey) {
//        global $orderUrl, $cpvkey, $platpkey;
        //下单接口
        $orderReq["appid"] = "5002711232";
        $orderReq["waresid"] = 1;
        $orderReq["cporderid"] = "00000000001";
        $orderReq["price"] = 6.00;   //单位：元
        $orderReq["currency"] = "RMB";
        $orderReq["appuserid"] = "test";
        $orderReq["cpprivateinfo"] = "test";
        $orderReq["notifyurl"] = "http://www.123.com";

        //组装请求报文
        $reqData = $this->composeReq($orderReq, $cpvkey);
        echo PHP_EOL;
        print_r($reqData);
        echo PHP_EOL;
        //发送到爱贝服务后台
        $respData = $this->request_by_curl($orderUrl, $reqData, "order test");

        echo "respData:$respData\n";

        //返回报文解析
        if(!$this->parseResp($respData, $platpkey, $respJson)) {
            echo "parse resp data failed!\n";
        }
        print_r($respJson);
    }

    /**
     * curl方式发送post报文
     * $remoteServer 请求地址
     * $postData post报文内容
     * $userAgent用户属性
     * return 返回报文
     */
    public function request_by_curl($remoteServer, $postData, $userAgent) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $remoteServer);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    /**
     * 组装request报文
     * $reqJson 需要组装的json报文
     * $vkey  cp私钥，格式化之前的私钥
     * return 返回组装后的报文
     */
    public function composeReq($reqJson, $vkey) {

        //获取待签名字符串
        $content = json_encode($reqJson);

        //格式化key，建议将格式化后的key保存，直接调用
        $vkey = $this->formatPriKey($vkey);

        //生成签名
        $sign = $this->sign($content, $vkey);

        //组装请求报文，目前签名方式只支持RSA这一种
        $reqData = "transdata=".urlencode($content)."&sign=".urlencode($sign)."&signtype=RSA";

        return $reqData;
    }

    /**RSA签名
     * $data待签名数据
     * $priKey商户私钥
     * 签名用商户私钥
     * 使用MD5摘要算法
     * 最后的签名，需要用base64编码
     * return Sign签名
     */
    public function sign($data, $priKey) {
        //转换为openssl密钥
        $res = openssl_get_privatekey($priKey);
//        openssl_pkey_get_private();

        //调用openssl内置签名方法，生成签名$sign
        openssl_sign($data, $sign, $res, OPENSSL_ALGO_MD5);

        //释放资源
        openssl_free_key($res);

        //base64编码
        $sign = base64_encode($sign);
        return $sign;
    }

    /**格式化公钥
     * $priKey PKCS#1格式的私钥串
     * return pem格式私钥， 可以保存为.pem文件
     */
    public function formatPriKey($priKey) {
        $fKey = "-----BEGIN RSA PRIVATE KEY-----\r\n";
        $len = strlen($priKey);
        for($i = 0; $i < $len; ) {
            $fKey = $fKey . substr($priKey, $i, 64) . "\r\n";
            $i += 64;
        }
        $fKey .= "-----END RSA PRIVATE KEY-----";
        return $fKey;
    }


    /**
     * 解析response报文
     * $content  收到的response报文
     * $pkey     爱贝平台公钥，用于验签
     * $respJson 返回解析后的json报文
     * return    解析成功TRUE，失败FALSE
     */
    public function parseResp($content, $pkey, &$respJson) {

//        $arr = array_map(create_function('$v', 'return explode("=", $v);'), explode('&', $content));
        $arr = array_map(function($v){
            return explode("=", $v);
        }, explode('&', $content));
        foreach($arr as $value) {
            $resp[($value[0])] = urldecode($value[1]);
        }
        //解析transdata
        if(array_key_exists("transdata", $resp)) {
            $respJson = json_decode($resp["transdata"]);
        } else {
            return FALSE;
        }

        //验证签名，失败应答报文没有sign，跳过验签
        if(array_key_exists("sign", $resp)) {
            //校验签名
            $pkey = $this->formatPubKey($pkey);
            return $this->verify($resp["transdata"], $resp["sign"], $pkey);
        } else if(!array_key_exists("errmsg", $respJson)) {
            return FALSE;
        }

        return TRUE;
    }

    /**格式化公钥
     * $pubKey PKCS#1格式的公钥串
     * return pem格式公钥， 可以保存为.pem文件
     */
    public function formatPubKey($pubKey) {
        $fKey = "-----BEGIN PUBLIC KEY-----\n";
        $len = strlen($pubKey);
        for($i = 0; $i < $len; ) {
            $fKey = $fKey . substr($pubKey, $i, 64) . "\n";
            $i += 64;
        }
        $fKey .= "-----END PUBLIC KEY-----";
        return $fKey;
    }

    /**RSA验签
     * $data待签名数据
     * $sign需要验签的签名
     * $pubKey爱贝公钥
     * 验签用爱贝公钥，摘要算法为MD5
     * return 验签是否通过 bool值
     */
    public function verify($data, $sign, $pubKey)  {
        //转换为openssl格式密钥
        $res = openssl_get_publickey($pubKey);

        //调用openssl内置方法验签，返回bool值
        $result = (bool)openssl_verify($data, base64_decode($sign), $res, OPENSSL_ALGO_MD5);

        //释放资源
        openssl_free_key($res);

        //返回资源是否成功
        return $result;
    }
}