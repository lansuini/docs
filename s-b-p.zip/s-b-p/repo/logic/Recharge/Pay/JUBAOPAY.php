<?php
/**
 * 聚宝支付-富翁
 * @author Taylor
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JUBAOPAY extends BASES {

    //与第三方交互
    public function start(){
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam(){
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            //基本参数
            'bb' => '1.0',//版本号
            'shid' => $this->partnerID,//商户编号
            'ddh' => $this->orderID,//商户订单号
            'je' => number_format($this->money,2,'.',''),//订单金额，精确到小数点后两位
            'zftd' => $this->payType,//支付通道
            'ybtz' => $this->notifyUrl,//异步通知URL
            'tbtz' => $this->returnUrl,//同步跳转URL
            'ddmc' => 'goods',//订单名称
            'ddbz' => 'vip'.$this->orderID,//订单备注
        );
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 生成sign
     */
    private function _sign($p, $tkey)
    {
        $sign = md5('shid='.$p['shid'].'&bb='.$p['bb'].'&zftd='.$p['zftd'].'&ddh='.$p['ddh'].'&je='.$p['je'].'&ddmc='.$p['ddmc'].'&ddbz='.$p['ddbz'].'&ybtz='.$p['ybtz'].'&tbtz='.$p['tbtz'].'&'.$tkey);//MD5加密串
        return $sign;
    }

    public function parseRE(){
        //使用表单提交的方式
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 返回地址验证
     * [status=1 通过  0不通过,
     * order_number = '订单',
     * third_order = 第三方订单,
     * third_money ='金额',
     * error'='未有该订单/订单未支付/未有该订单']
     * @param
     * @return boolean
     */
    public function returnVerify($data) {
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['ddh'],//商户订单号
            'third_order' => $data['ddh'],//系统订单号
            'third_money' => $data['je'],//支付金额
            'error' => '',
        ];

        if ($data['status'] != 'success') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($p, $tkey)
    {
        $sign = md5('status='.$p['status'].'&shid='.$p['shid'].'&bb='.$p['bb'].'&zftd='.$p['zftd'].'&ddh='.$p['ddh'].'&je='.$p['je'].'&ddmc='.$p['ddmc'].'&ddbz='.$p['ddbz'].'&ybtz='.$p['ybtz'].'&tbtz='.$p['tbtz'].'&'.$tkey);//MD5加密串
        if ($sign == $p['sign']){
            return true;
        }
        return false;
    }
}
