<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 博金创亿云支付
 */

class CYY extends BASES 
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {  
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/return_url.php';
        $this->parameter = [
            "uid"       => $this->partnerID, 
            "price"     => sprintf("%.2f", $this->money),
            "type"      =>$this->payType,
            "notify_url"     =>$this->notifyUrl,
            "return_url"     =>$this->returnUrl,
            "order_id"       => $this->orderID,
            "order_name"       => "充值",
            //"bankCode"      =>($this->payType==1)  ? "CMB" :"",
        ];
        $this->parameter['key'] = $this->_sign($this->parameter,trim($this->key));
        //var_dump($this->parameter);exit;
    }

    /**
     * 
     */
    public function parseRE()
    {   
        $result = json_decode($this->re, true);
        //var_dump($this->re);exit;
        //$response = $this->re;
        if ($result && $result['code']==0000 ) {
            $this->return['code']   = 0;
            $this->return['msg']    = 'success';
            $this->return['way']    = $this->data['return_type'];
            $this->return['str']    = $result['qrcode'];
        }else{
            $this->return['code'] =9999;
            $this->return['msg']  = 'CYY: ' . "支付失败";
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
        //var_dump($this->return);exit;
        
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        //$parameters=json_decode($parameters,true);
        $res = [
            'status' => 1,
            'order_number' => $parameters['order_id'],
            'third_order' => $parameters['pay_num'],
            'third_money' => $parameters['price'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($parameters['order_id']);

        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign

        if ($this->verity($parameters,$config['key']) != $parameters['key']) {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }
        return $res;
    }

    private function _sign($data,$key) {
        $str = 'notify_url='.$data['notify_url'].'&order_id='.$data['order_id'].'&order_name='.$data['order_name'].'&price='.$data['price'].'&return_url='.$data['return_url'].'&token='.$key.'&type='.$data['type'].'&uid='.$data['uid'];
        $sign = md5($str);
        return $sign;

    }
 
    /* 
    验证签名： 
    返回：签名结果，true为验签成功，false为验签失败 
    */  
    function verity($data, $key)  
    {  
       $string = "order_id=".$data['order_id'].'&order_uid='.$data['order_uid']."&real_price=".$data['price']."&transaction_id=".$data['transaction_id']."&token=".$key;
        $result   = md5($string);
        // var_dump($result);exit;
        return $result;  
    } 


}