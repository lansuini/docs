<?php
/**
 * 卡拉赞支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class KLZZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'merchant' => $this->partnerID,
            'payType' => $this->payType,
            'orderNo' => (string)$this->orderID,
            'amount' => sprintf("%.2f", $this->money),
            'currentTime' => time(),
            'refer' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,

        ];
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['version'] = '1';
        $this->parameter['type'] = 'text';
        $this->parameter['orderType'] = '0';

    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }
    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderNo']) || !isset($parameters['systemNo'])) {
            return [
                'status' => 0,
                'error' => '未知错误',
            ];
        }

        $res = [
            'order_number' => $parameters['orderNo'],
            'third_order' => $parameters['systemNo'],
            'third_money' => $parameters['money']
        ];
        if ($parameters['payFlag'] != '2') {
            $res['status'] = 0;
            $res['error'] = '支付失败！';
            return $res;
        }


        $config = Recharge::getThirdConfig($parameters['orderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }


        $result = $this->returnVail($parameters, $config['key']);

        if ($result) {
            $res['status'] = 1;
            $res['error'] = '';
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $kkey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key => $val) {
            if ($val) {
                $string = $string ? $string . "&" . $key . "=" . $val : $key . "=" . $val;
            }
        }
        $string = $string . '#' . $kkey;
        $sign = md5($string);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }
}