<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - 快联支付
 */
class KL extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'merchantNo' => $this->partnerID,
            'orderNo' => (string)$this->orderID,
            'orderAmount' => (string)$this->money*100,
            'payType' => $this->data['bank_data'],
            'notifyUrl' => $this->notifyUrl,
            'callbackUrl'=>$this->returnUrl
        ];
        if($this->data['bank_data']=='11'){
            $this->parameter['bankName'] =$this->data['bank_code'];
        }

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if($re['code'] == '0000'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            if( $this->data['return_type']=='code'){
                $this->return['str'] =$this->qrcodeUrl.$re['payUrl'];
            }else{
                $this->return['str'] = $re['payUrl'];
            }

        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = '快联支付:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['orderNo'],
            'third_order' => $data['wtfOrderNo'],
            'third_money' => $data['orderAmount']/100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderNo']);
        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
        }

        //校验sign
        $sign = $data['sign'];
        unset($data['sign']);
        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);
        $string = '';
        foreach ($params as $keyVal => $param) {
            if($param!=""){
                $param=urldecode($param);
                $string .= $keyVal . '=' . $param . '&';
            }
        }
        $sign = strtolower(md5(rtrim($string,'&') . $key));
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {

        $sign = $this->_sign($pieces, $key);

        return $thirdSign == $sign;
    }
}