<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;
use Utils\Client;


/**
 * 乐力付支付
 * @author zhangli
 */
class LLF extends BASES
{
    protected $dataArr;

    //与第三方交互
    public function start()
    {

        $this->initParam();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $this->dataArr = array(
            'payMode' => $this->data['bank_data'],
            'orderCode' => $this->orderID,
            'totalAmount' => (string)$this->money*100,
            'body' => 'goods',
            'clientIp' => $this->data['client_ip'],
            'frontUrl' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,
            'reqTime' => date('Y-m-d H:i:s'),
//            'bankCode' => $this->data['bank_code']
        );

        if($this->data['bank_data']=='00000012' || $this->data['bank_data']=='00000008' || $this->data['bank_data']=='00000007'){
            $this->dataArr['channelType']='01';
        }else{
            $this->dataArr['channelType']='02';
            $this->dataArr['bankCode']= $this->data['bank_data'];
        }

        $data = $this->pubEncrypt();
        $this->parameter = array(
            'charset' => 'utf-8',
            'mid' => $this->partnerID,
            'data' => $data,
            'signType' => 'MD5',
            'sign' => $this->sytMd5($this->dataArr,$this->key),
        );
    }


    public function sytMd5($piecess, $key)
    {
        $signStr = $piecess['channelType'] == '01' ? [
            'channelType' => $piecess['channelType'],
            'orderCode' => $piecess['orderCode'],
            'totalAmount' => $piecess['totalAmount'],
            'payMode' => $piecess['payMode'],
            'clientIp' => $piecess['clientIp'],
            'notifyUrl' => $piecess['notifyUrl'],
            'reqTime' => $piecess['reqTime'],
        ]: [
            'channelType' => $piecess['channelType'],
            'orderCode' => $piecess['orderCode'],
            'totalAmount' => $piecess['totalAmount'],
            'payMode' => $piecess['payMode'],
            'clientIp' => $piecess['clientIp'],
            'notifyUrl' => $piecess['notifyUrl'],
            'bankCode' => $piecess['bankCode'],
            'reqTime' => $piecess['reqTime'],
        ];
//        print_r($signStr);exit;
        $signStr = $this->_toJson($signStr).$key;
        $signStr = md5(urlencode($signStr));
        return base64_encode($signStr);
    }

    public static function _toJson($params, $sortFalg = false)
    {
        if ($sortFalg) ksort($params);

        $jsonStr = '{';
        while (list($key, $val) = each($params)) {
            if (is_array($val)) {

                $jsonStr .= "\"{$key}\":" . self::_toJson($val) . ",";
            } else {
                $jsonStr .= "\"{$key}\":\"{$val}\",";
            }

        };
        $jsonStr = rtrim($jsonStr, ",") . "}";
        return $jsonStr;
    }


    public function parseRE()
    {
        if($this->dataArr['channelType']=='01'){
            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . $this->payUrl;
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        }else{
            $this->basePost();
            $re = json_decode($this->re, true);
            if (isset($re['respCode']) && $re['respCode'] == '000000') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = $re['qrcodeUrl'];
            } else {
                $this->return['code'] = 886;
                $this->return['msg'] = 'LLF:' . $re['respMsg'] ?? "未知异常";
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }

    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        $res = [
            'status' => 1,
            'order_number' => $input['orderCode'],
            'third_order' => $input['tradeNo'],
            'third_money' => $input['totalAmount']/100 ,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($input['orderCode']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
        }

        $sign = $input['sign'];
        $newSign = $this->getVerify($input, $config['key']);
        if ($newSign != $sign) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        return $res;
    }

    public function getVerify($respData,$key){
        $params = array(
            'orderCode'		=> $respData['orderCode'],
            'totalAmount'	=> $respData['totalAmount'],
            'payMode' => $respData['payMode'],
            'orderStatus' => $respData['orderStatus'],
            'tradeNo'		=> $respData['tradeNo'],
            'payTime'		=> $respData['payTime']
        );
        $signStr 	= urlencode( self::_toJson($params).$key);
        $signStr 	= md5( $signStr );
        return  urlencode(base64_encode( $signStr ));
    }


    /**
     * 加密
     *
     * @param
     *            string 明文
     * @param
     *            string 密文编码（base64/hex/bin）
     * @param
     *            int 填充方式（貌似php有bug，所以目前仅支持OPENSSL_PKCS1_PADDING）
     * @return string 密文
     */
    public function pubEncrypt()
    {
        $jsonStr='';
        if(is_array($this->dataArr))
            $jsonStr = json_encode($this->dataArr);
        $encryptData = '';
        $crypto = '';
        foreach (str_split($jsonStr, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $this->pubKey);
            $crypto = $crypto . $encryptData;
        }

        $crypto = base64_encode($crypto);
        return $crypto;
    }

}
