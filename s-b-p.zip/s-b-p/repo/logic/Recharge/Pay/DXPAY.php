<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * DX支付
 * @author lavenkin
 */
class DXPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->parameter = [
            'mch_id' => $this->partnerID,
            'pay_type' => $this->data['bank_data'],
            'out_trade_id' => $this->orderID,
            'total_fee' => $this->money*100,
            'subject' => 'GOODS',
            'client_ip' => $this->data['client_ip'],
            'callback_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl
        ];

        $this->parameter['sign'] = $this->_createSign($this->parameter, $this->key);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        // var_dump($re);exit;
        if ($re['code'] != '0') {
            $this->return['code'] = 23;
            $this->return['msg'] = 'DX支付：' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['pay_info'];
        }
    }

    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['out_trade_id'],
            'third_order' => $data['order_id'],
            'third_money' => $data['amount']/100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['out_trade_id']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        // var_dump($data);exit;
        if ($data['pay_result'] == 2) {
            $res['status'] = 0;
            $res['error'] = '支付失败！';
            return $res;
        }

        if (!$this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signKey)
    {
        $str=$data['order_id'].'|'.$data['pay_result'].'|'.$data['amount'].'|'.$data['order_time'].'|'.$signKey;
        $sign = strtoupper(md5($str));
        return $sign == $data['sign'];
    }


    /**
     * 生成签名
     */
    private function _createSign($pieces, $signKey = '')
    {
        $string=$pieces['mch_id'].'|'.$pieces['pay_type'].'|'.$pieces['out_trade_id'].'|'.$pieces['total_fee'].'|'.$signKey;
        $sign = strtoupper(md5($string));
        return $sign;
    }
}