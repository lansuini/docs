<?php
/**
 * 大唐支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class DTZF extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = array(
            'merno' => $this->partnerID,
            'amount' => sprintf('%.2f', $this->money),
            'subject' => "GOODS",
            'mer_order_id' => $this->orderID,
            'notify_url' => $this->notifyUrl,
            'nonce_str' => $this->getRandSrting(),
            // 富翁大唐第三方要求，这个字段不要传，他们会自动分配
            'pay_code' => "",
        );
        $this->parameter["sign"] = $this->_sign($this->parameter, $this->key);
    }

    private function getRandSrting()
    {
        $str = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
        str_shuffle($str);
        $name = substr(str_shuffle($str), 26, 6);
        return $name;
    }


    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($key != 'sign' && $val != null) {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);
        $sign_str = $params . '&key=' . $tkey;
        $sign = strtoupper(md5($sign_str));
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == '000') {
            $this->return['code'] = 0;//code为空代表是OK
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['qrcode_url'];
        } else {
            $this->return['code'] = $re['code'];
            $this->return['msg'] = 'DTPAY:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['mer_order_id']) || !isset($data['state']) || !isset($data['amount'])) {
            return [
                'status' => 0,//默认支付失败
                'error' => '返回信息有误',
            ];
        }

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['mer_order_id'],//商户订单号
            'third_order' => $data['order_id'],//平台流水号
            'third_money' => $data['amount'],//支付金额，以分为单位
            'error' => '',
        ];

        if ($data['state'] != 1) {//00:支付成功/01:失败
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($data['sign'] != $this->_sign($data, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

}
