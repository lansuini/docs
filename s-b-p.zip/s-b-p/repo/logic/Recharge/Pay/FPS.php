<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;
use Utils\Utils;


/**
 * FPS支付
 */
class FPS extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->_payJson($this->key);
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'app_id' => $this->partnerID,
            'nonce_str' => Utils::randStr(),
            'body' => "Goods",
            'out_trade_no' => $this->orderID,
            'fee_type' => 'CNY',
            'total_fee' => $this->money,
            'pay_product' => $this->payType, //支付类型
            'notify_url' => $this->notifyUrl,
            'trade_type' => 'MWEB',
        ];

        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function _payJson($tkey)
    {
        $data_string = json_encode($this->parameter, JSON_UNESCAPED_UNICODE);
        $data_string = str_replace("\\/", "/", $data_string);//去除转义问题

        $sign = $this->getSign($data_string, $tkey);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->payUrl);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data_string),
                'ffbodysign:' . $sign,
            )
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        $this->re = $response;
    }

    public function getSign($dataString, $api_key)
    {
        $str = trim($dataString) . $api_key;
        $sign = strtolower(hash_hmac('sha256', $str, $api_key));
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['data']['biz_code']) && $re['data']['biz_code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];

            $biz_data = $re['data']['biz_data'];

            if ($this->showType == 'sdk') {
                if (!isset($biz_data['alipay_sdk_params'])) {
                    $this->parseError($re, "SDK模式alipay_sdk_params 字段不存在");
                    return;
                }
                $url = $biz_data['alipay_sdk_params'];
            } else {
                $url = $biz_data['client_pay_url'];

                if (empty($url)) {
                    $url = $biz_data['pay_qrcode_url'];
                }

                if (empty($url)) {
                    if (isset($biz_data['pay_html_frame'])) {
                        $url = $this->jumpURL.'?method=HTML&html=' . base64_encode($biz_data['pay_html_frame']);
                    }
                }
            }
            $this->return['str'] = $url;
        } else {
            $this->parseError($re);
        }
    }

    private function parseError($re,$msg=null)
    {
        $this->return['code'] = 23;
        $this->return['msg'] = 'FPS：' . ($msg ?? (isset($re['data']['biz_msg']) ? $re['data']['biz_msg'] : (isset($re['msg']) ? $re['msg'] : '请求支付失败')));
        $this->return['way'] = $this->data['return_type'];
        $this->return['str'] = null;
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['data']['biz_data']['out_trade_no'])) {
            return false;
        }
        $headers = $app->getContainer()->request->getHeaders();

        $data = $data['data']['biz_data'];
        $sign = $headers['HTTP_FFBODYSIGN'][0];//ffbodysign 通过Http传输会自动变成大写

        $res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['transaction_id'],
            'third_money' => $data['pay_fee'],
            'error' => '',
        ];

        //如果有验签问题需要查sign 通过log日志去查
        RechargeLog::addElkLogByTxt(['order_number' => $res['order_number'],'date'=>date('Y-m-d H:i:s'),"FPS Headers"=>$headers]);

//        if ($data['ret_code'] != '0000') {
//            $res['status'] = 0;
//            $res['error'] = '订单号未成功支付';
//            return $res;
//        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($sign, $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/soapi/pay/orderquery';
        }

        $success = $this->queryOrder($url, $res['order_number'], $res['third_order'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != 3) {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($signOld, $config)
    {
        $dataString = file_get_contents('php://input');
        $sign = $this->getSign($dataString, $config['key']);
        return $sign == $signOld;
    }

    public function queryOrder($queryUrl, $orderNumber, $thirdOrder, $partnerID, $tkey)
    {
        $params = [
            "app_id" => $partnerID,
            'nonce_str' => Utils::randStr(),
            'transaction_id' => $thirdOrder,
            "out_trade_no" => $orderNumber,
        ];

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->_payJson($tkey));

        $re = json_decode($this->re, true);

        if (isset($re['data']['biz_data']['trade_state'])) {
            return $re['data']['biz_data']['trade_state'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}