<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;


/**
 * 飞恒支付
 */
class FEIHENG extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $extra = [
            'notifyUrl' => $this->notifyUrl,
            'callbackUrl' => $this->returnUrl,
        ];
        if(in_array($this->payType,['union_app'])){
            $extra['channelType']='08';
        }
        if(in_array($this->payType,['wx_qr','qq_qr','union_qr'])){
            $extra['payUserName']='GOODS';
            $extra['clientIp']=Client::getIp();
            unset($extra['callbackUrl']);
        }

        //参与签名字段
        $data = [
            'tradeType' => 'cs.pay.submit',
            'version' => '2.0',
            'channel' => $this->payType, //支付类型
            'mchNo' => $this->partnerID,
            'body'=>'GOODS',
            'mchOrderNo' => $this->orderID,
            'amount' => $this->money*100,
            'timePaid'=>date('YmdHis'),
        ];

        $data['sign']=$this->getSign(array_merge($data,$extra), $this->key);
        $data['extra']=json_encode($extra,JSON_UNESCAPED_UNICODE);
        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            $val=strval($val);
            if($key !='sign'&&$val!=""){
                $string = $string . $key . '=' . $val . '&';
            }
        }
        $string=$string.'paySecret='. $api_key;
        $sign = md5($string);
        return strtoupper($sign);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset( $re['resultCode']) &&  $re['resultCode']==0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['codeUrl'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'FEIHENG：' . (isset($re['message']) ? $re['message'] : '下单失败');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['status'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['mchOrderNo'],
            'third_order' => $data['mchOrderNo'],
            'third_money' => $data['amount']/100,
            'error' => '',
        ];

        if ($data['payResult'] != 0) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/gateway/api/trade';
        }
        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        $sign = $this->getSign($data, $config['key']);
        return $sign == $signOld;
    }
    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "tradeType" => 'cs.order.query',
            'version'=>'2.0',
            'mchNo'=>$partnerID,
            "mchOrderNo" => $orderNumber,
        ];

        $params['sign'] = $this->getSign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['payResult'])) {
            return $re['payResult'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}