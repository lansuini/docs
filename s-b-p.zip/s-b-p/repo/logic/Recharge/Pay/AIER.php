<?php
/**
 * 艾尔支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class AIER extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'account' => $this->partnerID,
            'amount' => sprintf("%.2f", $this->money),
            'paytype' => $this->payType,
            'orderno' => $this->orderID,
            'hrefbackurl' => $this->returnUrl,
            'callbackurl' => $this->notifyUrl,
            'ip' => $this->data['client_ip']
        ];

        //秘钥存入 token字段中
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['attach'] = 'GOODS';
        $this->parameter['returntype'] = 'json';
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re) && $re['url']) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['url'];
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'AIER:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['orderno'],
            'third_order' => $data['orderno'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderno']);
        // var_dump($data);exit;
        if ($data['orderstatus'] != 1) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        unset($data['sign']);
        unset($data['attach']);
        unset($data['msg']);
        if (!$this->returnVail($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign = md5($string.'key='.$tKey);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey,$thirdSign)
    {
        $sign = $this->_sign($params, $tkey);

        return $thirdSign == $sign;
    }
}