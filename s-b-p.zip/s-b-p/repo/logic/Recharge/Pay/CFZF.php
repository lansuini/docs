<?php
/**
 * 乘风支付
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class CFZF extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->basePost();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'pay_memberid' => (string)$this->partnerID,
            'pay_orderid' => (string)$this->orderID,
            'pay_applydate' => date('Y-m-d H:i:s', time()),
            'pay_bankcode' => (string)$this->payType, //bank_data
            'pay_notifyurl' => $this->notifyUrl,
            'pay_callbackurl' => $this->returnUrl,
            'pay_amount' => $this->money,
            'pay_productname' => 'Goods',
        ];
        $re = json_encode([
            "pay_memberid" => $pub_params['pay_memberid'],
            "pay_orderid" => $pub_params['pay_orderid'],
            "pay_amount" => $pub_params['pay_amount']
        ]);
        $pub_params['sign'] = $this->createRsaSign($re, $this->key);

        //加密请求数据
        $encryptStr = $this->encryptStr(json_encode($pub_params), $this->data['token']);
        $request_data = [
            'encrypt_str' => $encryptStr,
            'pay_memberid' => $pub_params['pay_memberid'],
        ];

        $this->parameter = $request_data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['pay_url'];
            if ($this->showType == 'sdk') {
                if (!empty($re['sdk'])) {
                    $this->return['str'] = $re['sdk'];
                }
            }
        } else {
            $msg = isset($re['msg']) ? $re['msg'] : "下单有误";
            $this->return['code'] = 61;
            $this->return['msg'] = 'CFZF:' . $msg;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        $config = Recharge::getThirdConfig($parameters['orderid']);
        $decryptData = $this->decryptStr($parameters['encryptStr'], $config['token']);
        $data = json_decode($decryptData, true);

        $res = [
            'status' => 0,
            'order_number' => $data['orderid'],
            'third_order' => $data['transaction_id'],
            'third_money' => $data['amount'],
        ];

        if ($data['returncode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }
        /**
         * config['pub_key'] 验签的密钥是第三方后台的平台公钥，不要用错成自己生成的公钥了！！！
         */
        $verify = $this->verifyRsaSign(["memberid" => $data['memberid'], "orderid" => $data['orderid'], "amount" => $data['amount'], "sign" => $data['sign']], $config['pub_key']);
        if (!$verify) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        $order_number = $data['orderid'];
        $return_money = intval($data['amount']);

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    function verifyRsaSign($data, $pubKey)
    {
        if (!is_array($data)) {
            return false;
        }

        $sign = isset($data['sign']) ? $data['sign'] : '';
        if (!$sign) {
            return false;
        }
        if (!$pubKey) {
            return false;
        }
        $data = $data;
        unset($data['sign']);
        $pubKey = $this->getRsaKeyValue($pubKey, "public");
        $res = openssl_get_publickey($pubKey);

        $result = (bool)openssl_verify(json_encode($data), base64_decode($sign), $res, OPENSSL_ALGO_SHA256);

        return $result;
    }

    /**
     * 创建签名
     * @param string $data 数据
     * @return null|string
     */
    function createRsaSign($data = '', $privKey = "")
    {

        $privKey = $this->getRsaKeyValue($privKey, "private");

        $privGet = openssl_pkey_get_private($privKey);

        //  var_dump(self::getPrivateKey());die;
        if (!is_string($data)) {
            return null;
        }
        return openssl_sign($data, $sign, $privGet, OPENSSL_ALGO_SHA256) ? base64_encode($sign) : null;
    }

    function getRsaKeyValue($key, $type = 'private')
    {
        if (is_file($key)) {// 是文件
            $keyStr = @file_get_contents($key);
        } else {
            $keyStr = $key;
        }
        if (empty($keyStr)) {
            return null;
        }

        $keyStr = str_replace(PHP_EOL, '', $keyStr);
        // 为了解决用户传入的密钥格式，这里进行统一处理
        if ($type === 'private') {
            $beginStr = '-----BEGIN RSA PRIVATE KEY-----';
            $endStr = '-----END RSA PRIVATE KEY-----';
        } else {
            $beginStr = '-----BEGIN PUBLIC KEY-----';
            $endStr = '-----END PUBLIC KEY-----';
        }
        $keyStr = str_replace($beginStr, '', $keyStr);
        $keyStr = str_replace($endStr, '', $keyStr);

        $rsaKey = chunk_split($keyStr, 64, PHP_EOL);
        $rsaKey = $beginStr . PHP_EOL . $rsaKey . $endStr;

        return $rsaKey;
    }

    function encryptStr($string, $key)
    {

        // openssl_encrypt 加密不同Mcrypt，对秘钥长度要求，超出16加密结果不变
        $data = openssl_encrypt($string, 'AES-128-ECB', $key, OPENSSL_RAW_DATA);
        $data = strtolower(bin2hex($data));
        return $data;
    }

    function decryptStr($string, $key)
    {
        $decrypted = openssl_decrypt(hex2bin($string), 'AES-128-ECB', $key, OPENSSL_RAW_DATA);

        return $decrypted;
    }

}