<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * AK支付
 * @author benchan
 */
class AK extends BASES
{

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();

        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //组装数组
    public function initParam()
    {

        $this->parameter = array(
            //基本参数
            'appId' => $this->partnerID,
            'orderId' => $this->orderID,
            'totalFee' => $this->money * 100,
            'payType' => $this->payType,
            'notifyUrl' => $this->notifyUrl,
        );
        if (strpos($this->payType, '|') === false) {
            if ($this->payType == 'wx' || $this->payType == 'wxHtml') {
                $this->parameter['feeType'] = 4;
            } else {
                $this->parameter['feeType'] = 0;
            }
        } else {
            $args = explode('|', $this->payType);
            $this->parameter['payType'] = $args[0];
            $this->parameter['feeType'] = $args[1];
        }

        $this->parameter['sign'] = $this->getSign($this->parameter, $this->key);
    }

    public function parseRE()
    {
        if ($this->payType == 'wxHtml' || $this->payType == 'alipayHtml') {
//            $str=explode("='",$this->re);
//            $str2=explode("';",$str[1]);
//            $str3=rtrim($str2[0],";'");
//            var_dump($str3,$this->re);die;

            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . $this->payUrl;
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        } else {
            $this->basePost();
            $re = json_decode($this->re, true);
            if ($re && $re['code'] == '200') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];
                if ($this->data['return_type'] == 'code') {
                    $this->return['str'] = $this->qrcodeUrl . $re['qrcode'];
                } else {
                    $this->return['str'] = $re['qrcode'];
                }
            } else {
                $this->return['code'] = 99;
                $this->return['msg'] = 'AK:' . $re['msg'] ?? '未知异常';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }


    }

    public function getSign($params, $key)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            $string = $string . $k . '=' . $v . '&';
        }
        $str = md5($string . 'key=' . $key);
        return strtoupper($str);
    }


    public function returnVerify($input)
    {
        $res = [
            'status' => 1,
            'order_number' => $input['orderId'],
            'third_order' => $input['outerOrderId'],
            'third_money' => $input['totalFee'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($input['orderId']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if (!$this->returnVail($input, $config['key'], $input['sign'])) {
            $res['status'] = 0;
            $res['error'] = '该订单验签不通过或已完成';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function returnVail($result_pra, $key, $sign)
    {
        $sign2 = strtoupper(md5('outerOrderId=' . $result_pra['outerOrderId'] . '&orderId=' . $result_pra['orderId'] . '&key=' . $key));
        if ($sign == $sign2) {
            return true;
        } else {
            return false;
        }
    }

}
