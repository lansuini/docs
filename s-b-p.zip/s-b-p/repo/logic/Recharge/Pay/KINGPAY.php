<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 *
 * 赞呗支付
 */
class KINGPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //不参与签名字段
        $pub_params = [
            'device'	=>	'wap', //商品名称
            'parter'	=>	$this->partnerID, //开户商户id
            'value'	=>	sprintf("%.2f", $this->money),//订单金额
            'type'	=>	$this->payType,	//交易类型
            'orderid'	=>	$this->orderID,	//提交订单号
            'callbackurl'	=>	$this->notifyUrl,	//接收回调地址
        ];
        $pub_params['sign'] = $this->getSign($pub_params, $this->key);
        $this->parameter = $pub_params;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $tkey)
    {
        $data = [
            'parter' => $pieces['parter'],
            'type' => $pieces['type'],
            'value' => $pieces['value'],
            'orderid' => $pieces['orderid'],
            'callbackurl' => $pieces['callbackurl'],
        ];

        $string = [];
        foreach ($data as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params  . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    public function parseRE()
    {
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['orderid'],//商户订单号
            'third_order' => $data['sysorderid'],//平台流水号
            'third_money' => $data['ovalue'],//支付金额，以元为单位
            'error' => '',
        ];

        if ($data['opstate'] != '0') {//订单状态，1为成功，其它请看订单状态描述
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($data['orderid']);

        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data,$config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . '/Order/Search';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'],$config['key']);
        //查询第三方有结果
        if ($success != null && $success != '0') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }
    /**
     * 签名校验
     * @param $param
     * @return boolean
     */
    public function returnVail($param,$key)
    {
        $signstr = $param['sign'];
        $data = [
            'orderid' => $param['orderid'],
            'opstate' => $param['opstate'],
            'ovalue' => $param['ovalue'],
        ];
        $string = [];
        foreach ($data as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params  . $key;
        $sign = md5($sign_str);

        if ($signstr == $sign) {
            return true;
        }
        else
        {
            return false;
        }
    }

    private function queryOrder($queryUrl, $orderNumber, $partnerID,$tkey)
    {
        $data = [
            "orderid" => $orderNumber,
            "parter" => $partnerID,
        ];

        $string = [];
        foreach ($data as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params  . $tkey;

        $ms = "orderid={$orderNumber}&parter={$partnerID}{$tkey}";

        $data['sign'] = md5($ms);

        $this->payUrl = $queryUrl;
        $this->parameter = $data;

        $this->get();

        $re = json_decode($this->re, true);

        if (isset($re['opstate'])) {
            return $re['opstate'];
        }
        return null;
    }


}