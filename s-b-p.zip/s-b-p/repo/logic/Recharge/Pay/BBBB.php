<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/19
 * Time: 10:09
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 自营支付平台-大栋支付
 * @package Logic\Recharge\Pay
 */
class BBBB extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $tmp = explode('_', $this->payType);
        $this->parameter = array(
            'merchantNo' => $this->partnerID,
            'merchantOrderNo' => $this->orderID,
            'request_time' => date('YmdHis'),
            'amount' => $this->money,
            'summary' => 'Goods',
            'model' => $tmp[0],
            'pay_type' => $tmp[1],
            'terminal' => 'Phone',
            'userIp' => $this->clientIp,
            'card_type' => 'DEBIT',
            'noticeUrl' => $this->notifyUrl
        );
        $this->parameter['sign'] = md5($this->arrayToURL() . $this->key);
    }

    //返回参数
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['biz']['payUrl'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['biz']['payUrl'];
        } else {
            $this->return['code'] = 64;
            $this->return['msg'] = '大栋支付:' . $re['msg'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    //签名验证
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);
        $res = [
            'status' => 1,
            'order_number' => $result['biz']['merchantOrderNo'],
            'third_order' => $result['biz']['platformOrderNo'],
            'third_money' => $result['biz']['orderAmount'],
            'error' => '',
        ];

        if ($result['code'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($result['biz']['merchantOrderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($result['sign'] == md5($this->arrayToURLALL($result['biz']) . $config['key'])) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

}