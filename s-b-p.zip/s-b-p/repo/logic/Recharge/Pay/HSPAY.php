<?php
/**
 * HSZF
 * @author Taylor 2019-05-23
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HSPAY extends BASES {

    //与第三方交互
    public function start(){
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam(){

        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            'pay_memberid' => $this->partnerID,
            'pay_orderid' => $this->orderID,
            'pay_applydate' => date("Y-m-d H:i:s",time()),
            'pay_bankcode' => $this->payType,
            'pay_notifyurl' => $this->notifyUrl,
            'pay_callbackurl' => $this->returnUrl,
            'pay_amount' => $this->money,
        );
        ksort($this->parameter);
        $md5str = "";
        foreach ($this->parameter as $key => $val) {
            $md5str = $md5str . $key . "=" . $val . "&";
        }
        $sign = strtoupper(md5($md5str . "key=" . $this->key));
        $this->parameter["pay_md5sign"] = $sign;
        $this->parameter['pay_productname'] = 'VIP服务';
    }


    public function parseRE(){

        $re = json_decode($this->re,true);
        if (isset($re['status']) && $re['status']=='success'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['pay_url'];

        }else{
            $this->return['code'] = $re['status'];
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data) {

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['orderid'],//商户订单号
            'third_order' => $data['transaction_id'],//平台流水号
            'third_money' => $data['amount'],//支付金额，以分为单位
            'error' => '',
        ];

        if ($data['returncode'] != '00') {//00:支付成功/01:失败
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data,$config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $param
     * @return boolean
     */
    public function returnVail($param,$key)
    {
        $signstr = $param['sign'];
        unset($param['sign']);
        ksort($param);
        $md5str = "";
        foreach ($param as $key => $val) {
            $md5str = $md5str . $key . "=" . $val . "&";
        }
        $sign = strtoupper(md5($md5str . "key=" . $key));
        if ($signstr == $sign) {
            return true;
        }
        else
        {
            return false;
        }
    }

}
