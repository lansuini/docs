<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - Epay支付
 * @author Lavenkin
 * @date 2018-08-07
 */

class EPAY extends BASES {

	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam() 
    {
        $this->parameter = [
            // 'method' => $this->data['bank_data'] ?? 'mbupay.alipay.sqm', // 默认仅支持 mbupay.alipay.sqm                                    		
            // 'appid' => $this->data['app_id'],
            // 'mch_id' => $this->partnerID,                                       
            // 'nonce_str' => rand(1000, 99999),
            // 'body' => 'GOLDS',
            // 'out_trade_no' => $this->orderID,
            // 'total_fee' => $this->money * 100,
            // 'notify_url' => $this->notifyUrl,
            'command' => 'cmd102',
            'serverCode' => 'ser2001',
            'merchNo' => $this->partnerID,
            'version' => '2.0',
            'charset' => 'utf-8',
            'currency' => 'CNY',
            'reqIp' => $this->data['client_ip'],
            'reqTime' => time(),
            'signType' => 'MD52',
            'payType' => $this->data['bank_data'],
            'cOrderNo' => $this->orderID,
            'amount' => $this->money,
            'goodsName' => 'goods',
            'goodsNum' => '1',
            'goodsDesc' => 'goods',
            'memberId' => rand(1000, 99999),
            'notifyUrl' => $this->notifyUrl,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter);

        // $this->parameter = $this->toXml($this->parameter);
        // var_dump($this->parameter);exit;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
    	if ($re['code'] != '10000' && $re['status'] != 4) {
    		$this->return['code'] = $re['code'];
            $this->return['msg'] = 'Epay支付：' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
    	} else {
    		$this->return['code'] = 0;
	        $this->return['msg'] = 'SUCCESS';
	        $this->return['way'] = $this->data['return_type'];
    		$this->return['str'] = urldecode($re['payUrl']);
    	}
    }

    public function returnVerify($data)
    {
    	$res = [
            'status' => 1,
            'order_number' => $data['cOrderNo'],
            'third_order' => $data['pOrderNo'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['cOrderNo']);
        // var_dump($data['out_trade_no']);exit;
        if ($data['code'] != '10000' && $data['status'] != 4) {
        	$res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        // var_dump($config);exit;
        //校验sign
        if (! $this->_verifySign($data, $config['pub_key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        return $res;
    }

    /**
     * 生成签名
     */
    private function _sign($pieces)
    {
    	ksort($pieces);
        $string = '';
        foreach ($pieces as $keys => $value){
            if ($value != '' && $value != null){
                $string = $string.$keys . '=' . $value . '&';
            }
        }
        $string = $string . 'key=' . $this->key;
        // print($string);exit;
        $sign = md5($string);
 
        return $sign;
    }

    /**
     * 验证签名
     */
    private function _verifySign($pieces, $pubkey)
    {
    	ksort($pieces);
        $string = '';
        // var_dump($pieces);exit;
        foreach ($pieces as $key => $value) {
            if ($value != '' && $value != null && $key != 'sign') {
                $string = $string . $key . '=' . $value . '&';
            }
        }
        // var_dump($pubkey);exit;
        $string = $string . 'key=' . $pubkey;

        // var_dump($string);exit;
        $mySign = md5($string);
        return trim($pieces['sign']) == $mySign;
    }

}