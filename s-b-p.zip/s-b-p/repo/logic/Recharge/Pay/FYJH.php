<?php

/**
 * 风云聚合
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class FYJH extends BASES {

	public function start()
	{
		$this->initParam();
        // $this->get();
        // $this->parseRE();	
	}

	/**
	 * 
	 */
	public function initParam()
	{
        date_default_timezone_set('Asia/Shanghai');
		$uid = mt_rand(100000,999999999);
		$time = time();
        $rand = mt_rand(10,99)/100;
        $money = sprintf("%.2f", $this->money+$rand) ;
        $this->clientIp = $this->clientIp ? $this->clientIp : '127.0.0.1';
		$data = "cid=" . $this->partnerID . 
				"&uid=" . $uid . 
				"&time=" . $time . 
				"&amount=" . $money . 
				"&order_id=" . $this->orderID . 
				"&ip=" . $this->clientIp;

		$dig64 = base64_encode(hash_hmac('sha1', $data, $this->key, true)); 

		 $this->parameter = [
            //基本参数
            'cid' => $this->partnerID,
            'uid' => $uid,
            'time' => time(),
            'amount' => $money,
            'order_id' => $this->orderID,
            'ip' => $this->clientIp ? $this->clientIp : '127.0.0.1',
            'type' => 'qrcode',
            'tflag' => $this->payType,
            'sign' => $dig64
        ];

        $url_param = http_build_query($this->parameter);
        $this->parseRE($this->payUrl."?".$url_param);
	}

	public function parseRE($url)
	{
		$this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $url;
	}

	public function returnVerify($parameters) 
	{
        
		$res = [
            'status' => 1,
            'order_number' => $parameters['order_id'],
            'third_order' => $parameters['order_id'],
            'third_money' => $parameters['amount'] / 100,
            'error' => '',
        ];

        // $re = \DB::table('order')->select(['order_money'])->where('order_number',(string)($input['order_id']))->first();
        // $ordermoney = $re->order_money;
        // if($re->order_money != (float)$res['third_money']){
        //     $res['status'] = 0;
        //     $res['error'] = '实际金额与下单金额不一致';
        //     return $res;
        // }

        $config = Recharge::getThirdConfig($parameters['order_id']);
        // var_dump($config);exit;
        if (! $config){
            $res['status'] = 0;
            $res['error'] = '未有该订单';
        }

        if ($this->returnVail($parameters, $config)){
            $order_number = $parameters['order_id'];
            $return_money = intval($res['third_money'])+1;
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else{
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }

        return $res;
    }

    public function returnVail($parameters, $config)
    {
        $data = "order_id=" .$parameters['order_id']. 
                "&amount=" .$parameters['amount']. 
                "&verified_time=" .$parameters['verified_time'];
    	//$hmac = $_SERVER['HTTP_CONTENT_HMAC'];
    	$sign = base64_encode(hash_hmac('sha1', $data, $config['key'], true)); 
    	// var_dump($sign);exit;
    	if ($parameters['qsign'] == $sign) {
    		return true;
    	}
    	return false;
    }
}
