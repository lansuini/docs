<?php
/**
 * 辰星支付
 * @author Taylor 2019-04-07
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class CHENXING extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
//        $this->basePost();
        //$this->_httpPost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $param = [
            'shopAccountId' => $this->partnerID,//商家ID
            'shopUserId' => $this->_randSrting(),//商家⽤户ID
            'amountInString' => (int)$this->money,//订单⾦额，单位元
            'payChannel' => (string)$this->payType,//⽀付宝：alipay 微信：wechat ⽀付宝转银⾏：bank
            'shopNo' => (string)$this->orderID,//商家订单号
        ];

        //秘钥存入 token字段中
        $param['sign'] = $this->_sign($param, $this->key);
        $param['returnUrl'] =$this->returnUrl;
        $param['shopCallbackUrl'] =$this->notifyUrl;
        $param['target'] = '1';
        $this->parameter = $param;
    }

    /**
     * 组装前端数据,输出结果，使用go.php表单提交
     */
    public function parseRE()
    {
        //使用表单提交的方式
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['shop_no'],//商户订单号
            'third_order' => $data['order_no'],//系统订单号
            'third_money' => $data['money'],//支付金额
            'error' => '',
        ];

        if ($data['status'] != 0) {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        $result = $this->returnVail($data, $config['partner_id'], $config['key']);
        if ($result === false) {
            $res['error'] = '验签失败！';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    private function _randSrting()
    {
        $str="QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
        str_shuffle($str);
        $name=substr(str_shuffle($str),26,6);
        return $name;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
       $string = $params['shopAccountId'].$params['shopUserId'].$params['amountInString'].$params['shopNo'].$params['payChannel'].$tKey;
       $sign = md5($string);
       return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$shop_id,$tkey)
    {
        $return_sign = $params['sign'];
        $string = $shop_id.$params['user_id'].$params['order_no'].$tkey.$params['money'].$params['type'];
        $sign = md5($string);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}