<?php
/**
 * KT快通
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class KUAIT extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $money = $this->money * 100;
        $time = time();
        $this->parameter = [
            'partnerId' => $this->partnerID,
            'goodsPrice' => $money,
            'partnerOrderId' => $this->orderID,
            'goodsName' => 'Goods',
            'timeStamp' => $time,
            'payType' => $this->payType,
            'okUrl' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,
            'errorUrl' => $this->returnUrl
        ];

        //秘钥存入 token字段中
        $str = "partnerId={$this->partnerID}&goodsPrice={$money}&timeStamp=$time&signKay=" . $this->key;
        $this->parameter['sign'] = md5($str);
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re) && $re['result'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['msg'];
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'HUAIT:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
        $res = [
            'status' => 1,
            'order_number' => $data['partnerOrderId'],
            'third_order' => $data['myOrderCode'],
            'third_money' => $data['goodsPrice'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['partnerOrderId']);
//         var_dump($data);exit;
        if ($data['orderState'] != 0) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $str = "partnerId={$config['partner_id']}&goodsPrice={$data['goodsPrice']}&timeStamp={$data['timeStamp']}&signKay=" . $config['key'];
        if ($data['sign'] != md5($str)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'],$res['third_money']);

        return $res;
    }
}