<?php
/**
 * 环商支付

 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HSZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'request_id' => time(),
            'merchant_no' => $this->partnerID,
            'payment' => (string)$this->payType,
            'order_ip' => $this->clientIp,
            'out_order_number' => (string)$this->orderID,
            'total_fee' => $this->money * 100,
            'order_title' => 'VIP充值',
            'order_desc' => '订单：'.$this->orderID,
            'return_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter,$this->key);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        $re = json_decode($this->re,true);
        if (isset($re['status']) && $re['status']=='000000'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['content'];

        }else{
            $this->return['code'] = $re['status'];
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        $res = [
            'order_number' => $parameters['out_order_number'],
            'third_order' => '',
            'third_money' => $parameters['total_fee'] / 100,
        ];
        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != 'SUCCESS'){
            $res['status'] = 0;
            $res['error'] = '订单支付状态为失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($param,$tkey)
    {
        ksort($param);
        unset($param['sign']);
        $md5str = "";
        foreach ($param as $key => $val) {
            $md5str = $md5str . $key . "=" . $val . "&";
        }
        $signStr = $md5str . "key=" . $tkey;
        return md5($signStr);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];

        foreach ($params as $k=>$val)
        {
            if (empty($val)){
                unset($params[$k]);
            }
        }
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}