<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 邦富
 */

class BFPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            "MerID"  => $this->partnerID,
            "MerTradeID"     =>$this->orderID,
            "MerProductID"       =>$this->orderID,
            "MerUserID"      => rand(100000, 999999),
            "Amount"    => sprintf("%.2f", $this->money),
            "TradeDesc"      => 'des',
            "ItemName"       => 'vip',
            "NotifyUrl"     => $this->notifyUrl,
            "ReturnCodeURL"       =>$this->returnUrl,
        ];
        $this->parameter['Sign'] = md5($this->partnerID . $this->orderID . $this->orderID . $this->parameter['MerUserID'] . $this->parameter['Amount'].$this->key);;
    }

    /**
     *
     */
    public function parseRE()
    {
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        $res = [
            'status' => 1,
            'order_number' => $parameters['MerTradeID'],
            'third_order' => $parameters['MerTradeID'],
            'third_money' => $parameters['Amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($parameters['MerTradeID']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign

        if ($this->verity($parameters,$config['key'],$config['partner_id']) != $parameters['Sign']) {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }
        // var_dump($res);exit;
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    /*
    验证签名：
    返回：签名结果，true为验签成功，false为验签失败
    */
    function verity($data, $key,$parterID)
    {
        return md5('MerID='.$parterID.'&RtnCode=' . $data['RtnCode'].'&MerTradeID='. $data['MerTradeID'].'&MerUserID=' . $data['MerUserID'] .'&Amount='. $data['Amount'].'&SignKey='.$key);
    }


}