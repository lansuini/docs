<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 久久支付
 */
class JJZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'mch_id' => $this->partnerID,
            'ptype' => $this->payType, //支付类型
            'order_sn' => $this->orderID,
            'money' => $this->money,
            'goods_desc' => 'goods',
            'client_ip' => $this->clientIp,
            'format' => 'page',
            'notify_url' => $this->notifyUrl,
            'time' => time(),
        ];
        //1、先进行md5签名
        $data['sign'] = $this->getSign($data, $this->data['token']);
        //2、转json字符串
        $json_str = json_encode($data);
        //3、把json字符串进行base64编码
        $base64_str=base64_encode($json_str);
        //4、使用平台公钥加密base64编码得到的字符串
        $resultArr= $this->_rasKey($base64_str);
        //rsa加密只需要传加密后的数据，参数名称是 crypted
        $this->parameter = [
            'crypted'  => $resultArr
        ];
    }
    /**
     * 用公钥加密返回密文
     * @return string
     */
    public function _rasKey($data)
    {
        $this->pubKey  = $this->_mgetPublicKey($this->pubKey);
        $rstr='';
        $bits=openssl_pkey_get_details($this->pubKey)['bits'];
        $tmp_arr=str_split($data,($bits/8)-11);
        foreach($tmp_arr as $val){
            openssl_public_encrypt($val,$encrypt_data,$this->pubKey);
            $rstr.=$encrypt_data;
        }
        $base64_cry=base64_encode($rstr);
        return $base64_cry;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $key . '=' . $val . '&';
        }

        $string .= "key=" . $api_key;
        $sign = md5($string);
        return $sign;
    }


    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
        
        if (!isset($data['sh_order'])) {
            return false;
        }

        $config = Recharge::getThirdConfig($data['sh_order']);

        $private_key = $this->_getmPrivateKey($config['key']);

        $decrypted='';
        $str=base64_decode($data['crypted']);
        $bits=openssl_pkey_get_details($private_key)['bits'];
        $tmp_arr=str_split($str,$bits/8);
        foreach($tmp_arr as $val){
            openssl_private_decrypt($val,$decrypt_data,$private_key);
            if($decrypt_data){
                $decrypted.=$decrypt_data;
            }
        }
        $decrypted=base64_decode($decrypted);
        $data=json_decode($decrypted,true);

        if (!$data){
            $res['status'] = 0;
            $res['error'] = '参数解析错误';
            return $res;
        }


        $res = [
            'status' => 0,
            'order_number' => $data['sh_order'],
            'third_order' => $data['pt_order'],
            'third_money' => $data['money'],
            'error' => '',
        ];

        if ($data['status'] != 'success') {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '?c=Pay&a=query';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['token']);
        //查询第三方有结果
        if ($success != null && $success != 9) {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['token']);
        return $sign == $signOld;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "mch_id" => $partnerID,
            "out_order_sn" => $orderNumber,
            'time' => time(),
        ];

        $params['sign'] = $this->getSign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['data']['status'])) {
            return $re['data']['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

    /**
     * 整理私钥
     * @param $pkey
     * @return string
     */
    public function _getmPrivateKey($pkey)
    {
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\r\n";
        foreach (str_split($pkey,64) as $str){
            $private_key = $private_key . $str ;
        }
        $private_key .=  "\r\n-----END RSA PRIVATE KEY-----";
        $key = openssl_get_privatekey($private_key);
        return $key;
    }

    /**
     * 整理公钥
     * @param $key
     * @return string
     */
    public function _mgetPublicKey($key)
    {
        $pubkey = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($key,64) as $str){
            $pubkey = $pubkey . $str ;
        }
        $pubkey .= "\r\n-----END PUBLIC KEY-----";
        $rekey = openssl_pkey_get_public($pubkey);
        return $rekey;
    }

}