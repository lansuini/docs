<?php
/*
 * 阿联酋支付
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/11
 * Time: 15:52
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;

class ALQZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $data = [];
        $data['alq_merc_id'] = $this->partnerID;
        $data['alq_order_id'] = $this->orderID;
        $data['alq_order_amount'] = $this->money;
        $data['alq_notify_url'] = $this->notifyUrl;

        $sign = $this->_sign($data,$this->key);
        $data['alq_back_url'] = $this->returnUrl;
        $data['alq_pay_type'] = $this->payType;
        $data['alq_sign'] = $sign;
        $data['alq_sign_type'] = 'RSA';
        $data['alq_desc'] = '';
        $data['alq_extra'] = '';

        $data['alq_format'] = 'json';

        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {

        $re = json_decode($this->re,true);
        if(isset($re['alq_cashier_url']) && $re['alq_cashier_url'] != ''){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['alq_cashier_url'];
        }else{
            $this->return['code'] = 888;
            $this->return['msg'] = 'ALQZF:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        if (!isset($parameters['alq_order_id'])||!isset($parameters['alq_order_amount']))
        {
            return false;
        }
        $res = [
            'order_number' => $parameters['alq_order_id'],
            'third_order' => $parameters['alq_order_id'],
            'third_money' => $parameters['alq_order_amount'],
        ];
        $config = Recharge::getThirdConfig($parameters['alq_order_id']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['alq_status_code'] != '200'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态失败';
            return $res;
        }
        $data = [];
        $data['alq_merc_id'] = $parameters['alq_merc_id'];
        $data['alq_order_id'] = $parameters['alq_order_id'];
        $data['alq_transaction_id'] = $parameters['alq_transaction_id'];
        $data['alq_order_amount'] = $parameters['alq_order_amount'];
        $data['alq_status_code'] = $parameters['alq_status_code'];
        $data['alq_order_amount_real'] = $parameters['alq_order_amount_real'];

        $result = $this->returnVail($data,$parameters['alq_sign'], $config['pub_key']);

        if ($result) {
            $this->updateMoney($res['order_number'],$res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($data,$tkey)
    {
        $signature = '';
        $key_private = openssl_get_privatekey($this->format_certificate($tkey, 'PRIVATE'));
        if (!$key_private) {
            return false;
        }

        if (is_array($data)) {
            ksort($data);
            $text = '';
            $symbol = '';
            foreach ($data as $key => $item) {
                $text .= $symbol . $key . '=' . $item;
                $symbol = '&';
            }
        }

        openssl_sign($text, $signature, $key_private, OPENSSL_ALGO_SHA1);
        openssl_free_key($key_private);

        return base64_encode($signature);
    }

    public function returnVail($data,$sign,$tkey)
    {
        $key_public = openssl_get_publickey($this->format_certificate($tkey));
        if (!$key_public) {
            return false;
        }

        if (is_array($data)) {
            ksort($data);
            $text = '';
            $symbol = '';
            foreach ($data as $key => $item) {
                $text .= $symbol . $key . '=' . $item;
                $symbol = '&';
            }
        }

        $result = openssl_verify($text, base64_decode($sign), $key_public);
        openssl_free_key($key_public);
        return $result === 1 ? true : false;
    }


    function format_certificate($key, $type = 'public') {
        $type = strtoupper($type);
        $begin = "-----BEGIN $type KEY-----\n";
        $end = "-----END $type KEY-----\n";
        $key = chunk_split($key, 64, "\n");
        return $begin . $key . $end;
    }

}