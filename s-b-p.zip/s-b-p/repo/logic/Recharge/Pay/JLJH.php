<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
// use Utils\Client;
/**
 * 第三方支付 - 聚力聚合支付
 * @author Lavenkin
 * @date 2018-08-07
 */

class JLJH extends BASES {

	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        // $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam() 
    {
        $randUid = rand(100000, 999999);
        $this->parameter = [
            'WIDout_trade_no' => $this->orderID,
            'WIDtotal_amount' => (float) $this->money,
            'id' => $this->data['app_id'],
            'uid' => $randUid,
            'notify_url' => $this->notifyUrl,
            'return_url' => 'http://www.baidu.com',
            'Type' => 'pay',
            'PayType' => $this->data['bank_data'],
        ];

        $this->parameter['sign'] = urlencode($this->createSign($this->parameter));
    }

    public function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    public function returnVerify($data)
    {
    	$res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['platformid'],
            'third_money' => $data['total_amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['out_trade_no']);

        if ($config['order_money'] != $data['total_amount']) {
            $res['status'] = 0;
            $res['error'] = '第三方回调金额与下单金额不符';

            return $res;
        }

        if ($data['status'] != 'success') {
        	$res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        // var_dump($config);exit;
        //校验sign
        if (! $this->verifySign($data, $config['pub_key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        return $res;
    }

    /**
    * 签名
    * @param array $payContent 待签名数据
    * @return string
    */
    private function createSign($payContent)
    {
        $data = $this->getSignContent($payContent);
        $res = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($this->key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";//拼接
        openssl_sign($data, $sign, $res, OPENSSL_ALGO_SHA256);//对数据 进行签名
        $sign = base64_encode($sign);
        return $sign;
    }

    /**
     * check 获取签名内容 
     * @param array $payContent 需要验签的参数
     * @return string
     */
    private function getSignContent($payContent)
    {
        unset($payContent['sign']);
        ksort($payContent);
        $stringToBeSigned = "";
        $i = 0;
        foreach ($payContent as $k => $v) {
            if (!isset($v)) {
                $a = true;
            } else if ($v === null) {
                $a = true;
            } elseif (trim($v) === "") {
                $a = true;
            } else {
                $a = false;
            }
            //截取字符串
            if (false === $a && "@" != mb_substr($v, 0, 1)) {
                //     // 转换成目标字符集
                /*if (!empty($v)) {
                    $fileType = 'UTF-8';
                    if (strcasecmp($fileType, AggregateConfig::charset) != 0) {
                        $v = mb_convert_encoding($v, AggregateConfig::charset, 'utf-8');
                    }
                }*/
                if ($i == 0) {
                    $stringToBeSigned .= "$k" . "=" . "$v";
                } else {
                    $stringToBeSigned .= "&" . "$k" . "=" . "$v";
                }
                $i++;
            }
        }
        unset ($k, $v);
        return $stringToBeSigned;
    }

    /**
     * 验证签名
     */
    private function verifySign($data, $pubKey)
    {
        $sign=$data['sign'];
        unset($data['sign']);
        unset($data['s']);
        ksort($data);
        $stringToBeSigned = "";
        $i = 0;
        foreach ($data as $k => $v) {
            if (!isset($v)){
                $a= true;
            }else if ($v === null){
                $a= true;
            } elseif (trim($v) === ""){
                $a= true;
            }else{
                $a= false;
            }
            //截取字符串
            if (false === $a && "@" !=  mb_substr($v, 0, 1)) {
                if ($i == 0) {
                    $stringToBeSigned .= "$k" . "=" . "$v";
                } else {
                    $stringToBeSigned .= "&" . "$k" . "=" . "$v";
                }
                $i++;
            }
        }
        unset($k, $v);
        $resa = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($pubKey, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";
        $result = (openssl_verify($stringToBeSigned, base64_decode($sign), $resa, OPENSSL_ALGO_SHA256)===1);//进行验签
        return $result;
    }

}