<?php
/**
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2018/11/29
 * Time: 10:05
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JRJF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'pid' => $this->partnerID,
            'type' => (string)$this->payType,
            'pay_type_index' => 'wap',
            'out_trade_no' => (string)$this->orderID,
            'total_fee' => sprintf("%.2f", $this->money),
            'subject' => (string)$this->orderID,
            'return_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
            'name' => 'TC',
            //'clientIp' => Client::getIp(),
        ];
        //秘钥存入 token字段中
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        //var_dump($this->parameter);exit();
    }


    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if($re['status'] == true){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['url'];
        }else{
            $this->return['code'] = $re['status'];
            $this->return['msg'] = 'JRJF:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
        /*$this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;*/
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['order_sn'],
            'third_money' => $parameters['total_fee'],
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
       $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }
    public function paraFilter($para) {
        $para_filter = array();
        foreach($para as $key => $val){
            if($key == "sign" || $val == ""){
                continue;
            }else{
                $para_filter[$key] = $para[$key];
            }
        }
        return $para_filter;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key=>$val)
        {
            $string = $string?$string."&".$key."=".$val:$key."=".$val;
        }
        $string = $string.$tKey;

        $sign = strtolower(md5($string));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        $param_filter = $this->paraFilter($params);
        ksort($param_filter);
        $string = "";
        foreach ($param_filter as $key=>$val)
        {
            $string = $string?$string."&".$key."=".$val:$key."=".$val;
        }
        $string = $string.$tkey;
        $sign = strtolower(md5($string));
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}
