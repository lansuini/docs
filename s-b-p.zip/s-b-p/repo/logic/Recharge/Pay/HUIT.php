<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 汇通
 * @author benchan
 */
class HUIT extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $this->parameter = array(
            'mch_id' => $this->partnerID,
            'money' => $this->money,
            'order_no' => $this->orderID,
            'notifyurl' => $this->notifyUrl
        );
        $this->parameter['sign'] = $this->getSign($this->parameter, $this->key);
        $this->parameter['remark'] = time();
        $this->parameter['paytype'] = $this->payType;
        $this->parameter['get_code'] = 1;
        $this->parameter['returnurl'] = $this->returnUrl;

    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['url']) && $re['url'] != null) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
//            if ($this->payType == 'code') {
//                $this->return['str'] = $this->qrcodeUrl . $re['url'];
//            } else {
            $this->return['str'] = $re['url'];
//            }
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = '汇通:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function getSign($params, $tKey)
    {
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign = md5($string . $tKey);
        return $sign;
    }


    public function returnVerify($parameters)
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['order_no'],
            'third_order' => $parameters['sdpayno'],
            'third_money' => $parameters['money'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($parameters['order_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if (!$this->returnVail($parameters, $config['key'], $parameters['sign'])) {
            $res['status'] = 0;
            $res['error'] = '该订单验签不通过或已完成';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function returnVail($params, $tkey, $thirdSign)
    {
        $data['mch_id'] = $params['mch_id'];
        $data['status'] = $params['status'];
        $data['sdpayno'] = $params['sdpayno'];
        $data['order_no'] = $params['order_no'];
        $data['money'] = $params['money'];
        $data['paytype'] = $params['paytype'];
        $sign = $this->getSign($data, $tkey);

        return $thirdSign == $sign;
    }
}
