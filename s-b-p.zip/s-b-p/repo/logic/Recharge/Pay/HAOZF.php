<?php
/**
 * 豪支付
 * @author Taylor 2019-04-06
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HAOZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'mno' => (string)$this->partnerID,//商户号
            'orderno' => (string)$this->orderID,//商户订单号
            'amount' => $this->money * 100,
            'paytype' => (string)$this->payType,//支付类型，bank_data
            'notify_url' => $this->notifyUrl,//页面跳转返回地址
        ];
        $pub_params['sign'] = md5($this->orderID . ($this->money * 100) . $this->payType . $this->key);
        $this->parameter = $pub_params;
        //var_dump($this->parameter);exit();
    }

    /**
     * 发起请求
     */
    public function parseRE()
    {
        //{"data":"trade_no=2020051004200315151054506771&biz_type=share_pp_pay&biz_sub
        //_type=peerpay_trade&presessionid=&app=tb&channel=&type2=gulupay","status":"成功"}
            $re = json_decode($this->re, true);
            if (isset($re['data']) && $re['status'] == '成功') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = $re['data'];
            } else {
                $this->return['code'] = 23;
                $this->return['msg'] = '豪支付：' . $re['data'];
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = null;
            }
    }


    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['orderno']) || !isset($data['amount'])) {
            return false;
        }
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['orderno'],//商户订单号
            'third_order' => $data['orderno'],//系统订单号
            'third_money' => $data['amount'] / 100,//支付金额
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }
        $this->key = $config['key'];

        $re_sign = md5($data['orderno'] . $data['amount'] . $this->key);

        if ($re_sign != $data['sign']) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

}