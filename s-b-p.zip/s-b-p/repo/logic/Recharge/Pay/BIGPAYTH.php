<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * BigPay-泰版
 */
class BIGPAYTH extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        /**
         * 异步通知地址在第三方后台配置!!!
         *  回调处理完成后返回 SUCCESS
         */

        //业务请求参数 Business request parameters
        $params = array(
            'merchant_ref' => $this->orderID,//是	string	商户订单号 Merchant order number
            'product' => $this->payType,//	是	string	产品名称 根据商户后台开通为主 product name Mainly based on the merchant backstage activation
            'amount' => $this->money,//	是	string	金额，单位，保留 2 位小数 Amount, unit, 2 decimal places
            //'extra'           => $extra,//	否	Object	额外参数， 默认为json字符串 {} Extra parameters, the default is json string {}
            //'language'        => '',//	否	string	收银台语言选择（详细请看语言代码） Cashier language selection (please see language code for details)
        );

        //extra 参数, 可选字段 extra parameter, optional field
        $extra = array(
            //	否	string	玩家付款账号【需同时传递 bank_code 字段】 Player payment account [need to pass the bank_code field]
            //'account_no' => '1234567890',

            //	否	string	玩家付款银行代码（详细请看银行代码）【需同时传递 account_no 字段】
            //Player's payment bank code (please see bank code for details) [need to pass the account_no field at the same time]
            //'bank_code' => 'KBANK',
        );

        //判断 额外参数是否为空 Determine whether the extra parameter is empty
        if ($extra) {
            $params['extra'] = $extra;
        }

        //转换json串 Convert json string
        $params_json = json_encode($params, 320);

        //请求参数 Request parameter
        $data = array(
            'merchant_no' => $this->partnerID,//	是	string	商户号 business number
            'timestamp' => time(),//	是	integer	发送请求的 10 位时间戳 10-bit timestamp of sending request
            'sign_type' => 'MD5',//	是	string	默认为 MD5 Default is MD5
            'params' => $params_json,//	是	string	请求业务参数组成的 JSON String；若接口对应的业务参数不需要字段传输，该字段的值可为空字符串
        );

        $data['sign'] = $this->getSign($data, $this->key);//MD5签名 不区分大小写

        $this->parameter = $data;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($data, $api_key)
    {
        //组装签名字段 签名 MD5(merchant_no+params+sign_type+timestamp+Key)-说明key 是商户秘钥
        //Assemble the signature field Signature MD5 (merchant_no+params+sign_type+timestamp+Key)-indicating that the key is the merchant secret key
        $merchant_no = isset($data['merchant_no']) ? $data['merchant_no'] : '';
        $params = isset($data['params']) ? $data['params'] : '';
        $sign_type = isset($data['sign_type']) ? $data['sign_type'] : '';
        $timestamp = isset($data['timestamp']) ? $data['timestamp'] : '';

        $sign_str = $merchant_no . $params . $sign_type . $timestamp . $api_key;
        $sign = md5($sign_str);//MD5签名 不区分大小写  MD5 signature is not case sensitive
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 200 && !empty($re['params'])) {
            $re = json_decode($re['params'], true);
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['payurl'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'BIGPAY-TH:' . (isset($re['message']) ? $re['message'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $params = isset($data['params']) ? json_decode($data['params'], true) : array();

        if (!isset($params['merchant_ref']) || !isset($params['system_ref']) || !isset($params['pay_amount'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $params['merchant_ref'],
            'third_order' => $params['system_ref'],
            'third_money' => $params['pay_amount'],
            'error' => '',
        ];

        if ($params['status'] !== 1) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['key']); //生成签名 Generate signature
        return $sign == $signOld;
    }
}