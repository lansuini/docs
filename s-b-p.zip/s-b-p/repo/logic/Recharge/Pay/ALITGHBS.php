<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

//某个封闭好的支付宝红包的 第三方  回调
class ALITGHBS extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
    }


    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        if(isset($data['s'])) unset($data['s']);
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['out_trade_no'],//商户订单号
            'third_order' => $data['trade_no'],//支付宝交易号
            'third_money' => $data['total_fee'] / 100,//实际支付金额，以元为单位
            'error' => '',
        ];

        if ($data['result_code'] != 'SUCCESS') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getOriginThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        //支付宝签名校验
        $result = $this->verifySign($data, $config['key']);
        if ($result === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateZfbMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    //更新金额
    public function updateZfbMoney($order_number, $money){
        $order_info = (array)\DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
        if ($order_info && ($order_info['i_money'] - $money == 0)){
            return true;
        }

        \DB::table('zfb_order')->where('order_number', $order_number)->update(['order_money' => (int)$money]);
        $updata = array(
            'i_money' => (int)$money,
            'i_gold' => (int)$money,
        );
        \DB::connection('jlmj_config')->table('zfb_order_place')->where('i_order_no', $order_number)->update($updata);
    }

    public function verifySign($params, $key)
    {

        $signStr = self::getSignContent($params).'&key='.$key;

        return strtoupper($params['sign']) == strtoupper(md5($signStr));
    }

    public function getSignContent($data)
    {
        $buff = '';
        ksort($data);
        foreach ($data as $k => $v) {
            $v = urldecode($v);
            $buff .= (!in_array($k, ['sign']) && $v !== '' && !is_array($v)) ? $k . '=' . $v . '&' : '';
        }

        //如果存在转义字符，那么去掉转义
        if (get_magic_quotes_gpc()) $buff = stripslashes($buff);

        return trim($buff, '&');
    }
}