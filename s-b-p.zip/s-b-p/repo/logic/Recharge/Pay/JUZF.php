<?php
/**
 * 炬支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JUZF extends BASES
{

    private $MD5_KEY = '';

    /**
     * 生命周期
     */
    public function start()
    {
        $this->prepareRequset();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function prepareRequset()
    {

        $merno = $this->partnerID;
        $version = 'V1.1';
        $amount = $this->money * 100;
        $signkey = $this->data['app_id'];
        $orderNum = $this->orderID;
        $paydata = [
            'orderId' => (string)$orderNum,
            'version' => (string)$version,
            'charset' => 'UTF-8',
            'random' => (string)mt_rand(1000, 9999),
            'account' => (string)$merno,
            'type' => $this->payType,
            'amount' => (string)$amount,
            'trade' => (string)'goodname',
            'backUri' => $this->notifyUrl,
            'skipUri' => $this->returnUrl
        ];
        ksort($paydata);
        $paydata['sig'] = strtoupper(md5(json_encode($paydata, 320) . $signkey));
        $data = [
            'account' => $merno,
            'version' => $version
        ];
        $encrypt = $this->publicEncrypt(json_encode($paydata), '');
        $data['data'] = urlencode($encrypt);
        $postdata = '';
        foreach ($data as $key => $val) {
            $postdata .= $key . "=" . $val . "&";
        }
        $postdata = rtrim($postdata, '&');
        $result = $this->CurlPost($this->payUrl, $postdata);
        $this->re = $result;
    }

    function CurlPost($url, $param)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;
    }


    /**
     * 公钥加密
     * @param $data
     * @return string
     */
    public function publicEncrypt($data)
    {
        $encrypted = '';
        $public_key = openssl_pkey_get_public($this->buildPublicKey($this->pubKey));

        $plainData = str_split($data, 117);
        foreach ($plainData as $chunk) {
            $str = '';
            $encryption = openssl_public_encrypt($chunk, $str, $public_key, OPENSSL_PKCS1_PADDING);
            if ($encryption === false) {
                return false;
            }
            $encrypted .= $str;
        }
        $encrypted = base64_encode($encrypted);
        return $encrypted;
    }

    function _privateDecrypt($encrypted, $private_key)
    {
        $decrypted = '';
        $private_key = openssl_pkey_get_private($this->buildPrivateKey($private_key));
        $plainData = str_split(base64_decode($encrypted), 128);
        foreach ($plainData as $chunk) {
            $str = '';
            $decryption = openssl_private_decrypt($chunk, $str, $private_key, OPENSSL_PKCS1_PADDING);
            if ($decryption === false) {
                return false;
            }
            $decrypted .= $str;
        }
        return $decrypted;
    }

    protected function buildPublicKey($key)
    {
        return "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($key, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";
    }

    protected function buildPrivateKey($key)
    {
        return "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $res = json_decode($this->re, true);
        if ($res['flag'] == '00') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $res['payUri'];
        } else {
            $this->return['code'] = $res['flag'];
            $this->return['msg'] = $res['msg'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);

        $data = $result['data'];
        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $result['orderId'],
            'third_order' => $result['orderId'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        $decrypt = $this->_privateDecrypt(urldecode($data), $config['key']); // 将data进行urldecode后再用回调rsa私钥解密，得到明文json字符串
        $tData = json_decode($decrypt);// 将json字符串转换为对象
        $tDataArray = json_decode($decrypt, true);
        $res['third_money'] = $tDataArray['amount'] / 100;

        $returnSig = $tData->sig;
        unset($tData->sig);
        // 签名
        ksort($tDataArray); // 字段名按照字典顺序排序
        $sysig = strtoupper(md5(json_encode($tData, 320) . $config['app_id'])); // 追加signkey进行MD5签名后，并将其加入回调数据
        // 验证
        if (strstr($returnSig, $sysig) != FALSE) {
            $result = $tData->result;
            if ('00' == $result) {
                // 判断成功走成功逻辑..........
                $this->updateMoney($res['order_number'], $res['third_money']);
                $res['status'] = 1;
                return $res;
            } else {
                $res['error'] = '支付失败';
                $res['status'] = 0;
            }
        } else {
            $res['error'] = '验证签名失败';
            return $res;
        }

    }

}