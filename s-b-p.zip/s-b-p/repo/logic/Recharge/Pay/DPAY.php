<?php
/**
 * DPAY
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class DPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'appKey' => $this->partnerID,
            'orderNo' => $this->orderID,
            'payChannel' => $this->payType,
            'chain' => 'eth',
            'currency' => 'usdt',
            'amount' => $this->money,
            'notifyUrl' => $this->notifyUrl,
            'timestamp' => $this->msectime(),
            'version' => '1.0',
            'source' => 'web',
            'notifyAll' => 'true',
        ];

        $this->parameter['sign'] = $this->sign($this->parameter,$this->key);
     }

    //返回当前的毫秒时间戳
    function msectime() {
        list($msec, $sec) = explode(' ', microtime());
        $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
        return $msectime;
    }



    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $data = json_decode($this->re, true);
        if (isset($data['respCode']) && $data['respCode'] == '000000') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['data']['payUrl'];

        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = $data['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderNo']) || !isset($parameters['payload'])) {
            return [
                'status' => 0,
                'error' => '未知错误',
            ];
        }
        $payload = str_replace("\\/", "/", $parameters['payload']);//去除转义问题
        $payload = (array)json_decode($payload);

        $amount = $payload['amount'];
        $res = [
            'status' => 0,
            'order_number' => $parameters['orderNo'],
            'third_order' => $parameters['orderSn'],
            'third_money' => $amount
        ];

        if ($parameters['status'] != 'SUCCESS') {
            $res['error'] = '支付失败！';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        if (!$this->verify($parameters,$parameters['sign'],$config['pub_key'])) {
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /* 过滤参数，格式化数据 */
    protected function createSignString($data)
    {
        ksort($data);
        $string = '';
        foreach ($data as $k => $vo) {
            if (is_null($vo) || $vo ===('') || $k === ('sign')) {
                continue;
            }

            $string .= $k . '=' . $vo . '&';
        }
        $string = rtrim($string, '&');
        return $string;
    }

    /* 使用私钥签名数据 */
    public  function sign($data,$privateKey)
    {
        $private_key = $privateKey;
        $sign_data =  $this->createSignString($data);
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($private_key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $res = openssl_get_privatekey($private_key);
        openssl_sign($sign_data, $sign, $res, OPENSSL_ALGO_SHA256);
        openssl_free_key($res);

        $sign = base64_encode($sign);
        return $sign;
    }

    /* 使用公钥验签签名 */
    public function verify($data, $sign,$publickey)
    {
        $dataStr = $this->createSignString($data);
        $pub_key = $this->getPubkey($publickey);
        $publicKeyId = openssl_get_publickey($pub_key);
        return (boolean)openssl_verify($dataStr, base64_decode($sign), $publicKeyId, OPENSSL_ALGO_SHA256);
    }

    /* 组装公钥 */
    protected function getPubkey($key)
    {
        $pay_public_key = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($key, 64) as $str) {
            $pay_public_key = $pay_public_key . $str . "\r\n";
        }
        $pay_public_key = $pay_public_key . "-----END PUBLIC KEY-----";

        return $pay_public_key;
    }
}