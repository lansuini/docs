<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/19
 * Time: 10:09
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 宝盒支付
 */
class BHZF extends BASES
{
    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = array(
            'appId' => $this->partnerID,
            'orderId' => $this->orderID,
            'feeType' => $this->data['rule'] == '3' ? 1 : 0, //0任意金额、1固定金额(PDD)
            'totalFee' => $this->money * 100, //单位分
            'payType' => $this->data['bank_data'],
            'notifyUrl' => $this->notifyUrl,
            'returnUrl' => $this->returnUrl
        );
        $this->parameter['sign'] = $this->sytMd5New($this->parameter, $this->key);
    }

    public function sytMd5New($pieces, $key)
    {
        ksort($pieces);
        $md5str = "";
        foreach ($pieces as $keyVal => $val) {
            if ($val !== null && $val != "") {
                $md5str = $md5str . $keyVal . "=" . $val . "&";
            }
        }
        $md5str = $md5str . "key=" . $key;
        $sign = strtoupper(md5($md5str));
        return $sign;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }


    //返回参数
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == '200') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['qrcode'];
        } else {
            $msg = $re['msg'] ?? "未知异常";
            $this->return['code'] = 886;
            $this->return['msg'] = 'BH:' . $msg;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    //签名验证
    public function returnVerify($pieces)
    {
        global $app;
        $pieces = $app->getContainer()->request->getParams();
        if (isset($pieces['s'])) {
            unset($pieces['s']);
        }

        if (!(isset($pieces['orderId']) && isset($pieces['outerOrderId']) && isset($pieces['totalFee']))) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $pieces['orderId'],
            'third_order' => $pieces['outerOrderId'],
            'third_money' => $pieces['totalFee'] / 100,//单位分
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($pieces['orderId']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        $sign = $pieces['sign'];
        if (!self::retrunVail($sign, $pieces, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/pay/query_order';
        }
        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && !in_array($success, [1, 2])) { //0未收款 1成功 2补单 其他失败
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    public function retrunVail($sign, $pieces, $key)
    {
        $md5str = 'outerOrderId=' . $pieces['outerOrderId'] . '&' . 'orderId=' . $pieces['orderId'] . '&' . 'key=' . $key;
        $new_sign = strtoupper(md5($md5str));
        return $sign == $new_sign;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "appId" => $partnerID,
            "orderId" => $orderNumber,
        ];

        $params['sign'] = $this->sytMd5New($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['status'])) {
            return $re['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }
}