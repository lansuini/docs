<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 *
 * 火星科技
 */
class HXKJ extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $pub_params['body'] = 'goods'; //商品名称
        $pub_params['orderNo'] = $this->orderID;                             //商户订单号，务必确保在系统中唯一，必填
        $pub_params['totalFee'] = $this->money;               //订单金额，单位为RMB元，必填
        $pub_params['paymethod'] = 'directPay';             //支付方式，directPay：直连模式；bankPay：收银台模式，必填
        $pub_params['defaultbank'] = $this->payType;         //网银代码，当支付方式为bankPay时，该值为空；支付方式为directPay时该值必传
        $pub_params['service'] = "online_pay";                      //固定值online_pay，表示网上支付，必填
        $pub_params['paymentType'] = "1";                           //支付类型，固定值为1，必填
        $pub_params['merchantId'] = $this->partnerID;                    //支付平台分配的商户ID，必填
        $pub_params['returnUrl'] = $this->returnUrl;         //支付成功跳转URL，仅适用于支付成功后立即返回商户界面，必填
        $pub_params['notifyUrl'] = $this->notifyUrl;    //商户支付成功后，该地址将收到支付成功的异步通知信息，该地址收到的异步通知作为发货依据，必填
        $pub_params['charset'] = "utf-8";                           //参数编码字符集，必填
        $pub_params['title'] = "goods";                               //商品的具体描述，选填
        $pub_params['isApp'] = "H5";

        $pub_params['sign'] = $this->getSign($pub_params, $this->key);
        $pub_params['signType'] = "SHA";//signType不参与加密，所以要放在最后
        $this->parameter = $pub_params;
        $this->payUrl = $this->payUrl.'/payment/v1/order/'.$this->partnerID.'-'.$this->orderID;

    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }
    public function getSign($pieces, $tkey)
    {
        ksort($pieces);
        $string = "";
        foreach ($pieces as $name => $value) {
            $string .= $name . '=' . $value . '&';
        }
        $string = substr($string, 0, strlen($string) -1 );
        $string .= $tkey;
        return strtoupper(sha1($string));
    }

    public function parseRE()
    {

        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    public function returnVerify($data)
    {

        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['order_no'],//商户订单号
            'third_order' => $data['trade_no'],//平台流水号
            'third_money' => $data['total_fee'],//支付金额，以元为单位
            'error' => '',
        ];

        if ($data['is_success'] != 'T') {//订单状态，1为成功，其它请看订单状态描述
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($data['order_no']);

        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if (!$this->returnVail($data,$config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['payurl'];
        $url = $url.'/payment/v1/order/'.$config['partner_id'].'-'.$res['order_number'];


        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'],$config['key']);
        //查询第三方有结果
        if ($success != null && $success != 'completed') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }
    /**
     * 签名校验
     * @param $param
     * @return boolean
     */
    public function returnVail($param,$key)
    {
        $signstr = $param['sign'];
        unset($param['sign']);
        unset($param['signType']);

        foreach ($param as &$item) {
            $item = urldecode($item);
        }

        $sign = $this->getSign($param,$key);

        return $sign == $signstr;
    }

    private function queryOrder($queryUrl, $orderNumber, $partnerID,$tkey)
    {
        $data = [
            "charset" => 'utf-8',
            "orderNo" => $orderNumber,
            "merchantId" => $partnerID,
        ];


        $data['sign'] = $this->getSign($data,$tkey);
        $data['signType'] = "SHA";

        $this->payUrl = $queryUrl;
        $this->parameter = $data;

        $this->get();

        $re = json_decode($this->re, true);

        if (isset($re['status'])) {
            return $re['status'];
        }
        return null;
    }


}