<?php
/**
 * BD支付
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class BDPAY extends BASES
{
    public $selfKey;

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->payJson2();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $data = [
            "ip" => (string)$this->clientIp,
            "outerOrderId" => (string)$this->orderID,
            "username" => (string)$this->partnerID,
            "submitAmount" => (string)$this->money,
            "payType" => (string)$this->payType,
            "callbackUrl" => (string)$this->notifyUrl,
        ];
        $this->selfKey = $this->key;
        //加密之后的数据
        $data = $this->encrypt(json_encode($data), $this->key);

        $pub_params = [
            "username" => (string)$this->partnerID,
            "timestamp" => (string)time(),
            "data" => $data,
        ];
        $pub_params['sign'] = md5($pub_params['username'] . $pub_params['timestamp'] . $pub_params['data'] . $this->key);
        $pub_params['remark'] = $this->orderID;
        $this->parameter = $pub_params;
    }

    //解密
    public function decrypt($string, $key)
    {
        return openssl_decrypt(base64_decode($string), 'AES-128-ECB', $key, OPENSSL_RAW_DATA);
    }

    //加密
    public function encrypt($string, $key)
    {
        return base64_encode(openssl_encrypt($string, 'AES-128-ECB', $key, OPENSSL_RAW_DATA));
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {

        $re = json_decode($this->re, true);
        if (isset($re['url']) && $re['code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['url'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'BDPAY：' . ($re['msg'] ?? '通道返回有误');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);


        if (!isset($parameters['data']) || !isset($parameters['sign']) || !isset($parameters['remark'])) {
            return false;
        }

        $config = Recharge::getThirdConfig($parameters['remark']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        $resSign = $parameters['sign'];
        $timestamp = $parameters['timestamp'];
        $dataJsonStr = $this->decrypt($parameters['data'], $config['key']);
        $parameters = json_decode($dataJsonStr,true);

        $res = [
            'status' => 0,
            'order_number' => $parameters['outerOrderId'],
            'third_order' => $parameters['orderId'],
            'third_money' => $parameters['submitAmount'],
        ];


        if ($parameters['status'] != '1') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $submitAmount = $parameters['submitAmount'];
        if(is_numeric($submitAmount)){
            $precision = is_float($submitAmount) ? 3 : 0;
            $submitAmount =  number_format($submitAmount, $precision, '.', '');
        }

        //按规则验签
        $resSignStr = $parameters['orderId'] . $parameters['outerOrderId'] . $submitAmount . $timestamp;
        $result = md5($resSignStr);
        if ($result != $resSign) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/Pay_Trade_query.html';
        }

        $success = $this->queryOrder($url, $res['third_order'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $order_number = $parameters['outerOrderId'];
        $return_money = $parameters['submitAmount'];

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $data = [
            "orderId" => $orderNumber,
        ];
        //加密之后的数据
        $data = $this->encrypt(json_encode($data), $tkey);
        $params = [
            "username" => $partnerID,
            "timestamp" => time(),
            "data" => $data,
        ];

        $params['sign'] =  md5($params['username'] . $params['timestamp'] . $params['data'] . $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->payJson2());

        $re = json_decode($this->re, true);

        if (isset($re['orderInfo'])) {
            return $re['orderInfo']['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}