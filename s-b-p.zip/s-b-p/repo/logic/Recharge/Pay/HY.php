<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 虎牙支付
 * @author benchan
 */
class HY extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private $params;

    //组装数组
    public function initParam()
    {

        $this->params = array(
            //基本参数
            'version' => '1.0.1',
            'amount' => $this->money,
            'notifyUrl' => urlencode($this->notifyUrl),
            'orgOrderNo' => $this->orderID,
            'source' => $this->payType,
            'subject' => time(),
            'extra_para' => $this->orderID,
            'tranTp' => '1'
        );
        $this->parameter['reqJson'] = $this->getDeStr($this->params);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re && $re['responseCode'] == '200') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            if ($this->data['return_type'] == 'code') {
                $this->return['str'] = $this->qrcodeUrl . $re['responseObj']['qrCode'];
            } else {
                $this->return['str'] = $re['responseObj']['qrCode'];
            }
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = '虎牙:' . $re['responseMessage'] ?? '未知异常';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function getStr($params)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            $string = $string . $k . '=' . $v . '&';
        }
        $str = rtrim($string, '&');
        return $str;
    }

    //加密
    public function getDeStr($arr)
    {
        $str = $this->getStr($arr);
        $baseStr = base64_encode($str);
        $aesPrivage = $this->encrypt($baseStr, $this->data['app_secret']);
        $aesPrivage = strtoupper($aesPrivage);
        $sign = strtoupper(md5($aesPrivage . $this->key));
        $this->params['sign'] = $sign;

        $str2 = $this->getStr($this->params);
        $baseStr2 = base64_encode($str2);
        $transData = $this->encrypt($baseStr2, $this->data['app_secret']);
        $data = array();
        $data['merchantCode'] = $this->partnerID;
        $data['transData'] = $transData;
        $reqStr = json_encode($data);
        return $reqStr;
    }


    public function returnVerify($input)
    {
        $reqJson = $input['reqJson'];
        $data = json_decode($reqJson, true);

        $config = Recharge::getThirdConfig($data['extra_para']);

        //解密
        $sec_dec = $this->decrypt($data['transData'], $config['app_secret']);
        $sec_dec = base64_decode($sec_dec);
        $pra = explode("&", $sec_dec);
        $result_pra = array();//异步回调的参数
        foreach ($pra as $thispra) {
            $temp_pra = explode("=", $thispra);
            $result_pra[$temp_pra[0]] = $temp_pra[1];
        }

        $res = [
            'status' => 1,
            'order_number' => $result_pra['reqMsgId'],
            'third_order' => $result_pra['smzfMsgId'],
            'third_money' => $result_pra['totalAmount'],
            'error' => '',
        ];

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if (!$this->returnVail($result_pra, $config, $result_pra['sign'])) {
            $res['status'] = 0;
            $res['error'] = '该订单验签不通过或已完成';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function returnVail($result_pra, $config, $sign)
    {
        //移除sign
        unset($result_pra["sign"]);
        $result_str = $this->getStr($result_pra);
        $baseStr = base64_encode($result_str);
        $aesPrivage = $this->encrypt($baseStr, $config['app_secret']);
        $aesPrivage = strtoupper($aesPrivage);
        $sign2 = strtoupper(md5($aesPrivage . $config['pub_key']));
        if ($sign == $sign2) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 加密
     * @param String input 加密的字符串
     * @param String key   解密的key
     * @return HexString
     */
    public function encrypt($input, $key)
    {

        $size = @mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB);
        $input = $this->pkcs5_pad($input, $size);
        $td = @mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_ECB, '');
        $iv = @mcrypt_create_iv(@mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        @mcrypt_generic_init($td, $key, $iv);
        $data = @mcrypt_generic($td, $input);
        @mcrypt_generic_deinit($td);
        @mcrypt_module_close($td);
        $data = bin2hex($data);
        return $data;

    }

    /**
     * 填充方式 pkcs5
     * @param String text         原始字符串
     * @param String blocksize   加密长度
     * @return String
     */
    private function pkcs5_pad($text, $blocksize)
    {

        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);

    }

    /**
     * 解密
     * @param String input 解密的字符串
     * @param String key   解密的key
     * @return String
     */
    public function decrypt($sStr, $key)
    {
        $decrypted = @mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, self::hex2bins($sStr), MCRYPT_MODE_ECB);
        $dec_s = strlen($decrypted);
        $padding = ord($decrypted[$dec_s - 1]);
        $decrypted = substr($decrypted, 0, -$padding);
        return $decrypted;
    }

    public function hex2bins($data)
    {
        $len = strlen($data);
        $newdata = '';
        for ($i = 0; $i < $len; $i += 2) {
            $newdata .= pack("C", hexdec(substr($data, $i, 2)));
        }
        return $newdata;
    }
}
