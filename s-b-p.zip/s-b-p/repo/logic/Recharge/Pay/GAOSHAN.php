<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Curl;


/**
 * 高山支付 USDT
 */
class GAOSHAN extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
            \DB::table('order')->where('order_number', $this->orderID)->update(['order_money' => $this->money]);
        }
        $this->initParam();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //获取汇率
        $rates = $this->getCoinRates();
        $money_usdt = 0;
//        if (isset($rates['cny_usdt']['rate'])) {
//            $money_usdt = $this->money * $rates['cny_usdt']['rate'];
//        }
        if ($rates != null) {
            $money_usdt = $this->money / $rates;//rates 为usdt转cny汇率,例6.51
        }

        if ($money_usdt == 0) {
            //获取汇率失败，中断交易
            $this->return['code'] = 886;
            $this->return['msg'] = '获取虚拟货币汇率失败,请稍后重试';
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
            return;
        }

        //https://pay.s168.co/usdt_in_order
        $data = [
            'type' => 'ERC20', //支付类型
            'merchant_money' => sprintf("%.2f", $money_usdt), //usdt
            'order_id' => $this->orderID,
            'merchant' => $this->partnerID,
            'account' => $this->uid,
            'rt_url' => $this->notifyUrl,
            'merchant_amount_cny' => $this->money,//人民币金额。无作用，只作透传到回调，如果有要加入签名
        ];

        //https://pay.s168.co/usdt_in_3
        if (ends_with($this->payUrl, "usdt_in_3")) {
            $data['pick_url'] = $this->returnUrl;
        }

        $data['sign'] = $this->getSign($data, $this->key);
        $this->parameter = $data;
        $this->parseRE();
    }

    private function getSign($data, $key)
    {
        //签名前字符串(旧版)
//        $signStr = $data['type'] . $data['merchant'] . $data['pick_url'] . $this->key . $data['rt_url'] . $data['account'];
//        $data['sign'] = md5($signStr);//md5(type + merchant + pick_url + KEY + rt_url + account );

        /*
         * 新版签名
         * 有 merchant_amount_cny
sign=md5("type=" + type + "&merchant=" + merchant + "&merchant_money=" + merchant_money +
"&pick_url=" + pick_url + KEY + "&rt_url=" + rt_url + "&account=" + account + "&order_id=" + order_id
+ "&merchant_amount_cny=" + merchant_amount_cny);
無 merchant_amount_cny
sign=md5("type=" + type + "&merchant=" + merchant + "&merchant_money=" + merchant_money +
"&pick_url=" + pick_url + KEY + "&rt_url=" + rt_url + "&account=" + account + "&order_id=" + order_id);
         *
         */

        $signStr = "type=" . $data['type'] . "&merchant=" . $data['merchant'] . "&merchant_money=" . $data['merchant_money'] .
            (isset($data['pick_url']) ? "&pick_url=" . $data['pick_url'] : '') //usdt_in_order接口没这参数usdt_in_3接口有
            . $key . "&rt_url=" . $data['rt_url'] . "&account=" . $data['account'] . "&order_id=" . $data['order_id'] .
            (isset($data['merchant_amount_cny']) ? "&merchant_amount_cny=" . $data['merchant_amount_cny'] : '');
        return md5($signStr);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    private function getCoinRates()
    {
        /*
         *
        {
    "status": 200,
    "msg": "",
    "data": {
        "cny_usdt": {
            "coin": "cny",
            "currencyCoin": "usdt",
            "rate": "0.146471",
            "rateTime": "2018-08-03 23:29:03",
            "ratenm": "cny/usdt",
            "flatform": "api.k780.com",
            "created": "1533461732",
            "timezone": "PRC"
        },
        "usdt_cny": {
            "coin": "usdt",
            "currencyCoin": "cny",
            "rate": "6.853000",
            "rateTime": "2018-08-06 20:39:01",
            "ratenm": "usdt/cny",
            "flatform": "api.k780.com",
            "created": "1533559242",
            "timezone": "PRC"
        },
    }
        }
         */
//        $resp = Curl::get('https://apiv2.bitz.com/Market/currencyRate?symbols=cny_usdt,usdt_cny');
//        $re = json_decode($resp, true);
//        if (!empty($re['data'])) {
//            return $re['data'];
//        }

        $data = array(
            "merchant" => $this->partnerID,
            "type" => "CNY",
        );
        $sign_str = $this->partnerID . $this->key;
        $data['sign'] = md5($sign_str);
        $resp = Curl::commonPost('https://merchant.s168.co/coin_price', null, $data);
        $re = json_decode($resp, true);
        if (!empty($re['price'])) {
            return $re['price'];
        }
        return null;
    }

    public function parseRE()
    {
        if (ends_with($this->payUrl, "usdt_in_3")) {
            //使用redis保存信息的跳转页面
            $this->buildGoOrderUrl();
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->goPayUrl;
        } else {
            //https://pay.s168.co/usdt_in_order
            $this->basePost();
            $re = json_decode($this->re, true);
            if (isset($re['url']) && $re['code'] == '100') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->showType;
                $this->return['str'] = $re['url'];
            } else {
                $this->return['code'] = 886;
                $this->return['msg'] = 'GAOSHAN:' . (isset($re['status']) ? $re['status'] : $this->re);
                $this->return['way'] = $this->showType;
                $this->return['str'] = '';
            }
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['order'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['order'],
            'third_order' => $data['order'],
        ];

        if ($data['status'] != 'success' || !isset($data['pay_amount'])) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //因汇率问题,用下单金额上分
        $res['third_money'] = $config['order_money'];

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        //Md5(云端编号+订单号+商户号+'sign'+商户密钥key)(旧版)
        $key = $config['key'];
//        $signStr = $key . $data['account'] . $data['pay_amount'] . $data['order'] . $data['blocktime'] . $key . $data['merchant'] . $data['type'];
//        $sign = md5($signStr);//md5(KEY + account + pay_amount + order + blocktime + KEY + merchant + type);

        //新版
        /*
         有 merchant_amount_cny
sign= md5(KEY + "account=" + account + "&pay_amount=" + pay_amount + "&order=" + order +
"&blocktime=" + blocktime + KEY + "&merchant=" + merchant + "&type=" + type +
"&merchant_amount_cny=" + merchant_amount_cny);
無 merchant_amount_cny
sign= md5(KEY + "account=" + account + "&pay_amount=" + pay_amount + "&order=" + order +
"&blocktime=" + blocktime + KEY + "&merchant=" + merchant + "&type=" + type ); 
         */
        $signStr = $key . "account=" . $data['account'] . "&pay_amount=" . $data['pay_amount'] . "&order=" . $data['order'] . "&blocktime=" . $data['blocktime'] . $key . "&merchant=" . $data['merchant'] . "&type=" . $data['type'] .
            (isset($data['merchant_amount_cny']) ? "&merchant_amount_cny=" . $data['merchant_amount_cny'] : '');
        $sign = md5($signStr);
        return $sign == $signOld;
    }

}