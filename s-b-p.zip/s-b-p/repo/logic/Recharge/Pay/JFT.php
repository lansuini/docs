<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 聚付通
 * @author lavenkin
 */
class JFT extends BASES 
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = [
            'mch_id' => $this->partnerID,
            'trade_type' => $this->data['bank_data'],
            'nonce' => md5(time() . mt_rand(0,1000)),
            'user_id' => '',
            'timestamp' => time(),
            'subject' => 'gold',
            'detail' => '',
            'out_trade_no' => $this->orderID,
            'total_fee' => (int) $this->money * 100,
            'spbill_create_ip' => $this->clientIp,
            'timeout' => '',
            'sign_type' => 'MD5',
            'notify_url' => $this->notifyUrl,
            'return_url' => $this->returnUrl,
        ];


        $this->parameter['sign'] = $this->_sign($this->parameter);
    }

    public function parseRE()
    {
        // var_dump($this->re);exit;
        $re = json_decode($this->re, true);

        if (isset($re['pay_url']) && $re['pay_url'] != null) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['pay_url'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '聚富通：' . $re['message'] ?? '通道返回有误';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 生成sign
     */
    private function _sign($pieces)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $keys => $value){
            if ($value != '' && $value != null){
                $string = $string.$keys . '=' . $value . '&';
            }
        }
        $string = $string . 'key=' . $this->key;
        // print($string);exit;
        $sign = strtoupper(md5($string));
 
        return $sign;
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($parameters) 
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['platform_trade_no'],
            'third_money' => $parameters['total_fee'] / 100 ?? 0,
            'error' => '',
        ];

        if ($parameters['result_code'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        //校验sign
        $publicKeyString = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($config['pub_key'], 64, "\n", true) . "\n-----END PUBLIC KEY-----";
        // var_dump($publicKeyString);exit;
        if (! $this->_verifySign($parameters, $publicKeyString, $parameters['sign'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        return $res;
    }

    /**
     * 验证sign
     */
    private function _verifySign($data, $pubkey, $sign) 
    {
        ksort($data);
        $arg = '';
        foreach($data as $key => $val) {
            if ($key == 'sign' || $val == '')
                continue;

            $arg .= $key.'='.$val.'&';
        }
        $arg = substr($arg, 0, strlen($arg) - 1);
        $arg = md5($arg);
        // var_dump($arg);exit;
        //如果带有反斜杠 则转义
        // if (get_magic_quotes_gpc()) $arg = stripslashes($arg);
        $res = openssl_get_publickey($pubkey);
        // var_dump($res);exit;
        $result = (bool) openssl_verify($arg, base64_decode(urldecode($sign)), $res, OPENSSL_ALGO_SHA256);
        // var_dump($result);exit;
        // openssl_free_key($res);

        return $result;
    }

}
