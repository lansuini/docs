<?php
/**
 * E付付
 * Created by PhpStorm.
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class EFBZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'merchantid' => intval($this->partnerID),
            'paytype' => (string)$this->payType,
            'money' => sprintf("%.2f", $this->money),
            'orderid' => (string)$this->orderID,
            'returnurl' => $this->returnUrl,
            'notifyurl' => $this->notifyUrl,
        ];

        $signParams = [
            'merchantid' => intval($this->partnerID),
            'money' => sprintf("%.2f", $this->money),
            'orderid' => (string)$this->orderID
        ];

        $this->parameter['sign'] = $this->_sign($signParams, $this->key);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderid']) || !isset($parameters['money']) || !isset($parameters['status'])) {
            return [
                'status' => 0,
                'error' => "参数错误",
            ];
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['orderid'],
            'third_order' => $parameters['orderid'],
            'third_money' => $parameters['money'],
        ];

        if ($parameters['status'] != 'success') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['error'] = '支付失败';
            return $res;
        }

        $signParams = [
            'merchantid' => $parameters['merchantid'],
            'money' => $parameters['money'],
            'orderid' => $parameters['orderid'],
        ];

        if ($parameters['sign'] != $this->_sign($signParams, $config['key'])) {
            $res['error'] = '验证签名失败';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $url = $config['payurl'] . 'queryorder.html';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != 'success') {
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "merchantid" => $partnerID,
            "orderid" => $orderNumber,
        ];

        $params['sign'] = $this->_sign($params, $tkey);

        $params['reqtime'] = date('YmdHis');

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->get();

        $re = json_decode($this->re, true);

        if (isset($re['status'])) {
            return $re['status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $privateKey)
    {
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . '&' . $privateKey;
        $sign = md5($sign_str);
        return strtolower($sign);
    }
}