<?php
/**
 * 返利支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/28
 * Time: 9:02
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class FLPAY extends BASES
{


    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    public function initParam()
    {
        date_default_timezone_set('Asia/Shanghai');
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        //第三方方案，对金额-5处理
        $money = $this->money -5;
        $pub_params = [
            'mch_id' => $this->partnerID,
            'paytype' => $this->payType,
            'order_no' => (string)$this->orderID,
            'order_time' => date('YmdHis',time()),
            'amount' => $money,
            'return_url' => $this->notifyUrl,
            'subject' => (string)$this->orderID,
        ];
        $pub_params['sign'] = $this->_sign($pub_params,$this->key);
        //var_dump($pub_params);exit();
        $this->parameter = $pub_params;
    }

    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if (isset($re['data'])){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $re_data = $re['data'];
            $this->return['str'] = $re_data['qrcode'];

        }else{
            $this->return['code'] = 999;
            $this->return['msg'] = $re['err_msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['order_no'],
            'third_order' => $parameters['tran_id'],
            'third_money' => $parameters['amount'],
        ];
        $config = Recharge::getThirdConfig($parameters['order_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['order_no'];
            $return_money = intval($parameters['amount']);
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    private function _sign($pieces,$tkey)
    {
        $string = $pieces['order_no'].$pieces['amount'].$tkey.$pieces['mch_id'];
        $sign = md5($string);
        return $sign;
    }

    public function returnVail($params,$tkey)
    {
        if (isset($params['re_flag'])){
            if ($params['re_flag'] != 1){
                return false;
            }
        }
        $return_sign = $params['sign'];
        $string = $params['order_no'].$params['amount'].$params['tran_id'].$tkey;
        $sign = md5($string);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}