<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 大相支付/大向支付
 * @author lavenkin
 */
class DAX extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $tmp = [
            'orderNo' => $this->orderID,
            'orderAmt' => $this->money * 100,
            'orderName' => 'GOODS'.time(),
            'payMethod' => $this->payType,
            'userId' => $this->uid,
            'userIp' => $this->clientIp,
            'notifyUrl' => $this->notifyUrl,
            'returnUrl' => $this->returnUrl,
            'commont' => $this->orderID,
        ];
        $this->parameter = [
            'servicename' => 'order.submit',
            'charset' => 'UTF-8',
            'version' => '1.0',
            'merid' => $this->partnerID,
            'requesttime' => date("YmdHis"),
            'busidata' => json_encode($tmp),
        ];

        $this->parameter['signdata'] = strtoupper($this->currentMd5('key='));
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if(isset($re['busidata'])) {
            $re['busidata'] = json_decode( $re['busidata'],true);
        }
        if (isset($re['busidata']) && $re['busidata']['resultCode'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['busidata']['payUrl'];
        } else {
            $msg = $re['busidata']['resultDesc'] ?? '第三方通道返回有误';
            $this->return['code'] = 23;
            $this->return['msg'] = 'DAX：' . $msg;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($parameters) 
    {
        $data = json_decode($parameters['busidata'],true);
        $res = [
            'status' => 0,
            'order_number' => $data['orderNo'],
            'third_order' => $data['orderNo'],
            'third_money' => $data['orderAmt'] / 100,
            'error' => '',
        ];

        if ($data['result'] != 'SUCCESS') {
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($data['orderNo']);
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }
        $sign = $parameters['signdata'];
        unset($parameters['signdata']);
        $this->parameter = $parameters;
        $this->key = $config['key'];
        if (strtolower($sign) != strtolower($this->currentMd5('key='))) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
