<?php
/**
 * AK支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class AK2 extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {

        $this->parameter = [
            'MchId' => $this->partnerID,
            'MchOrderNo' => $this->orderID,
            'NotifyUrl' => $this->notifyUrl,
            'RequestTime' => date('Y-m-d H:i:s', time()),
            'CategoryCode' => $this->payType,
            'Amount' => sprintf("%.2f", $this->money),
            'ClientIp' => $this->clientIp,
        ];

        //签名方式由第三方后台控制，我们采用的MD5方式 第三方后台可能默认是RC4 需要自行登陆上去修改
        $this->parameter['Sign'] = $this->_sign($this->parameter, $this->key);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($val != null && $val !== '' && $key !== 'Sign') {
                $string[] = strtolower($key) . '=' . $val;//MD5加密时字段请改为小写
            }
        }
        $params = join('&', $string);
        $sign_str = $params . '&key=' . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['Success']) && $re['Success'] == true && isset($re['ResData'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;

            $content = $re['ResData']['CallBackUrl'];
//            if ($this->showType == 'sdk' && !empty($re['data']['sdk'])) {
//                $content = $re['data']['sdk'];
//            }
            $this->return['str'] = $content;
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = "AK2:" . (isset($re['ErrMsg']) ? $re['ErrMsg'] : $this->re);
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);

        if (!isset($data['MchOrderNo']) || !isset($data['Amount'])) {
            // 非法数据
            return false;
        }
        $res = [
            'status' => 1,
            'order_number' => $data['MchOrderNo'],
            'third_order' => $data['OrderNo'],
            'third_money' => $data['Amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

//        if ($data['pay_status'] != 4) {
//            $res['status'] = 0;
//            $res['error'] = '未支付';
//            return $res;
//        }

        unset($data['OrderNo']);//不进入验签参数
        if (isset($data['Amount']) && is_float($data['Amount'])) {
            $data['Amount'] = sprintf("%.2f", $data['Amount']);//因为整数300.00验签时自动转为300 导致验签不通过
        }
        if (strtolower($data['Sign']) != $this->_sign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }


        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/api/Core/Order/GetOrderInfo';
        }

        $success = $this->queryOrder($url, $res['order_number'], $res['third_order'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '查询订单返回状态:' . $success,
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function queryOrder($queryUrl, $orderNumber, $third_order, $partnerID, $tkey)
    {
        $params = [
            "OrderNo" => $third_order,
            "MchId" => $partnerID,
            "MchOrderNo" => $orderNumber,
        ];

        $params['Sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->payJson2());

        $re = json_decode($this->re, true);

        if (isset($re['ResData'])) {
            return $re['ResData'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }
}
