<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * CUPAY
 * @author
 */
class CUPAY extends BASES {

    //与第三方交互
    public function start(){
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }
    //组装数组
    public function initParam(){
        $this->parameter = array(
            'merchNo' => $this->partnerID,
            'orderNo' => $this->orderID,
            'amount' => sprintf('%.2f', $this->money * 100), //保留两位小数一分为单位
            'currency' => 'CNY',
            'outChannel' => $this->payType,
            'title' => 'way memo',
            'product' => 'way memo',
            'returnUrl' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,
            'reqTime' =>  date('YmdHis',time()),
            'userId' => $this->uid,
        );

        $this->parameter = json_encode($this->parameter);
        $sendSign = md5($this->parameter.$this->key);

        $this->parameter = [
            'sign' => $sendSign,
            'context' => base64_encode($this->parameter),
        ];
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }


    public function parseRE(){
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    public function returnVerify($data) {

        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if(!isset($data['orderNo']) || !isset($data['code']) || !isset($data['context'])){
            $res['status'] = 0;
            $res['error'] = '非法数据';
            return $res;
        }

        $sign = $data['sign'];
        $successCode = $data['code'];
        $data = json_decode(base64_decode($data['context'], true), true);

        $res = [
            'status' => 0,
            'order_number' => $data['orderNo'],
            'third_order' => $data['orderNo'],
            'third_money' => $data['amount'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($successCode != 0) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $data = json_encode($data);
        $sendSign = md5($data.$config['key']);
        if ($sign != $sendSign) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }
}
