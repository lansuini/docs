<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * APAY
 */
class APAY extends BASES
{

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $tmp = explode('-', $this->payType);
        $this->parameter = [
            'mechno' => $this->partnerID,
            'payway' => $tmp[0],
            'paytype' => $tmp[1],
            'amount' => $this->money * 100,
            'timestamp' => time() * 1000,
            'orderno' => $this->orderID,
            'body' => 'GOODS',
            'orderip' => $this->clientIp,
            'returl' => $this->returnUrl,
            'notifyurl' => $this->notifyUrl,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function parseRE()
    {
        //支付宝Wap/微信H5直接重定向
        if (in_array($this->parameter['paytype'], ['DIRECT_PAY', 'H5PAY'])) {
            $this->buildGoOrderUrl("get");
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->goPayUrl;
        } else {
            $this->basePost();
            $re = json_decode($this->re, true);
            if (isset($re['data']['payUrl']) && $re['data']['payUrl']) {
                $this->return['code'] = 0;
                $this->return['msg'] = 'success';
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = $re['data']['payUrl'];
            } else {
                $this->return['code'] = 23;
                $this->return['msg'] = 'APAY：' . ($re['message'] ?? '通道返回有误');
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }
    }

    /**
     * 返回地址验证
     *
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!(isset($parameters['extra']) && isset($parameters['transactionid']) && isset($parameters['totalfee']))) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $parameters['extra'],
            'third_order' => $parameters['transactionid'],
            'third_money' => $parameters['totalfee'] / 100,
            'error' => '',
        ];

        if ($parameters['tradestate'] != 100) {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['extra']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign
        $sign = $parameters['sign'];

        if (strtoupper($sign) != $this->_sign($parameters, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _sign($arr, $tkey)
    {
        unset($arr['sign']);
        unset($arr['s']);
        ksort($arr);
        $str = '';
        foreach ($arr as $key => $val) {
            $str .= $key . '=' . $val . '&';
        }
        $str .= 'key=' . $tkey;
        return strtoupper(md5($str));
    }
}
