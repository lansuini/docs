<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 *
 * 传奇支付
 */
class CHUANQIPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $parameter = [
            'bid' => $this->partnerID,
            'money' => $this->money,
            'order_sn' => (string)$this->orderID,
            'notify_url' => $this->notifyUrl,
            'pay_type' => $this->payType,
        ];
        $parameter['sign'] = $this->_sign($parameter, $this->key);
        $this->parameter = $parameter;
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['data']) && $re['code'] == '100') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['url'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'CHUANQIPAY:' . (isset($re['msg']) ? $re['msg'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        if (!isset($parameters['order_sn']) || !isset($parameters['sys_order_sn']) || !isset($parameters['pay_money'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['order_sn'],
            'third_order' => $parameters['sys_order_sn'],
            'third_money' => $parameters['pay_money'],
        ];

        if ($parameters['pay_state'] != '1') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['order_sn']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        $arr = parse_url($config['payurl']);
        if (empty($url)) {
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/api/detail';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1' ) {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }

        $order_number = $parameters['order_sn'];
        $return_money = intval($parameters['pay_money'] );

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($val != null && $val != '') {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);
        $sign_str = $params . $tkey;
        $sign = md5($sign_str);

        //echo $sign."\n";
        //echo $sign_str."\n";
        return ($sign);
    }


    public function returnVail($data, $pubkey)
    {
        $signstr = $data['sign'];
        unset($data['sign']);
        //echo $signstr."\n";
        $sign = $this->_sign($data, $pubkey);
        return $sign == $signstr;
    }

    /**
     * 请求查询，核对字段
     */
    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "bid" => $partnerID,
            "order_sn" => $orderNumber
        ];

        $params['Sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());
        $re = json_decode($this->re, true);

        if (isset($re['data']['pay_state'])) {
            return $re['data']['pay_state'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

}