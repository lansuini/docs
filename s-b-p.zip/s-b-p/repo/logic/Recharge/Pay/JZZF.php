<?php
/**
 * 聚众支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JZZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = array(
            'merId'			   => $this->partnerID,
            'terId'            => '201906121415200',
            'businessOrdid'    => $this->orderID,
            'orderName'		   => 'goods',
            'tradeMoney'       => $this->money * 100,
            'payType'          =>  $this->payType,
            'appSence'         => '1002',
            'asynURL'          => $this->notifyUrl,
        );

        //秘钥存入 sign字段中
        $this->parameter['sign'] = $this->_sign($this->parameter,$this->key);

    }

    /**
     * 生成sign
     */
    private function _sign($params,$tkey)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign_str = $string.'key='.$tkey;
        $sign = md5($sign_str);
        return strtolower($sign);
    }
    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;

    }



    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);

        $res = [
            'status' => 1, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $result['orderId'],
            'third_order' => $result['payOrderId'],
            'third_money' =>$result['money']/100,  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        if ($result['respCode'] != '1000'){
            $res['error'] = '支付失败';
            return $res;
        }

        $result = $this->returnVail($result, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }

        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }
    /*  这个是验签方法  */
    public function returnVail($_encParam,$apikey){
//        $apikey=$this->apikey;//秘钥
        $str222='';
        foreach($_encParam as $k=>$v){
            if($k=='sign'){
                $str222=$_encParam[$k];
                unset($_encParam[$k]);
            }
            if($k=='signType'){
                unset($_encParam[$k]);
            }
        }
        $_encParam=array_filter($_encParam); // 过滤掉数组中键值为空的值
        ksort($_encParam);   // 按照键名首字母进行排序
        $str='';
        foreach($_encParam as $k=>$v){
            $str.=$k.'='.$v.'&';
        }
        $key=$apikey;
        $str.= "key=".$key;
        $sign=md5($str);
        if($sign==$str222){
            return $bool=true;  //验签成功
        }else{
            return $bool=false;  //验签失败
        }
    }
}