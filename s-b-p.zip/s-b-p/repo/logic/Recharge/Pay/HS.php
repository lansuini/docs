<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Logic\Recharge\Traits\RechargeLog;


/**
 * 红杉支付
 * @author zhangli
 */
class HS extends BASES
{

    //与第三方交互
    public function start()
    {

        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $this->parameter = array(
            'companyId' => $this->partnerID,
            'userOrderId' => $this->orderID,
            'fee' => $this->money * 100,
            'payType' => $this->data['bank_data'],
            'item' => 'goods',
            'syncUrl' => $this->notifyUrl,
            'callbackUrl' => $this->returnUrl,
            'ip' => $this->data['client_ip']
        );

        $this->parameter['sign'] = $this->sytMd5($this->parameter, $this->key);
//        if($this->data['bank_data']=='21'){
//            $this->parameter['sign']=
//        }
    }


    public function sytMd5($piecess, $key)
    {
        $pieces['companyId'] = $piecess['companyId'];
        $pieces['userOrderId'] = $piecess['userOrderId'];
        $pieces['fee'] = $piecess['fee'];
        $string = '';
        foreach ($pieces as $keys => $value) {
            if ($value != '' && $value != null) {
                $string = $string . $value . '_';
            }
        }
        $string = $string . $key;
        $sign = strtolower(md5($string));
        return $sign;
    }


    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['result'] == '0') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['param'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'HS:' . $re['msg'] ?? "未知异常";
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        $res = [
            'status' => 1,
            'order_number' => $input['userOrderId'],
            'third_order' => $input['orderId'],
            'third_money' => $input['fee'] / 100,
            'error' => '',
        ];


        $config = Recharge::getThirdConfig($input['userOrderId']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
        }

        $sign = $input['sign'];
        $newSign = $this->sytMd5($input, $config['key']);
        if ($newSign != $sign) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        return $res;
    }
}
