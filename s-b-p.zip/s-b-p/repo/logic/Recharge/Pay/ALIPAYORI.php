<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/19
 * Time: 10:09
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 原生支付宝
 * @package Logic\Recharge\Pay
 */
class ALIPAYORI extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $apiMethodName = 'alipay.trade.wap.pay';
        //公共请求参数
        $sysParams = [
            'app_id' => $this->data['partner_id'],
            'method' => $apiMethodName,
            'format' => 'JSON',
            'charset' => 'UTF-8',
            'sign_type' => 'RSA2',
            'timestamp' => date("Y-m-d H:i:s"),
            'version' => '1.0',
//            'return_url'=>'',
            'notify_url'=>$this->data['url_notify'],
        ];
        //业务参数
        $bizContent = [
            'subject'=> 'VIP:'.time(),//商品的标题
            'out_trade_no' => $this->data['order_number'],//商户网站唯一订单号
//            'timeout_express'=> '',//最晚付款时间
            'total_amount' => $this->data['money'],//订单总金额，单位为元
            'product_code' => 'QUICK_WAP_WAY',
        ];
        $apiParams = [
            'biz_content' => $this->getBizContent($bizContent),
        ];
        $this->parameter = array_merge($apiParams, $sysParams);
        $this->parameter['sign'] = $this->createRsaSign($this->parameter, $this->data['key']);
    }

    protected function getBizContent($arrBizContent)
    {
        $strBizContent = "{";

        foreach ($arrBizContent ?? [] as $key => $val) {
            $strBizContent .= '"' . $key . '":"' . $val . '",';
        }

        if (strlen($strBizContent) > 1) {
            $strBizContent = \substr($strBizContent, 0, -1);
        }

        $strBizContent .= "}";

        return $strBizContent;
    }

    protected function createRsaSign($params, $rsaPrivateKey)
    {
        $sign = '';
        $content = $this->getSignContent($params);
        $key = "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($rsaPrivateKey, 64, "\n", true) . "\n-----END RSA PRIVATE KEY-----";
        openssl_sign($content, $sign, $key, OPENSSL_ALGO_SHA256);
        $sign = base64_encode($sign);
        return $sign;
    }

    protected function getSignContent($params)
    {
        ksort($params);
        $stringToBeSigned = "";
        $i = 0;
        foreach ($params as $k => $v) {
            if (false === $this->checkEmpty($v) && "@" != substr($v, 0, 1)) {
                if ($i == 0) {
                    $stringToBeSigned .= "$k" . "=" . "$v";
                } else {
                    $stringToBeSigned .= "&" . "$k" . "=" . "$v";
                }
                $i++;
            }
        }

        unset($k, $v);
        return $stringToBeSigned;
    }

    protected function checkEmpty($value) {
        if (!isset($value))
            return true;
        if ($value === null)
            return true;
        if (trim($value) === "")
            return true;

        return false;
    }

    //返回参数
    public function parseRE()
    {
        //使用表单提交的方式
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . urlencode($this->payUrl);
        $this->parameter .= '&method2=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    //签名验证
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        if(!empty($result['s']))    unset($result['s']);

        $res = [
            'status' => 1,
            'order_number' => $result['out_trade_no'],
            'third_order' => $result['trade_no'],
            'third_money' => $result['buyer_pay_amount'],
            'error' => '',
        ];

        if (!in_array($result['trade_status'], ['TRADE_SUCCESS', 'TRADE_FINISHED'])) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        $sign = $result['sign'];
        $result['sign_type'] = null;
        $result['sign'] = null;
        $data = $this->getSignContent($result);
        //转换为openssl格式密钥
        $pubKey= $config['pub_key'];
        $pubRes = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($pubKey, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";
        $signStatus = (bool)openssl_verify($data, base64_decode($sign), $pubRes, OPENSSL_ALGO_SHA256);

        if ($signStatus === true) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

}