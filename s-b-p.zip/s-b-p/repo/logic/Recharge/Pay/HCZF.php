<?php
/**
 * 惠诚支付
 * Created by Hans.
 * Date: 2019/7/3
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HCZF extends BASES
{

    public function start()
    {
        $this->initParams();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'pay_memberid' => (string)$this->partnerID,
            'pay_orderid' => (string)$this->orderID,
            'pay_applydate' => date('Y-m-d H:i:s', time()),
            'pay_bankcode' => (string)$this->payType, //bank_data
            'pay_notifyurl' => $this->notifyUrl,
            'pay_callbackurl' => $this->returnUrl,
            'pay_amount' => $this->money,
        ];
        $pub_params['pay_md5sign'] = $this->_sign($pub_params, $this->key);
        $pub_params['pay_productname'] = $this->orderID;
        $this->parameter = $pub_params;
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        //组装前端Form数据
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . urlencode($this->payUrl);
        $this->parameter .= '&method=POST';

        //响应结果
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;

    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if ($parameters['returncode'] != '00') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['orderid'],
            'third_order' => isset($parameters['transaction_id']) ? $parameters['transaction_id'] : $parameters['orderid'],
            'third_money' => $parameters['amount'],
        ];

        $config = Recharge::getThirdConfig($parameters['orderid']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }
        $order_number = $parameters['orderid'];
        $return_money = $parameters['amount'];

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . '&key=' . $tkey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }

    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        unset($params['attach']);
        $params['datetime'] = urldecode($params['datetime']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }

}