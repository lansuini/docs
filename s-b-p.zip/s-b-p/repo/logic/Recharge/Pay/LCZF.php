<?php
/**
 * 浪潮支付
 * Created by Hans.
 * Date: 2019/6/1
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class LCZF extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';

        $extra = array(
            "timeout_express" => "10m",
            "returnType" => "URL",
        );

        $this->parameter = [
            'mchId' => (string)$this->partnerID,
            'appId' => (string)$this->data['app_id'],
            "productId" => $this->payType, //
            'mchOrderNo' => $this->orderID, //bank_data
            'currency' => 'cny',
            'amount' => $this->money * 100,
            'notifyUrl' => $this->notifyUrl,
            'subject' => 'product',
            'body' => 'product',
            'extra' => json_encode($extra),
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }


    function http_post_data($url, $parms)
    {
        $datajsonstr = json_encode($parms);
        $newdata = array(
            "params" => $datajsonstr,
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $newdata);
        ob_start();
        curl_exec($ch);
        $return_content = ob_get_contents();
        ob_end_clean();
        $return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        return $data = json_decode(array($return_code, $return_content)[1], true);
    }

    private function parseRE()
    {
        $data = $this->http_post_data($this->payUrl, $this->parameter);
        if ($data['retCode'] == 'SUCCESS') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['payParams']['payUrl'];

        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = '失败:'.(isset($data['retMsg'])?$data['retMsg']:'下单失败');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['mchOrderNo']) || !isset($parameters['payOrderId']) || !isset($parameters['amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['mchOrderNo'],
            'third_order' => $parameters['payOrderId'],
            'third_money' => $parameters['amount'] / 100,
        ];

        if ($parameters['status'] != '2' ) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        if ($parameters['sign'] != $this->_sign($parameters, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $signString = '';
        foreach ($pieces as $key => $value) {
            if ($key != "sign" && $key != "" && $value != "") {
                $signString .= "$key=$value&";
            }
        }
        $signString .= 'key=' . $tkey;
        $sign = strtoupper(md5($signString));
        return $sign;
    }
}