<?php
/**

 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Psr\Http\Message\ServerRequestInterface;

/**
 * 国通支付
 * Class GF
 * @package Logic\Recharge\Pay
 */
class GTZF extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = array(
            'parter' => $this->partnerID,
            'type'=>$this->data['bank_data'],
            'orderid' => $this->orderID,
            'value' => $this->money,
            'callbackurl' => $this->notifyUrl,
        );
        $sign = "parter=".$this->partnerID."&type=".$this->payType."&orderid=".$this->orderID."&callbackurl=".$this->notifyUrl;
        $this->parameter['sign'] = md5($sign.$this->key);//签名数据 32位小写的组合加密验证串
        $this->parameter['hrefbackurl'] = $this->returnUrl;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function sytMd5New($pieces, $key)
    {
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . $key;
        $sign = md5($sign_str);
        return $sign;
    }

    //返回参数
    public function parseRE()
    {
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    //签名验证
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);

        $res = [
            'status' => 0,
            'order_number' => $result['orderid'],
            'third_order' => $result['orderid'],
            'third_money' => $result['ovalue'],
            'error' => '',
        ];

        if ($result['restate'] != '0') {//订单状态，0为成功，其它请看订单状态描述
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($result['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
                        return $res;
        }

        $sign = $result['sign'];
        unset($result['sign']);
        if(isset($result['s']))unset($result['s']);

        if (!self::retrunVail($sign, $result, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
                        return $res;
        }
        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/pay/Query.aspx';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    public function retrunVail($sign, $data, $key)
    {
        $signstr = "orderid=".$data['orderid']."&restate=".$data['restate']."&ovalue=".$data['ovalue'];
        return $sign == md5($signstr.$key);//签名数据 32位小写的组合加密验证串
    }
    private function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "orderid" => $orderNumber,
            "type" => '1',
            "parter" => $partnerID,
        ];

        $signstr = "parter=".$partnerID."&type=".$params['type']."&orderid=".$params['orderid'];
        $params['sign'] = md5($signstr.$tkey);//签名数据 32位小写的组合加密验证串

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['ordstate'])) {
            return $re['ordstate'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }
}