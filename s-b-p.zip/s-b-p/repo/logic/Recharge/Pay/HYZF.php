<?php
/**
 *   恒洋支付
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HYZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
//        $this->post();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $params = [
            'mchid'        => $this->partnerID,
            'type'          =>  4,
            'amount'        =>  sprintf("%.2f", $this->money),
            'applydate'     =>  date('YmdHis',time()),
            'out_trade_id'   =>  $this->orderID,
            'callback_url'    =>  $this->notifyUrl,
            'return_url'     =>  $this->returnUrl,
        ];
        $params['version']         =  "1.0";
        $params['act']             =  0;
        $params['goodsname']       =  'goodsname';
        $params['bankcode']        =  $this->payType;
        $params['attach']          =  'attach';
        $params['signtype']        =  0;
        $signStr=$this->arraytosignstring($params);
        $sign=strtoupper(md5($signStr."key=".$this->key));
        $params['sign'] = $sign;
        $params['method']          =  "web";

        $this->parameter = $params;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
//        print_r($this->re);exit;
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        print_r($parameters);
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        print_r($parameters);


        $res = [
            'order_number' => $parameters['out_trade_id'],
            'third_order' => $parameters['orderid'],
            'third_money' => $parameters['payamount'],
            'status'=>0,
            'error'=>''
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_id']);
        print_r($config);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['code'] != '1'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        print_r('tongguole');
        print_r($res);exit;
        return $res;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        $pub_parms = [
            'amount' => $params['amount'],
            'applydate' => $params['applydate'],
            'code' => $params['code'],
            'mchid' => $params['mchid'],
            'msg' => $params['msg'],
            'orderid' => $params['orderid'],
            'out_trade_id' => $params['out_trade_id'],
            'payamount' => $params['payamount'],
            'status' => $params['status'],
            'version' => $params['version'],
            'signtype' => $params['signtype'],
            'attach' => $params['attach'],

        ];
        $signStr = $this->arraytosignstring($pub_parms);
        $sign=strtoupper(md5($signStr."key=".$tkey));

        print_r($sign);
        print_r("\n");
        print_r($return_sign);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function arraytosignstring($arr){
        ksort($arr);
        $md5str = "";
        foreach ($arr as $key => $val) {
            if (!empty($val) && $key!='sign' && $key!='') {
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        return $md5str;
    }
}