<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 恒通支付
 * @author lavenkin
 */
class HENGT extends BASES
{
	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
    	$this->parameter = [
            'customer' => $this->partnerID,
            'banktype' => $this->payType,
            'amount' => sprintf("%.2f",$this->money),
            'orderid' => $this->orderID,
            'asynbackurl' => $this->notifyUrl,
    		'request_time' => date('YmdHis'),
        ];
        if($this->payType == 'QUICK') {
            unset($this->parameter['banktype']);
        }
        $this->sort = false;
        $this->parameter['sign'] = $this->currentMd5('key=');
    }

    public function parseRE()
    {
//        foreach ($this->parameter as &$item) {
//            $item = urlencode($item);
//        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    public function returnVerify($data)
    {
        global $app;
        $input = $app->getContainer()->request->getParams();
        unset($input['s']);
    	$res = [
            'status' => 1,
            'order_number' => $data['orderid'],
            'third_order' => $data['systemorderid'],
            'third_money' => $data['payamount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        if ($data['result'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单未支付';
            return $res;
        }
        $this->parameter = [
            'orderid' => $data['orderid'],
            'result' => $data['result'],
            'amount' => $data['amount'],
            'systemorderid' => $data['systemorderid'],
            'completetime' => $data['completetime'],
        ];
        $this->key = $config['key'];
        $this->sort = false;
        if (strtolower($data['sign']) != strtolower($this->currentMd5('key='))) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

}