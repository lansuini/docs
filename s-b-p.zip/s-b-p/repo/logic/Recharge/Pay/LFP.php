<?php
/**
 * 隆发支付
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/30
 * Time: 18:08
 */

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class LFP extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $param = [
            'merchNo' => $this->partnerID,
            'randomNo' => $this->_randSrting(),
            'netwayType' => (string)$this->payType,
            'orderNo' => (string)$this->orderID,
            'amount' => (string)($this->money*100),
            'goodsName' => (string)$this->orderID,
            'notifyViewUrl' => $this->returnUrl,
            'notifyUrl' => $this->notifyUrl,
            //'clientIp' => Client::getIp(),
        ];
        //秘钥存入 token字段中
        $param['sign'] = $this->_sign($param, $this->data['app_secret']);
        $this->parameter = $this->_rasKey($param);
        //var_dump($this->parameter);exit();
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if($re['stateCode'] == '00'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['qrcodeUrl'];
        }else{
            $this->return['code'] = $re['stateCode'];
            $this->return['msg'] = 'LF:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['orderNo']
        ];
        $config = Recharge::getThirdConfig($parameters['orderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }

        $private_key = $this->_getPrivateKey($config['key']);
        $ras_data = $parameters['data'];
        $base_decrypt = $this->privateDecrypt(base64_decode(urldecode($ras_data)),$private_key);
        $data_base = json_decode($base_decrypt,true);
        if (!$data_base){
            $res['status'] = 0;
            $res['error'] = '解密失败';
            return $res;
        }
        $result = $this->returnVail($data_base, $config['app_secret']);
        if ($result) {
            $res['status'] = 1;
            $res['third_order'] = $data_base['orderNo'];
            $res['third_money'] = $data_base['amount']/100;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }
    public function paraFilter($para) {
        $para_filter = array();
        foreach($para as $key => $val){
            if($key == "sign" || $val == ""){
                continue;
            }else{
                $para_filter[$key] = $para[$key];
            }
        }
        return $para_filter;
    }

    private function _randSrting()
    {
        $str="QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
        str_shuffle($str);
        $name=substr(str_shuffle($str),26,4);
        return $name;
    }

    /**
     * 整理私钥
     * @param $pkey
     * @return string
     */
    public function _getPrivateKey($pkey=null)
    {
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\r\n";
        foreach (str_split($pkey,64) as $str){
            $private_key = $private_key . $str ;
        }
        $private_key .=  "\r\n-----END RSA PRIVATE KEY-----";
        $key = openssl_get_privatekey($private_key);
        return $key;
    }

    /**
     * 用公钥加密返回密文
     * @return string
     */
    public function _rasKey($params)
    {
        $data = json_encode($params);
        $this->pubKey  = $this->_getPublicKey($this->pubKey);
        $this->parameter = $data;
        $openssl_encry = $this->pukOpenssl();
        $return = [
            'data' => $openssl_encry,
            'merchNo' => $params['merchNo'],
            'version' => 'V3.6.0.0',
        ];
        return $return;
    }

    /**
     * 整理公钥
     * @param $key
     * @return string
     */
    public function _getPublicKey($key=null)
    {
        $pubkey = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($key,64) as $str){
            $pubkey = $pubkey . $str ;
        }
        $pubkey .= "\r\n-----END PUBLIC KEY-----";
        $rekey = openssl_pkey_get_public($pubkey);
        return $rekey;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = json_encode($params,JSON_UNESCAPED_SLASHES);

        $string = $string.$tKey;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        $param_filter = $this->paraFilter($params);
        ksort($param_filter);
        $sign = $this->_sign($param_filter, $tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}
