<?php
/**
 * 汇鑫支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class HUIXINZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->postJson();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'order_no' => $this->orderID,
            'user_ip' => $this->clientIp,
            'num' => $this->money,
            'payment' => (string)$this->payType,
            'returnType' => 'uri',
        ];
    }

    public function postJson()
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->payUrl);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($this->parameter));
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/x-www-form-urlencoded',
                'X-Requested-With: ' . 'XMLHttpRequest',
                'MsToken: ' . $this->partnerID,
                'uToken: ' . $this->uid,
            )
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        $this->curlError = curl_error($curl);
        $this->re = $response;
    }


    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $data = json_decode($this->re, true);
        if (isset($data['status']) && $data['status'] == 'success') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['data']['pay_url'];

        } else {
            $this->return['code'] = $data['code'];
            $this->return['msg'] = $data['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['num']) || !isset($parameters['uuid']) || !isset($parameters['order_no'])) {
            return [
                'status' => 0,
                'error' => '未知错误',
            ];
        }
        $res = [
            'status' => 0,
            'order_number' => $parameters['uuid'],
            'third_order' => $parameters['order_no'],
            'third_money' => $parameters['num']
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($parameters['sign'] != $this->_sign($parameters, $config['key'])) {
            $res['error'] = '验签失败！';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);
        $signPars = "";
        foreach ($params as $k => $v) {
            if ($k != 'sign' && $k != 'sign_type') {
                $signPars .= $k . '=' . $v . '&';
            }
        }
        $signPars = substr($signPars, 0, -1) . $key;
        $signPars = urldecode($signPars);
        return strtoupper(md5($signPars));
    }

}