<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Curl;
use Utils\Utils;

/**
 * HENRY
 */
class HENRY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    /**
     * 获取token
     */
    public function getAccessToken()
    {
        $url = $this->getPayUrlHostPath($this->payUrl) . '/api/v1/getAccessToken/merchant';
        $params = [
            'merchantNo' => $this->partnerID,
            'nonce' => Utils::createStr(),
            'timestamp' => date("YmdHis"),
        ];

        $params['sign'] = $this->createSign($params);

        $result = CURL::post($url, '', $params);
//         var_dump($result);exit;
        $result = json_decode($result, true);
        $accessToken = '';
        if (isset($result['success']) && $result['success'] == true) {
            $accessToken = $result['value']['accessToken'];
        }
        return $accessToken;
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        /**
         *
         * 支付宝扫码    http://api.henrypay.vip:8888/api/v1/order/alipayScan
         * 微信扫码    http://api.henrypay.vip:8888/api/v1/order/wechatScan
         * 微信wap    http://api.henrypay.vip:8888/api/v1/order/wechatWapPay 注意参数，请求下单时请传：merchantIp参数及对应值
         * 支付宝wap http://api.henrypay.vip:8888/api/v1/order/alipayWapPay
         */
        $accessToken = $this->getAccessToken();
        $this->parameter = [
            'accessToken' => $accessToken,
            'param' => [
                'outTradeNo' => (string)$this->orderID,
                'money' => (int)$this->money * 100,//分
                'type' => 'T1',//付款类型
                'body' => '商品购买',//商品描述
                'detail' => $this->data['scene'],//商品详情
                'notifyUrl' => (string)$this->notifyUrl,
                'productId' => basename($this->payUrl),//商品ID
            ],
        ];

        //微信wap要传参数merchantIp
        if (strpos($this->payUrl, 'wechatWap')) {
            $this->parameter['param']['merchantIp'] = $this->clientIp;
        }
        // var_dump(json_encode($this->parameter));exit;
    }

    public function parseRE()
    {
        // var_dump($this->re);exit;
        $result = json_decode($this->re, true);
        if (isset($result['success']) && $result['success']) {
            $this->return['code'] = $result['errorCode'];
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $result['value'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'Henry：' . (isset($result['message']) ? $result['message'] : '请求失败');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    /**
     * 验签
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['outTradeNo']) || !isset($data['no']) || !isset($data['money'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['outTradeNo'],
            'third_order' => $data['no'],
            'third_money' => $data['money'] / 100,
            'error' => '',
        ];

        if (!$data['success']) {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $verfiyParams = [
            'merchantNo' => $data['merchantNo'],
            'no' => $data['no'],
            'nonce' => $data['nonce'],
            'timestamp' => $data['timestamp'],
        ];

        if (!$this->verfiySign($verfiyParams, $data['sign'], $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 签名
     */
    public function createSign($params, $key = '')
    {
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null) {
                $string .= $k . '=' . $v . '&';
            }
        }
        $string .= 'key=' . ($key ? $key : $this->key);
        // print($string);exit;
        $sign = strtoupper(md5($string));

        return $sign;
    }

    /**
     * 回调验签验证
     */
    public function verfiySign($params, $sign, $key)
    {
        $mySign = $this->createSign($params, $key);
        // var_dump($mySign);exit;
        return $mySign == $sign;
    }

    private function getPayUrlHostPath($url)
    {
        $arr = parse_url($url);
        return $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "");
    }

}