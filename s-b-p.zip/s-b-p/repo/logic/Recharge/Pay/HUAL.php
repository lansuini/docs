<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 华联
 */

class HUAL extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {  
        $this->parameter = [
            "merchant"    => $this->partnerID,
            "amount"      => $this->money,
            "pay_code"    => $this->payType,
            "order_no"       => $this->orderID,
            "notify_url"     =>$this->notifyUrl,
            "return_url"     =>$this->returnUrl,
            "order_time"      => date('Y-m-d H:i:s'),

        ];
        $this->parameter['sign'] = $this->currentMd5('key=');
        $this->parameter['return_url'] = urlencode($this->parameter['return_url']);
        $this->parameter['notify_url'] = urlencode($this->parameter['notify_url']);
        $this->parameter['order_time'] = urlencode($this->parameter['order_time']);
    }

    /**
     * 
     */
    public function parseRE()
    {
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . urlencode($this->payUrl);
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['out_order_no'],
            'third_order' => $parameters['sys_order_no'],
            'third_money' => $parameters['amount'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($parameters['out_order_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $sign = $parameters['sign'];
        unset($parameters['sign']);
        unset($parameters['s']);
        $this->parameter = $parameters;
        $this->key = $config['key'];
        if (strtolower($sign) != $this->currentMd5('key=')) {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

}