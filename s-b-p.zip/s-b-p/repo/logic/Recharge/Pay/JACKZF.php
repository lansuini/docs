<?php
/**
 * jack支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JACKZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {

        $this->parameter = [
            'appid' => $this->partnerID,
            'userid' => $this->uid,
            'orderid' => $this->orderID,
            'paytype' => $this->payType,
            'rmb' => $this->money*100,
            'extra' => 'good',
        ];

        $this->parameter['sign'] = $this->sign($this->parameter, $this->key);
    }

    private function sign($pieces,$privitekey){
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            if ($key != 'sign'){
                $string[] = $key.'='.$val;
            }
        }
        $params = join('&',$string);
        $appSignContent = hash_hmac('sha256', $params, $privitekey);
        return $appSignContent;
    }
    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' . $this->arrayToURL();
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        if(isset($result['s'])){
            unset($result['s']);
        }

        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $result['orderid'],
            'third_order' => $result['orderid'],
            'third_money' =>$result['rmb']/100,  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }


        if ($result['sign'] != $this->sign($result, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}