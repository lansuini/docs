<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Utils\Utils;


/**
 * 支付宝官方
 */
class ALIPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $params['app_id'] = $this->partnerID;
        $params['method'] = 'alipay.trade.app.pay';
        $params['format'] = 'json';
        $params['sign_type'] = "RSA2";
        $params['timestamp'] = date("Y-m-d H:i:s");
        $params['alipay_sdk'] = 'alipay-sdk-php-20200415';
        $params['charset'] = "UTF-8";
        $params['version'] = '1.0';
        $params['notify_url'] = $this->notifyUrl;
        $params['app_auth_token'] = null;

        $biz_content = [
            "body" => '李宁服装' . rand(1, 10),//交易
            "subject" => '衣服用品',//关键字
            "out_trade_no" => $this->orderID,//商户订单号
            "timeout_express" => "5m",
            "total_amount" => $this->money,//元
            "product_code" => "QUICK_MSECURITY_PAY",
        ];
        $params['biz_content'] = json_encode($biz_content, JSON_UNESCAPED_UNICODE);

        $params['sign'] = $this->getSign($params, $this->key);
        $this->parameter = $params;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($data, $api_key)
    {
        ksort($data);
        $string = '';
        foreach ($data as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }

        $string = rtrim($string, "&");
        $priKey = $api_key;
        $res = "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($priKey, 64, "\n", true) . "\n-----END RSA PRIVATE KEY-----";
        openssl_sign($string, $sign, $res, OPENSSL_ALGO_SHA256);
        $sign = base64_encode($sign);
        return $sign;
    }

    public function parseRE()
    {
        //暂时只处理sdk
        $re = http_build_query($this->parameter);
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->data['return_type'];
        $this->return['str'] = $re;
    }

    public function returnVerify($data)
    {

        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!(isset($data['out_trade_no']) && isset($data['trade_no']) && isset($data['total_amount']))) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['out_trade_no'],
            'third_order' => $data['trade_no'],
            'third_money' => $data['total_amount'],
            'error' => '',
        ];

        if (!in_array($data['trade_status'], ['TRADE_SUCCESS', 'TRADE_FINISHED'])) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        //不知道回调ip,跳过ip白名单验证
        $config = self::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }


    public function getThirdConfig($order_number)
    {
        $config = \DB::table('order')->leftJoin('passageway AS p', 'order.passageway_id', '=', 'p.id')
            ->leftJoin('pay_config AS c', 'p.pay_config_id', '=', 'c.id')
            ->where('order_number', $order_number)->where('order.status', '=', 'pending')->first(['order_money', 'desc', 'p.payurl', 'c.*']);

        if ($config) {
            $config = (array)$config;
            //$config = RechargeCallback::decryptConfig($config);
            foreach ($config as $key => &$val) {
                if (in_array($key, ['app_id', 'app_secret', 'key', 'pub_key', 'token'])) {
                    $val = Utils::XmcryptString($val, false);
                }
            }
            return $config;
        } else
            return false;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        unset($data['sign_type']);

        ksort($data);
        $string = '';
        foreach ($data as $k => $v) {
            if ($v != '' && $v != null) {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $string = rtrim($string, "&");

        $res = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($config['pub_key'], 64, "\n", true) . "\n-----END PUBLIC KEY-----";
        //调用openssl内置方法验签，返回bool值
        return (bool)openssl_verify($string, base64_decode($signOld), $res, OPENSSL_ALGO_SHA256);
    }


}