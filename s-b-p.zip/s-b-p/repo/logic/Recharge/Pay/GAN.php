<?php
/**
 * GAN支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class GAN extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'requestNo' => $this->orderID,
            'merNo' => $this->partnerID,
            'transType' => $this->payType,
            'payWayCode' => $this->payType,
        ];
        $this->parameter['data'] = [
            'outTradeNo' => $this->orderID,
            'transAmt' => $this->money * 100,
            'transType' => $this->payType,
            'subject' => 'Goods'.time(),
            'notifyUrl' => $this->notifyUrl,
            'orderDate' => date('Ymd'),
            'returnUrl' => $this->returnUrl,
        ];

        //秘钥存入 token字段中
        $this->parameter['signature'] = $this->_sign($this->parameter, $this->key);
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re) && $re['url']) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['url'];
        } else {
            $this->return['code'] = 0;
            $this->return['msg'] = 'GAN:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
        $res = [
            'status' => 1,
            'order_number' => $data['requestNo'],
            'third_order' => $data['data']['bankOrderNo'],
            'third_money' => $data['data']['transAmt'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['requestNo']);
        // var_dump($data);exit;
        if ($data['paySt'] != 1) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        unset($data['sign']);
        unset($data['attach']);
        unset($data['msg']);
        if (!$this->returnVail($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign = md5($string.'key='.$tKey);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey,$thirdSign)
    {
        $sign = $this->_sign($params, $tkey);

        return $thirdSign == $sign;
    }
}