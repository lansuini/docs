<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 甲天下多宝
 * @author viva
 */
class JTXDBZF extends BASES
{

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }

        $this->initParam();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //组装数组
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';

        $type=explode('|',$this->payType);

        $this->parameter = array(
            'customerid' => $this->partnerID,
            'sdcustomno' => $this->orderID,
            'orderamount' => $this->money * 100,
            'cardno' => $type[0],
            'noticeurl' => $this->notifyUrl,
            'backurl' => $this->returnUrl,
            'mark' => 'GOODS123',
            'zftype' => 'casher',
            'device' => isset($type[1])?$type[1]:'mobile',
            'ordertime' => time(),
        );
        $signStr = "customerid=" . $this->partnerID . "&sdcustomno=" . $this->orderID . "&orderamount=" . $this->money * 100 . "&cardno=" . $this->payType . "&noticeurl=" . $this->notifyUrl . "&backurl=" . $this->returnUrl . "&ordertime=" . $this->parameter['ordertime'] . $this->key;
        $this->parameter['sign'] = strtoupper(md5($signStr));
    }

    public function parseRE()
    {
        if ($this->data['return_type'] == 'sdk') {
            $this->basePost();
            $re = json_decode($this->re, true);

            if ($re['state'] == '1' && $re['sdk'] != null) {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];
                $content = $re['sdk'];
                if (strpos($content, "%") && (!strpos($content, "&"))) {
                    $content = urldecode($content);
                }
                $this->return['str'] = $content;
            } else {
                $this->return['code'] = $re['state'];
                $this->return['msg'] = '甲天下多宝支付:' . $re['errmsg'];
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        } else {
            $this->buildGoOrderUrl();
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->goPayUrl;
        }
    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        global $app;
        $input = $app->getContainer()->request->getParams();
        unset($input['s']);

        if (!(isset($input["sdcustomno"]) && ($input["ordermoney"]))) {
            //非法数据
            return [
                'status' => 0,
                'error' => '未知错误',
            ];
        }

        $res = [
            'status' => 0,
            'order_number' => $input['sdcustomno'],
            'third_order' => $input['sd51no'],
            'third_money' => $input['ordermoney'] / 100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($input['sdcustomno']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if ($input['state'] != 1) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        $sign = $input['sign'];
        $sign = 'sign=' . $sign . '&customerid=' . $input['customerid'] . '&ordermoney=' . $input['ordermoney'] . '&sd51no=' . $input['sd51no'] . '&state=' . $input['state'] . '&key=' . $config['key'];
        if (strtoupper(md5($sign)) != $input['resign']) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }

        $res['status'] = 1;
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }
}
