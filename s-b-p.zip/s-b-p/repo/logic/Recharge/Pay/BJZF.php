<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 铂金支付
 * @package Logic\Recharge\Pay
 */
class BJZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->customJson();
        $this->parseRE();
    }

    //curl的json格式传输
    public function customJson(){
        $data_string = json_encode($this->parameter, JSON_UNESCAPED_UNICODE);
        $data_string = str_replace("\\/", "/", $data_string);//去除转义问题
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->payUrl);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl,CURLOPT_POST,1);
        curl_setopt($curl,CURLOPT_POSTFIELDS,$data_string);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data_string),
                'Signature:MD5'
            )
        );
        $header = array(
            'Content-Type: application/json; charset=utf-8',
            'Content-Length: ' . strlen($data_string),
            'key:'.$this->parameter['sign'],
            'value=MD5'
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        $this->curlError = curl_error($curl);
        $this->re = $response;
    }
    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $parameter = [
            'merchantNo' => $this->partnerID,
            'timestamp' => time(),
            'orderNo' => (string)$this->orderID,
            'trxAmt' => $this->money,
            'tradeType' => $this->payType,
            'notifyUrl' => $this->notifyUrl,
            'subject' => (string)$this->orderID,
            'body' => (string)$this->orderID,
            'ip' => $this->clientIp,
        ];
        $parameter['sign'] = $this->_sign($parameter, $this->key);
        $this->parameter = $parameter;
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {

        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == '0') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['src'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'BJZF:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderNo']) || !isset($parameters['trxAmt'])) {
            return false;
        }

        $res = [
            'order_number' => $parameters['orderNo'],
            'third_order' => $parameters['orderNo'],
            'third_money' => $parameters['trxAmt'],
        ];
        $config = Recharge::getThirdConfig($parameters['orderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != '0000') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $this->updateMoney($res['order_number'], $res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key => $val) {
            if ($val) {
                $string = $string ? $string . "&" . $key . "=" . $val : $key . "=" . $val;
            }

        }
        $string = $string . '&key=' . $tKey . $params['timestamp'];
        $sign = md5($string);
        return $sign;
    }

    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }
}