<?php
/**
 * 豪汇 HonorPay
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HPPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'account' => $this->partnerID,
            'payMoney' => sprintf("%.2f", $this->money),
            'payType' => $this->payType,
            'orderNo' => $this->orderID,
            'notifyURL' => $this->notifyUrl,
            'ip' => $this->data['client_ip']
        ];
        $this->_call();
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['retCode']) && $re['retCode'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
//            if(isset($re['qrContent']) && $re['qrContent']) {
//                $this->return['str'] = $this->qrcodeUrl.$re['qrContent'];
//            }else{
                $this->return['str'] = $re['redirectURL'] ?? $re['qrContent'];
//            }

        } else {
            $this->return['code'] = 57;
            $this->return['msg'] = 'HPPAY:' . $re['retMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function _call(){
        $curl = curl_init($this->payUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Bearer '.$this->key));
//        $para = json_encode($this->parameter, JSON_UNESCAPED_UNICODE);
        curl_setopt($curl, CURLOPT_HEADER, 0); // 过滤HTTP头
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 转向
        curl_setopt($curl, CURLOPT_POST, true); // post传输数据
        curl_setopt($curl, CURLOPT_POSTFIELDS, $this->parameter);// post传输数据
        $responseText = curl_exec($curl);
        curl_close($curl);
        $this->re = $responseText;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 1,
            'order_number' => $data['orderNo'],
            'third_order' => $data['uuid'],
            'third_money' => $data['payMoney'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderNo']);
        if ($data['payStatus'] != 'success') {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['sign'];
        unset($data['sign']);
        unset($data['s']);
        $this->parameter = $data;
        $str = http_build_query($data).'&key='.$config['pub_key'];
        if (strtoupper($sign) != strtoupper(hash_hmac('sha256',$str,$config['pub_key']))) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }


}