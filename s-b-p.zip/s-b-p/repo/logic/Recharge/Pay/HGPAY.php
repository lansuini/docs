<?php
/**
 * 皇冠支付
 * @author Taylor 2019-05-15
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HGPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'src_code' => $this->data['token'],//唯一标识
            'mchid' => (string)$this->partnerID,//平台商户号
            'out_trade_no' => (string)$this->orderID,//商户订单号
            'total_fee' => $this->money * 100,//订单金额，单位，分
            'time_start' => date('YmdHis'),//支付时间
            'goods_name' => 'VIP:'.$this->orderID,//商品名称
            'trade_type' => (string)$this->payType,//交易类型代码
            'finish_url' => $this->returnUrl,//页面跳转返回地址
            'notify_url' => $this->notifyUrl,//异步接受支付结果通知的回调地址
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;
        //var_dump($this->parameter);exit();
    }

    /**
     * 生成sign
     */
    private function _sign($param_arr, $tkey)
    {
        ksort($param_arr);
        $str = '';
        foreach($param_arr as $k => $v){
            $str .= $k.'='.$v.'&';
        }
        $str .= 'key='.$tkey;
        return strtoupper(md5($str));
    }
    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        //{"respcd":"101","respmsg":"\u6682\u672a\u5f00\u901a\u8be5\u4ea4\u6613\u7c7b\u578b(60104)","data":{}}
        //{"respcd":"0000","respmsg":"","data":{"trade_no":"201905152102484941","trade_type":"60107","time_start":"20190515214735","pay_time":"","goods_name":"VIP:19051420476472334","src_code":"YLeekM1557903768gWwBJ","sign":"94B919C93B7E0698F932E3632EDB599B","out_trade_no":"19051420476472334","total_fee":"20000","order_status":2,"pay_params":"http://90xpay.nkae.cn/pay?orderId=201905152102485137&gotrue=http%3A%2F%2Fapi.yucunmuhuo.com%2Fpay%2Ffinish%2F568f81c7cbab49fd2774d50ee25e17293f806bef76656dcedaaad1a3c079cfe6&uuid=192211403&paytype=104&sign=2ef4270587fcb393c795cf2c661c014c&amount=200.00&token=VIP%3A19051420476472334&callbackurl=http%3A%2F%2Fnotify.yucunmuhuo.com%2Fxpaycn%2Frecv"}}
        $re = json_decode($this->re, true);
        if ($re['respcd'] == '0000') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            $this->return['str'] = $re['data']['pay_params'];//支付地址
        } else {
            $this->return['code'] = 8;
            $this->return['msg'] = 'HGPAY:' . (isset($re['respmsg']) ? $re['respmsg'] : '');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['out_trade_no'],//商户订单号
            'third_order' => $data['trade_no'],//系统订单号
            'third_money' => $data['total_fee']/100,//支付金额，分
            'error' => '',
        ];

        //1:下单中；2:等待支付；3:支付成功；4:支付失败；6:用户未支付
        if ($data['order_status'] != 3) {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($data, $tkey)
    {
        $s_params = array_map('urldecode', $data);
        if(isset($s_params['s'])) unset($s_params['s']);
        $sys_sign = $s_params['sign'];
        unset($s_params['sign']);

        ksort($s_params);
        $str = '';
        foreach($s_params as $k => $v){
            if(!empty($v)){
                $str .= $k.'='.$v.'&';
            }
        }
        $str .= 'key='.$tkey;
        $sign = strtoupper(md5($str));
        if ($sign != $sys_sign){
            return false;
        }
        return true;
    }
}