<?php
/**
 * 宝瑞通

 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class BRT extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'mid' => $this->partnerID,
            'pay_type' => (string)$this->payType,
            'order_no' => (string)$this->orderID,
            'price' => $this->money * 100,
            'goods_name' => '订单：'.$this->orderID,
            'call_back_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter,$this->key);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        $re = json_decode($this->re,true);
        $data = $re['data'];
//        print_r($re);exit;
        if (isset($re['status']) && $re['status']=='200'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['pay_url'];

        }else{
            $this->return['code'] = $re['status'];
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        $res = [
            'order_number' => $parameters['order_no'],
            'third_order' => $parameters['sys_no'],
            'third_money' => $parameters['price'] / 100,
        ];
        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != '1'){
            $res['status'] = 0;
            $res['error'] = '订单支付状态为失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            if($key == 'sign') continue;  //sign不参与签名
            if($key == '' || $val =='') continue;//键名或键值为空不参与签名
            if($key == 'notify_url' || $key == 'call_back_url') {
                $string[] = $key.'='.urlencode($val);
            }
            else
            {
                $string[] = $key.'='.$val;
            }
        }
        $params = join('&',$string);
        $sign_str = $params.'&key='.$tkey;
        $sign = strtoupper(md5($sign_str));
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        foreach ($params as $k=>$val)
        {
            if (empty($val)){
                unset($params[$k]);
            }
        }
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}