<?php
/**
 * 欢欢支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HHPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'mid' => $this->partnerID,
            'order' => $this->orderID,
            'money' => (int)$this->money,
            'pay_type' => (string)$this->payType,
            'time' => time(),
        ];
        $md5Str = $this->parameter['mid'] . $this->parameter['order'] . $this->parameter['money'] . $this->parameter['time'] . $this->key;
        $this->parameter['sign'] = md5($md5Str);
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        $re = json_decode($this->re, true);
        $data = $re['data'];
        if (isset($re['code']) && $re['code'] == '1') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['url'];

        } else {
            $this->return['code'] = $re['status'];
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        $res = [
            'order_number' => $parameters['order_id'],
            'third_order' => $parameters['time'],
            'third_money' => $parameters['money'],
        ];
        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['pay_status'] != '1') {
            $res['status'] = 0;
            $res['error'] = '订单支付状态为失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }


    /**
     * 回调后进行业务判断
     */
    public function returnVail($params, $tkey)
    {
        $md5Str = $params['order_id'].$params['mid'].$params['time'].$params['money'].$params['pay_type'].$params['pay_status'].$tkey;
        $sign = md5($md5Str);
        return $sign==$params['sign'];
    }
}