<?php
/**
 * 聚友支付
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/7
 * Time: 17:11
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class JYZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        //$this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'mid' => $this->partnerID,
            'oid' => $this->orderID,
            'amt' => sprintf("%.2f", $this->money),
            'way' => $this->payType,
            'back' => 'http://faqugames.com', //bank_data
            'notify' => $this->notifyUrl
        ];
        //
        $this->parameter['sign'] = $this->_sign($this->parameter,$this->key);
        //var_dump($this->parameter);exit();
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        /*$re = json_decode($this->re,true);
        if($re['rspCode'] == 1){
            //$data = json_decode($re['data'],true);
            $data = $re['data'];
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            //$this->return['str'] = $data['r6_qrcode'];
            if ($this->data['return_type'] == 'code') {
                $this->return['str'] = $this->data['url_qr_domain'] . '/qrcoder?code=' . Utils::imgUpload($data['r6_qrcode'])['img_name'] . '&pay_type=' . $this->data['scene']. '&amount=' . $this->money;
            } else {
                $this->return['str'] = $data['r6_qrcode'];
            }
        }else{
            $this->return['code'] = $re['rspCode'];
            $this->return['msg'] = 'JY:'.$re['rspMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }*/
    }

    private function _sign($params,$pub_key)
    {
        $string='';
        foreach ($params as $key=>$value){
            $string = $string.$value;
        }
        $string=$string. $pub_key;
        //var_dump($string);exit();
        $sign = md5($string);
        return $sign;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {

        $sign_data = [
            'mid' =>  $parameters['mid'],
            'oid' =>  $parameters['oid'],
            'amt' =>  $parameters['amt'],
            'way' =>  $parameters['way'],
            //'back' =>  $parameters['back'], //bank_data
            'code' =>  $parameters['code']
        ];
        $re_sign = $parameters['sign'];
        $res = [
            'order_number' => $parameters['oid'],
            'third_order' => '',
            'third_money' => $parameters['amt'],
        ];

        if ($parameters['code']!=100) {
            $res['status'] = 0;
            $res['error']  = '订单交易失败--'.$res['code'];

            return $res;
        }


        $config = Recharge::getThirdConfig($parameters['oid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error']  = '没有该订单';
            return $res;
        }
        $check = $this->returnVail($sign_data,$re_sign,$config['key']);
        if ($check){
            $order_number = $parameters['oid'];
            $return_money = $parameters['amt'];
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        }else{
            $res['status'] = 0;
            $res['error']  = '验签失败！';
        }
        return $res;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($sign_data,$re_sign,$pub_key)
    {
        $string='';
        foreach ($sign_data as $key=>$value){
            $string = $string.$value;
        }
        $string=$string. $pub_key;
        //var_dump($string);exit();
        $sign = md5($string);
        if ($sign != $re_sign){
            return false;
        }
        return true;
    }

}