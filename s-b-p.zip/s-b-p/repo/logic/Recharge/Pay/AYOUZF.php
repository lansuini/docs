<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 天元/新万通支付/a优支付
 * @package Logic\Recharge\Pay
 */
class AYOUZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $parameter = [
            'mchId' => $this->partnerID,
            'appId' => $this->data['app_id'],
            'mchOrderNo' => (string)$this->orderID,
            'amount' => $this->money * 100,
            'notifyUrl' => $this->notifyUrl,
            'returnUrl' => $this->returnUrl,
            'subject' => (string)$this->orderID,
            'body' => (string)$this->orderID,
            'currency' => 'cny',
            'productId' => $this->payType,
            'clientIp' => $this->data['client_ip'],
            'param1' => $this->uid,
        ];
        $parameter['sign'] = $this->_sign($parameter, $this->key);
        $this->parameter = [
            'params' => json_encode($parameter),
        ];
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['retCode']) && $re['retCode'] == 'SUCCESS') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $content = $re['payUrl'] ?? $re['payParams']['payUrl'];
            if (strpos($content, 'form>') || strpos($content, 'script>')) {
                $content = $this->jumpURL . '?method=HTML&html=' . base64_encode($content);
            } else if (strpos($content, "%") && (!strpos($content, "&") || strpos($content, "%22"))) {
                $content = urldecode($content);
            }
            $this->return['str'] = $content;
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'ayou:' . $re['retMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        $res = [
            'order_number' => $parameters['mchOrderNo'],
            'third_order' => $parameters['payOrderId'],
            'third_money' => $parameters['amount'] / 100,
        ];
        $config = Recharge::getThirdConfig($parameters['mchOrderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != 2) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $this->updateMoney($res['order_number'], $res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key => $val) {
            if ($val) {
                $string = $string ? $string . "&" . $key . "=" . $val : $key . "=" . $val;
            }

        }
        $string = $string . '&key=' . $tKey;
        $sign = md5($string);
        return strtoupper($sign);
    }

    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != strtoupper($return_sign)) {
            return false;
        }
        return true;
    }
}