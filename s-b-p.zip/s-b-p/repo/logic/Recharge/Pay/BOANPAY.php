<?php
/**
 * 铂安支付
 * @author Taylor 2019-05-02
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class BOANPAY extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            //基本参数
            'merchant_no' => $this->partnerID,//商户号
            'version' => 'v1',//版本号
            'channel_no' => '01',//渠道号
            'out_trade_no' => $this->orderID,//商户订单号
            'amount' => $this->money * 100,//交易金额订单金额，以"分"为单位
            'channel' => $this->payType,//支付通道
            'goods_name' => 'shop',//商品名称
            'remark' => 'vip' . $this->orderID,//商品自用备注信息
            'return_url' => $this->returnUrl,//同步地址
            'notify_url' => $this->notifyUrl,//异步通知URL
            'ip' => $this->clientIp,//客户ip
        );
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $k => $v) {
            if ($v != '' && $v != null) {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $string = $string . 'key=' . $tkey;
        $sign = md5($string);

        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        //{"sign":"cfcf1b63b91e02ccd0c195e2f34b5ffe","amount":"10000","trade_flow":"201905023195133789504512","remark":"vip1905022037366","return_msg":"success","return_code":"1","out_trade_no":"1905022037366","return_url":"http://api.boenpay.com/payapi/api/trade/fast/RVny6v"}
        if ($re['return_code'] == 1) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            if ($this->data['return_type'] == 'code'||$this->payType == "ZFBZF"||$this->payType=="WXZF") {
                $this->return['str'] = $this->qrcodeUrl.$re['return_url'];
            }else{
                $this->return['str'] = $re['return_url'];//支付地址
            }
        } else {
            $this->return['code'] = 8;
            $this->return['msg'] = 'BOANPAY:' . (isset($re['return_msg']) ? $re['return_msg'] : '');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     * [status=1 通过  0不通过,
     * order_number = '订单',
     * third_order = 第三方订单,
     * third_money ='金额',
     * error'='未有该订单/订单未支付/未有该订单']
     * @param
     * @return boolean
     */
    public function returnVerify($data)
    {
//        $data = array_map('urldecode', $data);
        if (isset($data['s'])) unset($data['s']);
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['out_trade_no'],//商户订单号
            'third_order' => $data['trade_flow'],//平台流水号
            'third_money' => $data['amount'] / 100,//支付金额，以分为单位
            'error' => '',
        ];

        if ($data['status'] != 'success') {//1:信息返回成功 0:信息返回失败
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($p, $tkey)
    {
        $sys_sign = $p['sign'];
        unset($p['sign']);
        $sign = $this->_sign($p, $tkey);//MD5加密串
        if ($sign == $sys_sign) {
            return true;
        }
        return false;
    }
}
