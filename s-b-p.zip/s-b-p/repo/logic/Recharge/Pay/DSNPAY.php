<?php
/**
 * Created by PhpStorm.
 * User: pxb
 * Date: 2019-06-03
 * Time: 09:54
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;
class DSNPAY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'aid' => $this->partnerID,
            'price' => $this->money,
            'out_order_id' => $this->orderID,
            'type' => $this->payType,
            'format' =>  'json',
            'notifyurl' => $this->notifyUrl,
            'secretkey' => $this->key,
        ];

        $tmp = [
            'aid' => $this->partnerID,
            'price' => $this->money,
            'out_order_id' => $this->orderID,
            'type' => $this->payType,
            'notifyurl' => $this->notifyUrl,
        ];

        $str= implode('',$tmp);

        //秘钥存入 token字段中
        $this->parameter['sign'] = md5(md5($str).$this->key);
    }


    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == '1') {
            $this->return['code'] = 0;//code为空代表是OK
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['payurl'];
        } else {
            $this->return['code'] = 65;  //非0代付 错误
            $this->return['msg'] = 'DSNPAY:' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {

        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $data['out_order_id'],
            'third_order' => $data['order_id'],
            'third_money' => $data['realprice'],  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['out_order_id']);
        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        $tmp = [
            'aid' => $data['order_id'],
            'out_order_id' => $data['out_order_id'],
            'price' => $data['price'],
            'realprice' => $data['realprice'],
            'type' => $data['type'],
            'paytime' => $data['paytime'],
        ];

        if ($data['sign'] != md5(md5(implode('',$tmp)).$config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
