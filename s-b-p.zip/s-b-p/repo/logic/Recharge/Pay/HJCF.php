<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;


/**
 * 汇聚财富
 */
class HJCF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        //参与签名字段
        $data = [
            'mchId' => $this->partnerID,
            'orderId' => $this->orderID,
            'payType' => $this->payType, //支付类型
            'amount' => $this->money,
            'randomstr' => Utils::randStr(),
            'timestamp' => time(),
            'ip' => $this->clientIp,
            'notify_url' => $this->notifyUrl,
            'remarks' => "uid:" . $this->uid,
        ];

        //不参与签名字段
        $pub_params = [
            'sign' => $this->getSign($data, $this->key)
        ];
        $this->parameter = array_merge($data, $pub_params);
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        $pieces['key'] = $api_key;
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key => $val) {
            $string = $string . $key . '=' . $val . '&';
        }

        $string = rtrim($string, '&');
        $sign = md5($string);
        unset($pieces['key']);
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['data']) && $re['status'] === 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['qrUrl'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'HJCF:' . (isset($re['msg']) ? $re['msg'] : '请求失败');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['orderId']) || !isset($data['tradeNo']) || !isset($data['amount'])) {
            return false;
        }

        $res = [
            'status' => 1,
            'order_number' => $data['orderId'],
            'third_order' => $data['tradeNo'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

        if ($data['status'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单号未成功支付';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $signOld, $config)
    {
        unset($data['sign']);
        $sign = $this->getSign($data, $config['key']);
        return $sign == $signOld;
    }


}