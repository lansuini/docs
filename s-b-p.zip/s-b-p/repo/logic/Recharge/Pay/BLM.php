<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 菠萝蜜支付
 * @author lavenkin
 */
class BLM extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = [
            'shopAccountId' => $this->partnerID,
            'shopUserId' => 1+$this->uid,
            'amountInString' => $this->money,
            'shopNo' => $this->orderID,
            'payChannel' => $this->payType
        ];


        $this->parameter['sign'] = $this->_sign($this->parameter);
        $this->parameter['shopCallbackUrl'] =$this->notifyUrl;
        $this->parameter['returnUrl'] ='';
        $this->parameter['target'] = 3;

    }

    public function parseRE()
    {
       // print_r($this->re);exit;
        $re = json_decode($this->re, true);

        if (isset($re['page_url']) && $re['page_url'] != null) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['page_url'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '菠萝蜜：' . $re['message'] ?? '通道返回有误';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 生成sign
     */
    private function _sign($pieces)
    {

        $string = '';
        foreach ($pieces as $keys => $value){
            if ($value != '' && $value != null){
                $string = $string.$value;
            }
        }

        $string = $string .$this->key;
        // print($string);exit;
        $sign = md5($string);
 
        return $sign;
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($parameters) 
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['shop_no'],
            'third_order' => $parameters['order_no'],
            'third_money' => $parameters['money'],
            'error' => '',
        ];

        if ($parameters['status'] != 0) {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['shop_no']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        //校验sign
        //$publicKeyString = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($config['pub_key'], 64, "\n", true) . "\n-----END PUBLIC KEY-----";
        // var_dump($publicKeyString);exit;
        if (! $this->_verifySign($parameters, $config, $parameters['sign'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        $return_money= (int) $parameters['money'];
        $order_number=$parameters['shop_no'];
        $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
        $order_info = (array)$order_info;
        if (empty($order_info)){
            $res['status'] = 0;
            $res['error'] = '不存在的订单！';
        }else{
            if ($order_info['i_money'] - $return_money == 0){
                $res['status'] = 1;
            }else{
                \DB::table('order')->where('order_number', $parameters['shop_no'])->update(['order_money' =>$return_money]);
                $updata = array(
                    'i_money' => $return_money,
                    'i_gold' => $return_money,
                );
                \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                $res['status'] = 1;
            }
        }





        return $res;
    }

    /**
     * 验证sign
     */
    private function _verifySign($data, $config, $sign)
    {
        $re_sign = md5($config['partner_id'].$data['user_id'].$data['trade_no'].$config['pub_key'].$data['money'].$data['type']);
        if($re_sign!=$sign){
            return false;
        }
        return true;
    }

}
