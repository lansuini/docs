<?php
/**
 * 广付通支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/10
 * Time: 16:51
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class GFTPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->_httpUrl();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'mchId' => $this->partnerID,
            'payType' => (string)$this->payType,
            'mchOrderNo' => (string)$this->orderID,
            'timestamp' => time(),
            'amount' => $this->money*100,
            'version' => 'V001',
            'backNotifyUrl' => $this->notifyUrl,
            'commodityName'=>(string)$this->orderID,
            'frontNotifyUrl' => $this->returnUrl
        ];
        $pub_params['sign'] = strtoupper($this->_sign($pub_params,$this->key));
        //var_dump($pub_params);exit();
        $this->parameter = json_encode($pub_params);
    }

    public function _httpUrl()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->payUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->parameter);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        curl_close($ch);
        $this->re = $result;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if (isset($re['code']) && $re['code']==200){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $re_data = $re['data'];
            //$this->return['str'] = $re_data['qr_code'];
            if ($this->data['return_type'] == 'code') {
                $this->return['str'] = $this->data['url_qr_domain'] . '/qrcoder?code=' . Utils::imgUpload($re_data['qr_code'])['img_name'] . '&pay_type=' . $this->data['scene']. '&amount=' . $this->money;
            } else {
                $this->return['str'] = $re_data['qr_code'];
            }
        }else{
            $this->return['code'] = $re['code'];
            $this->return['msg'] = $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['mchOrderNo'],
            'third_order' => $parameters['platformOrderId'],
            'third_money' => $parameters['amount']/100,
        ];
        $config = Recharge::getThirdConfig($parameters['mchOrderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != 2){
            $res['status'] = 0;
            $res['error'] = '订单支付状态失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['mchOrderNo'];
            $return_money = $parameters['amount']/100;
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            if (!empty($val)){
                $string[] = $key.'='.$val;
            }
        }
        $params = join('&',$string);
        $sign_str = $params.'&key='.$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}