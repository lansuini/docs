<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 蓝莓支付
 */
class BLUEBERRY extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $amount = number_format($this->money, 2);//必须两位小数，否则不通过
        $params = [
            'pay_type' => (int)$this->payType,//交易回调通知地址
            'amount' => $amount,
            'attach' => 'Xepay',
            'client_ip' => $this->clientIp,
            'ref_number' => $this->orderID,
            'notify_url' => $this->notifyUrl,
        ];

        $header = [
            'merchant_code' => $this->partnerID,
            'timestamp' => time(),
            'nonce' => $this->NonceStr(16),
        ];


        $data = array_merge($params, $header);
        $sign = $this->getSign($data, $this->key);

        //发起请求
        $this->httpPost($params, $sign, $header['timestamp'], $header['nonce']);

        //记录参数用于存储数据库
        $this->parameter = $data;
        $this->parameter['sign'] = $sign;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function getSign($pieces, $api_key)
    {
        ksort($pieces);
        $hashstr = http_build_query($pieces);
        return hash_hmac('sha256', $hashstr, $api_key);
    }

    private function httpPost($params, $sign, $timestamp, $nonce)
    {
        $headers = array();
        $headers[] = "Content-Type:application/json";
        $headers[] = "sign:$sign";
        $headers[] = "timestamp:$timestamp";
        $headers[] = 'nonce:' . $nonce;
        $headers[] = "merchant_code:" . $this->partnerID;
        $params['amount'] = (float)$params['amount'];
        $data_json = json_encode($params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->payUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $this->re = curl_exec($ch);
        curl_close($ch);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['code'] == 2000 && isset($re['data'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['url'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '蓝莓支付：' . $re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!isset($data['ref_number']) || !isset($data['amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $data['ref_number'],
            'third_order' => $data['ref_number'],
            'third_money' => $data['amount'],
            'error' => '',
        ];

//        if ($data['tradeStatus'] != 2) {
//            $res['status'] = 0;
//            $res['error'] = '订单号未成功支付';
//            return $res;
//        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    private function _verifySign($data, $config)
    {
        $param = array(
            "ref_number" => $data['ref_number'],
            "amount" => number_format($data['amount'], 2),
            "pay_type" => $data['pay_type'],
            "attach" => $data['attach'],
            "merchant_code" => $config['partner_id'],
        );
        $signOld = $data['sign'];

        $sign = $this->getSign($param, $config['key']);
        return $sign == $signOld;
    }

    protected function NonceStr($length = 16)
    {
        $returnStr = '';
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for ($i = 0; $i < $length; $i++) {
            $returnStr .= $pattern{mt_rand(0, 61)};
        }
        return $returnStr;
    }

}