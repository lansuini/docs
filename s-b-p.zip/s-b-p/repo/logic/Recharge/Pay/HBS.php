<?php
/**
*海必胜
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HBS extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
//        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $pub_params = [
            'ApiMethod' => 'OnLinePay',
            'Version' => 'V2.0',
            'MerID' => $this->partnerID,
            'TradeNum' => (string)$this->orderID,
            'Amount' => $this->money,
            'NotifyUrl' => $this->notifyUrl,
            'TransTime' => date('YmdHis',time()),
            'PayType' => $this->payType,
//            'IsImgCode' => 1,
//            'UserIP' => $this->clientIp,
            'SignType' => 'MD5',
        ];
        $pub_params['Sign'] = $this->_sign($pub_params,$this->key);
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
//       $re = json_decode($this->re,true);
//       if(isset($re['PayUrl'])&&$re['PayUrl']) {
//           $this->return['code'] = 0;
//           $this->return['msg'] = 'SUCCESS';
//           $this->return['way'] = $this->showType;
//           $this->return['str'] = $re['PayUrl'];
//       }else {
//           $this->return['code'] = 59;
//           $this->return['msg'] = 'HBS'.$re['Message'] ?? '第三方未知错误';
//           $this->return['way'] = $this->showType;
//           $this->return['str'] = '';
//       }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        $res = [
            'order_number' => $parameters['TradeNum'],
            'third_order' => $parameters['OrderNum'],
            'third_money' => $parameters['Amount'],
            'status'=>1,
            'error'=>''
        ];
        $config = Recharge::getThirdConfig($parameters['TradeNum']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['Status'] != '01'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        if (strtoupper($parameters['Sign']) != strtoupper($this->_sign($parameters,$config['key']))) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params,$tkey)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != '' && $v != null && $k != 'Sign') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign_str = $string.'key='.$tkey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }
}