<?php
/**
 * 欢乐付
 * Created by Hans.
 * Date: 2019/6/1
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Utils;

class HLPAY extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'charset' => 'UTF-8',
            'merchantCode' => (string)$this->partnerID,
            'orderNo' => (string)$this->orderID,
            'amount' => $this->money * 100,
            'channel' => 'BANK',
            'bankCode' => $this->payType,
            'remark' => 'goods',
            'notifyUrl' => $this->notifyUrl,
            'returnUrl' => $this->returnUrl,
            'extraReturnParam' => '',
        ];

        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $pub_params['signType'] = 'RSA';
        $this->parameter = $pub_params;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderNo']) || !isset($parameters['payOrderNo']) || !isset($parameters['amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['orderNo'],
            'third_order' => $parameters['payOrderNo'],
            'third_money' => $parameters['successAmt']/100,
        ];

        if ($parameters['orderStatus'] != 'Success') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['orderNo']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->verifySign($parameters,$config['pub_key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/Pay_Trade_query.html';
        }

        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != 'T') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    private function _sign($data, $pkey){
        $buff = "";
        foreach ($data as $k => $v) {
            if ($k != "SIGN_DAT" && !is_array($v)) {
                $buff .= $k . "=" . $v . "&";
            }
        }
        $buff = trim($buff, "&");

        $key = openssl_get_privatekey($pkey);

        openssl_sign($buff, $sign, $key, OPENSSL_ALGO_SHA1);
        $sign = base64_encode($sign);

        return $sign;
    }
    /**
     * 验证签名
     */
    private function verifySign($pub_params, $pubKey)
    {
        $original_str = "merchantCode={$pub_params['merchantCode']}&orderNo={$pub_params['orderNo']}&amount={$pub_params['amount']}&successAmt={$pub_params['successAmt']}&payOrderNo={$pub_params['payOrderNo']}&orderStatus={$pub_params['orderStatus']}&extraReturnParam={$pub_params['extraReturnParam']}";
        $sign = $pub_params['sign'];
        $sign = base64_decode ($sign);
        $public_key = openssl_get_publickey ( $pubKey );

        $result = openssl_verify ( $original_str, $sign, $public_key, OPENSSL_ALGO_SHA1 );
        return $result;
    }

    public function queryOrder($queryUrl,$orderNo, $partnerID, $tkey)
    {
        $params = [
            "merchantCode" => $partnerID,
            "orderNo" => $orderNo,
        ];


        $params['sign'] = $this->_sign($params, $tkey);
        $params['signType'] = 'RSA';

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNo, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['isSuccess'])) {
            return $re['isSuccess'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNo, $this->payUrl, $this->parameter);
        return null;
    }

}