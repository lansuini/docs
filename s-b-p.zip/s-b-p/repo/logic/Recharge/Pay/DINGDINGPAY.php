<?php
/**
 * 钉钉支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class DINGDINGPAY extends BASES
{

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $this->parameter = array(
            //基本参数
            'version' => 'v1.0',    // 终端用户标识
            'type' => $this->payType,//支付通道
            'userId' => $this->partnerID,    // 商户编号
            'requestNo' => $this->orderID,//商户订单号
            'amount' => $this->money * 100,//交易金额订单金额，以"分"为单位
            'callBackURL' => $this->notifyUrl,
            'redirectUrl' => $this->returnUrl,
        );

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 生成sign
     */
    private function _sign($params, $tkey)
    {
        ksort($params);
        $string = '';
        foreach ($params as $k => $v) {
            if ($v != null && $v != '') {
                $string = $string . $k . '=' . $v . '&';
            }
        }
        $sign_str = $string . 'key=' . $tkey;
        return md5($sign_str);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['status'] != null && $re['status'] == '1') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            $this->return['str'] = $re['payUrl'];
        } else {
            $this->return['code'] = $re['status'];
            $this->return['msg'] = '钉钉支付:' . $re['message'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {

        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['requestNo'],//商户订单号
            'third_order' => $data['orderNo'],//平台流水号
            'third_money' => $data['payAmount'] / 100,
            'error' => '',
        ];


        $config = Recharge::getThirdConfig($data['requestNo']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($data['status'] == null || $data['status'] != '3') {
            $res['status'] = 0;
            $res['error'] = $data['message'];
            return $res;
        }

        $result = $this->returnVail($data, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $param
     * @return boolean
     */
    public function returnVail($param, $key)
    {
        $sys_sign = $param['sign'];
        unset($param["sign"]);
        $sign_string = $this->_sign($param, $key);

        if ($sign_string == $sys_sign) {
            return true;
        } else {
            return false;
        }

    }
}
