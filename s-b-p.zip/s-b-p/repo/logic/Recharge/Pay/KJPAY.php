<?php
/**
 * 快捷支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class KJPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'account' => (string)$this->partnerID,
            'orderId' => (string)$this->orderID,
            'money' => $this->money,
            'notifyUrl' => $this->notifyUrl,
        ];
        $pub_params['sign'] = $this->_signature($pub_params, $this->key);
        $this->parameter = $pub_params;
    }

    //签名实现
    private static function _signature($arr, $keys)
    {
        $priKey = "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($keys, 64, "\n", true) . "\n-----END RSA PRIVATE KEY-----";
        $priKey = openssl_get_privatekey($priKey);
        $signStr = $arr['orderId'];
        openssl_sign($signStr, $sign, $priKey, OPENSSL_ALGO_MD5);
        openssl_free_key($priKey);
        return base64_encode($sign);
    }

    //回调实现
    private static function _designature($sign, $re_sign, $keys)
    {
        $publickey = "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($keys, 64, "\n", true) . "\n-----END RSA PRIVATE KEY-----";
//对数据进行解密
        openssl_private_decrypt(base64_decode($re_sign), $decrypted, $publickey);//私钥解密

        if ($decrypted == $sign) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $data = json_decode($this->re, true);
        if (isset($data['status']) && $data['status'] == '0') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['data']['encode'];

        } else {
            $this->return['code'] = $data['code'];
            $this->return['msg'] = $data['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderId']) || !isset($parameters['money'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['orderId'],
            'third_order' => $parameters['orderId'],
            'third_money' => $parameters['money'],
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($parameters['status'] != '1') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }


        if ($this->_designature($res['order_number'], $parameters['sign'], $config['key'])) {
            $res['error'] = '验签失败！';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }


}