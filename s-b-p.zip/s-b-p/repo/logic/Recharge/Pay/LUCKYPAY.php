<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * AA支付
 */
class LUCKYPAY extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'merchantNo' => $this->partnerID,
            'merchantOrderNo' => $this->orderID,
            'merchantReqTime' => date("YmdHis"),
            'orderAmount' => $this->money,
            'tradeSummary' => 'testSummary',
            'payModel' => 'Direct',   // Direct	直连  NonDirect	非直连
            'payType' => $this->payType,
            'cardType' => 'DEBIT',  // DEBIT:借记卡  CREDIT:信用卡
            'userTerminal' => 'PC',  // PC  Phone  Pad
            'userIp' => $this->clientIp,  // 付款人 IP
            'backNoticeUrl' => $this->notifyUrl,    // 回调地址
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 'SUCCESS') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['biz']['payUrl'] ?? "不存在payUrl参数";
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'LuckPay:' . (isset($re['message']) ? $re['message'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }


    /**
     * 回调验证处理
     */
    public function returnVerify($params)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        $data = $result['biz'];
        $res = [
            'status' => 0,
            'order_number' => $data['merchantOrderNo'],
            'third_order' => $data['platformOrderNo'],
            'third_money' => $data['orderAmount'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($data['merchantOrderNo']);
        // var_dump($data);exit;
        if ($data['code'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //校验sign
        $sign = $params['sign'];
        if (array_key_exists('s', $data)) {
            unset($data['s']);
        }
        unset($params['sign']);

        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);

        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string = rtrim($string, '&');
        $string .= $key;
        $sign = md5($string);
//        print_r($string);
//        echo PHP_EOL;
//        echo PHP_EOL;
//        print_r($sign);
//        exit;
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {
        $pieces = json_encode($pieces, JSON_UNESCAPED_UNICODE);
        $string = $pieces . $key;
        $sign = md5($string);

        return $thirdSign == $sign;
    }
}