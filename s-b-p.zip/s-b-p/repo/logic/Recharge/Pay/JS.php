<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 晋商支付
 * @author zhangli
 */
class JS extends BASES
{
    protected $dataArr;

    //与第三方交互
    public function start()
    {

        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $type = explode('_', $this->data['bank_data']);
        $this->parameter = array(
            'MerchantNo' => $this->partnerID,
            'OutTradeNo' => $this->orderID,
            'ChannelType' => $type[0],
            'PayWay' => $type[1],
            'Body' => 'GOODS',
            'Amount' => (string)$this->money * 100,
            'NotifyUrl' => $this->notifyUrl
        );
        $this->parameter['Sign'] = $this->sytMd5($this->parameter, $this->key);
    }


    public function sytMd5($piecess, $key)
    {
        unset($piecess['NotifyUrl']);
        ksort($piecess);
        $signStr = md5(implode($piecess ). $key);
        return $signStr;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['Code']) && $re['Code'] == '1000') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['Data']['PayHtml'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = '晋商:' . $re['Msg'] ?? "未知异常";
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }

    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        $res = [
            'status' => 1,
            'order_number' => $input['OutTradeNo'],
            'third_order' => $input['OrderNo'],
            'third_money' => $input['Amount'] / 100,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($input['OutTradeNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
        }

        $sign = $input['Sign'];
        $newSign = $this->getVerify($input, $config['key']);
        if ($newSign != $sign) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
        }
        return $res;
    }

    public function getVerify($respData, $key)
    {
        $params = array(
            'OrderNo' => $respData['OrderNo'],
            'MerchantNo' => $respData['MerchantNo'],
            'Amount' => $respData['Amount'],
            'OutTradeNo' => $respData['OutTradeNo'],
            'Status' => $respData['Status'],
            'key' => $key
        );
        $signStr = md5(implode($params));
        return $signStr;
    }

}
