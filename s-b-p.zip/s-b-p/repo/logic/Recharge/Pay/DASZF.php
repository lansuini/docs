<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 大圣支付
 */
class DASZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->parameter = [
            'Amount' => $this->money * 100,
            'OrderNo' => $this->orderID,
            'ProductName' => $this->orderID,
            'Remark' => 'uid:' . $this->uid . ',ip:' . $this->clientIp,
            'HubpayCode' => $this->payType, //大于0：指定已开通的通道，等于0：随机切换已开通通道
            'NotifyUrl' => $this->notifyUrl,
            'TimeStamp' => time(),
            'NonceStr' => $this->NonceStr(),
            'AppId' => $this->partnerID,
        ];

        $this->parameter['Signature'] = $this->getSign($this->parameter, $this->key);
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['ret']) && $re['ret'] == 0 && isset($re['data'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = $re['msg'] ?? 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['Qrcode'] ?? $re['data']['PayUrl'];
        } else {
            $this->return['code'] = $re['ret'] > 0 ? $re['ret'] : 23;
            $this->return['msg'] = '大圣支付：' . $re['msg'] ?? '请求失败';
            $this->return['way'] = $this->data['return_type'];
        }
    }

    //生成数字和字母组合随机数
    public function NonceStr($length = 16)
    {
        $returnStr = '';
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for ($i = 0; $i < $length; $i++) {
            $returnStr .= $pattern{mt_rand(0, 61)};
        }
        return $returnStr;
    }

    public function getSign($pieces, $api_key)
    {
        $arr = array_filter($pieces);
        unset($arr['Signature']);
        unset($arr['AppSecret']);

        ksort($arr);
        $string = '';
        foreach ($arr as $key => $val) {
            $string = $string . $key . '=' . $val . '&';
        }
        $string = $string . 'AppSecret=' . $api_key;
        $sign = strtoupper(md5($string));
        return $sign;
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res = [
            'status' => 0,
            'order_number' => $data['OrderNo'],
            'third_order' => $data['OutTradeNo'],
            'third_money' => $data['PayAmount'] / 100,
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }

    private function _verifySign($data, $config)
    {
        $returnSign = $data['Signature'];
        $sign = $this->getSign($data, $config['key']);
        return $sign == $returnSign;
    }

}