<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 东方支付
 */
class DFANG extends BASES
{
    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    //初始化参数
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = array(
            'mallCode' => $this->partnerID,
            'outTradeNo' => $this->orderID,
            'mallPlayerId' => $this->uid,
            'chargeAmount' => sprintf("%.2f", $this->money),
            'payChannel' => $this->payType,
            'notifyUrl' => $this->notifyUrl,
            'time' => time(),
        );

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['clientIp'] = $this->clientIp;
        $this->parameter['mallData'] = $this->orderID;
        $this->parameter['deviceInfo'] = $this->uid;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        ksort($params);
        $string = [];
        foreach ($params as $k => $v) {
            if ($k != 'sign') {
                $string[] = $k . '=' . $v;
            }
        }
        $params = join('&', $string);
        $signPars = $params . "&key=" . $key;
        return strtoupper(md5($signPars));
    }

    //返回参数
    public function parseRE()
    {
        $data = json_decode($this->re, true);
        if (isset($data['data']['code']) && $data['data']['code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['data']['aliurl'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = isset($data['data']['message']) ? $data['data']['message'] : (isset($data['message']) ? $data['message'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    //签名验证
    public function returnVerify($pieces)
    {
        global $app;
        $pieces = $app->getContainer()->request->getParams();
        unset($pieces['s']);
        if (!isset($pieces['outTradeNo']) || !isset($pieces['paidAmount'])) {
            $res['status'] = 0;
            $res['error'] = '非法数据';
            return $res;
        }

        $res = [
            'status' => 0,
            'order_number' => $pieces['outTradeNo'],
            'third_order' => $pieces['orderId'],
            'third_money' => $pieces['paidAmount'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($pieces['outTradeNo']);
        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }

        if ($pieces['status'] != '1') {
            $res['error'] = '失败！';
            return $res;
        }

        if (!self::retrunVail($pieces['sign'], $pieces, $config)) {
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    public function retrunVail($sign, $pieces, $config)
    {
        unset($pieces['sign']);
        $this->parameter = $pieces;
        $signStr = $this->_sign($this->parameter, $config['key']);
        return $sign == $signStr;
    }


}