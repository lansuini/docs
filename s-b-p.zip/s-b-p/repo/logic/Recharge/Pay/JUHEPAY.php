<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
/**
 * 聚合支付3.0
 */

class JUHEPAY extends BASES {

	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        // $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam() 
    {
        $type = explode('_', $this->data['bank_data']);
        $this->parameter = [
            'version' => '1.0',
            'agentId' => $this->partnerID,
            'agentOrderId' => $this->orderID,
            'payType' => $type[0],
            'bankCode' => $type[1],
            'payAmt' => sprintf("%.2f", $this->money),
            'orderTime' => date('YmdHis'),
            'payIp' => $this->clientIp ? $this->clientIp : '127.0.0.1',
            'notifyUrl' => $this->notifyUrl,
            'noticePage' => '',
            'bankAccno' => '',
            'remark' => 'golds',
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter);
        // $this->parameter = $this->toXml($this->parameter);
        // var_dump($this->parameter);exit;
    }

    public function parseRE()
    {
        $this->parameter = $this->arrayToUrlByAll();
		$this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->data['return_type'];
		$this->return['str'] = $this->data['payurl'] . '?' . $this->parameter;
    }

    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

    	$res = [
            'status' => 0,
            'order_number' => $data['agentOrderId'],
            'third_order' => $data['jnetOrderId'],
            'third_money' => $data['payAmt'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['agentOrderId']);
        // var_dump($data['out_trade_no']);exit;
        if ($data['payResult'] != 'SUCCESS') {
        	$res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        // var_dump($config);exit;
        //校验sign
        if (! $this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    /**
     * 生成签名
     */
    private function _sign($pieces)
    {
    	$params = [
            'version',
            'agentId',
            'agentOrderId',
            'payType',
            'payAmt',
            'orderTime',
            'payIp',
            'notifyUrl',
        ];
        $string = '';
        foreach ($params as $keys => $param){
            $string .= $pieces[$param] . '|';
        }
        $string = $string . $this->key;
        // print($string);exit;
        $sign = md5($string);
 
        return $sign;
    }

    /**
     * 验证签名
     */
    private function _verifySign($pieces, $skey)
    {
        $params = [
            'version',
            'agentId',
            'agentOrderId',
            'jnetOrderId',
            'payAmt',
            'payResult',
        ];

        $string = '';
        foreach ($params as $keys => $param){
            $string .= $pieces[$param] . '|';
        }
        $string = $string . $skey;

        $mySign = md5($string);
        return trim($pieces['sign']) == $mySign;
    }

}