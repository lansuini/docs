<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 欢快支付
 */
class HKPAY extends BASES
{

    private $MAX_RETRY_ROB = 15; //最多下单抢单次数
    private $is_rob = false; //是否使用抢单模式:关闭抢单

    //与第三方交互
    public function start()
    {
        if ($this->is_rob) {
            //抢单模式
            $this->multiRequest();
        } else {
            $this->parameter = $this->initParam(0);
            $this->basePost();
            $this->parseRE($this->re);
        }
    }

    public function windUp()
    {
        if ($this->is_rob && $this->return['code'] == 0) {
            //保存抢单单号，以备运营后台查单号
            \DB::table('order')->where('order_number', $this->orderID)->update(['third_order' => $this->parameter['outOrderNo']]);
        }
        parent::windUp();
    }

    //组装数组
    public function initParam($count)
    {
        $order_number = $this->orderID;
        if ($count > 0)
            $order_number = $this->orderID . "rob" . $count;

        $pub_params = [
            'coopId' => $this->partnerID,
            'outOrderNo' => $order_number,
            'subject' => 'Goods',
            'money' => $this->money * 100,
            'notifyUrl' => $this->notifyUrl,
            'pathType' => $this->payType,

        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        //必需返回下单参数
        return $pub_params;
    }

    private function multiRequest()
    {
        $mh = curl_multi_init();

        $handles = [];
        $params_array = [];
        // 初始化多个请求句柄为一个
        //将所有请求按数量分为多组，分多次请求
        $chuck_num = ceil($this->MAX_RETRY_ROB/2);//防止超时，只分两波请求发出
        $split_count = ceil($this->MAX_RETRY_ROB / $chuck_num);

        $total_request = 0;
        for ($split_index = 0; $split_index < $split_count; $split_index++) {
            $start = $split_index * $chuck_num;

            for ($i = 0; $i < $chuck_num && $total_request < $this->MAX_RETRY_ROB; $i++, $total_request++) {
                //构建请求参数
                $pub_params = $this->initParam($start + $i);

                //curl配置
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->payUrl);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                //请求参数
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($pub_params));
                curl_multi_add_handle($mh, $ch);

                //保存下单参数和curl句柄
                $params_array[] = $pub_params;
                $handles[] = $ch;
            }

            $active = null;
            // 检测操作的初始状态是否OK，CURLM_CALL_MULTI_PERFORM为常量值-1
            do {
                $mrc = curl_multi_exec($mh, $active);
            } while ($mrc == CURLM_CALL_MULTI_PERFORM);

            do {
                if (curl_multi_select($mh) == -1) {
                    //没有就阻塞50毫秒
                    usleep(50000);
                }
                do {
                    // 返回的$active是活跃连接的数量，$mrc是返回值，正常为0，异常为-1
                    $mrc = curl_multi_exec($mh, $active);
                } while ($mrc == CURLM_CALL_MULTI_PERFORM);

                while ($info = curl_multi_info_read($mh)) {
                    $content = curl_multi_getcontent($info['handle']);

                    if (!empty($content)) {
                        //这里解开注释可以打印每个请求的日志
//                        $index = array_search($info['handle'], $handles);
//                        print_r($params_array[$index]);
//                        print_r($content . PHP_EOL);
                        $this->parseRE($content);


                        if ($this->return['code'] == 0) {
                            //保存请求参数
                            $index = array_search($info['handle'], $handles);
                            $this->parameter = $params_array[$index];

                            //抢到单了，全部结束
                            $active = 0;
                            break;
                        }
                    }
                }

            } while ($active > 0);

            if ($this->return['code'] == 0) {
                break;
            }
        }

        curl_multi_close($mh);

        if ($this->parameter == null) {
            $this->parameter = $params_array[0];
        }
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tKey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($key != 'sign' && $val != '' && $val != null) {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);
        $sign = $params . $tKey;
        return md5($sign);
    }

    public function parseRE($content)
    {
        $re = json_decode($content, true);
        if (isset($re['code']) && $re['code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['payurl'];
        } else {
            $msg = $re['msg'];
            $this->return['code'] = 53;
            $this->return['msg'] = '欢快支付:' . $msg ?? '第三方未知错误';
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {

        if (!isset($input['outOrderNo'])) {
            // 非法数据
            return false;
        }

        $order_number = $input['outOrderNo'];
        $find = strpos($order_number, "rob");//下单时加进去的抢单单号标识
        if ($find && $find > 0) {
            $order_number = substr($order_number, 0, $find);
        }

        $res = [
            'status' => 0,
            'order_number' => $order_number,
            'third_order' => $input['outOrderNo'],
            'third_money' => $input['money'] / 100,
            'error' => '',
        ];


        $config = Recharge::getThirdConfig($order_number);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        if ($input['code'] != 0) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }


        $result = $this->returnVail($input, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    public function returnVail($params, $tkey)
    {
        $sign = $params['sign'];
        unset($params['sign']);
        $signResult = $this->_sign($params, $tkey);

        return $sign == $signResult;
    }
}
