<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/19
 * Time: 10:09
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * BLUE支付
 * @package Logic\Recharge\Pay
 */
class BLUE extends BASES
{
    protected $param;

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $apiMethodName = 'trade.place.order';

        //业务参数
        $bizContent = [
            'merchantId'=> $this->partnerID,//商户号
            'orderDesc'=> 'goods',//描述
            'payType'=> !empty($this->data['app_secret']) ? $this->data['app_secret']:'WECHAT_SCAN',//支付类型 默认WECHAT_SCAN
            'productCode'=> $this->payType,//产品编码
            'goodsName'=> 'goods',
            'goodsType'=> '1',
            'amount' => $this->money * 100,//订单总金额，单位为分
            'notifyUrl' => $this->notifyUrl,
            // 个码支付必传参数
            'orderCreateIp' => $this->clientIp,
            'payerCustId' => $this->uid,
        ];

        $data = json_encode($bizContent);

        //公共请求参数
        $sysParams = [
            'orderNo' => $this->orderID,
            'appId' => $this->data['app_id'],
            'method' => $apiMethodName,
            'tradeTime' => date("Y-m-d H:i:s"),
            'version' => '1.0.0',
            'bizContent'=>  $data,
        ];
        $sysParams['sign'] = $this->generate_sign($sysParams,$this->key);

        $this->parameter =  $sysParams;
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }
    /**
     * 生成签名
     * @param  array $params 待签参数
     * @param  string $apikey API秘钥
     * @return string         签名
     */
    public static function generate_sign($params,$apikey)
    {
        ksort($params);
        $string = [];
        foreach ($params as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $params = join('&',$string);
        $sign_str = $params.'#'.$apikey;
        $sign = md5($sign_str);
        return $sign;
    }


    //返回参数
    public function parseRE()
    {
        $data = json_decode($this->re,true);

        $re = json_decode($data['data'],true);

        if (isset($data['respCode']) && $data['respCode']=='000000'){
            $content = $re['qrCode'];
            $qrCode = json_decode($content, true);
            if (isset($qrCode['codeUrl'])) {
                $content = $qrCode['codeUrl'];
            }
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $content;

        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = "Blue:".$data['respMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    //签名验证
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        if(!empty($result['s']))    unset($result['s']);

        $res = [
            'status' => 0,
            'order_number' => $result['orderNo'],
            'third_order' => $result['paySerialNo'],
            'third_money' => $result['amount'] /100, //单位为分
            'error' => '',
        ];

        if ($result['respCode'] != '000000') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($result['orderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        //按规则验签
        $data = $this->returnVail($result, $config['key']);
        if (!$data) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }
        $res['status'] = 1;
        $this->updateMoney($res['order_number'], $res['third_money']);

        return $res;
    }
    public function returnVail($data, $pubkey)
    {
        $returnArray = array( // 返回字段
            "merchantId" => $data["merchantId"], // 商户ID
            "orderNo" => $data["orderNo"], // 订单号
            "amount" => $data["amount"], // 交易金额
            "status" => $data["status"], // 交易状态
            "paySerialNo" => $data["paySerialNo"], // 支付流水号
            "respCode" => $data["respCode"],
            "respMsg" => $data["respMsg"],

        );
        ksort($returnArray);
        $string = [];
        foreach ($returnArray as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $params = join('&',$string);
        $sign_str = $params.'#'.$pubkey;
        $sign = strtoupper(md5($sign_str));
        return $sign;
    }
}