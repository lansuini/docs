<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 昌达支付
 * @author lavenkin
 */
class CD extends BASES 
{
	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
    	$this->parameter = [
    		'uid' => $this->partnerID,
    		'orderNo' => $this->orderID,
    		'body' => 'Golds',
    		'price' => $this->money,
    		'backUrl' => $this->returnUrl,
    		'postUrl' => $this->notifyUrl,
    		'type' => $this->data['bank_data'],
        ];

        $this->parameter['sign'] = $this->_createSign($this->parameter);
    }

    public function parseRE()
    {
    	$re = json_decode($this->re, true);
    	// var_dump($re);exit;
    	if ($re['resultCode'] != 'success') {
    		$this->return['code'] = 23;
            $this->return['msg'] = '昌达支付：' . $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
    	} else {
    		$this->return['code'] = 0;
	        $this->return['msg'] = $re['message'];
	        $this->return['way'] = $this->data['return_type'];
    		$this->return['str'] = $re['payUrl'];
    	}
    }

    public function returnVerify($data)
    {
    	$res = [
            'status' => 1,
            'order_number' => $data['orderNo'],
            'third_order' => $data['sysOrderNo'],
            'third_money' => $data['price'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['orderNo']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        // var_dump($data);exit;
        if ($data['resultCode'] != 'success') {
        	$res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        if (! $this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }
    }

    private function _verifySign($data, $signKey)
    {
    	$sign = $this->_createSign($data, $signKey);

    	return $sign == $data['sign'];
    }


    /**
     * 生成签名
     */
    private function _createSign($pieces, $signKey = '')
    {
    	ksort($pieces);
    	$string = '';
    	foreach ($pieces as $k => $v) {
    		if ($v != '' && $v != null && $k != 'sign' && $k != 's') {
    			$string .= $k . '=' . $v . '&';
    		}
    	}

    	$key = $signKey ? $signKey : $this->key;

    	$string .= 'key=' . $key;

    	// var_dump($string);exit;

    	$sign = strtoupper(md5($string));

    	return $sign;
    }
}