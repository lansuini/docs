<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 诚意付
 */
class CYF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->parameter['mchtid'] = $this->partnerID;
        $reqdata = [
            'p1_mchtid' => $this->partnerID,
            'p2_paytype' => $this->payType,
            'p3_paymoney' => $this->money,
            'p4_orderno' => $this->orderID,
            'p5_callbackurl' => $this->notifyUrl,//回调地址
            'p6_notifyurl' => $this->notifyUrl,//同步地址
            'p7_version' => 'v2.9',
            'p8_signtype' => 2,//签名加密方式（2.RSA）
            'p9_attach' => 'GOODS',
            'p10_appname' => '',
            'p11_isshow' => 0,////是否显示收银台
            'p12_orderip' => $this->clientIp,
            'p13_memberid' => strlen($this->uid) < 5 ? 'userid' . $this->uid : $this->uid
        ];

        $signKey = $this->data['token'];
        $reqdata['sign'] = $this->getSign($reqdata, $signKey);
        $dataJson = json_encode($reqdata);
        $rsaStr = $this->encryptPublic($this->_getPublicKey(), $dataJson);
        $this->parameter['reqdata'] = urlencode($rsaStr);


        //需平台商自己包装响应字段“r6_qrcode”的值生成二维码
        if ($this->payType == "FALIPAY" || $this->payType == "FWECHAT") {
            $this->basePost();
            $this->parseRE();
        } else {
            //使用表单提交的方式
            foreach ($this->parameter as &$item) {
                $item = urlencode($item);
            }
            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . urlencode($this->payUrl);
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        }
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['rspCode'] == 1 && isset($re['data'])) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $url = sprintf('http://qr.liantu.com/api.php?text=%s', urlencode($re['data']['r6_qrcode']));
            $this->return['str'] = $url;
        } else {
            $this->return['code'] = $re['rspCode'] > 0 ? $re['rspCode'] : 23;
            $this->return['msg'] = '诚意付：' . $re['rspMsg'] ?? '请求失败';
            $this->return['way'] = $this->data['return_type'];
        }
    }

    /**
     * 公钥加密
     */
    public function encryptPublic($publicKey, $data)
    {
        $encryptData = '';
        $crypto = '';
        foreach (str_split($data, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $publicKey);
            $crypto = $crypto . $encryptData;
        }
        openssl_free_key($publicKey);
        $crypto = base64_encode($crypto);
        return $crypto;
    }

    public function getSign($pieces, $api_key)
    {
        $signStr = '';
        foreach ($pieces as $x => $x_value) {
            if ($signStr == "") {
                $signStr = $signStr . $x . '=' . $x_value;
            } else {
                $signStr = $signStr . '&' . $x . '=' . $x_value;
            }
        }
        $string = $signStr . $api_key;
        $sign = md5($string);
        return $sign;
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res['order_number'] = $data['ordernumber'];
        //待解密字符串
        $reqdata = $data['reqdata'];
        if (!isset($reqdata)) {
            $res['status'] = 0;
            $res['error'] = '非完整内容，验签驳回';
            return $res;
        }

        //判断字符串是否需要 urldecode解码
        if (strpos($reqdata, '%')) {
            //urldecode解码
            $reqdata = urldecode($reqdata);
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        //获取私钥
        $private_key = $this->_getPrivateKey($config['key']);

        if ($private_key == false) {
            $res['status'] = 0;
            $res['error'] = '读取私钥失败';
            return $res;
        }

        //解密
        $dataJson = $this->decryptPrivate($private_key, $reqdata);
        if (!$dataJson) {
            $res['status'] = 0;
            $res['error'] = '私钥解密数据失败';
            return $res;
        }

        $data = json_decode($dataJson, true);

        if ($data['orderstatus'] != 1) {
            $res['status'] = 0;
            $res['error'] = '订单支付失败';
            return $res;
        }

        $res = [
            'status' => 0,
            'order_number' => $data['ordernumber'],
            'third_order' => $data['sysnumber'],
            'third_money' => $data['paymoney'],
        ];

        if (!$this->_verifySign($data, $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }

    /**
     * 私钥解密
     */
    public function decryptPrivate($privateKey, $data)
    {
        $data = base64_decode($data);
        $encryptData = '';
        $crypto = '';
        foreach (str_split($data, 128) as $chunk) {
            openssl_private_decrypt($chunk, $encryptData, $privateKey);
            $crypto .= $encryptData;
        }
        openssl_free_key($privateKey);
        return $crypto;
    }

    private function _verifySign($data, $config)
    {
        $returnSign = $data['sign'];
        unset($data['sign']);
        unset($data["sysnumber"]);
        unset($data["attach"]);
        //token配置的是签名密钥,key是privateKey
        $sign = $this->getSign($data, $config['token']);
        return $sign == $returnSign;
    }

}