<?php
/**
 * 金蚂蚁支付
 * Created by Hans.
 * Date: 2019/6/1
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JMYZF extends BASES
{

    public function start()
    {
        $this->initParams();
        $this->get();
        $this->parseRE();
    }

    private function initParams()
    {
        $pub_params = [
            'platform_code' => (string)$this->partnerID,
            'body' => (string)$this->orderID,//充值描述
            'nonce_str' => md5(uniqid(microtime(true), true)),//32位随机唯一字符串
            'out_trade_no' => (string)$this->orderID, //随机字符串
            'spbill_create_ip' => $this->clientIp,
            'trade_type' => $this->payType,// 'zfb' : 'wx'
            'total_fee' => $this->money,
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;

        $this->sort = false;
    }

    /**
     * 异步返回，使用go.php自动跳转
     */
    private function parseRE()
    {
        $re = json_decode($this->re, true);

        if ($re['return_code'] != 'SUCCESS') {
            //响应结果
            $this->return['code'] = 1;
            $this->return['msg'] = '金蚂蚁支付:'.($re['return_msg'] ?? 'UnKnow');
            $this->return['way'] = $this->showType;
        } else {
            //响应结果
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['code_url'];
        }
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();

        unset($parameters['s']);

        $res = [
            'status' => 1,
            'order_number' => $parameters['out_trade_no'],
            'third_money' => $parameters['total_fee'],
        ];

        if ($parameters['result_code'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }
        $order_number = $parameters['out_trade_no'];
        $return_money = $parameters['total_fee'];
        $this->updateMoney($order_number, $return_money);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . '&key=' . $tkey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }

    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }

}