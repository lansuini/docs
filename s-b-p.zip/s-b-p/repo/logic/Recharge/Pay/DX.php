<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 大象支付
 * @author lavenkin
 */
class DX extends BASES
{
	/**
	 * 生命周期
	 */
	public function start() 
	{
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
    	$this->parameter = [
    		'return_type' => 'json',
            'api_code' => $this->partnerID,
            'is_type' => $this->data['bank_data'],
            'price' => sprintf("%.2f",$this->money),
    		'order_id' => $this->orderID,
    		'return_url' => $this->returnUrl,
    		'notify_url' => $this->notifyUrl,
            'mark'=>'GOODS',
    		'time' => time(),
        ];

        $this->parameter['sign'] = $this->getSign($this->parameter,$this->key);
    }

    public function getSign($pieces,$api_key){
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key=>$val)
        {
            $string = $string.$key.'='.$val.'&';
        }
        $string = $string.'key='.$api_key;
        $sign = strtoupper(md5($string));
        return $sign;
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if ($re['messages']['returncode'] == 'SUCCESS') {
            $this->return['code'] = 0;
            $this->return['msg'] = $re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['payurl'];

        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = '大象支付：' . $re['messages']['returnmsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = null;
        }
    }

    public function returnVerify($data)
    {
    	$res = [
            'status' => 1,
            'order_number' => $data['order_id'],
            'third_order' => $data['paysapi_id'],
            'third_money' => $data['real_price'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['order_id']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (! $this->_verifySign($data,$data['sign'], $config)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    private function _verifySign($data,$signOld, $config)
    {
        unset($data['sign']);
        unset($data['messages']);
    	$sign = $this->getSign($data,$config['key']);

    	return $sign == $signOld;
    }


}