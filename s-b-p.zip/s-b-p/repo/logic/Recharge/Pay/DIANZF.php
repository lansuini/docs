<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Requests;
/**
 * 威富通
 * @author viva
 */
class DIANZF extends BASES {

    //与第三方交互
    public function start(){
        $this->initParam();
        $this->parseRE();
    }
    //组装数组
    public function initParam(){
        $this->parameter = array(
            //基本参数
            'mch_id' => $this->partnerID,//必填项，商户号
            'notify_url' => $this->notifyUrl,
            'out_trade_no' => $this->orderID,
            'body' => 'goods-',
            'total_fee' => $this->money*100,
            'mch_create_ip' => $this->data['client_ip'],  //订单生成的机器 IP
            'nonce_str' => mt_rand(time(),time()+rand()), //随机字符串，不长于 32 位
        );
        $this->parameter['sign'] = $this->verifyData($this->parameter,$this->key);
        $this->parameter = $this->toXml($this->parameter);
        $this->payUrl = $this->payUrl . '?' . 'token=' . $this->getAccessToken();
        $this->xml_post();
    }

    private function xml_post()
    {
        $header[] = "Content-type: text/xml";
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $this->payUrl);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->parameter);
        $return_xml = curl_exec($ch);
        $this->re = $this->xmlToArray($return_xml);
        curl_close($ch);
    }

    /**
     * 获取token
     */
    public function getAccessToken()
    {
        $url = 'http://qm.xmqnf.cn:8081/api/auth/access-token';
        $params = [
            'appid' => $this->partnerID,
            'secretid' => $this->key,
        ];
        $query = http_build_query($params);
        $url = $url . '?' . $query;
        $result = Requests::get($url);
        $result = $this->parseXML($result->body);
        return $result['token'];
    }

    public function parseRE(){
        $re = $this->re;
        if($re['status'] == 0 && $re['result_code'] == 0){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            if ($this->payType == "ALIPAYH5"){
                $this->return['str'] = $re['code_url'];
            }else{
                $this->return['str'] = $this->qrcodeUrl . $re['code_url'];
            }
        }else{
            $msg = $re['err_msg'] ?? $re['err_msg'];
            $this->return['code'] = 886;
            $this->return['msg'] = 'WFT:'.$msg;
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }


    public function xmlToArray($xml) {
        //将XML转为array
        $array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $array_data;
    }
    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    //[status=1 通过  0不通过,
    //order_number = '订单',
    //'third_order'=第三方订单,
    //'third_money'='金额',
    //'error'='未有该订单/订单未支付/未有该订单']
    public function returnVerify($parameters) {
        $res = [
            'status' => 0,
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['transaction_id'],
            'third_money' => $parameters['total_fee']/100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        if($parameters['status'] != 0 || $parameters['result_code'] != 0){
            $res['error'] = '支付失败';
            return $res;
        }

        if($parameters['sign'] != $this->verifyData($parameters, $config['key'])){
            $res['error'] = '该订单验签不通过';
            return $res;
        }

        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    public function verifyData($parameters,$key) {
        $signPars = "";
        ksort($parameters);
        foreach($parameters as $k => $v) {
            if("sign" != $k && "" != $v) {
                $signPars .= $k . "=" . $v . "&";
            }
        }
        $signPars .= "key=" . $key;
        $sign = strtoupper(md5($signPars));
        return $sign;

    }
}
