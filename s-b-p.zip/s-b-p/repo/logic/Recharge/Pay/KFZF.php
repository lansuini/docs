<?php
/**
 * 快付支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class KFZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {

        $this->parameter = [
            //异步返回结果地址
            'notify_url' => $this->notifyUrl,
            'out_order_no' => $this->orderID,
            'partner' => $this->data['app_id'],
            'return_url' => $this->returnUrl,
            'subject' => 'GOODS',
            'total_fee' => $this->money,
            'user_seller' => $this->partnerID,
        ];

        //秘钥存入 token字段中
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['pay_type'] = $this->payType;
        $this->parameter['http_referer'] = $_SERVER['HTTP_HOST'];
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($key != 'sign' && $val != null) {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);

        $sign_str = $params . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {

        foreach ($this->parameter as &$item) {
            $item = urlencode($item);
        }

        $this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($result)
    {
        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $result['out_order_no'],
            'third_order' => $result['trade_no'],
            'third_money' => $result['total_fee'],  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        if ($result['trade_status'] != 'TRADE_SUCCESS') {
            $res['error'] = '支付失败';
            return $res;
        }

        $tmp = [
            'out_order_no' => $result['out_order_no'],
            'total_fee' => $result['total_fee'],
            'trade_status' => $result['trade_status'],
            'pid' => $config['app_id'],
            'key' => $config['key'],
        ];

        if ($result['sign'] != md5(implode('', $tmp))) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}