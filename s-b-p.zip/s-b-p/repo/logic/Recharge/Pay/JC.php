<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 第三方支付 - 集创支付
 */
class JC extends BASES
{

    public function start()
    {
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'tradeno' => $this->orderID,
            'tradename'=>'GOODS',
            'amount' => $this->money*100,
            'partner' => $this->partnerID,
            'paytype' => $this->data['bank_data'],
            'inttime' => time(),
            'paynotifyurl' => $this->notifyUrl
        ];

        $this->parameter['signinfo'] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 组装前端数据
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if($re['retcode'] == '1'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['payurl'];
        }else{
            $this->return['code'] = 886;
            $this->return['msg'] = 'JC:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
        $res = [
            'status' => 1,
            'order_number' => $data['tradeno'],
            'third_order' => $data['outtradeno'],
            'third_money' => $data['amount']/100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($data['tradeno']);
        //无此订单
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }

        //校验sign
        $sign = $data['signinfo'];
        unset($data['signinfo']);
        if (!$this->_verifySign($data, $config['key'], $sign)) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $key)
    {
        $string = '';
        foreach ($params as $keyVal => $param) {
            $string .= $keyVal . '=' . $param . '&';
        }
        $string .= 'key=' . $key;
        $sign = strtolower(md5($string));
        return $sign;
    }

    /**
     * 验证sign
     */
    private function _verifySign($pieces, $key, $thirdSign)
    {

        $sign = $this->_sign($pieces, $key);

        return $thirdSign == $sign;
    }
}