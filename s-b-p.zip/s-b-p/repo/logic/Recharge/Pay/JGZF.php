<?php
/**
 * 坚果支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JGZF extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->payJson2();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {

        $this->parameter = array(
            'merchantCode' => $this->partnerID,
            'interfaceVersion' => '1.0',
            'serviceType' => $this->payType,
            'notifyUrl' => $this->notifyUrl,
            'orderId' => $this->orderID,
            'amount' => number_format($this->money, 2, '.', ''),
        );
        $this->parameter["sign"] = $this->_sign($this->parameter, $this->key);
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($key != 'sign') {
                $string[] = $key . '=' . $val;
            }
        }
        $params = join('&', $string);

        $sign_str = $params . '&' . 'key=' . $tkey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }


    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['status']) && $re['status'] == 'SUCCESS') {
            $this->return['code'] = 0;//code为空代表是OK
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['payUrl'];
        } else {
            $this->return['code'] = $re['status'];
            $this->return['msg'] = 'JGZF:' . $re['message'];
            $this->return['way'] = $this->showType;;
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {

        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['orderId'],//商户订单号
            'third_order' => $data['sysOrderId'],//平台流水号
            'third_money' => $data['amount'],//支付金额，以分为单位
            'error' => '',
        ];

        if ($data['status'] != 'SUCCESS') {//00:支付成功/01:失败
            $res['error'] = '付款失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($data['sign'] != $this->_sign($data, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

}
