<?php
/**
 * GO支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2018/12/31
 * Time: 9:03
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;

class GOPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->_httpUrl();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $parameter = [
            'out_trade_no' => (string)$this->orderID,
            'amount' => (int)$this->money,
            'notify_url' => $this->notifyUrl,
        ];
        $this->parameter = json_encode($parameter);
        //var_dump($this->parameter);exit();
    }


    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if(!isset($re['code']) && empty($re['errors'])){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            if ($this->data['return_type'] == 'code') {
                $this->return['str'] = $this->data['url_qr_domain'] . '/qrcoder?code=' . Utils::imgUpload($re['uri'])['img_name'] . '&pay_type=' . $this->data['scene']. '&amount=' . $this->money;
            } else {
                $this->return['str'] = $re['uri'];
            }
        }else{
            $this->return['code'] = $re['code'];
            $this->return['msg'] = 'GOPAY:'.$re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
        /*$this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;*/
    }
    public function _httpUrl()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->payUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->parameter);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$this->key));
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        // 获得响应结果里的code
        //$headercode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        /*$arr = [
            //'res' => $result,
            'code'=>$headercode
        ];
        //解释header参数
        list($header, $body) = explode("\r\n\r\n", $result, 2);

        $headers = explode("\r\n", $header);
        $arr['content'] = $body;*/
        $this->re = $result;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['trade_no'],
            'third_money' => $parameters['amount'],
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if (strtolower($parameters['status']) != 'success'){
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }
        $res['status'] = 1;
        /*$result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }*/
        return $res;
    }
    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key=>$val)
        {
            $string = $string?$string."&".$key."=".$val:$key."=".$val;
        }
        $string = $string.'&'.$tKey;

        $sign = md5($string);
        return $sign;
    }
}