<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 乐汇
 * @author lavenkin
 */
class LEH extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = [
            'merchantID' => $this->partnerID,
            'notifyUrl' => $this->notifyUrl,
            'outTradeNo' => $this->orderID,
            'payMoney' => $this->money * 100,
            'channel' => $this->payType,
        ];
        $this->sort = false;
        $signPars = urlencode(implode('&',$this->parameter).'&'.$this->key);
        $this->parameter['sign'] = strtoupper(md5($signPars));
        $this->parameter['goodsName'] = 'GOODS'.time();
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['resultCode']) && $re['resultCode'] == 100) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['qr_code'];
        } else {
            $msg = $re['message'] ?? '第三方通道返回有误';
            $this->return['code'] = 23;
            $this->return['msg'] = 'DAX：' . $msg;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($data)
    {
        $res = [
            'status' => 0,
            'order_number' => $data['outTradeNo'],
            'third_order' => $data['tradeNo'],
            'third_money' => $data['payMoney'] / 100,
            'error' => '',
        ];

        if ($data['resultCode'] != '00') {
            $res['error'] = '渠道商返回支付失败';
            return $res;
        }

        $config = Recharge::getThirdConfig($data['outTradeNo']);
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }
        $tmp = [
            'merchantID' => $data['merchantID'],
            'tradeNo' => $data['tradeNo'],
            'outTradeNo' => $data['outTradeNo'],
            'payMoney' => $data['payMoney'],
            'payTime' => $data['payTime'],
            'status' => $data['status'],
            'key' => $config['key'],
        ];
        if (strtolower($data['sign']) != strtolower(md5(urlencode(implode('&',$tmp))))) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
