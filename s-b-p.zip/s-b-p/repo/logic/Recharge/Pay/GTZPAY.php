<?php
/**
 * GTZ支付
 * @author Taylor 2019-05-10
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class GTZPAY extends BASES
{
    protected $pay_jump;

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $pay_kinds = [
            '008'=> ['v'=>'2.0', 'n'=>'银联h5直连', 't'=>'form'],
            '014'=> ['v'=>'2.0', 'n'=>'支付宝h5直连', 't'=>'form'],
            '015'=> ['v'=>'2.0', 'n'=>'微信h5直连', 't'=>'form'],
            '016'=> ['v'=>'2.0', 'n'=>'QQh5直连', 't'=>'form'],
            '017'=> ['v'=>'2.0', 'n'=>'京东h5直连', 't'=>'form'],
            '020'=> ['v'=>'2.0', 'n'=>'微信扫码直连', 't'=>'form'],
            '021'=> ['v'=>'2.0', 'n'=>'支付宝扫码直连', 't'=>'form'],

            '001'=> ['v'=>'1.0', 'n'=>'微信wap', 't'=>'curl'],
            '002'=> ['v'=>'1.0', 'n'=>'微信扫码', 't'=>'curl'],
            '003'=> ['v'=>'1.0', 'n'=>'支付宝扫码', 't'=>'curl'],
            '004'=> ['v'=>'1.0', 'n'=>'QQ扫码', 't'=>'curl'],
            '006'=> ['v'=>'1.0', 'n'=>'支付宝wap', 't'=>'curl'],
            '009'=> ['v'=>'1.0', 'n'=>'QQwap', 't'=>'curl'],
            '012'=> ['v'=>'1.0', 'n'=>'银联扫码', 't'=>'curl'],
            '013'=> ['v'=>'1.0', 'n'=>'京东扫码', 't'=>'curl'],
            '018'=> ['v'=>'1.0', 'n'=>'银联wap', 't'=>'curl'],
        ];
        $kind = $pay_kinds[$this->payType];
        $this->pay_jump = $kind['t'];//请求方式
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'version' => $kind['v'],//版本号
            'mer_no' => (string)$this->partnerID,//商户代码
            'back_url' => $this->notifyUrl,//后台通知地址
//            'page_url' => $this->returnUrl,//前台通知地址
            'mer_order_no' => (string)$this->orderID,//商家订单号
            'gateway_type' => (string)$this->payType,//支付类型
            'currency' => '156',//交易币种
            'trade_amount' => (int)$this->money,//商品金额（精确小数点后两位）
            'order_date' => date('Y-m-d H:i:s'),//支付时间
            'client_ip' => $this->clientIp,//客户端ip
            'goods_name' => 'vip'.$this->orderID,//商品名称
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $pub_params['sign_type'] = 'MD5';//签名方式
        $this->parameter = $pub_params;
        //var_dump($this->parameter);exit();
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        $sign_str = "back_url={$pieces['back_url']}&client_ip={$pieces['client_ip']}&currency={$pieces['currency']}&gateway_type={$pieces['gateway_type']}&goods_name={$pieces['goods_name']}&mer_no={$pieces['mer_no']}&mer_order_no={$pieces['mer_order_no']}&order_date={$pieces['order_date']}&trade_amount={$pieces['trade_amount']}&version={$pieces['version']}&key={$tkey}";
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        if($this->pay_jump == 'form'){
            //使用表单提交的方式
            foreach ($this->parameter as &$item) {
                $item = urlencode($item);
            }
            $this->parameter = $this->arrayToURL();
            $this->parameter .= '&url=' . $this->payUrl;
            $this->parameter .= '&method=POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->parameter;
        }else{
            //{"version":null,"signType":null,"sign":null,"auth":null,"tradeResult":null,"errorCode":"ERRORCODE","errorMsg":"Status：errorretMsg:{\"code\":\"error\",\"msg\":\"没有可用渠道\"}","merNo":null,"merOrderNo":null,"currency":null,"oriAmount":null,"tradeAmount":null,"orderDate":null,"orderNo":null,"payInfo":null}
            //{"version":"1.0","signType":"MD5","sign":"63047a19df6b7d7175628cd8fd4a9ec7","auth":"SUCCESS","tradeResult":"1","errorCode":null,"errorMsg":null,"merNo":"100003006","merOrderNo":"1905102047558851","currency":"156","oriAmount":"300","tradeAmount":"300","orderDate":"2019-05-10 17:53:30","orderNo":"388908491","payInfo":"https://a.kinvin.cn/order/3306/5222084/1/1557482010/85932/ff3c853aef48d4d4e04aa5e215613757/0"}
            $this->basePost();
            $re = json_decode($this->re, true);
            if ($re['tradeResult'] == '1') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
                $this->return['str'] = $re['payInfo'];//支付地址
            } else {
                $this->return['code'] = 8;
                $this->return['msg'] = 'GTZPAY:' . (isset($re['errorMsg']) ? $re['errorMsg'] : '');
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }
    }


    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        $data = array_map('urldecode', $data);
        if(isset($data['s'])) unset($data['s']);
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['merOdNo'],//商户订单号
            'third_order' => $data['orderNo'],//系统订单号
            'third_money' => $data['amount'],//支付金额
            'error' => '',
        ];

        if ($data['tradeResult'] != '1') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($params, $tkey)
    {
        //验签字段
//        $s_params = [
//            "version" => $params["version"],//版本号
//            "tradeResult" =>  $params["tradeResult"], // 业务结果
//            "merNo" =>  $params["merNo"], // 商户代码
//            "merRetMsg" =>  $params["merRetMsg"], // 回传参数
//            "notifyType" => $params["notifyType"], // 通知类型
//            "merOdNo" => $params["merOdNo"], //商家订单号
//            "currency" => $params["currency"], //交易币种
//            "oriAmount" => $params["oriAmount"], //原始订单金额
//            "amount" => $params["amount"], //交易金额
//            "orderDate" => $params["orderDate"], //订单时间
//            "orderNo" => $params["orderNo"], //支付订单号
//        ];
        $s_params = $params;
        unset($s_params['signType'], $s_params['sign']);
        ksort($s_params);
        reset($s_params);
        $md5str = "";
        foreach ($s_params as $key => $val) {
            if ($val != '' && $val != null){
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $sign = md5($md5str . "key=" . $tkey);
        if ($sign != $params['sign']){
            return false;
        }
        return true;
    }
}