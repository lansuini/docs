<?php
/*
 * 新98k支付
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/11
 * Time: 15:52
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 新98k 支付
 * @package Logic\Recharge\Pay
 */
class JIUBAK extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $parameter = [
            'amount' => $this->money,
            'outOrderNum' => (string)$this->orderID,
            'mchNum' => $this->partnerID,
            'payType' => $this->payType ,
            'timestamp' => time() ,
            'notifyUrl' => $this->notifyUrl,
        ];

        $parameter['sign'] = $this->getSign($parameter);
        $this->parameter =$parameter;
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
//        {	"code":"200",  //接口请求成功返回200，失败返回0
//	"msg":"操作成功",//成功返回成功，失败返回失败原因
//	"attrData":{
//            "outOrderNum":"43489023423432",  //商户系统订单号
//		"orderNum":"KP20202093232323",//本系统订单号
//		"amount":100 	// 订单金额
//"payUrl":"http://xxx.com/pay.html"  //返回收银台链接地址
//}
//}
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 200) {
            $data=$re['attrData'];
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $content = $data['payUrl'] ?? false;
            $this->return['str'] = $content;
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = '新98k支付:' . (isset($re['msg']) ? $re['msg'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
//        echo 222;print_r($parameters);die();
        unset($parameters['s']);

        if (!isset($parameters['status']) || !isset($parameters['amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['outOrderNum'],
            'third_order' => $parameters['orderNum'] ?? '',
            'third_money' => $parameters['amount'],
        ];

        if ($parameters['status'] != 'success' ) {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        //未查询到配置数据
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        //按规则验签
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }
        $this->updateMoney($parameters['outOrderNum'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    public function returnVail($params, $tkey)
    {
        $returnSign = $params['sign'];
        unset($params['sign']);

        $verifySign = $this->getSign($params,$tkey);
        if ($returnSign != $verifySign) {
            return false;
        }
        return true;
    }


    public function getSign($data = [] ,$signKey = ''){
        if(!$data) return false;
        $string = '';
        ksort($data);
        foreach ($data as $key => $value){
            $string .= $key . '=' . $value .'&';
        }
        $sercetKey = $signKey ? $signKey : $this->key;
        $string .= 'key='. $sercetKey;
        return strtoupper(md5($string));
    }

}