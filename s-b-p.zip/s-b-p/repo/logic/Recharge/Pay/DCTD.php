<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 大成通达
 */
class DCTD extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 初始化参数
     */
    public function initParam()
    {
        $this->parameter = [
            'outTradeNo' => $this->orderID,
            'amount' => $this->money,
            'notifyUrl' => $this->notifyUrl,
            'appId' => $this->data['app_id'],
            'merchantId' => $this->partnerID,
        ];

        $this->parameter['sign'] = $this->getSign($this->parameter, $this->key);
    }

    public function parseRE()
    {
        //响应结果
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . "?" . $this->arrayToUrlByAll();
    }

    public function getSign($arr, $api_key)
    {
        $signPars = "";
        ksort($arr);
        foreach ($arr as $k => $v) {
            if ($v != null && !$v == "") {
                $signPars .= $k . "=" . $v . "&";
            }
        }
        $signPars .= $api_key;
        return md5($signPars);
    }


    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        if (!(isset($data['outTradeNo']) && isset($data['amount']))) {
            //非法数据
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $data['outTradeNo'],
            'third_money' => $data['amount'],
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        if (!$this->_verifySign($data, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        $res['error'] = '验签通过';
        return $res;
    }

    private function _verifySign($arr, $key)
    {
        $returnSign = $arr['sign'];
        unset($arr['sign']);
        $sign = $this->getSign($arr, $key);
        return $sign == $returnSign;
    }

}