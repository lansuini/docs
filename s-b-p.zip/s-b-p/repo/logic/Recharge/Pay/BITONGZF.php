<?php
/**
 * 币通支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;

class BITONGZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'mchno' => $this->partnerID,
            'timestamp' => time(),
            'username' => $this->uid,
            'order_no' => $this->orderID,
            'order_type' => '1',
            'vcoin_code' => 'USDT',
            'currency_type' => 'CNY',
            'currency_money' => $this->money,
            'pay_methods' => $this->payType,
        ];


        //秘钥存入 token字段中
        $this->parameter['signature'] = $this->_sign($this->parameter, $this->key);

    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            if ($key != 'signature') {
                $string[] = $key . $val;
            }
        }
        $params = join('', $string);

        $sign_str = $tkey . $params . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['errcode']) && $re['errcode'] == '0') {
            $this->return['code'] = 0;//code为空代表是OK
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data'];
        } else {
            $this->return['code'] = 65;  //非0代付 错误
            $this->return['msg'] = 'XGPAY:' . $re['errmsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);

        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $data['order_no'],
            'third_order' => $data['pay_order_no'],
            'third_money' => $data['pay_amount'],  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        $errMsg = '';
        if ($data['status'] != 2) {
            switch ($data['status']) {
                case 0:
                    $errMsg = '初始创建';
                    break;
                case 1:
                    $errMsg = '已付款未确认';
                    break;
                case 3:
                    $errMsg = '投诉取消';
                    break;
                case 4:
                    $errMsg = '正常取消';
                    break;
                case 5:
                    $errMsg = '申诉中';
                    break;
                case 9:
                    $errMsg = '验证失败取消';
                    break;
            }
            $res['error'] = $errMsg;
            return $res;
        }

        if ($data['signature'] != $this->_sign($data, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
