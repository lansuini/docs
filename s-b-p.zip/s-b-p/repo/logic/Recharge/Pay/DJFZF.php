<?php
/**
 *   多聚发支付
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class DJFZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        //$this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'partner' => (string)$this->partnerID,
            'type' => (string)$this->payType, //bank_data
            'value' => $this->money,
            'orderid' => (string)$this->orderID,
            'callbackurl' => $this->notifyUrl,
        ];
        $pub_params['sign'] = $this->_sign($pub_params,$this->key);
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        $res = [
            'order_number' => $parameters['orderid'],
            'third_order' => $parameters['sysorderid'],
            'third_money' => $parameters['ovalue'],
            'status'=>0,
            'error'=>''
        ];
        $config = Recharge::getThirdConfig($parameters['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['opstate'] != '0'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $params = join('&',$string);
        $sign_str = $params.$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign_data = [
            'partner' => $params['partner'],
            'orderid' => $params['orderid'],
            'opstate' => $params['opstate'],
            'ovalue' => $params['ovalue'],

        ];

        $sign = $this->_sign($sign_data,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}