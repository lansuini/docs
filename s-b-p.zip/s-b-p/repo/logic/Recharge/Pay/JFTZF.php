<?php
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 玖付通支付
 * @author lavenkin
 */
class JFTZF extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = [
            'down_num' => $this->partnerID,
            'pay_service' => $this->payType,
            'amount' => (int) $this->money * 100,
            'order_down' => $this->orderID,
            'subject' => 'gold'.time(),
            'client_ip' => $this->data['client_ip'],
            'version' => '1.0',
            'callback_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
        ];
        $this->parameter['sign'] = strtoupper($this->currentMd5('key='));
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);

        if (isset($re['pay_info']) && $re['pay_info']) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'success';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['pay_info'];
        } else {
            $this->return['code'] = 23;
            $this->return['msg'] = 'JFTZF：' . $re['rst_msg'] ?? '第三方返回有误';
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    /**
     * 返回地址验证
     *
     * @param
     * @return boolean
     */
    public function returnVerify($parameters) 
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['order_down'],
            'third_order' => $parameters['order_up'],
            'third_money' => $parameters['amount'] / 100 ?? 0,
            'error' => '',
        ];

        if ($parameters['order_status'] != '1') {
            $res['status'] = 0;
            $res['error'] = '渠道商返回支付失败';

            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['order_down']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';

            return $res;
        }
        $this->parameter['order_status'] = $parameters['order_status'];
        $this->parameter['order_down'] = $parameters['order_down'];
        $this->parameter['order_up'] = $parameters['order_up'];
        $this->parameter['amount'] = $parameters['amount'];
        $this->parameter['time'] = $parameters['time'];
        $this->key = $config['key'];
        if (strtolower($parameters['sign']) != $this->currentMd5('key=')) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';

            return $res;
        }

        return $res;
    }


}
