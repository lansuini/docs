<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 火星支付
 */

class HXZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {  
        $this->parameter = [
            "app_id"  => $this->partnerID,
            "pay_type"     => 2,
            "order_id"     => $this->orderID,
            "order_amt"      => sprintf("%.2f", $this->money),
            "notify_url"      => $this->notifyUrl,
            "return_url"      => $this->returnUrl,
            "time_stamp"     => time(),
        ];
        $this->sort = false;
        $this->key = md5($this->key);
        $this->parameter['sign'] = $this->currentMd5('key=');
        $this->parameter["goods_name"]     = 'GOD_'.time();
        $this->parameter["user_ip"]     = $this->data['client_ip'];
    }

    /**
     * 
     */
    public function parseRE()
    {   
      $re = json_decode($this->re ,true);
        if (isset($re['status_code']) && $re['status_code'] == 0) {
            $this->return['code']   = 0;
            $this->return['msg']    = 'success';
            $this->return['way']    = $this->data['return_type'];;
            $this->return['str']    = $re['pay_url'];
        }else{
            $msg = $re['status_msg'] ?? '第三方未知错误';
            $this->return['code'] =9999;
            $this->return['msg']  = 'HXZF: ' .$msg;
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
        
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($para)
    {

        $res = [
            'status' => 0,
            'order_number' => $para['order_id'],
            'third_order' => $para['pay_seq'],
            'third_money' => $para['pay_amt'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($para['order_id']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        if($para['pay_result'] !=20 ){
            $res['status'] = 0;
            $res['error'] = '订单号未支付';
            return $res;
        }
        $key = md5($config['key']);
        $str = "app_id={$para['app_id']}&order_id={$para['order_id']}&pay_seq={$para['pay_seq']}&pay_amt={$para['pay_amt']}&pay_result={$para['pay_result']}&key={$key}";
        //校验sign
        if (strtolower($para['sign']) != strtolower(md5($str))) {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }else {
            $res['status'] = 1;
        }

        return $res;
    }

}