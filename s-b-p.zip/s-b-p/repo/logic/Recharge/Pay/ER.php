<?php

/**
 * Created by PhpStorm.
 * User: 95684
 * Date: 2019/5/10
 * Time: 9:03
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class ER extends  BASES {

    protected $curlError;

    public function start(){
        $this->initParams();
        $this->dopay();
    }

    public function initParams(){

    // 签名	key	是	String(32)	把使用到的所有参数，连商户密钥一起，按参数名字母升序排序。把参数值拼接在一起。做md5-32位加密，取字符串小写。得到签名。网址类型的参数值不要urlencode
    // 说明：
    // key的拼接顺序：如用到了所有参数，就按这个顺序拼接：goods_name + pay_way + notify_url + order_id + order_uid + price + return_url + 商户密钥 + 商户号

    //把使用到的所有参数，连商户密钥(token)一起，按参数名字母升序排序，将非空参数值以key1=value1&key2=value2方式拼接在一起。做md5-32位加密，取字符串小写。得到签名。网址类型的参数值不要urlencode

        $this->parameter = [
            "uid"=>$this->partnerID,
            "price"=>$this->money,
            "pay_way"=>$this->payType,
            "notify_url"=>$this->notifyUrl,
            "return_url"=>$this->returnUrl,
            "order_id"=>$this->orderID,
            "order_uid"=>rand(1,10000),
            "goods_name"=>'团购',
            "token"=>$this->key
        ];

        $this->parameter['key'] = $this->getSign($this->parameter);

    }
    private function dopay(){


        $re = $this->request($this->payUrl,$this->parameter);
    //    if($data['code'] >= 0  && in_array($pay_way, [1,2])){//微信 支付宝
    //        $qrcode = $data['data']['pay_url'];
    //        echo "<script>
    //       jQuery(function(){
    //            jQuery('#qrcode').qrcode('$qrcode');
    //        })
    //    </script>";
    //    }else if($data['code'] >= 0  && in_array($pay_way, [3,4,5])){//微信h5 支付宝H5 网银
    //        echo $data['data']['pay_html'];
    //    }
        $this->return['code'] = 886;
        $this->return['msg'] = 'ER:网络异常';
        $this->return['way'] = $this->showType;
        $this->return['str'] = '';
    //        var_dump($this->re);
        if($re){
            if ($re["code"] == 0) {

                $this->return['code'] = 0;
                $this->return['msg'] = 'success';
                $this->return['way'] = $this->data['return_type'];
                $this->return['url'] = $re['data']['pay_url'];
                $this->return['str'] = $re['data']['pay_url'];

            } else {
                $this->return['code'] = 886;
                $this->return['msg'] = isset($re['msg']) && !empty($re['msg']) ? $re['message'] : 'ER:第三方通道未知错误';
                $this->return['way'] = $this->showType;
                $this->return['str'] = '';
                return;
            }
        }else{
            $this->return['msg'] = $this->curlError;
            $this->return['str'] = $this->curlError;
        }

    }

    public function getSign($params){

        ksort($params);
        $temp_key = '';
        foreach ($params as $key => $value) {
            $temp_key .= ($key.'='.$value.'&');
        }
        $temp_key = substr($temp_key,0,-1);
        return md5($temp_key);

    }

    private function retrunVail($data,$token){
        //        api_order_id=平台订单号&order_id=商户自定义订单号&order_uid=商户自定义客户号&price=价格&status=订单状态&token=商户密钥
        $signString = "api_order_id=".$data['api_order_id']."&order_id=".$data['order_id']."&order_uid=".$data['order_uid']."&price=".$data['price']."&status=".$data['status']."&token=".$token;
        $sign = md5($signString);
        return $data['key'] == $sign;
    }

    public function returnVerify($data)
    {
        $res = [
            'status' => 0,
            'order_number' => $data['order_id'],//商户订单号
            'third_order' => $data['api_order_id'],//第三方的支付订单号
            'third_money' => $data['price'],//支付金额为元
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($data['order_id']);
        if (!$config) {
            $res['error'] = '没有该订单';
        }
        if($data['status'] != 2){
            $res['error'] = '支付失败';
        }

        if ($this->retrunVail($data, $config['key'])) {
            $res['status'] = 1;
        } else {
            $res['error'] = '验签失败！';
        }
//        print_r($res);exit;
        return $res;
    }

    public function request($url,$params){

    // 注意：商户密钥在安全上非常重要，一定不要显示在任何网页代码、网址参数中。只可以放在服务端。计算key时，先在服务端计算好，把计算出来的key传出来。严禁在客户端计算key，严禁在客户端存储商户密钥。key值必为小写
    // $headers = array(
    // 	"Content-Type: application/x-www-form-urlencoded",
    // 	"Accept: application/json",
    // 	"Cache-Control: no-cache",
    // 	"Pragma: no-cache"
    // );

        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);

        $postdata = http_build_query($params);
    //    $postdata = "uid=".urlencode($uid)."&price=".urlencode($price)."&pay_way=".urlencode($pay_way)."&notify_url=".urlencode($notify_url)."&return_url=".urlencode($return_url)."&order_id=".urlencode($order_id)."&order_uid=".urlencode($order_uid)."&goods_name=".urlencode($goods_name)."&key=".urlencode($key);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);

    // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        if ($errno = curl_errno($ch)) {
            $this->curlError = curl_error($ch);
            curl_close($ch);
            return false;
        }
        curl_close($ch);

        $data = json_decode($data,true);
        return $data;

    }

}