<?php
/**
 * 汇盛支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HUISHENGPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {

        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $api = trim(basename($this->payUrl));//根据下单地址来获取service值
        $pub_params = [
            'service' => in_array($api, ["unifiedOrderTc", "unifiedOrder"]) ? $api : 'unifiedOrderTc',
            'inputCharset' => 'UTF-8',
            'sysMerchNo' => $this->partnerID,
            'outOrderNo' => (string)$this->orderID,
            'orderTime' => date('YmdHis', time()),
            'orderAmt' => $this->money,
            'orderTitle' => (string)$this->orderID,
            'orderDetail' => "goods",
            'selectFinaCode' => $this->payType,
            'tranAttr' => 'NATIVE',
            'backUrl' => $this->notifyUrl,
            'settleCycle' => "T0",
            'ip' => $this->clientIp,
//            'ip' => "120.204.127.43",
            'chnMerchNo' => $this->data['app_id'],
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $pub_params['signType'] = 'MD5';
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['orderStatus']) && $re['orderStatus'] == '01') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['codeUrl'];
        } else {
            $this->return['code'] = 99;
            $this->return['msg'] = '汇盛:' . (isset($re['tranDesc']) ? $re['tranDesc'] : (isset($re['retMsg']) ? $re['retMsg'] : $this->re));
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['outOrderNo']) || !isset($parameters['tranNo']) || !isset($parameters['tranAmt'])) {
            return false;
        }

        $res = [
            'order_number' => $parameters['outOrderNo'],
            'third_order' => $parameters['tranNo'],
            'third_money' => $parameters['tranAmt'],
        ];
        $config = Recharge::getThirdConfig($parameters['outOrderNo']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['tranResult'] != 'SUCCESS') {
            $res['status'] = 0;
            $res['error'] = '该订单支付状态失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }


        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/trade/api/queryPay';
        }

        $success = $this->queryOrder($url, $res['order_number'], $res['third_order'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '02') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            //盗刷问题，查单订单状态不对，直接关闭订单
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }

        $order_number = $parameters['outOrderNo'];
        $return_money = intval($parameters['tranAmt']);

        $this->updateMoney($order_number, $return_money);
        $res['status'] = 1;

        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key => $val) {
            $string[] = $key . '=' . $val;
        }
        $params = join('&', $string);
        $sign_str = $params . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        unset($params['signType']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }

    public function queryOrder($queryUrl, $orderNumber, $thirdNumber, $partnerID, $tkey)
    {
        $params = [
            "service" => "queryPay",
            "inputCharset" => "UTF-8",
            "sysMerchNo" => $partnerID,
            "outOrderNo" => $orderNumber,
            "tranNo" => $thirdNumber,
        ];

        $params['sign'] = $this->_sign($params, $tkey);
        $params['signType'] = 'MD5';

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);
        if (isset($re['orderStatus'])) {
            return $re['orderStatus'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }
}