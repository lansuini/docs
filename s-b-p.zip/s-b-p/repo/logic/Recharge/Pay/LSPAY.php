<?php
/**
 * 乐刷支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/9
 * Time: 18:53
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class LSPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'total_fee' => sprintf("%.2f", $this->money),
            'order_sn' => (string)$this->orderID,
            'return_url' => $this->returnUrl,
            'notify_url' => $this->notifyUrl,
            'goods' => (string)$this->orderID,
            'client' => 'wap',
            'client_ip' => $this->data['client_ip'],
        ];
        $params = [
            'mch_id' => (string)$this->partnerID,
            'method' => 'shop.payment.aliH5',
            'version' => '1.0',
            'timestamp' => time(),
            'content' =>json_encode($pub_params),
        ];
        //var_dump($pub_params);exit();
        $params['sign'] = $this->_sign($params,$this->key);
        foreach ($params as &$item) {
            $item = urlencode($item);
        }
        $this->parameter = $params;
        //var_dump($this->parameter);exit();
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if(isset($re['success']) && $re['success']){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = 'https://pay.dtpay.net'.$re['data']['pay_url'];
        }else{
            $this->return['code'] = $re['code'];
            $this->return['msg'] = 'LSPAY:'.$re['message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        //解码
        foreach ($parameters as $key => &$value) {
            $value = urldecode($value);
        }
        $res = [
            'order_number' => $parameters['mch_order_no'],
            'third_order' => $parameters['order_no'],
            'third_money' => $parameters['total_fee'],
        ];
        $config = Recharge::getThirdConfig($parameters['mch_order_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != 1){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        //解码
        foreach ($pieces as $key => &$value) {
            $value = urldecode($value);
        }
        unset($value);
        //如果有sign，去除sign
        if (isset($pieces['sign'])){
            unset($pieces['sign']);
        }
        ksort($pieces); //数组正序排序
        $params_str = urldecode(http_build_query($pieces)); //拼接
        $params_str =  $params_str.'&key='.$tkey; //拼接商户秘钥在最后面
        return md5($params_str);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        unset($params['s']);
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}