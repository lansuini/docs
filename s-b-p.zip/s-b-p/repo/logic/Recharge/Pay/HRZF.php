<?php
/**
 * 华容支付
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;
class HRZF extends BASES
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'parter' => $this->partnerID,
            'type' => $this->payType,
            'value' => sprintf('%0.2f', $this->money),
            'orderid' => $this->orderID,
            'callbackurl' => $this->notifyUrl,
        ];

        //秘钥存入 token字段中
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);

        $this->parameter['h5'] = '1';
        $this->parameter['attach'] = '2';

    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            if ($key != 'sign'){
                $string[] = $key.'='.$val;
            }
        }
        $params = join('&',$string);

        $sign_str = $params.$tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' .$this->arrayToURL();;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {

        global $app;
        $data = $app->getContainer()->request->getParams();
        unset($data['s']);
        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $data['orderid'],
            'third_order' => $data['sysorderid'],
            'third_money' =>$data['ovalue'],  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);

        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        if ($data['opstate'] != 0){
            $res['error'] = '未支付';
            return $res;
        }

        $signData = [
            'orderid' => $data['orderid'],
            'opstate' => $data['opstate'] ,
            'ovalue' => $data['ovalue'],
        ];

        if ($data['sign'] != $this->_sign($signData, $config['key'])) {
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

}
