<?php
/**
 * happy支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/27
 * Time: 14:30
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HAPPYPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        //$this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'sitekey' => $this->partnerID,
            //'passageId' => (string)($this->money *100),
            'out_trade_no' => (string)$this->orderID,
            'trade_time' => date('Y-m-d H:i:s',time()),
            'total_fee' => sprintf("%.2f", $this->money),
            'notify_url' => $this->notifyUrl,
            'return_url'=>$this->returnUrl,
        ];
        $pub_params['sign'] = $this->_sign($pub_params);
        //var_dump($pub_params);exit();
        foreach ($pub_params as $key=>$val)
        {
            $pub_params[$key] = urlencode($val);
        }
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $this->parameter = $this->arrayToURL();
        //$this->parameter .= '&url=' . $this->payUrl;
        //$this->parameter .= '&method=GET_FORM';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->payUrl . '?' . $this->parameter;
        /*$re = json_decode($this->re,true);
        if (isset($re['Status']) && $re['Status']==1){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $re_data = $re['Result'];
            $this->return['str'] = $re_data['payurl'];

        }else{
            $this->return['code'] = $re['errCode'];
            $this->return['msg'] = $re['errDes'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }*/
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['trade_no'],
            'third_money' => $parameters['total_fee'],
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['out_trade_no'];
            $return_money = $parameters['total_fee'];
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces)
    {
        ksort($pieces);
        $string = [];
        foreach ($pieces as $key=>$val)
        {
            $string[] = $key.'='.$val;
        }
        $params = join('&',$string);
        $sign = md5($params);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        unset($params['s']);
        $sign = $this->_sign($params);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}