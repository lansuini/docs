<?php
/**
 * 菠萝支付
 */

namespace Logic\Recharge\Pay;


use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class BOLUOZF extends BASES
{

    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParams();
        $this->basePost();
        $this->parseRE();
    }

    private function initParams()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'app_id' => $this->partnerID,
            'mark' => 'goods',
            'notify_url' => $this->notifyUrl,
            'order_id' => $this->orderID,
            'price' => $this->money,
            'time' => time()
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);
        $this->parameter['pay_method'] = $this->payType;

    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }


    private function parseRE()
    {
        $data = json_decode($this->re, true);
        if ($data['Status'] == '1') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $data['Result']['payurl'];

        } else {
            $this->return['code'] = 888;
            $this->return['msg'] = $data['Message'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        $parameters = json_decode($parameters['return_type'], true);

        if (!isset($parameters['order_id']) || !isset($parameters['price'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['order_id'],
            'third_order' => $parameters['order_id'],
            'third_money' => $parameters['price'],
        ];

        if ($parameters['msg'] != '支付成功') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';

            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        $signArray = [
            'api_id' => $parameters['api_id'],
            'mark' => $parameters['mark'],
            'msg' => $parameters['msg'],
            'order_id' => $parameters['order_id'],
            'pay_time' => $parameters['pay_time'],
            'price' => $parameters['price'],
        ];

        if ($parameters['sign'] != $this->_sign($signArray, $config['key'])) {
            $res['status'] = 0;
            $res['error'] = '验签失败!';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        $signString = '';
        foreach ($pieces as $key => $value) {
            if ($key != "sign" && $key != "" && $value != "") {
                $signString .= "$key=$value&";
            }
        }
        $signString .= 'key=' . $tkey;
        $sign = md5(strtoupper($signString));
        return $sign;
    }
}