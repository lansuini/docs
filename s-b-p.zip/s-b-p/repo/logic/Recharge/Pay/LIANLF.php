<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;


/**
 * 连连付
 * @author zhangli
 */
class LIANLF extends BASES
{

    //与第三方交互
    public function start()
    {

        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        $this->parameter = array(
            'app_id' => $this->partnerID,
            'shop_order_no' => $this->orderID,
            'pay_code' => $this->data['bank_data'],
            'format' => 1,
            'price' => sprintf('%.2f', $this->money),
            'notify_url' => $this->notifyUrl,
            'return_url' => $this->returnUrl
        );
        $this->parameter['sign'] = $this->sytMd5($this->parameter, $this->key);
    }


    public function sytMd5($piecess, $key)
    {
        ksort($piecess);
        $string = '';
        foreach ($piecess as $k => $v) {
            if ($v != '' || $v != null|| !empty($v)) {
                $string .= $k . "=" . $v . "&";
            }
        }
        $string = $string . 'app_key=' . $key;
        $sign = strtolower(md5($string));
        return $sign;
    }

    public function parseRE()
    {

        $re = json_decode($this->re, true);
        if (isset($re['res_code']) && $re['res_code'] == true) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['url'];
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = '连连付:' . $re['res_msg'] ?? $this->re;
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }


    }

    /**
     * 回调验签
     * @param $input
     * @return array
     */
    public function returnVerify($input)
    {
        $res = [
            'status' => 1,
            'order_number' => $input['shop_order_no'],
            'third_order' => $input['order_no'],
            'third_money' => $input['real_price'],
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($input['shop_order_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }

        $sign = $input['sign'];
        unset($input['sign']);
        $newSign = $this->getVerify($input, $config['key']);
        if ($newSign != $sign) {
            $res['status'] = 0;
            $res['error'] = '签名验证失败';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function getVerify($respData, $key)
    {
        if (isset($respData['s'])) {
            unset($respData['s']);
        }
        $signStr = $this->sytMd5($respData, $key);
        return $signStr;
    }

}
