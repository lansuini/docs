<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

header("Content-type:text/html;charset=utf-8");
/**
 * 银牛恆潤
 */

class HR extends BASES 
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->post();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {  
        $this->parameter = [
            'appID'             =>$this->partnerID,
            "tradeCode"         =>$this->payType,
            "randomNo"          => (string) rand(1000,9999),
            "outTradeNo"        => $this->orderID,
            "totalAmount"       => $this->money*100,
            "productTitle"      => "goods",
            "notifyUrl"         =>$this->notifyUrl,
            "tradeIP"           =>$this->data['client_ip'],
        ];
        ksort($this->parameter); 
        $data = implode("|", $this->parameter); 
        $sign = md5($data . '|' . $this->key); 
        $this->parameter['sign'] = strtouPPer($sign); 
        $this->parameter = 'ApplyParams='.json_encode($this->parameter); 
        //var_dump($this->parameter);
    }

    /**
     * 
     */
    public function parseRE()
    {          
        $result = json_decode($this->re, true);
        if ($result['stateCode']=="0000") {
            $this->return['code']   = 0;
            $this->return['msg']    = 'success';
            $this->return['way']    = $this->data['return_type'];;
            $this->return['str']    = $result['payURL'];
        }else{
            $this->return['code'] = $result['stateCode'];
            $this->return['msg']  = 'HR: ' . $result['stateInfo'];
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'status' => 1,
            'order_number' => $parameters['outTradeNo'],
            'third_order' => $parameters['outTradeNo'],
            'third_money' => $parameters['totalAmount']/100,
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($parameters['outTradeNo']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign

        if (!$this->sign_check($parameters,$config['key'])) {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }

        // var_dump($res);exit;
        return $res;
    }


 
    /* 
    验证签名： 
    返回：签名结果，true为验签成功，false为验签失败 
    */  
    function sign_check($responseData,$md5Key){

        $re_sign = $responseData['sign']; #返回签名
        $arr = array();
        foreach ($responseData as $key=>$v){
            if ($key !== 'sign'){ #删除签名
                $arr[$key] = $v;
            }
        }
        ksort($arr);
        $data_check = implode("|", $arr);
        $sign_check = strtouPPer(md5($data_check . '|' . $md5Key)); #签名数据   md5(value1|value2|value3|....|md5Key)转大写
        if ($sign_check == $re_sign){
            return true;
        }else{
            return false;
        }
    }


}