<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 银牛好利宝宝支付
 */

class HLB extends BASES 
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {  
        date_default_timezone_set('PRC'); 
        $this->parameter = [
            "inputCharset"  =>'utf-8',
            "notifyUrl"     =>$this->notifyUrl,
            "payType"       =>$this->payType,
            //"bankCode"      =>($this->payType==1)  ? "CMB" :"",
            "merchantId"    => $this->partnerID, 
            "transAmt"      => sprintf("%.2f", $this->money),
            "orderId"       => $this->orderID,
            "orderTime"     => date('Y-m-d H:m:s'),
            "isPhone"       =>1,
        ];
        $this->parameter['sign'] = $this->_sign($this->parameter,$this->key);
    }

    /**
     * 
     */
    public function parseRE()
    {   
        //$result = json_decode($this->re, true);
        $response = $this->re;
        preg_match("/action=\"([^>]+?)\"[^>]*?/", $response, $content);
        //var_dump($content);exit;
        preg_match("/action=\"([^>]+?)\"[^>]*?/", $response, $content[0]);
        $str = str_replace("action=\"","",$content[0]);
        $url = str_replace("\"","",$content[1]);
        if ($url) {
            $this->return['code']   = 0;
            $this->return['msg']    = 'success';
            $this->return['way']    = $this->data['return_type'];;
            $this->return['str']    = $url;
        }else{
            $this->return['code'] =9999;
            $this->return['msg']  = 'HLB: ' . "支付失败";
            $this->return['way'] = '';
            $this->return['str'] = '';
        }
        
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        // $res = [
        //     'merchantId'    => $parameters['merchantId'],
        //     'sign'          => $parameters['sign'],
        //     'orderId'       => $parameters['orderId'],
        //     'transAmt'      => $parameters['transAmt'],
        //     'orderTime'     => $parameters['orderTime'],
        //     'status'        => $parameters['payDatetime'],
        //     'transId'       => $parameters['transId'],      

        // ];
        //var_dump($parameters);exit;
        // var_dump($parameters);exit;/
        $res = [
            'status' => 1,
            'order_number' => $parameters['transId'],
            'third_order' => $parameters['orderId'],
            'third_money' => $parameters['transAmt'],
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($parameters['transId']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign

        if ($this->verity($parameters,$config['key']) != $parameters['sign']) {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
            return $res;
        }

        // var_dump($res);exit;
        return $res;
    }

    private function _sign($data,$key) {
        ksort($data);
        $string = '';
        if(is_array($data)){
            foreach ($data as $k => $v){
                if ($v != '' && $v != null && $k != 'sign'){
                    $string = $string . $k . '=' . $v . '&';
                }
            }
        }
        $string = substr($string, 0, strlen($string) - 1);
        $string = $string.'&key='.$key;
        $sign   = md5($string);
        return $sign;
    }
 
    /* 
    验证签名： 
    返回：签名结果，true为验签成功，false为验签失败 
    */  
    function verity($data, $key)  
    {  
        unset($data['sign']);
        ksort($data);
        // var_dump($data);exit;
        $string = '';
        if(is_array($data)){
            foreach ($data as $k => $v){
                if ($v != '' && $v != 'null' && $k != 'sign' && $k != 's' ){
                    $string = $string . $k . '=' . $v . '&';
                }
            }
        }
        // $string   = substr($string, 0, strlen($string) - 1);
        $string = $string.'key='.$key;
        // var_dump($string);exit;
        $result   = md5($string);
        // var_dump($result);exit;
        return $result;  
    } 


}