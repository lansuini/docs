<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 菠萝pay
 * @author lavenkin
 */
class BOLUOPAY extends BASES
{

    //与第三方交互
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //组装数组
    public function initParam()
    {
        /**
         * 1:支付宝H5
         *
         * 2:微信H5
         *
         * 3:支付宝扫码
         *
         * 4:微信扫码
         *
         * 5:银联快捷
         *
         * 6:银联扫码
         *
         * 7:三方聚合扫码
         *
         * 8:微信话费H5
         *
         * 9:支付宝话费H5
         *
         * 10:支付宝企业H5
         *
         * 11:支付宝企业码
         *
         * 12:微信PDD固额
         *
         * 13:支付宝PDD固额
         */
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $this->parameter = [
            'version' => '1.0',
            'merchant_no' => $this->partnerID,
            'sign_type' => 'MD5',
            'trade_amount' => (int)$this->money * 100,
            'subject' => 'Golds',
            'pay_type' => $this->payType,
            'notify_url' => $this->notifyUrl,
            'out_trade_no' => $this->orderID,
        ];

        $this->parameter['sign'] = $this->_sign($this->parameter, $this->key);

    }

    private function getRequestMoney($money)
    {
        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 200) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['data'];
        } else {
            $re['message'] = isset($re['msg']) ? $re['msg'] : '第三方未知错误';
            $this->return['code'] = 886;
            $this->return['msg'] = 'BOLUOPAY:' . $re['message'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $signString = '';
        foreach ($pieces as $key => $value) {
            if ($key != "sign" && $key != "" && $value != "") {
                $signString .= "$key=$value&";
            }
        }
        $signString .= 'key=' . $tkey;
        $sign = strtoupper(md5($signString));
        return $sign;
    }

    /**
     * 返回地址验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['out_trade_no']) || !isset($parameters['trade_amount'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['out_trade_no'],
            'third_money' => $parameters['trade_amount'] / 100,
        ];

        if ($parameters['pay_status'] != '1') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);

        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '支付失败';
            return $res;
        }

        if (!$this->returnVail($parameters, $config['key'])) {
            $res['error'] = '签名验证失败';
            $res['status'] = 0;
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 验证sign
     */
    private function returnVail($param, $key)
    {
        $signstr = $param['sign'];
        unset($param['sign']);

        $sign = $this->_sign($param, $key);
        return $sign == $signstr;
    }

}
