<?php
/**
 * 蜂鸟支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
class FNZF extends BASES
{

    private $content;

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
    }


    /**
     * 提交参数组装
     */
    public function initParam()
    {

        $this->parameter = [
            'partner' => $this->partnerID,
            'input_charset' => "utf-8",
            'sign_type' => "SHA1WITHRSA",
            'request_time' => date('ymdhis', time()),

        ];

        $this->content = [
            'out_trade_no' => $this->orderID,
            'amount' => $this->money,
            'pay_type' => $this->payType,
            'subject' => "GOODS",
            'sub_body' => "PAY",
            'notify_url' => $this->notifyUrl,
        ];

        //秘钥存入 token字段中

        $this->parameter['content'] = $this->encodeRSA();

        $this->parameter['sign'] = $this->rsaSHA1Sign($this->key);

        $this->re = $this->callurl($this->payUrl,$this->parameter);

        $this->parseRE();

    }

    /**
     * 组装前端数据,输出结果
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        if ($re['is_succ'] == "T") {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $payurl = $this->decrypt($re['response'],$this->key);
            $this->return['str'] = $payurl;
        } else {
            $this->return['code'] = $re['fault_code'];
            $this->return['msg'] = $re['fault_reason'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['fault_reason'];
        }
    }

    private function callurl($url, $data)
    {
        $ch = curl_init();  //启动一个CURL会话
        curl_setopt($ch, CURLOPT_TIMEOUT, 120); //设置curl允许执行的最长秒数
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, 1);  //发送一个常规的POST请求
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url); //要传送的URL地址
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);    //要传送的所有数据
        $res = curl_exec($ch);  //执行操作

        curl_close($ch);
        return $res;
    }

    private function encodeRSA()
    {
        ksort($this->content);
        $content = '';
        foreach ($this->content as $k => $v) {
            if ("" != $v) {   //空值参数不参与加密
                $content .= $k . "=" . $v . "&";
            }
        }
        $content = substr($content, 0, -1);
        $public_key = openssl_get_publickey($this->buildPublicKey($this->pubKey));

        $encrypt_data = '';
        $crypto = '';

        foreach (str_split($content, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encrypt_data, $public_key);
            $crypto = $crypto . $encrypt_data;
        }
        $crypto = base64_encode($crypto);

        return $crypto;

    }

    /**
     * 签名  生成签名串  基于sha1withRSA
     */
    public  function rsaSHA1Sign($privateKey) {
        $signPars = "";
        $signedStr = "";
        ksort($this->content);
        foreach ($this->content as $k => $v) {
            if ("" != $v) {   //空值参数不参与加密
                $signPars .= $k . "=" . $v . "&";
            }
        }
        $signPars = substr($signPars, 0, -1);
        openssl_sign($signPars,$signedStr , openssl_get_privatekey($this->buildPrivateKey($this->key)));
        $encrypted = base64_encode($signedStr);
        return $encrypted;
    }


    //私钥解密
    public function decrypt($data,$key, $code = 'base64', $padding = OPENSSL_PKCS1_PADDING, $rev = false)
    {
//        $data = base64_decode($data);
//        $rsa = new RSA();
//        $rsa->loadKey($this->buildPrivateKey($key));    //商户私钥
//        $rsa->setEncryptionMode(RSA::ENCRYPTION_PKCS1);
//        $plaintext = $rsa->decrypt($data);
//        var_dump($plaintext);exit;
        $ret = '';
        $decryptedTemp = '';
        $data = base64_decode($data);
        if ($data !== false) {
            $key  = $this->buildPrivateKey($key);
            $enArray = str_split($data, 128);
            foreach ($enArray as $va) {
                openssl_private_decrypt($va,$decryptedTemp,openssl_get_privatekey($key));//私钥解密
                $ret .= $decryptedTemp;
            }
        }else
        {
            return false;
        }
        if($ret) $ret = substr($ret,7);
        return $ret;
    }


    //私钥解密
    public function decryptCommon($data,$key, $code = 'base64', $padding = OPENSSL_PKCS1_PADDING, $rev = false)
    {
        $ret = '';
        $data = base64_decode($data);
        if ($data !== false) {
            $key  = $this->buildPrivateKey($key);
            $enArray = str_split($data, 256);
            foreach ($enArray as $va) {
                openssl_private_decrypt($va,$decryptedTemp,$key);//私钥解密
                $ret .= $decryptedTemp;
            }
        }else
        {
            return false;
        }

        return $ret;
    }

    private function urlStringToArray($data){
        $reslut = [];
        foreach(explode('&',$data) as $v){

            $val = explode('=',$v);
            $reslut[$val[0]] = $val[1];
        }
        return $reslut;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($result)
    {
        global $app;
        $result = $app->getContainer()->request->getParams();
        unset($result['s']);
        $res = [
            'status' => 0, //为０表示 各种原因导致该订单不能上分（）
            'order_number' => $result['out_trade_no'],
            'third_order' => $result['out_trade_no'],
            'third_money' => 0,  //必须为元
            'error' => '',
        ];

        $config = Recharge::getThirdConfig($res['order_number']);
        //无此订单
        if (!$config) {
            $res['error'] = '订单号不存在';
            return $res;
        }

        $resStr = $this->decryptCommon($result['response'], $config['key']);
        $resData = $this->urlStringToArray($resStr);

        if ($resData['pay_status'] != 1){
            $res['error'] = '付款失败';
            return $res;
        }

        $res['third_money'] = $resData['money'];
        $this->updateMoney($res['order_number'],$res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    protected function buildPublicKey($key) {
        return "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($key, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";
    }

    protected function buildPrivateKey($key) {
        return "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
    }

}