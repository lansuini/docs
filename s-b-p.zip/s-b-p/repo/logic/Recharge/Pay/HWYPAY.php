<?php
/**
 * 汇旺云支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class HWYPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $request_money = $this->getRequestMoney($this->money, $this->payType);
        $this->money = $request_money;
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    private function getRequestMoney($money, $type)
    {
        if ($type != "alipay_h5") {
            return $money;
        }
        if ($money < 300) {
            //type 1 小额支付宝H5话费
            return $money;
        }
        //支付宝H5大额 PDD通道
        //对应第三方请求的金额
        $money_source = explode(',', $this->data['moneys']);
        $money_real = explode(',', $this->data['app_site']);
        $index = array_search($money*100,$money_source);

        return $money_real[$index];
    }


    /**
     * 提交参数组装
     */
    public function initParam()
    {

        $pub_params = [
            'mercId' => $this->partnerID,
            'mercOrderId' => $this->orderID,
            'amount' => $this->money,
            'notifyUrl' => $this->notifyUrl,
            'productName' => $this->orderID,
            'channel' => (string)$this->payType,
            'time' => time(),
        ];
        $pub_params['sign'] = $this->_sign($pub_params, $this->key);
        $this->parameter = $pub_params;

    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);

        if (isset($re['code']) && $re['code'] == '0') {
            $this->return['code'] = 0;//code为空代表是OK
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = $re['data']['qrCode'];
        } else {
            $this->return['code'] = 65;  //非0代付 错误
            $this->return['msg'] = '汇旺云支付:' . $re['msg'] ?? '请求超时';
            $this->return['way'] = $this->data['return_type'];
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        $res = [
            'order_number' => $parameters['mercOrderId'],
            'third_order' => $parameters['orderId'],
            'third_money' => $parameters['txnAmt'],
            'status' => 0,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($parameters['mercOrderId']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['orderStatus'] != 'paid') {
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces, $tkey)
    {
        ksort($pieces);
        $params = http_build_query($pieces);

        $sign_str = $params . $tkey;
        $sign = md5($sign_str);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        return $return_sign == $this->_sign($params, $tkey);
    }
}