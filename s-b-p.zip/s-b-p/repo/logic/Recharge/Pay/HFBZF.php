<?php
/**
 * 海付宝: Taylor 2019-03-07
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 海付宝对接
 * Class GT
 * @package Logic\Recharge\Pay
 */
class HFBZF extends BASES
{
    private $httpCode = '';

    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = array(
            'mch_number' => $this->partnerID,//商户id
            'pay_type' => $this->data['bank_data'],//请求支付的类型
            'totle_amount' => $this->money * 100,//支付额度，分为单位
            'this_date' => time(), //订单时间，时间戳
            'order_sn' => $this->orderID,//商户订单号
            'jump_url' => $this->returnUrl,//前端通知地址
            'asyn_url' => $this->notifyUrl,//异步同步地址
            'ip_add' => $this->data['client_ip'],//客户端真实IP
        );
        $this->parameter['sign_info'] = $this->sytMd5($this->parameter, $this->key);
    }

    //生成支付签名
    public function sytMd5($data, $key)
    {
        //MD5(mch_number+order_sn+pay_type+ip_add+商户密钥)
        return md5($data['mch_number'].$data['order_sn'].$data['pay_type'].$data['ip_add'].$key);
    }


    //返回参数
    public function parseRE()
    {
        if(in_array($this->data['bank_data'], [11002, 12001])){//扫码通道get
            //{"resultCode":"9007","resultMsg":"渠道无计费通道","qrCode":"","qrUrl":""}
            //{"resultCode":"200","resultMsg":"成功","qrCode":"http://pay.longfapay.com:88/api/eBankPay?token=GA7J0RXTMDK14sdd8iOx0CTYXTkeQZ92MD3Ia4zw4hA1vIBnvytCwg%3D%3D","qrUrl":"http://pay.longfapay.com:88/api/eBankPay?token=GA7J0RXTMDK14sdd8iOx0CTYXTkeQZ92MD3Ia4zw4hA1vIBnvytCwg%3D%3D"}
            $this->get();//发起请求
            $re = json_decode($this->re, true);
            if ($re['resultCode'] == '200') {
                $this->return['code'] = 0;
                $this->return['msg'] = 'SUCCESS';
                $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
                $this->return['str'] = $re['qrCode'];//支付地址
            } else {
                $this->return['code'] = 8;
                $this->return['msg'] = 'HFBZF:' . (isset($re['resultMsg']) ? $re['resultMsg'] : '');
                $this->return['way'] = $this->data['return_type'];
                $this->return['str'] = '';
            }
        }else{
            //使用表单提交的方式
            $this->parameter['url'] = $this->payUrl;
            $this->parameter['method'] = 'POST';

            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $this->jumpURL . '?' . $this->arrayToURL();
        }
    }

    //签名验证
    public function returnVerify($pieces)
    {
        $res = [
            'status' => 1,
            'order_number' => $pieces['order_sn'],//商户订单号
            'third_order' => $pieces['platform_sn'],//第三方的支付订单号
            'third_money' => $pieces['totle_amount'] / 100,//支付金额为元
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($pieces['order_sn']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
        }
        if($pieces['status'] != 1){
            $res['status'] = 0;
            $res['error'] = '支付失败';
        }
        if (self::retrunVail($pieces, $config['key'])) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    //验签
    public function retrunVail($array, $signKey)
    {
        $sys_sign = $array['sign_info'];
        return $sys_sign == md5($array['order_sn'].$array['platform_sn'].$signKey);
    }
}