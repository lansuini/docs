<?php
/**
 * 捷豹支付
 * @author Taylor 2019-04-19
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class JIEBAOPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'mchntId'=>(string)$this->partnerID,//商户号
            'mchntOrderId' => (string)$this->orderID,//商户订单号
            'orderSubject'=> 'goods',//订单标题
            'orderDesc'=> 'vip'.$this->orderID,//订单描述
            'bizType' => (string)$this->payType,//业务类型，bank_data
            'txnAmt' => $this->money * 100,//交易金额（单位：分）
            'currency'=> 'CNY',//交易货币
            'notifyUrl' => $this->notifyUrl,//异步接受支付结果通知的回调地址
            'returnUrl' => $this->returnUrl,//页面跳转返回地址
            'sendIp' => $this->clientIp,//客户端的IP地址
            'txnTime' => date('YmdHis'),//订单发送时间
            'remarks' => 'shop',
            'signMethod' => 'MD5',//签名算法
        ];
        $pub_params['signature'] = $this->_sign($pub_params, $this->key);//MD5加密结果
        $this->parameter = $pub_params;
    }

    /**
     * 生成sign
     * @param 待签名的参数列表
     */
    private function _sign($array, $md5Key)
    {
        ksort($array);
        $msg = "";
        foreach ($array as $key => $val) {
            // 不参与签名
            if($key != "signMethod" && $key != "signature"){
                $msg = $msg."$key=$val&";
            }
        }
        $msg = substr($msg, 0, -1);

        $msg = $msg.$md5Key;
        return  strtoupper(md5($msg));
    }

    /**
     * 发起请求
     */
    public function parseRE()
    {
        //{"code":"0000","imgUrl":"http://jh.ak007.net/jb/forward?orderId=06719041917590735922","mchntOrderId":"190419203731753","message":"请求处理成功","orderId":"06719041917590735922","signMethod":"MD5","signature":"AD8C7D9D9CF800E6231D306359624797","success":"true"}
        $re = json_decode($this->re, true);
        if ($re['code'] == '0000') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];//jump跳转或code扫码
            $this->return['str'] = $re['imgUrl'];//支付地址
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'JIEBAOPAY:' . (isset($re['message']) ? $re['message'] : '');
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($data)
    {
        if(isset($data['s'])) unset($data['s']);
        $res = [
            'status' => 0,//默认支付失败
            'order_number' => $data['mchntOrderId'],//商户订单号
            'third_order' => $data['orderId'],//系统订单号
            'third_money' => $data['txnAmt']/100,//支付金额
            'error' => '',
        ];

        if ($data['success'] != "true") {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '该订单不存在';
            return $res;
        }

        if ($this->returnVail($data, $config['key']) === false) {
            $res['error'] = '签名验证失败';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;//支付成功
        return $res;
    }

    /**
     * 签名校验
     * @param $params
     * @param $tkey
     */
    public function returnVail($array, $pub_key)
    {
        $signature = $array['signature'];
        unset($array['signature']);
        unset($array['signMethod']);

        ksort($array);
        $msg = "";
        foreach ($array as $key => $val) {
            // 不参与签名
            if($key != "signMethod" && $key != "signature"){
                $msg = $msg."$key=$val&";
            }
        }
        $msg = substr($msg, 0, -1);

        $msg = $msg.$pub_key;
        $sign = strtoupper(md5($msg));
        if ($sign == $signature){
            return true;
        }
        return false;
    }
}