<?php
/**
 * 聚金支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/2
 * Time: 21:48
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;
use Utils\Utils;

class JJPAY extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $parameter = [
            'merch_id' => $this->partnerID,
            'channel' => (string)$this->payType,
            'out_trade_no' => (string)$this->orderID,
            'detail'=>(string)$this->orderID,
            'callback_url' => $this->notifyUrl,
            'money' => $this->money*100,
            'timestamp' => time(),
            'version'=>'10',
            'signtype' => '0',
            'nonce_str'=> $this->_randSrting(),
            'ip'=>$this->data['client_ip'],
        ];
        $parameter['sign'] = $this->_sign($parameter, $this->key);
        $this->parameter = $parameter;
        //var_dump($this->parameter);exit();
    }


    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        $data = base64_decode($re['body']);
        if(isset($re['result']) && strtolower($re['result']) == 'success'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $return = json_decode($data,true);
            $this->return['str'] = $return['payurl'];
        }else{
            $this->return['code'] = $re['result'];
            $this->return['msg'] = 'JJPAY:'.$re['msg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
        /*$this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;*/
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['out_trade_no'],
            'third_order' => $parameters['orderid'],
            'third_money' => $parameters['money']/100,
        ];
        $config = Recharge::getThirdConfig($parameters['out_trade_no']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['status'] != 1) {
            $res['status'] = 0;
            $res['error'] = '未支付';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $this->updateMoney($res['order_number'],$res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }
    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key=>$val)
        {
            $string = $string?$string."&".$key."=".$val:$key."=".$val;
        }
        $string = $string.'&key='.$tKey;

        $sign = md5($string);
        return strtoupper($sign);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
    private function _randSrting()
    {
        $str="QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
        str_shuffle($str);
        $name=substr(str_shuffle($str),21,10);
        return $name;
    }
}