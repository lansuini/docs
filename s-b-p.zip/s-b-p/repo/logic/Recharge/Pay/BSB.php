<?php

namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

/**
 * 唐朝必胜宝支付
 */

class BSB extends BASES 
{
    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {  
        date_default_timezone_set('PRC'); 
        $this->parameter = [
            'inputCharset'    => 1,
            'partnerId'       => $this->partnerID,
            'signType'        => 1,
            'notifyUrl'       => (string)$this->notifyUrl,
            'returnUrl'       => (string)$this->notifyUrl,
            'orderNo'         => (string)$this->orderID,
            'orderAmount'     => $this->money*100,
            'orderCurrency'   => 156,
            'orderDatetime'   => date('YmdHis'),
            'payMode'         => $this->payType,       
            'ip'              => $this->data['client_ip'],
        ];
        $this->parameter['signMsg'] = $this->_sign($this->parameter,$this->key);
        //var_dump($this->parameter);exit;
    }

    /**
     * 
     */
    public function parseRE()
    {
        $result = json_decode($this->re, true);
        if ($result && $result['errCode'] == '0000') {
            if(isset($result['qrCode']) && $result['qrCode']) {
                $tranStr = strpos($result['qrCode'],'http') || strpos($result['qrCode'],'HTTP')? $result['qrCode'] : $this->qrcodeUrl . $result['qrCode'];
            }else {
                preg_match("/<script>([\s\S]*?)<\/script>/i", $result['retHtml'], $content);
                $str = str_replace('window.open(\'', ' ', $content[1]);
                $tranStr = str_replace('\',\'_self\');', ' ', $str);
            }
            $tranStr = $tranStr ? $tranStr : $result['retHtml'];
            $this->return['code'] = 0;
            $this->return['msg']  = 'success';
            $this->return['way']  = $this->data['return_type'];;
            $this->return['str']  = $tranStr;
        }else{
            $this->return['code'] = $result['errCode'];
            $this->return['msg'] = 'BSB: ' . $result['errMsg'];
            $this->return['way'] = '';
            $this->return['str'] = $result['orderNo'];
        }
        
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        // $res = [
        //     'inputCharset'    => $parameters['inputCharset'],
        //     'partnerId'       => $parameters['partnerId'],
        //     'signType'        => $parameters['signType'],
        //     'tradeSeq'        => $parameters['tradeSeq'],
        //     'orderNo'         => $parameters['orderNo'],
        //     'orderAmount'     => $parameters['orderAmount'],
        //     'orderDatetime'   => $parameters['orderDatetime'],
        //     'payDatetime'     => $parameters['payDatetime'],
        //     'payResult'       => $parameters['payResult'],      
        //     'signMsg'         => $parameters['signMsg'],
        //     'returnDatetime'  => $parameters['returnDatetime'],
        // ];
        $res = [
            'status' => 1,
            'order_number' => $parameters['orderNo'],
            'third_order'  => $parameters['tradeSeq'],
            'third_money'  => $parameters['orderAmount']/100,
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($parameters['orderNo']);
        if (! $config) {
            $res['status'] = 0;
            $res['error'] = '订单号不存在';
            return $res;
        }
        //校验sign
        $result = $this->verity($parameters, $parameters['signMsg'],$config['pub_key']);
        if ($result) {
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error']  = '验签失败！';
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    private function _sign($data, $private_key){
        $signType = $data['signType'];
        unset($data['signType']);
        ksort($data);
        $buff = "";
        foreach ($data as $k => $v) {
            if ($k != "SIGN_DAT" && $v != "" && !is_array($v)) {
                $buff .= $k . "=" . $v . "&";
            }
        }
        $buff = trim($buff, "&");
       //var_dump($buff);exit;
        $sign = false;
        $str = chunk_split($this->key, 64, "\n");
        $key = "-----BEGIN RSA PRIVATE KEY-----\n$str-----END RSA PRIVATE KEY-----\n";      
        if (openssl_sign($buff, $sign, $key,OPENSSL_ALGO_SHA1)){
            $sign = base64_encode($sign);
        } 
        $data['signType'] = $signType;
        return $sign;
    }
 
    /* 
    验证签名： 
    data：原文 
    signature：签名 
    publicKeyPath：公钥 
    返回：签名结果，true为验签成功，false为验签失败 
    */  
    function verity($data, $signature, $publicKey)  
    {  
        $signMsg = $data['signMsg'];
        unset($data['signMsg']);
        $signType = $data['signType'];
        unset($data['signType']);
        ksort($data);
        //var_dump($data);exit;
        $ret = false;
        $str = chunk_split($publicKey, 64, "\n");
        $key = "-----BEGIN PUBLIC KEY-----\n$str-----END PUBLIC KEY-----\n";
        $pubKey = $key;  
        $buff = "";
        foreach ($data as $k => $v) {
            if ($k != "SIGN_DAT" && $v != "" && !is_array($v)) {
                $buff .= $k . "=" . $v . "&";
            }
        }
        $buff = trim($buff, "&");
        $res = openssl_get_publickey($pubKey);
        $result = (bool)openssl_verify($buff, base64_decode($signature), $res,OPENSSL_ALGO_SHA1);
        openssl_free_key($res);   
        return $result;  
    } 


}