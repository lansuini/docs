<?php
/**
 * 郭巨侠支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/2/11
 * Time: 14:15
 */
namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class GJXZF extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        //$this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $pub_params = [
            'pay_memberid' => (string)$this->partnerID,
            'pay_bankcode' => (string)$this->payType, //bank_data
            'pay_amount' => $this->money,
            'pay_orderid' => (string)$this->orderID,
            'pay_callbackurl' => $this->returnUrl,
            'pay_notifyurl' => $this->notifyUrl,
            'pay_applydate' => date('Y-m-d H:i:s',time())
        ];
        $pub_params['pay_md5sign'] = $this->_sign($pub_params,$this->key);
        $pub_params['pay_productname'] = $this->orderID;
        $pub_params['pay_getqrurl'] = true;
        $this->parameter = $pub_params;
    }

    /**
     * 组装前端数据,输出结果，使用go.php方法，自动post到支付
     */
    public function parseRE()
    {
        //使用redis保存信息的跳转页面
        $this->buildGoOrderUrl();
        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->goPayUrl;
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['orderid']) || !isset($parameters['amount'])) {
            return false;
        }
        $res = [
            'order_number' => $parameters['orderid'],
            'third_order' => $parameters['orderid'],
            'third_money' => $parameters['amount'],
            'status'=>1,
            'error'=>''
        ];
        $config = Recharge::getThirdConfig($parameters['orderid']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['returncode'] != '00'){
            $res['status'] = 0;
            $res['error'] = '支付订单状态未成功';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
            return $res;
        }
        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/Pay_Trade_query.html';
        }
        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success != null && $success != '1' && $success != '2') {
            $res['status'] = 0;
            $res['error'] = '查询第三方订单返回状态:' . $success;
            return $res;
        }
        $this->updateMoney($res['order_number'],$res['third_money']);
        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($pieces,$tkey)
    {
        ksort($pieces);
        $string = '';
        foreach ($pieces as $key=>$val)
        {
            $string =$string. $key.'=>'.$val.'&';
        }
        $sign_str = $string.'key='.$tkey;
        $sign = md5($sign_str);
        return strtoupper($sign);
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $ReturnArray = array( // 返回字段
            "memberid" => $params["memberid"],      // 商户ID
            "orderid" => $params["orderid"],      // 订单号
            "amount" => $params["amount"],      // 交易金额
            "datetime" => $params["datetime"],      // 交易时间
            "returncode" => $params["returncode"],
            "realamount" => $params["realamount"],
        );
        $return_sign = $params['sign'];
        $sign = $this->_sign($ReturnArray,$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "pay_memberid" => $partnerID,
            "pay_orderid" => $orderNumber,
        ];

        $params['pay_md5sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);
        if (isset($re['returncode'])) {
            return $re['returncode'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }
}