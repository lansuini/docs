<?php
/**
 * K支付
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

class KPAY extends BASES
{

    //与第三方交互
    public function start()
    {
        $this->initParam();//数据初始化
        $this->basePost();
        $this->parseRE();//处理结果
    }

    //组装数组
    public function initParam()
    {
        $this->parameter['version'] = '1.0';//版本号 固定值
        $this->parameter['customerid'] = $this->partnerID;//商户号
        $this->parameter['sdorderno'] = $this->orderID;//商户订单号   不超过30
        $this->parameter['total_fee'] = sprintf('%0.2f', $this->money);//订单金额，以元为单位
        $this->parameter['paytype'] = $this->data['bank_data'];//支付类型，支付编号
        $this->parameter['notifyurl'] = $this->notifyUrl;//异步通知
        $this->parameter['returnurl'] = $this->returnUrl;//同步
        $this->parameter['sign'] = $this->sign($this->parameter, $this->key);//签名
    }

    //生成签名
    public function sign($data, $key)
    {
        $ms = "version={$data['version']}&customerid={$data['customerid']}&total_fee={$data['total_fee']}&sdorderno={$data['sdorderno']}&notifyurl={$data['notifyurl']}&returnurl={$data['returnurl']}&{$key}";
        return md5($ms);
    }

    //处理结果
    public function parseRE()
    {
        $re = json_decode($this->re, true);

        if (isset($re['code']) && $re['code'] == 10000) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = $re['payurl'];
        } else {
            $this->return['code'] = 99;
            $this->return['msg'] = 'K支付:' . (isset($re['msg']) ? $re['msg'] : '未知异常');
            $this->return['way'] = $this->showType;
        }
    }

    /*
     * 第三方通知数组
     * */
    public function returnVerify($pieces)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!(isset($pieces['sdorderno']) && isset($pieces['sdpayno']) && isset($pieces['total_fee']))) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $pieces['sdorderno'],//商户订单号
            'third_order' => $pieces['sdpayno'],//第三方的支付订单号
            'third_money' => $pieces['total_fee'],//支付金额为元
            'error' => '',
        ];
        $config = Recharge::getThirdConfig($pieces['sdorderno']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
        }
        if ($pieces['status'] != '1') {
            $res['status'] = 0;
            $res['error'] = '支付失败';
        }
        if (self::retrunVail($pieces, $config['key'])) {
            $this->updateMoney($res['order_number'], $res['third_money']);
            $res['status'] = 1;
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }

    //验签
    public function retrunVail($array, $signKey)
    {
        $sys_sign = $array['sign'];
        $my_sign = md5("customerid={$array['customerid']}&status={$array['status']}&sdpayno={$array['sdpayno']}&sdorderno={$array['sdorderno']}&total_fee={$array['total_fee']}&paytype={$array['paytype']}&{$signKey}");
        return $my_sign == $sys_sign;
    }
}