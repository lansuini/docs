<?php
/**
 * 皮皮支付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2019/1/1
 * Time: 14:40
 */
namespace Logic\Recharge\Pay;
use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;
use Utils\Client;

class KK extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        $this->initParam();
        $this->get();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->returnUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/return_url.php';
        $parameter = [
            'usercode' => $this->partnerID,
            'customno' => (string)$this->orderID,
            'scantype' => (string)$this->payType,
            'notifyurl' => $this->notifyUrl,
            'money' => sprintf("%.2f", $this->money),
            'sendtime' => date('YmdHis',time()),
            'buyerip' => $this->data['client_ip'],
        ];
        //秘钥
        $parameter['sign'] = $this->_sign($parameter, $this->key);
        $parameter['productname'] = (string)$this->orderID;
        $this->parameter = $parameter;
        //var_dump($this->parameter);exit();
    }


    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re,true);
        //var_dump($re);exit();
        if(isset($re['success']) && $re['success'] && $re['resultCode'] == '10000'){
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            //$url = str_replace(' ','',$re['data']['scanurl']);
            $this->return['str'] = $re['data']['scanurl'];
        }else{
            $this->return['code'] = $re['resultCode'];
            $this->return['msg'] = 'KK:'.$re['resultMsg'];
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
        /*$this->parameter = $this->arrayToURL();
        $this->parameter .= '&url=' . $this->payUrl;
        $this->parameter .= '&method=POST';

        $this->return['code'] = 0;
        $this->return['msg'] = 'SUCCESS';
        $this->return['way'] = $this->showType;
        $this->return['str'] = $this->jumpURL . '?' . $this->parameter;*/
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        $res = [
            'order_number' => $parameters['customno'],
            'third_order' => $parameters['orderno'],
            'third_money' => $parameters['tjmoney'],
        ];
        $config = Recharge::getThirdConfig($parameters['customno']);
        if (!$config) {
            $res['status'] = 0;
            $res['error'] = '没有该订单';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if ($result) {
            $order_number = $parameters['customno'];
            $return_money = $parameters['tjmoney'];
            $order_info = \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',(string)$order_number)->first(['i_order_no','i_money','i_uid']);
            $order_info = (array)$order_info;
            if (empty($order_info)){
                $res['status'] = 0;
                $res['error'] = '不存在的订单！';
            }else{
                if ($order_info['i_money'] - $return_money == 0){
                    $res['status'] = 1;
                }else{
                    \DB::table('order')->where('order_number', $order_number)->update(['order_money' =>(int)$return_money]);
                    $updata = array(
                        'i_money' => (int)$return_money,
                        'i_gold' =>(int)$return_money,
                    );
                    \DB::connection('jlmj_config')->table('order_place')->where('i_order_no',$order_number)->update($updata);
                    $res['status'] = 1;
                }
            }
        } else {
            $res['status'] = 0;
            $res['error'] = '验签失败！';
        }
        return $res;
    }
    public function paraFilter($para) {
        $para_filter = array();
        foreach($para as $key => $val){
            if($key == "sign" || $val == ""){
                continue;
            }else{
                $para_filter[$key] = $para[$key];
            }
        }
        return $para_filter;
    }


    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        $string = "";
        foreach ($params as $key=>$val)
        {
            $string = $string?$string."|".$val:$val;
        }
        $string = $string.'|'.$tKey;

        $sign = md5($string);
        return $sign;
    }

    /**
     * 回调后进行业务判断
     * @param $params
     * @param $conf
     * @param $reques_params
     * @return bool
     */
    public function returnVail($params,$tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign_origin = $params['usercode'].'|'.$params['orderno'].'|'.$params['customno'].'|'.$params['type'].'|'.$params['bankcode'].'|'.$params['tjmoney'].'|'.$params['money'].'|'.$params['status'].'|'.$params['refundstatus'].'|'.$params['currency'];
        $sign = md5($sign_origin.'|'.$tkey);
        if ($sign != $return_sign){
            return false;
        }
        return true;
    }
}