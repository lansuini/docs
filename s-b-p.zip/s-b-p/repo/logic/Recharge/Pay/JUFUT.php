<?php
/*
 * 天元支付
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/11
 * Time: 15:52
 */

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 聚富通支付
 * @package Logic\Recharge\Pay
 */
class JUFUT extends BASES
{

    /**
     * 生命周期
     */
    public function start()
    {
        if ($this->data['rule'] == '3') {//固额
            $request_money = $this->getRequestMoney($this->money);
            if (empty($request_money)) {
                $this->return['code'] = 99;
                $this->return['msg'] = '请求失败,不支持此固额,请检查支付配置中APP_SITE是否为空或不存在对应金额(以,分隔填写金额)';
                $this->return['way'] = $this->showType;
                return;
            }
            $this->money = $request_money;
        }
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    /**
     * 提交参数组装
     */
    public function initParam()
    {
        $this->parameter = [
            'merchant_code' => $this->partnerID,
            'merchant_order' => (string)$this->orderID,
            'trans_amount' => $this->money * 100,//单位分
            'pay_type' => $this->payType,
            'goods_info' => 'GOODS',
            'notify_url' => $this->notifyUrl,
            'return_url' => $this->returnUrl,
            'buyer_ip' => $this->data['client_ip'],
            'input_charset' => 'utf-8',
            'bank_code' => 'ICBC',
            'return_params' => '1',
            'extra' => '1'
        ];
        $this->parameter ['sign'] = $this->_sign($this->parameter, $this->key);
    }

    private function getRequestMoney($money)
    {

        if (empty($this->data['app_site'])) {
            return $money;
        }
        //PDD通道
        //例如：支付渠道配置的固额(200,300,400) 支付配置中APP_SITE就要对应配置上要转的金额(169,296,399)
        $money_source = explode(',', $this->data['moneys']);
        //对应第三方请求的金额,在支付配置APP_SITE框中配置
        $money_real = explode(',', $this->data['app_site']);

        $index = array_search($money * 100, $money_source);

        if ($index < 0 || $money_real == null || count($money_real) < $index - 1) {
            return null; //找不到对应金额映射
        }
        return $money_real[$index];
    }

    /**
     * 组装前端数据,输出结果,
     */
    public function parseRE()
    {
        $re = json_decode($this->re, true);
        if (isset($re['code']) && $re['code'] == 'ok') {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->data['return_type'];
            $content = $re['data']['url_info'];
            if (empty($content)) {
                $content = $re['url'];
            }
            if ($this->showType == 'sdk' && strpos($content, "%")) {//以下为sdk转义处理
                if (!strpos($content, "&")) {//没有字符串&分隔符号，说明必须解码一次
                    $content = urldecode($content);
                }

                //以下都是针对不稳定上游返回的SDK串，导致拉不起支付，需要我们接入方手动decode一次，如有误判修改此处逻辑
                if (strpos($content, "&")) {
                    //分离每个参数
                    $array = explode("&", $content);
                    if (!empty($array) && (
                            strpos($array[0], 'biz_content') > 0 //前面参数&被转义了未分离和biz_content粘在一起
                            || strpos($array[0], "%22")) //前面参数不规范有空格转义
                    ) {
                        $content = urldecode($content);
                    }
                }
            }
            $this->return['str'] = $content;
        } else {
            $this->return['code'] = 886;
            $this->return['msg'] = 'JUFUT:' . (isset($re['msg']) ? $re['msg'] : $this->re);
            $this->return['way'] = $this->data['return_type'];
            $this->return['str'] = '';
        }
    }

    /**
     * 回调验证处理
     * 获取接口返回数据，再次验证
     */
    public function returnVerify($parameters)
    {
        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);
        $res = [
            'order_number' => $parameters['merchant_order'],
            'third_order' => $parameters['out_trade_no'],
            'third_money' => $parameters['trans_amount'] / 100,
            'status'=>0,
            'error'=>''
        ];
        $config = Recharge::getThirdConfig($res['order_number']);
        if (!$config) {
            $res['error'] = '没有该订单';
            return $res;
        }
        if ($parameters['order_status'] != 'success') {
            $res['error'] = '支付订单状态失败';
            return $res;
        }
        $result = $this->returnVail($parameters, $config['key']);
        if (!$result) {
            $res['error'] = '验签失败！';
            return $res;
        }

        //向第三方查询支付订单,查询地址可配置
        $url = $config['terminal'];
        if (empty($url)) {
            $arr = parse_url($config['payurl']);
            $url = $arr['scheme'] . '://' . $arr['host'] . (isset($arr["port"]) ? ":" . $arr["port"] : "") . '/api/Apipay/queryOrderInfo';
        }
        $success = $this->queryOrder($url, $res['order_number'], $config['partner_id'], $config['key']);
        //查询第三方有结果
        if ($success && $success != 'success') {
            $res['error'] = '查询第三方订单返回状态:' . $success;
            $update = [
                'desc' => '订单关闭,查询订单返回状态:' . $success . '与回调状态不一致',
                'status' => 'failed',
            ];
            \DB::table('order')->where('order_number', $res['order_number'])->update($update);
            return $res;
        }
        $res['status'] = 1;
        $this->updateMoney($res['order_number'], $res['third_money']);
        return $res;
    }

    public function queryOrder($queryUrl, $orderNumber, $partnerID, $tkey)
    {
        $params = [
            "merchant_code" => $partnerID,
            "merchant_order" => $orderNumber,
        ];

        $params['sign'] = $this->_sign($params, $tkey);

        $this->payUrl = $queryUrl;
        $this->parameter = $params;

        $this->logCurlFunc($orderNumber, $this->basePost());

        $re = json_decode($this->re, true);

        if (isset($re['data']['order_status'])) {
            return $re['data']['order_status'];
        }
        //没有查到单，记录信息(可能网络问题无法访问，但更可能时查单地址不对)
        //虽然不影响上分，但需要检查第三方的地址是不是正常的，以免出现刷单行为
        $this->updateOrderQueryFailDesc($orderNumber, $this->payUrl, $this->parameter);
        return null;
    }

    /**
     * 生成sign
     */
    private function _sign($params, $tKey)
    {
        ksort($params);
        $string = "";
        foreach ($params as $key => $val) {
            $string .= $key . "=" . $val . "&";

        }
        $string = $string . 'key=' . $tKey;
        $sign = md5($string);
        return $sign;
    }

    public function returnVail($params, $tkey)
    {
        $return_sign = $params['sign'];
        unset($params['sign']);
        $sign = $this->_sign($params, $tkey);
        if ($sign != $return_sign) {
            return false;
        }
        return true;
    }
}