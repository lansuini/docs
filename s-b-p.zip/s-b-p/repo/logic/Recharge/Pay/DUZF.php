<?php

namespace Logic\Recharge\Pay;

use Logic\Recharge\Bases;
use Logic\Recharge\Recharge;

/**
 * 都付支付
 * Class DUZF
 * @package Logic\Recharge\Pay
 */
class DUZF extends BASES
{
    //与第三方交互
    public function start()
    {
        $this->initParam();
        $this->basePost();
        $this->parseRE();
    }

    //初始化参数
    public function initParam()
    {
        $this->parameter = array(
            'merchant_code' => $this->partnerID,
            'service_type' => $this->payType,
            'interface_version' => 'V3.1',
            'client_ip' => $this->clientIp,
            'notify_url' => $this->notifyUrl,
            'order_no' => $this->orderID,
            'order_time' => Date('Y-m-d H:i:s'),
            'order_amount' => $this->money,
            'product_name' => 'goods',
        );

        $this->parameter['sign'] = $this->encryptSign($this->parameter);
        $this->parameter['sign_type'] = 'RSA-S';
    }


    public function encryptSign($sign_arr)
    {
        $signStr = "";
        $signStr = $signStr . "client_ip=" . $sign_arr['client_ip'] . "&";
        $signStr = $signStr . "interface_version=" . $sign_arr['interface_version'] . "&";
        $signStr = $signStr . "merchant_code=" . $sign_arr['merchant_code'] . "&";
        $signStr = $signStr . "notify_url=" . $sign_arr['notify_url'] . "&";
        $signStr = $signStr . "order_amount=" . $sign_arr['order_amount'] . "&";
        $signStr = $signStr . "order_no=" . $sign_arr['order_no'] . "&";
        $signStr = $signStr . "order_time=" . $sign_arr['order_time'] . "&";
        $signStr = $signStr . "product_name=" . $sign_arr['product_name'] . "&";
        $signStr = $signStr . "service_type=" . $sign_arr['service_type'];
        $merchant_private_key = openssl_get_privatekey($this->buildPrivateKey($this->key));
        openssl_sign($signStr, $sign_info, $merchant_private_key, OPENSSL_ALGO_MD5);
        $sign = base64_encode($sign_info);
        return $sign;
    }

    protected function buildPublicKey($key)
    {
        return "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($key, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";
    }

    protected function buildPrivateKey($key)
    {
        return "-----BEGIN PRIVATE KEY-----\n" .
            wordwrap($key, 64, "\n", true) .
            "\n-----END PRIVATE KEY-----";
    }

    //返回参数
    public function parseRE()
    {
        $result = $this->parseXML($this->re);
        $re = $result['response'];
        if ($re['result_code'] == 0) {
            $this->return['code'] = 0;
            $this->return['msg'] = 'SUCCESS';
            $this->return['way'] = $this->showType;
            $this->return['str'] = urldecode($re['payURL']);
        } else {
            $this->return['code'] = 55;
            $this->return['msg'] = 'DUZF:' . $re['result_desc'];
            $this->return['way'] = $this->showType;
            $this->return['str'] = '';
        }
    }

    //签名验证
    public function returnVerify($parameters)
    {

        global $app;
        $parameters = $app->getContainer()->request->getParams();
        unset($parameters['s']);

        if (!isset($parameters['order_no']) || !isset($parameters['order_amount']) || !isset($parameters['trade_status'])) {
            return false;
        }

        $res = [
            'status' => 0,
            'order_number' => $parameters['order_no'],
            'third_order' => $parameters['order_no'],
            'third_money' => $parameters['order_amount'],
            'error' => '',
        ];

        if ($parameters['trade_status'] != 'SUCCESS') {
            $res['error'] = '支付订单状态未成功';
            return $res;
        }

        $config = Recharge::getThirdConfig($parameters['order_no']);
        if (!$config) {
            $res['error'] = '未有该订单';
            return $res;
        }

        if (!$this->returnVail($parameters, $config)) {
            $res['error'] = '验签失败！';
            return $res;
        }

        $this->updateMoney($res['order_number'], $res['third_money']);
        $res['status'] = 1;

        return $res;
    }

    //签名验证封装
    public function returnVail($parameters, $config)
    {
        $signStr = "";
        if (isset($parameters['bank_seq_no']) && $parameters['bank_seq_no'] != "") {
            $signStr = $signStr . "bank_seq_no=" . $parameters['bank_seq_no'] . "&";
        }
        if (isset($parameters['extra_return_param']) && $parameters['extra_return_param'] != "") {
            $signStr = $signStr . "extra_return_param=" . $parameters['extra_return_param'] . "&";
        }
        $signStr = $signStr . "interface_version=" . $parameters['interface_version'] . "&";
        $signStr = $signStr . "merchant_code=" . $parameters['merchant_code'] . "&";
        $signStr = $signStr . "notify_id=" . $parameters['notify_id'] . "&";
        $signStr = $signStr . "notify_type=" . $parameters['notify_type'] . "&";
        $signStr = $signStr . "order_amount=" . $parameters['order_amount'] . "&";
        $signStr = $signStr . "order_no=" . $parameters['order_no'] . "&";
        $signStr = $signStr . "order_time=" . $parameters['order_time'] . "&";
        $signStr = $signStr . "trade_no=" . $parameters['trade_no'] . "&";
        $signStr = $signStr . "trade_status=" . $parameters['trade_status'] . "&";
        $signStr = $signStr . "trade_time=" . $parameters['trade_time'];
        $dinpaySign = base64_decode($parameters['sign']);
        $dinpay_public_key = openssl_get_publickey($this->buildPublicKey($config['pub_key']));
        $flag = openssl_verify($signStr, $dinpaySign, $dinpay_public_key, OPENSSL_ALGO_MD5);
        return $flag;
    }
}