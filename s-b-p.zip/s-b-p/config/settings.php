<?php
define('RUNMODE', '');
define('ELKNAME', 'tcqp-pay.log');
function initEnv()
{
    // 加载环境变量配置文件
    if (is_file('/data/www/env.php')) {
        $content = require '/data/www/env.php';
        $env = parse_ini_string($content, true);

        foreach ($env as $key => $val) {
            $name = strtoupper($key);
            if (is_array($val)) {
                foreach ($val as $k => $v) {
                    $item = $name . '_' . strtoupper($k);
                    putenv("$item=$v");
                }
            } else {
                putenv("$name=$val");
            }
        }
    } else if (is_file(dirname(__FILE__) . '/../.env')) {
        $env = parse_ini_file(dirname(__FILE__) . '/../.env', true);

        foreach ($env as $key => $val) {
            $name = strtoupper($key);
            if (is_array($val)) {
                foreach ($val as $k => $v) {
                    $item = $name . '_' . strtoupper($k);
                    putenv("$item=$v");
                }
            } else {
                putenv("$name=$val");
            }
        }
    }
}

/**
 * 获取环境变量值
 * @access public
 * @param string $name 环境变量名（支持二级 . 号分割）
 * @param string $default 默认值
 * @return mixed
 */
function ggetEnv($name, $default = null)
{
    $result = getenv(strtoupper(str_replace('.', '_', $name)));
    if (false !== $result) {
        if ('false' === $result) {
            $result = false;
        } elseif ('true' === $result) {
            $result = true;
        }

        return $result;
    }

    return $default;
}

initEnv();
return [
    'settings' => [
        'ip' => ['103.196.124.252', '103.72.144.62', '47.75.0.151', '103.74.193.27', '182.16.54.66'],   //总的IP白名单
        'test' => true,
        'displayErrorDetails' => true, // set to false in production        正式上线改为false
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header
        'db' => [
            'default' => [                  //改为线上的SQL地址
                'driver' => 'mysql',
                'host' => ggetEnv('RECHARGE_HOST'),
                'database' => ggetEnv('RECHARGE_NAME'),
                'username' => ggetEnv('RECHARGE_USER'),
                'password' => ggetEnv('RECHARGE_PASS'),
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ],
            'jlmj_config' => [
                'driver' => 'mysql',
                'host' => ggetEnv('JLMJ_CONFIG_HOST'),
                'database' => ggetEnv('JLMJ_CONFIG_NAME'),
                'username' => ggetEnv('JLMJ_CONFIG_USER'),
                'password' => ggetEnv('JLMJ_CONFIG_PASS'),
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ],
            'accounts_jlmj' => [
                'driver' => 'mysql',
                'host' => ggetEnv('ACCOUNTS_JLMJ_HOST'),
                'database' => ggetEnv('ACCOUNTS_JLMJ_NAME'),
                'username' => ggetEnv('ACCOUNTS_JLMJ_USER'),
                'password' => ggetEnv('ACCOUNTS_JLMJ_PASS'),
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ],
        ],

        // rabbitmq
        'rabbitmq' => [  //改为线上的SQL地址
            'host' => ggetEnv('RABBITMQ_HOST'),
            'port' => ggetEnv('RABBITMQ_PORT'),
            'user' => ggetEnv('RABBITMQ_USER'),
            'password' => ggetEnv('RABBITMQ_PASS'),
            'vhost' => ggetEnv('RABBITMQ_VHOST'),
        ],

        // redis
        'cache' => [  //改为线上的SQL地址
            'schema' => 'tcp',
            'host' => ggetEnv('REDIS_HOST'),
            'port' => ggetEnv('REDIS_PORT'),
            'database' => 10,
            'password' => ggetEnv('REDIS_AUTH'),
        ],
        // 名称   payrequest   host  改为线上的
        'website' => ['name' => '支付平台', 'payrequest' => 'https', 'host' => str_replace(['http://', 'https://'], '', ggetEnv('PAY_DOMAIN')), 'alias' => 'recharge'],

        //'customer' => ['dir' => 'funds/recharge','method'=>'GET'],
        'customer' => ['dir' => '/api.php?', 'method' => 'GET', 'key' => ggetEnv('API_KEY')],

        'hosts' => [
            'api_host' => ggetEnv('PAY_API_HOST'),
            'plat_host' => ggetEnv('PAY_API_HOST'),
            'withdraw_host' => ggetEnv('PAY_WITHDRAW_HOST'),
        ],
    ],
];
