<?php
require __DIR__ . '/../repo/vendor/autoload.php';

$settings = require __DIR__ . '/../config/settings.php';

$app = new \Slim\App($settings);

// Set up dependencies
require __DIR__ . '/src/dependencies.php';

// Register middleware
require __DIR__ . '/src/middleware.php';

$app->run();
$app->getContainer()->db->getConnection('default');

$alias = $app->getContainer()
             ->get('settings')['website']['alias'];

$alias = strtoupper($alias) . 'Server';

if (empty($alias)) {
    echo 'please input website alias';
    exit;
}

$logger = $app->getContainer()->logger;
$worker = new \Workerman\Worker();
$worker->count = 2;
$worker->name = $alias;

// 防多开配置
// if ($app->getContainer()->redis->get(\Logic\Define\CacheKey::$perfix['callbackServer'])) {
//     echo 'callbackServer服务已启动，如果已关闭, 请等待5秒再启动', PHP_EOL;
//     exit;
// }

$worker->onWorkerStart = function ($worker) {
    global $app, $logger;

    $processId = 0;

    // 定时跑因进程线程出问题而未向客户提交通知的订单  补发客户通知
    if ($worker->id === $processId) {
        $interval = 30;
        \Workerman\Lib\Timer::add($interval, function () use ($app) {
            try {
                $callback = new Logic\Recharge\Recharge($app->getContainer());
                echo 'test', PHP_EOL;
                $callback->notifyCustomer();
            }catch (\Exception $e){
                echo 'error';
            }
        });
    }

    $processId++;
    // POST数据 为支付成功率分析
    if ($worker->id === $processId) {
        $interval = 60;
        \Workerman\Lib\Timer::add($interval, function () use ($app) {
            try {
                $data = \DB::table('notify_order')->forPage(1,200)->orderBy('id','asc')->get()->toArray();
                $url = $app->getContainer()
                    ->get('settings')['analyse_url'] ?? 'https://tg-ops.com/tools/pay/order';
                foreach ($data as $val){
                    $t = json_decode($val->json,true);
                    if(!is_array($t)){
                        \DB::table('notify_order')->delete($val->id);
                    }
                    $param = [
                        'orderNumber' => (string)$val->order_number,
                        'channelName' => $t['payname'] ?? '',
    //                'venderName' => $t['vendername'] ?? '',
                        'payMoney' => intval($t['money'] * 100), //分
                        'userId' => isset($t['user_id']) ? (string)$t['user_id'] : '0', //分
                        'payType' => $t['scene'] ?? '',
                        'payCode' => $t['code'] ?? '',
                        'status' => $t['status'] ?? 0,
                    ];
                    if($param['status'] == 1){
                        $param['updatedTime'] = isset($t['update']) ? date('Y-m-d H:i:s',$t['update']) :  date('Y-m-d H:i:s');
                    }else {
                        $param['createTime'] = isset($t['create']) ? date('Y-m-d H:i:s',$t['create']) :  date('Y-m-d H:i:s');
                    }
                    $param = array_filter($param);
                    $param['status'] = isset($param['status']) ? intval($param['status']) : 0;
                    print_r($param);
                    $re = \Utils\Curl::post($url,'',$param);
                    $re = json_decode($re,true);
                    print_r($re);
                    if($re['status'] == 200) {
                        \DB::table('notify_order')->delete($val->id);
                    }
                }
                $data = null;
            }catch (\Exception $e){
                echo 'error2';
            }
        });
    }
};

\Workerman\Worker::runAll();