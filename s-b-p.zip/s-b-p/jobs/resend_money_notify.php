<?php
/**
 * Created by Hans.
 * Date: 2020/5/5
 */

const KEY = "notify_money_with_failOrder";
$container = $app->getContainer();
$redis = $container->redis;


//echo json_encode($data, true);


function addTest()
{
    global $redis;
    //利用zSet设置列表元素过期时间
    $expired_time = time() + (100);
    $redis->zAdd(KEY, $expired_time, 20190430000004);
}

function queryOrders()
{
    global $redis;
    $array = $redis->zRange(KEY, 0, -1, ['withscores' => true]);
    print_r($array);
}

function clear()
{
    global $redis;
    $redis->del(KEY);
}

function removeExpiredOrder()
{
    global $redis;
    $time = time();
    $count = $redis->zRemRangeByScore(KEY, 0, $time);
    echo "=========================================================\n";
    echo "清理已超时失败订单 [数量:$count timestamp:$time]\n";
    echo "=========================================================\n\n";
}

function send_notify()
{
    global $container;
    global $redis;
    //获取所有要补发的订单
    $array = $redis->zRange(KEY, 0, -1);
    if (empty($array)) {
        echo "订单已过期或没有需要补单的订单\n";
        return;
    }

    echo "============================================================== 开始对失败订单进行补单:\n";
    foreach ($array as $order) {
        $data = \DB::table('order')->where("order_number", $order)->where('status', '=', 'failed')->get(['order_number', 'third_money', 'status'])->first();
        if (empty($data)) {
            echo "Order:$order 不存在或已上分\n";
            continue;
        }

        $data = (array)$data;

        $pay = new \Logic\Recharge\Recharge($container);
        $pay->creaseCustomer($order, $data['third_money']);
    }

    echo "============================================================== 补单结束:\n";
}


$execFlag = false;

if (isset($argv[2])) {
    $cmd = $argv[2];

    switch ($argv[2]) {
        case "query":
            queryOrders();
            break;

//        case "test":
//            addTest();
//            break;

//        case "clear":
//            clear();
//            break;

        default:
            $execFlag = true;
            break;
    }

} else {
    $execFlag = true;
}

if ($execFlag) {
    removeExpiredOrder();
    send_notify();
}