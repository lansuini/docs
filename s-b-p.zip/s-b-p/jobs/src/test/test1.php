<?php


$order = \DB::table('order')->where('order_number', '163654612664609')->first();
var_dump($order);
$order = \DB::select("select * from `order` where `order_number` = '163654612664609' order by id desc limit 1");
var_dump($order);



$order = \DB::table('order')->where('order_number', '163654612664609')->first();
$order = (array)$order;
var_dump($order);
$create_timestamp = strtotime($order['created']);
var_dump(date('Y-m-d H:i:s'));
$current_timestamp = strtotime(date('Y-m-d H:i:s'));
$timeout = ($current_timestamp-$create_timestamp)/60; //间隔/分钟
echo $timeout;
die;

