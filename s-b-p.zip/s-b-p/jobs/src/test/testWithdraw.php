<?php

require __DIR__ . '/../../../paid/BIGPAYTH.php';
$platform='BIGPAYTH';

$exchangeInfos['amount']=50;
$bankInfos['bank_code']='ICBC';
$bankInfos['user_name']='张三';
$bankInfos['bank_num']='1111111111111111';
//$commonParams = [
//    'order_num' => 'P'.rand(10000, 99999) . rand(10000, 99999),
//    'exchange_infos' => $exchangeInfos,
//    'bank_infos' => $bankInfos,
//];
$commonParams = [
    'order_number' => 'P2244742846',
];


$platConf=\DB::connection('log_comm_jlmj')->table('transfer_config')->where('code','=',$platform)->first();
$platConf=decryptConfig((array)$platConf);
$channel=new BIGPAYTH();

//$res=$channel->withdraw($commonParams,$platConf);
$res=$channel->searchTransfer($commonParams,$platConf);
print_r($res);exit;


function decryptConfig($config)
{

    foreach ($config as $key => &$val) {
        if (in_array($key, ['app_id', 'app_secret', 'key', 'pub_key', 'token']) && trim($val) != '') {
            $val = xmcrypString($val, false);
        }
    }
    return $config;
}

function xmcrypString($string, $encrypt = true)
{
    $key = getKey('kQYOdspay9I5elv2wdaaaDcg==');
    $cipher = 'AES-256-CBC';
    $iv = strrev($key);
    if ($encrypt) { //加密
        $encrypted = openssl_encrypt($string, $cipher, $key, OPENSSL_RAW_DATA, $iv);
        if (false === $encrypted) {
            return $string;
        }
        return base64_encode($encrypted);
    } else { //解密
        $_encrypted = base64_decode($string);
        if (!$_encrypted) {
            return $string;
        }
        $decrypted = openssl_decrypt($_encrypted, $cipher, $key, OPENSSL_RAW_DATA, $iv);
        if (false === $decrypted) {
            return $string;
        }
        return $decrypted;
    }

}

function getKey($key)
{
    $k = '';
    $s = array('*', '$', '\\', '/', "'", '"', "?", "#", "]", ",", ";", "[");
    $r = array('A', 'E', 'S', '2', "5", '6', "C", "B", "C", "a", "e", "s");
    $key = str_replace($s, $r, strtoupper($key));
    for ($i = 0; $i < strlen($key); $i++) {
        $strtoint = ord($key[$i]);
        $newint = $strtoint + 2;
        $k .= chr($newint);
    }
    $k = substr($k, strlen(str_replace($s, $r, $k)) - 16);
    return $k;
}