<?php
/**
 * 友付代付KPAY
 * @author Taylor 2019-06-13
 */
class KPAY {
    /**
     * 配置
     */
    private $config;

    //异步回调
    public function callback(){
        exit('success');
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];//提现订单信息
        $bankInfos 	   = $params['bank_infos'];//银行信息
//        使用测试账号
//        $bankInfos['bank_code'] = "ABC";
//        $bankInfos['user_name'] = "范超东";
//        $bankInfos['bank_num'] = "6230521720024401374";
//        $exchangeInfos['mobile'] = "19833037749";
//        $exchangeInfos['amount'] = 1;
//        $bankInfos['bank_name'] = '建设银行';
        $bank_code = $this->_getBankCode($bankInfos['bank_name']);
        if($bank_code === false) {
            return false;
        }
        $data = [
            "version" => "2.0",//版本号
            "charset" => "UTF-8",//字符集
            "spid" => $this->config['partner_id'],//商户号
            "spbillno" => $params['order_num'],//商户代付单号
//            "amount" => sprintf("%.2f", $exchangeInfos['amount']),
            "tranAmt" => $exchangeInfos['amount'] * 100,//交易金额，单位为分
            "acctName"=> $bankInfos['user_name'],//收款人姓名
            "acctId"=> $bankInfos['bank_num'],//收款人账号
            "acctType"=> "0",//账号类型，0-借记卡 1-贷记卡 2-对公 暂不支持贷记卡
            "certType"=> "1",//1-身份证 对私必传
            "certId"=> "422823197401237843",//证件号码 对私必传
            "mobile"=> $exchangeInfos['mobile'],//银行预留手机号
            "bankName"=> $bank_code ? $bank_code[0] : "",//开户行名称
            "bankCode"=> $bank_code ? $bank_code[1] : "",//银行编码
            "accountNo"=> $this->get_account_no($params),//账户编号
            "notifyUrl"=> $this->config['url_notify'],//后台通知地址
            "signType"=> "MD5",//签名类型
        ];
        $data['sign'] = $this->_createSign($data);
        $return = $this->toXml($data);

        return $return;
    }

    //获取账户编号，因为存在多账户问题
    private function get_account_no($params){
        if(!empty($this->config['app_id'])){//使用专用通道
            return $this->config['app_id'];
        }
        $data = [
            "version" => "2.0",//版本号
            "charset" => "UTF-8",//字符集
            "spid" => $this->config['partner_id'],//商户号
            "spbillno" => 'YE'.$params['order_num'],//商户代付单号
            "signType"=> "MD5",//签名类型
        ];
        $data['sign'] = $this->_createSign($data);
        $return = $this->toXml($data);
        $url = $this->config['request_url'].'/payment/balance';
        $http_result = $this->_httpUrl($return, $url);
        if($http_result['retcode'] == '0'){
            $account = $http_result['accountDetail'];
            if(!empty($account[0]['accountNo'])){//二个账户，二维数组
                $acc_no = $account[0]['accountNo'];
                $acc_amount = $account[0]['amount'];
                foreach($account as $d){
                    if($d['amount'] > $acc_amount){
                        $acc_no = $d['accountNo'];
                        $acc_amount = $d['amount'];
                    }
                }
                return $acc_no;
            }else{//只有一个账户
                return $account['accountNo'];
            }
        }
    }

    /**
     * 生成sign
     */
    private function _createSign($data)
    {
        if(isset($data['signType'])){
            unset($data['signType']);
        }
        ksort($data);
        $string = '';
        foreach ($data as $key=>$val)
        {
            if ($val != ''){
                $string = $string ? $string.'&'.$key.'='.$val : $key.'='.$val;
            }
        }
        $md5_str = md5($string.'&key='.$this->config['pub_key']);

        return strtoupper($md5_str);
    }

    /**
     * 将数据转为XML
     */
    public function toXml(array $array){
        $xml = '<xml>';
        forEach($array as $k=>$v){
            $xml.='<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
        }
        $xml.='</xml>';
        return $xml;
    }

    //将XML转为array
    public function xmlToArray($xml){
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $values;
    }

    /**
     * XML解析成数组
     */
    public function parseXML($xmlSrc){
        if(empty($xmlSrc)){
            return false;
        }
        $array = array();
        $xml = simplexml_load_string($xmlSrc);
        $encode = $this->getXmlEncode($xmlSrc);
        if($xml && $xml->children()) {
            foreach ($xml->children() as $node){
                //有子节点
                if($node->children()) {
                    $k = $node->getName();
                    $nodeXml = $node->asXML();
                    $v = $this->parseXML($nodeXml);
                } else {
                    $k = $node->getName();
                    $v = (string)$node;
                }
                if($encode!="" && strpos($encode,"UTF-8") === FALSE ) {
                    $k = iconv("UTF-8", $encode, $k);
                    $v = iconv("UTF-8", $encode, $v);
                }
                $array[$k] = $v;
            }
        }
        return $array;
    }

    //获取xml编码
    public function getXmlEncode($xml) {
        $ret = preg_match ("/<?xml[^>]* encoding=\"(.*)\"[^>]* ?>/i", $xml, $arr);
        if($ret) {
            return strtoupper ( $arr[1] );
        } else {
            return "";
        }
    }

    public function _httpUrl($xmlData, $url)
    {
        $header[] = "Content-type:text/xml";
        $header[] = "charset:utf-8";
        $header[] = "User-Agent:Mozilla/5.0 (Windows NT 6.2; Win64; x64) 		AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";
        $ch = curl_init ($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $xmlData);
        $response = curl_exec($ch);
        if(!empty($response)){
            return $this->xmlToArray($response);
        }else{
            return false;
        }
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params, $config)
    {
        $this->config = $config;
        $data = $this->_parseParams($params);
        if($data === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 5,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        //https://paymentv2.surperpay.com/payment/paymentPay
        $http_result = $this->_httpUrl($data, $this->config['request_url'].'/payment/paymentPay');
//        $http_result = json_decode('{"retcode":"0","retmsg":"\u64cd\u4f5c\u6210\u529f","version":"2.0","charset":"UTF-8","signType":"MD5","spid":"C1559896507375","spbillno":"3847829048200029","tranAmt":"1000","result":"processreview","msg":"\u8f6c\u8d26\u7533\u8bf7\u6210\u529f","sign":"B9C6B613F2146E634BB1884B41353049"}', true);
//        $http_result = ["retcode"=> "10040", "retmsg"=> "请求IP错误"];
//        $http_result = ["retcode"=> "0", "retmsg"=> "操作成功", "version"=> "2.0", "charset"=> "UTF-8", "signType"=> "MD5", "spid"=> "C1554533772018", "spbillno"=> "4418314084200029", "transactionId"=> "267688483445800960", "tranAmt"=> "100", "result"=> "processreview", "msg"=> "转账申请成功", "sign"=> "E07E4FDDE7D32B898FC3A8FC115625FC"];

        if($http_result['retcode'] == 0 && isset($http_result['sign'])){
            $status = true;
            $withdraw_status = 4;//成功
            $msg = '';
        }else{
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $http_result['retcode'].":".$http_result['retmsg'];
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($http_result['transactionId']) ? $http_result['transactionId'] : $http_result['spbillno'],
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){
        $this->config = $config;
        //查询转账任务接口
        $data = [
            "version" => "2.0",//版本号
            "charset" => "UTF-8",//字符集
            "spid" => $this->config['partner_id'],//商户号
            "spbillno" => $data['order_number'],//商户代付单号
            "signType"=> "MD5",//签名类型
        ];
        $data['sign'] = $this->_createSign($data);
        $return = $this->toXml($data);
        //https://paymentv2.surperpay.com/payment/paymentQuery
        $http_result = $this->_httpUrl($return, $this->config['request_url'].'/payment/paymentQuery');
        $status = 2;//转账中
        if($http_result['retcode'] == 0 && isset($http_result['sign'])) {
            switch ($http_result['result']) {
                //0 代付成功，-1 订单不存在，1 代付处理中，2 代付失败
                case 'processsuccess' :
                    $status = 1;//成功
                    break;
                case 'processfailed' :
                    $status = 5;//失败
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function verifySign($data)
    {
        $return_sign = $data['sign'];
        unset($data['sign']);
        $sign = $this->_createSign($data);
        if ($return_sign == $sign){
            return true;
        }
        return false;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            '工商银行' => ['工商银行', 1001],
            '农业银行' => ['农业银行', 1002],
            '建设银行' => ['建设银行', 1004],
            '浦发银行' => ['浦发银行', 1014],
            '兴业银行' => ['兴业银行', 1029],
            '民生银行' => ['民生银行', 1010],
            '交通银行' => ['交通银行', 1005],
            '中信银行' => ['中信银行', 1007],
            '光大银行' => ['光大银行', 1008],
            '北京银行' => ['北京银行', 1016],
            '招商银行' => ['招商银行', 1012],
            '广发银行' => ['广发银行', 1017],
            '上海银行' => ['上海银行', 1025],
            '中国银行' => ['中国银行', 1003],
            '华夏银行' => ['华夏银行', 1009],
            '平安银行' => ['平安银行', 1011],
            '中国邮政' => ['邮储银行', 1006],
//            'SDB' => ['深圳发展银行', 1006],
//            'RCC' => ['农村信用社', 1006],
//            'HSB' => ['微商银行', 1006],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

}