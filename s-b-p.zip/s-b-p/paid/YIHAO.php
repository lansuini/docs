<?php
/**
 * 一号代付
 * @author Taylor 2019-05-25
 */
class YIHAO {
    protected $config;//代付通道配置
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];//订单信息
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }

        //添加转账任务
        $en_str = array(
            'mer_id'=>$this->config['app_id'],//商户号
            'out_trade_no'=>$params['order_num'],//商户订单号
            'pay_type'=>'016',//代付接口，支付类型
            'total_fee'=>$exchangeInfos['amount'] * 100,//转账金额，分为单位
            'acct_name'=>$bankInfos['user_name'],//收款人
            'acct_no'=>$bankInfos['bank_num'],//银行账号
            'bank_name'=>$tmp_bank,//开户行名称
            'cnaps_name'=>$bankInfos['bank_detail'],//开户行支行
//            'notify_url'=>$this->config['url_notify'],//异步通知地址
            'nonce_str'=>$exchangeInfos['uid'].mt_rand(time(),time()+rand()),//随机字符串
        );
        $en_str['sign'] = $this->dataSign($en_str);//生成签名
        return $en_str;
    }

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($para){
        $blankStr = 'acct_name='.$para['acct_name'].'&acct_no='.$para['acct_no'].'&mer_id='.$para['mer_id'].
            '&nonce_str='.$para['nonce_str'].'&out_trade_no='.$para['out_trade_no'].'&total_fee='.$para['total_fee'].'&key='.$this->config['app_secret'];
        return md5($blankStr);
    }

    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return json
     */
    public function withdraw($params, $config){
        $this->config = $config;
//        $params['exchange_infos']['amount'] = '1';
//        $params['bank_infos']['bank_name'] = '浦发银行';
//        $params['bank_infos']['bank_detail'] = '重庆合川支行';
//        $params['bank_infos']['bank_code'] = 'SPDB';
//        $params['bank_infos']['bank_num'] = '6217920901890629';
//        $params['bank_infos']['user_name'] = '周强';
        $data = $this->_parseParams($params);
        if($data === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 5,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result_str = $this->request($this->config['request_url']."/proxy_server/proxy_api", $data);
//        {"resp_code":"7000","resp_msg":"IP受限,请联系管理员"}
//        {"resp_code":"6004","resp_msg":"余额不足，最大金额0.00元"}
//        {"resp_code":"0000","resp_msg":"请求成功","pay_trade_no":"20180704153605231589"}
        $result = json_decode($result_str,true);
        if(isset($result['resp_code']) && $result['resp_code'] == '0000'){
            $status = true;
            $withdraw_status = 4;//成功
            $msg = '';
        }else{
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['resp_msg'];
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($result['pay_trade_no']) ? $result['pay_trade_no'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>0 , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>1 , 'name' => '中国农业银行'],
            'CCB' => ['code'=>3 , 'name' => '中国建设银行'],
            'SPDB' => ['code'=>12 , 'name' => '浦发银行'],
            'CIB' => ['code'=>11 , 'name' => '兴业银行'],
            'CMBC' => ['code'=>-1 , 'name' => '中国民生银行'],
            'BCM' => ['code'=>4 , 'name' => '交通银行'],
            'CNCB' => ['code'=>5 , 'name' => '中信银行'],
            'CEB' => ['code'=>6 , 'name' => '中国光大银行'],
            'BCCB' => ['code'=>13 , 'name' => '北京银行'],
            'CMB' => ['code'=>10 , 'name' => '招商银行'],
            'GDB' => ['code'=>8 , 'name' => '广东发展银行'],
            'SHB' => ['code'=>138 , 'name' => '上海银行'],
            'BOC' => ['code'=>2 , 'name' => '中国银行'],
            'HXB' => ['code'=>7 , 'name' => '华夏银行'],
            'PAB' => ['code'=>9 , 'name' => '平安银行'],
            'PSBC' => ['code'=>161 , 'name' => '中国邮政储蓄银行'],
            'SDB' => ['code'=>162 , 'name' => '深圳发展银行'],
//            'RCC' => ['code'=>163 , 'name' => '农村信用社'],
            'HSB' => ['code'=>127 , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code]['name'] : false;
    }

    //异步回调
    public function callback(){
        exit('success');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){
        $this->config = $config;
        //查询转账任务接口
        $en_str = array(
            'out_trade_no'=>$data['order_number'],//Api订单号
        );
        $result_str = $this->request($this->config['request_url']."/proxy_server/proxy_query", $en_str);
        //{"resp_code":"1","resp_msg":"代付处理中","pay_trade_no":"20190525175624212083","out_trade_no":"4838190480200029","total_fee":100}
        $result = json_decode($result_str,true);
        $status = 2;//转账中
        if(isset($result['resp_code'])) {
            switch ($result['resp_code']) {
                //0 代付成功，-1 订单不存在，1 代付处理中，2 代付失败
                case '0' :
                    $status = 1;//成功
                    break;
                case '-1' :
                case '2' :
                    $status = 5;//失败
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($url, $param){
        $request_url = $url.'?' . http_build_query ($param);
        // user_agent一定要带
        $user_agent = $_SERVER ['HTTP_USER_AGENT'];
        $header = array (
            "User-Agent: $user_agent"
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $request_url );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

}