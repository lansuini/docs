<?php
/**
 * 老高代付
 * @author Taylor
 */
class LGDF {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config){

//               $re= $this->searchTransfer(['order_number' => '9793654346200029'],$config);
//               var_dump($re);die;
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $datas = [
            'mchid'=> $config['partner_id'],//平台分配商户号
            'out_trade_no' => $params['order_num'],//商户订单号
            'money' => $exchangeInfos['amount'],//付款金额，单位元，
            'bankname' => $bankInfos['bank_name'],//银行名称 必填
            'subbranch' => $bankInfos['bank_detail'] ? $bankInfos['bank_detail'] : '人民路支行',//支行名称，必填
            'accountname' => $bankInfos['user_name'],//户名（开户名称）；支付宝填写登录账户；
            'cardnumber' =>$bankInfos['bank_num'],//户号（卡号）；支付宝填写登录账户
            'province' =>  trim($bankInfos['bank_province']) ? $bankInfos['bank_province'] : '浙江',//所属省份 必填
            'city' => '6',//所属城市 必填
            'notify_url' => $config['url_notify'],//回调地址
        ];

//
//        $datas = [
//            'mchid'=> $config['partner_id'],//平台分配商户号
//            'out_trade_no' => $params['order_num'],//商户订单号
//            'money' => 100,//付款金额，单位元，
//            'bankname' => '中国建设银行',//银行名称 必填
//            'subbranch' => '中国建设银行股份有限公司曲阜支行',//支行名称，必填
//            'accountname' => '王洪旭',//户名（开户名称）；支付宝填写登录账户；
//            'cardnumber' =>'6217002210033488294',//户号（卡号）
//            'province' =>  '山东',//所属省份 必填
//            'city' => '济宁',//所属城市 必填
//        ];


        $datas['pay_md5sign'] = $this->getSign($datas, $config['key']);
        return $datas;
    }

    public function getSign($data, $key) {
        ksort($data);

        $signPars = "";
        foreach($data as $k => $v) {
            if($v && $v!=""){
                $signPars .= $k . "=" . $v . "&";
            }
        }
        //字符串转大写  md5加密拼接字符串 连接密钥
        $sign = strtoupper(md5($signPars . "key=" . $key));
        return $sign;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     */
    public function withdraw($params, $config){
        $data = $this->_parseParams($params,$config);

        if($e = oo::withdraw()->error($params, $data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/Payment_Dfpay_add.html', $data);
        $result = json_decode($result,true);
        if($result['status'] == "error" ){
            $status = false;
            $withdraw_status = 5;//代付失败
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['transaction_id'] ?? '',
            'msg' 			  => $result['msg'] ?? '',
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data, $config){
        $data = [
            'mchid' => $config['partner_id'],//商户 PID
            'out_trade_no' 	=> $data['order_number'],//商户订单号
        ];
        $data['pay_md5sign'] = $this->getSign($data, $config['key']);
        $result = $this->_curl($config['request_url'].'/Payment_Dfpay_query.html', $data);
        $result = json_decode($result,true);
        $status = 2;

        if ( isset($result['refCode'])) {
            switch ($result['refCode']) {
                case '1'://交易成功
                    $status = 1;
                    break;
                case '2': case '5': case '7'://交易失败
                $status = 5;
                break;
                default:
                    $status = 2;
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 老高代付：' . '请求地址：' . $url . '请求参数：' . json_encode($para) . '结果：' . $response);
        return $response;
    }

    public function callback(){
        echo 'SUCCESS';exit;

    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/lgdf.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}