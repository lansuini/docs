<?php

/**
 * 银盈通代付
 */
header("Content-type:text/html;charset=utf-8");
class YYT {

	/**
	 * 实例化
	 */
	public function init()
	{
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params,$config)
	{
		$exchangeInfos = $params['exchange_infos'];
		$bankInfos     = $params['bank_infos'];
		$data = [
            "businessId" 	=> $config['partner_id'],
            "money" 	=> $exchangeInfos['amount']*100,
            "method"  => $config['request_code'],
            "orderNo"  => $params['order_num'],
            "name"  => $bankInfos['user_name'],
            "bankCard"  => $bankInfos['bank_num'],
            "bankCode"  => $bankInfos['bank_code'],  //
            "bankName"  => $bankInfos['bank_name'],
            "bankBranchName"  => $bankInfos['bank_detail'] ? $bankInfos['bank_detail'] : '未知',//
            "bankProvince"  => '广东',//
            "bankCity"  => '深圳',//
            "bankLinked"  => '308584000013',//
            "service"  => $config['app_id'],//
		];
		$data['sign'] = $this->_sign($data,$config['key']);
		return $data;
	}

	/**
	 * 生成签名
	 */
    private function _sign($data,$key) {
		ksort($data);
        $string = '';
        if(is_array($data)){
        	foreach ($data as $k => $v){
	            $string.=$v;
        	}
        }
        $string = $string.$key;
		$sign   = MD5($string);
		return $sign;
	}


	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params,$config){
        //初始化 curl
	    $data = $this->_parseParams($params,$config);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/daifu',$data);
		$res = [
			'status' 		  => !$result || $result['code'] == 0 ? true : false,
			'withdraw_status' => isset($result['tradeStatus']) && $result['tradeStatus'] == 2 ? 5 : 4,
			'out_order_num'   => $result['orderNo'] ?? '',
			'msg' 			  => $result['ret_message'] ?? '',
		];
		return $res;
	}
	// 569928617329426432
	public function searchTransfer($data,$config){
        $data = [
            "businessId" 	=> $config['partner_id'],
            "orderNo" 	=> $data['order_number'],
        ];
        $data['sign'] = $this->_sign($data,$config['key']);
        $result = $this->_curl($config['request_url'].'/query',$data);
        if(isset($result['data']['orderStatus']) && in_array($result['data']['orderStatus'],['FAIL','EXPIRED'])){
            return ['status' => 5];
        }elseif(isset($result['data']['orderStatus']) && $result['data']['orderStatus'] == 'SUCCESS'){
            return ['status' => 1];
        }
        return ['status' => 2];
    }

    public function _curl($url,$para){
        $para = json_encode($para, JSON_UNESCAPED_UNICODE);
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_HEADER, 0); // 过滤HTTP头
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 转向
        curl_setopt($curl, CURLOPT_POST, true); // post传输数据
        curl_setopt($curl, CURLOPT_POSTFIELDS, $para);// post传输数据
        $result = curl_exec($curl);
        curl_close($curl);

        return json_decode($result, true);
    }
}