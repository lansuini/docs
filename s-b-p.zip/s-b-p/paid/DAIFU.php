<?php

/**
 * 大栋
 */
class DAIFU {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
        if(!$tmp_bank){
            $tmp_bank = $this->_getBankCode($bankInfos['bank_name']);
        }
        if($tmp_bank === false) {
            return false;
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];
        $datas = [
            'merchantNo' => $config['partner_id'],
            'merchantOrderNo' => $params['order_num'],
            'merchantReqTime' => date('YmdHis'),
            'orderAmount' => $exchangeInfos['amount'],
            'bankAccountNo' => $bankInfos['bank_num'],
            'bankAccountName' => $bankInfos['user_name'],
            'tradeSummary' => 'transfer',
            'province' => '未知',
            'city' => '未知',
            'orderReason' => 'personal_reasons',
            'backNoticeUrl' => $config['url_notify'],
            'requestIp' => fn::getip(),
            'bankName' => $bank_name,
            'bankCode' => $bank_code,
        ];
        ksort($datas);
        $datas['sign'] = md5($this->arrayToURL($datas).$config['key']);
        return $datas;
    }

    public function arrayToURL($data) {
        $signPars = "";
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        return $signPars;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/paygateway/settlement',$data);
        $result = json_decode($result,true);
        if(isset($result['code']) && $result['code'] != 'SUCCESS'){
            $status = false;
            $withdraw_status = 5;
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['biz']['platformOrderNo'] ?? '',
            'msg' 			  => $result['msg'] ?? '',
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'ICBC' => ['code'=>'ICBC' , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>'ABC' , 'name' => '中国农业银行'],
            'BOC' => ['code'=>'BOC' , 'name' => '中国银行'],
            'CCB' => ['code'=>'CCB' , 'name' => '中国建设银行'],
            'BCM' => ['code'=>'BCOM' , 'name' => '中国交通银行'],
            'CNCB' => ['code'=>'CITIC' , 'name' => '中信银行'],
            'CEB' => ['code'=>'CEB' , 'name' => '中国光大银行'],
            'HXB' => ['code'=>'HXB' , 'name' => '华夏银行'],
            'CMBC' => ['code'=>'CMBC' , 'name' => '中国民生银行'],
            'GDB' => ['code'=>'GDB' , 'name' => '广东发展银行'],
            'PAB' => ['code'=>'PAB' , 'name' => '平安银行'],
            'CMB' => ['code'=>'CMB' , 'name' => '招商银行'],
            'CIB' => ['code'=>'CIB' , 'name' => '兴业银行'],
            'SPDB' => ['code'=>'SPDB' , 'name' => '浦发银行'],
            'BCCB' => ['code'=>'BOB' , 'name' => '北京银行'],
            'SHB' => ['code'=>'SHB' , 'name' => '上海银行'],
            'PSBC' => ['code'=>'PSBC' , 'name' => '中国邮政储蓄银行'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($bankName = '')
    {
        if(!$bankName) return false;
        $bank_list = [
            '工商银行' => ['name' => '工商银行', 'code'=>'ICBC'],
            '农业银行' => ['name' => '农业银行', 'code'=>'ABC'],
            '中国银行' => ['name' => '中国银行', 'code'=>'BOC'],
            '建设银行' => ['name' => '建设银行', 'code'=>'CCB'],
            '交通银行' => ['name' => '交通银行', 'code'=>'COMM'],
            '中信银行' => ['name' => '中信银行', 'code'=>'CITIC'],
            '光大银行' => ['name' => '光大银行', 'code'=>'CEB'],
            '华夏银行' => ['name' => '华夏银行', 'code'=>'HXB'],
            '民生银行' => ['name' => '民生银行', 'code'=>'CMBC'],
            '广发银行' => ['name' => '广东发展银行', 'code'=>'GDB'],
            '平安银行' => ['name' => '平安银行', 'code'=>'SZPAB'],
            '招商银行' => ['name' => '招商银行', 'code'=>'CMB'],
            '兴业银行' => ['name' => '兴业银行', 'code'=>'CIB'],
            '浦发银行' => ['name' => '浦东发展银行', 'code'=>'SPDB'],
            '北京银行' => ['name' => '北京银行', 'code'=>'BCCB'],
            '上海银行' => ['name' => '上海银行', 'code'=>'BOS'],
            '中国邮政' => ['name' => '中国邮储银行', 'code'=>'PSBC'],
            '深圳发展银行' => ['name' => '深圳发展银行', 'code'=>'SDB'],
            '徽商银行' => ['name' => '微商银行', 'code'=>'HSBANK'],
//            '农村信用社' => ['name' => '农村信用社', 'code'=>'RCC'],
        ];
        return isset($bank_list[$bankName]) ? $bank_list[$bankName] : false;
    }

    // 1413295644200102
    public function searchTransfer($data,$config){
        $data = [
            'merchantOrderNo' 	=> $data['order_number'],
            'merchantNo' => $config['partner_id'],
        ];
        ksort($data);
        $data['sign'] = md5($this->arrayToURL($data).$config['key']);
        $result = $this->_curl($config['request_url'].'/paygateway/querySettlementOrder',$data);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['biz']['orderStatus'])) {
            switch ($result['biz']['orderStatus']) {
                case 'Success' :
                    $status = 1;
                    break;
                case 'Fail' :
                    $status = 5;
                    break;
            }
        }else if($result['code'] == 'E2101'){
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 大栋代付：' . '请求地址：' . $url . '请求参数：' . json_encode($para) . '结果：' . $response);
        return $response;
    }

    public function callback()
    {
//        $params = file_get_contents("php://input");
//        $params = json_decode($params, true);
//        $data = $params['biz'];
//        $orderInfos = oo::withdraw()->getOrderByOrderId($data['merchantOrderNo']);
//        if(!$orderInfos){
//            die('订单不存在！');
//        }
//        if($orderInfos['withdraw_status'] != 0){
//            die('订单已结束！');
//        }
//        $updateData = [
//            'verified_time' => date('Y-m-d H:i:s', $data['ctime'])
//        ];
//        // 处理提现回调
//        if ($data['orderStatus'] == 'Success') {
//
//            $status = 1;
//
//        } elseif($data['orderStatus'] == 'Fail'){
//
//            $status = 5;
//
//        }else{
//            return ;
//        }
//
//        $updateData['status'] = $status;
//        oo::withdraw()->updateOrder($data['api_sn'], $updateData);
//        if ($orderInfos['exchange_type'] == 'user') {
//
//            oo::db('log_comm')->query(sprintf("UPDATE exchange SET withdraw_status = %s WHERE id = %s", $status, $orderInfos['exchange_id']));
//
//        } elseif ($orderInfos['exchange_type'] == 'agent') {
//
//            oo::db('jinliu_agent2')->query(sprintf("UPDATE spread_tx SET pay_status = %s , pay_time = '%s' WHERE tx_id = %s", $status, date('Y-m-d H:i:s'), $orderInfos['exchange_id']));
//
//        }

        echo 'SUCCESS';exit;

    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/dadong.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}