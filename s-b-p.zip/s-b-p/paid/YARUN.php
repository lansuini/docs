<?php

/**
 * DPay(亚润)代付
 */
class YARUN
{

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];
        $datas = [
            'mcht_no' => $config['partner_id'],
            'orderid' => $params['order_num'],
            'total_fee' => $exchangeInfos['amount'],
            'sendip' => fn::getip(),
            'notify_url' => urlencode($config['url_notify']),
            'accounttype' => 0,
            'bank_cardno' => $bankInfos['bank_num'],
            'nonce_str' => time(),
            'sendtime' => date('Y-m-d H:m:s'),
            'bank_user_name' => $bankInfos['user_name'],
//            "bank_code"  => $bankInfos['bank_code'],// $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
//            "bank_name"=>$bankInfos['bank_name'],
        ];
        $datas['sign'] = $this->_signData($datas, $config['key']);
        return $datas;
    }


    public function _signData($data, $apikey)
    {
        ksort($data);
        $md5str = "";
        foreach ($data as $key => $val) {
            if ($val && $key != 'sign') {
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $sign = md5($md5str . "key=" . $apikey);

        return $sign;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config)
    {
        $dataArr = $this->_parseParams($params, $config);

        if($e = oo::withdraw()->error($params,$dataArr)){
            return $e;
        }

        $result = $this->_curl($config['request_url'] . '/api/order/pay', $dataArr);

        $resqDataArray = json_decode($result, true);

        if (isset($resqDataArray['code']) && $resqDataArray['code'] != '0') {
            $status = false;
            $withdraw_status = 5;
        } else {
            $status = true;
            $withdraw_status = 1;
        }
        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' => $resqDataArray['out_trade_id'],
            'msg' => $resqDataArray['msg'] ?? '',
        ];
        return $res;
    }


    // 查询代付结果
    public function searchTransfer($data, $config)
    {
        $data = [
            'sendip' =>fn::getip(),
            'mcht_no' => $config['partner_id'],
            'sendtime' => date('YmdHms'),
            "orderid" 	=> $data['order_number'],
        ];
        $data['sign'] = $this->_signData($data,$config['key']);
        //查询 必须 GET请求
        $result = $this->_curl($config['request_url'].'/api/order/searchOrderState',$data);
        $result = json_decode($result,true);
        if(isset($result['code']) && $result['code'] != 0){
            $status = 5;
        }else{
            switch ($result['status']){
                case 1: $status = 1;break;
                case 3: $status = 2;break;
                default : $status = 5;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para)
    {
        $data_string = json_encode($para, JSON_UNESCAPED_UNICODE);
        $data_string = str_replace("\\/", "/", $data_string);//去除转义问题
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data_string)
            )
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
//        var_dump($test,$response);
        return $response;

    }

    public function callback()
    {
        $params = file_get_contents('php://input');


        $this->addLog('亚润代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '参数：' . $params);

        if (!$params)
            die('参数错误！');
        $data = json_decode($params, true);
//        print_r($data);
        if (!$data || !$data['sign']) {
            die('参数或签名不通过！');
        }

        $platform = fn::get('platform');
        $pSql = sprintf("SELECT * FROM transfer_config WHERE code = '%s'", $platform);
        $platConf = oo::db('log_comm')->getOne($pSql);

        if (!$this->verifySign($data, $data['sign'], $platConf['key'])) {
            die('验签不通过！');
        }
        $orderInfos = oo::withdraw()->getOrderByOrderId($data['out_order_no']);
//        print_r($orderInfos);
        if (!$orderInfos) {
            die('订单不存在！');
        }
        if ($orderInfos['withdraw_status'] != 0) {
            die('订单已结束！');
        }
        $updateData = [
            'verified_time' => date('Y-m-d H:i:s')
        ];
        // 处理提现回调
        // status  1 成功   5 失败   2 转账中
        if ($data['code'] == 0) {
            $status = 1;
        } else {
            $status = 5;
        }
        $updateData['status'] = $status;
        oo::withdraw()->updateOrder($data['out_order_no'], $updateData);
        if ($orderInfos['exchange_type'] == 'user') {
            $p = oo::db('log_comm')->query(sprintf("UPDATE exchange SET withdraw_status = %s WHERE id = %s", $status, $orderInfos['exchange_id']));
        } elseif ($orderInfos['exchange_type'] == 'agent') {
            $p = oo::db('jinliu_agent2')->query(sprintf("UPDATE spread_tx SET pay_status = %s , pay_time = '%s' WHERE tx_id = %s", $status, date('Y-m-d H:i:s'), $orderInfos['exchange_id']));
        }
        if (isset($data['msg']) && $data['msg']) {
            oo::db('log_comm')->query(sprintf("UPDATE exchange SET remark = %s WHERE id = %s", $data['msg'], $p['id']));
        }
        echo 'success';
        exit;
    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/yarunpay.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    public function verifySign($data, $sign, $key)
    {
        unset($data['sign']);
        if ($sign != $this->_signData($data, $key)) {
            return false;
        }
        return true;

    }
}