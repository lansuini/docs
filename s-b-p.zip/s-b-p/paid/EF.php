<?php
/**
 * 唐朝易付代付
 */
header("Content-EFpe:text/html;charset=utf-8");
class EF {
    /**
     * 配置
     */
    private $config;
    /**
     * 商户号
     */
    private $user_id;


    /**
     * md5key
     */
    private $md5Key;

    /**
     * 请求地址
     */
    private $apiUrl;

    /**
     * 机构号
     */
    private $channel_code;//支付通道编码 


    /**
     * 实例化
     */
    public function __construct()
    {
        $this->config = cfg::comm('pay');
        $this->user_id  = $this->config['EF']['user_id'];
        $this->channel_code = $this->config['EF']['channel_code'];
        $this->md5Key   = $this->config['EF']['md5_key'];
        $this->apiUrl  = $this->config['EF']['api_url'];
    }

    public function _initData($config){
        $this->config = $config;
        $this->user_id  = $this->config['partner_id'];
        $this->channel_code = $this->config['request_code'];
        $this->md5Key   = $this->config['key'];
        $this->apiUrl  = $this->config['request_url'];
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $bank_name = $bankInfos['bank_name'];
        $data = [
            "user_id" => $this->user_id,
            "channel_code" => $this->channel_code,
            "amount" => $exchangeInfos['amount'],
            //"order_id" => $params['order_num'],
            "bank_settle_name" => $bankInfos['bank_name'],
            "bank_name" =>$bankInfos['bank_name'],
            "bank_card_no" => $bankInfos['bank_num'],
            "bank_card_name" => $bankInfos['user_name'],
        ];
        $data['sign'] = $this->_createSign($data);
        return $data;
    }

    /**
     * 生成sign
     */
    private function _createSign($data)
    {
        unset($data['bank_settle_name']);
        unset($data['bank_name']);
        unset($data['bank_card_name']);
        ksort($data);
        $string = '';
        foreach ($data as $key=>$val)
        {
            $string = $string?$string.'&'.$key.'='.$val:$key.'='.$val;
        }
        $string = $string.$this->md5Key;
        $md5_str = md5($string);
        return $md5_str;
    }

    public function _httpUrl($data)
    {
        $post_string = http_build_query($data);
        //初始化 curl
        $ch = curl_init();
        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config = [])
    {
        if($config) {
            $this->_initData($config);
            $this->apiUrl .= '/withdraw.interface';
        }
        $data = $this->_parseParams($params);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $http_result = $this->_httpUrl($data);
        $result = json_decode($http_result,true);
        //var_dump($result);exit;
        $status = true;
        $withdraw_status = 4;
        if(isset($result['resp_code']) && !in_array($result['resp_code'],[1002])){
            $status = false;
        }
        if(!isset($result['resp_code'])){
            $withdraw_status = 1;
        }elseif(!in_array($result['resp_code'],[1002])){
            $withdraw_status = 5;
        }
        $res = [
            'status'          => $status,
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['sys_order_no'] ?? '',
            'msg'             => $result['resp_info'],
        ];
        return $res;
    }

    private function _getErrorStr($code)
    {
        $error =  [
            20001 => '数据中心当前不可用',
            20002 => '数据中心服务状态异常',
            50001 => '只接受POST请求',
            50002 => '缺少参数',
            50003 => '错误的参数',
            50004 => '商户信息不存在',
            50005 => '系统未记录商户密钥，请联系上游平台解决',
            50006 => '签名验证失败',
            50007 => '支付通道未开通',
            50008 => '用户支付通道手续费率存在异常，请联系上游平台解决',
            50009 => '无法生成订单，订单金额将导致商户余额超限',
            50010 => '无法生成订单，订单金额将导致平台余额超限',
            50011 => '机构信息缺失，请联系上游平台解决',
            50012 => '支付平台帐户信息缺失，请联系上游平台解决',
            50013 => '交易请求未能提交到渠道',
            50014 => '交易请求已提交，但渠道未受理该请求，创建交易失',
            50015 => '交易金额低于最低要求',
            50016 => '交易金额高于最大单笔限制',
            50104 => '交易单号不存在',
            50105 => '不可查询其他商户的订单信息',

        ];

        return $error[$code];
    }

    // EBDFGMLZ20190513155932D5AC97E861
    public function searchTransfer($data,$config,$p){
        $this->md5Key = $config['key'];
        $this->apiUrl = $config['request_url'].'/checkwithdraw.interface';
        $datas = [
            'user_id' => $config['partner_id'],
            "sys_order_no" 	=> $p['out_order_num'],
        ];
        $datas['sign'] = $this->_createSign($datas);
        $result = $this->_httpUrl($datas);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['resp_code'])) {
            switch ($result['resp_code']) {
                case '1005' :
                    $status = 1;
                    break;
                case '1007' :
                    $status = 5;
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

}