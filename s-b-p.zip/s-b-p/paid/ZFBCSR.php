<?php

/**
 * 支付宝CSR公钥证书代付
 */
class ZFBCSR {
	/**
	 * cid
	 */
	private $cid;
	/**
	 * 密钥key
	 */
	private $apikey;

	/**
	 * marchant 私钥
	 */
	private $privateKey;

	/**
	 * 请求地址
	 */
	private $apiUrl;

	/**
	 * 回调地址，可有可无，文档没有说明若有回调地址的情况
	 */
	private $callbackUrl;

    /**
     * 配置信息
     */
    private $config;

	/**
	 * 实例化
	 */
	public function __construct()
	{
	}

	public function initData($config){
	    $this->config = $config;
		$this->apiUrl 			   = $config['request_url'];
		$this->cid  			   = $config['partner_id'];
		$this->privateKey   	   = $config['key'];
		$this->rsa_third_pub_key   = $config['pub_key'];
		$this->apiVersion   	   = $config['ver'];
		$this->signType   		   = 'RSA2';
		$this->postCharset   	   = 'UTF-8';
		$this->format   		   = 'json';
		$this->timestamp 		   = date('Y-m-d H:i:s');
    }

    public function get_crt_data($file_name, $crt_str){
        if(!empty($crt_str)){
            $pub_data = $crt_str;
        }else{
            $crt_dir = dirname(__FILE__);
            $pub_data = file_get_contents($crt_dir.'/crt/'.$file_name);
        }
        preg_match_all("/-----BEGIN CERTIFICATE-----(.*?)-----END CERTIFICATE-----/si", $pub_data, $matches);
        if(empty($matches)){
            return '';
        }
        $crt_data = [];
        foreach ($matches[0] as $k=>$v){
            $pub_res = openssl_x509_read($v);
            $pub_crt = openssl_x509_parse($pub_res);
            $crt_data[] = $pub_crt;
            openssl_x509_free($pub_res);
        }
        return count($crt_data) == 1 ? $crt_data[0] : $crt_data;
    }

    //获取根证书sn
    public function get_root_sn($file_name){
	    $pub_data = $this->get_crt_data($file_name, $this->config['alipay_root_cert']);
	    $sn_arr = [];
        foreach ($pub_data as $v){
            if(stripos($v['signatureTypeSN'], 'RSA-SHA') === FALSE){
                continue;
            }
            $tmp_arr = [];
            $issuer = array_reverse($v['issuer']);
            foreach ($issuer as $k1=>$v1){
                $tmp_arr[] = "$k1=$v1";
            }
            $str = implode(",", $tmp_arr);
            $sn_arr[] = md5($str.$v['serialNumber']);
        }
        return implode('_', $sn_arr);
    }

    //获取应用sn
    public function get_app_sn($file_name){
        $pub_data = $this->get_crt_data($file_name, $this->config['app_public_cert']);
        $issuer = array_reverse($pub_data['issuer']);
        foreach ($issuer as $k1=>$v1){
            $tmp_arr[] = "$k1=$v1";
        }
        $str = implode(",", $tmp_arr);
        return md5($str.$pub_data['serialNumber']);
    }

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params)
	{
	    $root_crt = $this->get_root_sn($this->cid.'alipayRootCert.crt');
	    $app_crt = $this->get_app_sn($this->cid.'appCertPublicKey.crt');
		$exchangeInfos = $params['exchange_infos'];
		$userInfos 	   = $params['bank_infos'];
		$biz_content   = [
			"out_biz_no" 	  => $params['order_num'],
			"payee_type" 	  => "ALIPAY_LOGONID",
			"payee_account"   =>$userInfos['ali'],
			"amount" 		  => sprintf("%.2f", $exchangeInfos['amount']),
            "payer_show_name" => $this->config['token'] ? $this->config['token'] : '提现',
			"payee_real_name" => $userInfos['real_name'],
            "remark" 		  => $this->config['terminal'] ? $this->config['terminal'] : "转账备注"
		];
		$datas = array(
			"app_id" 		=> $this ->cid,
			"method" 		=> 'alipay.fund.trans.toaccount.transfer',
			"charset" 		=> $this ->postCharset,
			"sign_type" 	=> $this ->signType,
			"app_cert_sn" => $app_crt,
			"alipay_root_cert_sn" => $root_crt,
			"timestamp" 	=> $this->timestamp,//yyyy-MM-dd HH:mm:ss
			"biz_content" 	=> json_encode($biz_content),
			"version" 		=> $this ->apiVersion,
		);
		return $datas;
	}

	/**
	 * 生成签名
	 */
    private function sign($data) {
		ksort($data);
        $string = '';
        if(is_array($data)){
        	foreach ($data as $k => $v){
	            if ($v != '' && $v != null && $k != 'sign'){
	                $string = $string . $k . '=' . $v . '&';
	            }
        	}
        }
      
        $string = substr($string, 0, strlen($string) - 1);
		$priKey=$this->privateKey;
		$res = "-----BEGIN RSA PRIVATE KEY-----\n" .
				wordwrap($priKey, 64, "\n", true) .
				"\n-----END RSA PRIVATE KEY-----";
		($res) or die('您使用的私钥格式错误，请检查私钥配置'); 
		if ("RSA2" == $this->signType) {
			openssl_sign($string, $sign, $res, OPENSSL_ALGO_SHA256);
		} else {
			openssl_sign($string, $sign, $res);
		}
		$sign = base64_encode($sign);
		return $sign;
	}


	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return array
	 */
	public function withdraw($params, $config)
	{
        $this->initData($config);
	    $data=$this->_parseParams($params);
		$data['sign'] = $this->sign($data);
		ksort($data);
		$post_string = http_build_query($data);
		//初始化 curl
		$ch = curl_init();
		$ch = curl_init($this->apiUrl);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		$result = curl_exec($ch);
		curl_close($ch);
		//超时默认成功处理中
        if(!$result){
            $res = [
                'status' 		  => true,
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			  => '超时默认成功',
            ];
            return $res;
        }
        $tmpResult = iconv('GBK', 'UTF-8', $result);
        file_put_contents("/data/logs/php/zfbdb.txt", $post_string."\n".$result."\n\n", FILE_APPEND);
        $result = mb_convert_encoding($result,'UTF-8');
		$arr = json_decode($result, true);
		$tmpArr = json_decode($tmpResult, true);
        file_put_contents("/data/logs/php/zfbdb.txt", '转码后：'."\n".$result."\n\n", FILE_APPEND);
        if(!$arr){
            $res = [
                'status' 		  => true,
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			  => '超时默认成功',
            ];
            return $res;
        }
		$result=$arr['alipay_fund_trans_toaccount_transfer_response'];
		$res = [
			'status' 		  => $result['code'] == '10000' ? true : false,
			'withdraw_status' => $result['code'] == '10000' ? 4 : 5,
			'out_order_num'   => $result['out_biz_no'] ?? '',
			'msg' 			  => $result['code'] != '10000' ? $this->_getErrorStr($result['code']) .$tmpArr['alipay_fund_trans_toaccount_transfer_response']['sub_msg'] : "Success",
		];
		return $res;
	}

	private function _parseRe($res)
	{
		$res = preg_split("/\s+/",$res);

		foreach ($res as $v) {
		   $result[substr($v, 0, strpos($v, '='))] = substr($v, strpos($v, '=') + 1);
		}

		return $result;
	}

	// 8227686044416981   企业支付宝太多，暂时无法知道是哪个
    public function searchTransfer($order, $config){
	    $data = $this->searchParam($order['order_number'], $config);
        ksort($data);
        $post_string = http_build_query($data);
        //初始化 curl
        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $result = curl_exec($ch);
        curl_close($ch);
        file_put_contents("/data/logs/php/zfbdb.txt", $post_string."\n".$result."\n\n", FILE_APPEND);
        if(!$result){
            return ['status' => 2];
        }
//        $result = iconv('GBK', 'UTF-8', $result);
        $result = mb_convert_encoding($result,'UTF-8');
        $arr = json_decode($result, true);
        if(!$arr){
            return ['status' => 2];
        }
        $result=$arr['alipay_fund_trans_order_query_response'];
        if($result['code'] == '40004'){//转账订单号不存在，可能是转账还在处理中,也可能是转账处理失败
            return ['status' => 6];// 转账失败，transfer2.php为失败，transfer.php为处理中
        }
        $status = 2;
        if(isset($result['status'])) {
            switch ($result['status']) {
                case 'SUCCESS' ://成功
                    $status = 1;
                    break;
                case 'FAIL' ://失败
                    $status = 5;
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

	private function searchParam($order_num, $config){
	    $this->initData($config);
        $biz_content   = [
            "out_biz_no" 	  => $order_num,
//            "out_biz_no" 	  => '7697149206200029',
        ];
        $root_crt = $this->get_root_sn($this->cid.'alipayRootCert.crt');
        $app_crt = $this->get_app_sn($this->cid.'appCertPublicKey.crt');
        $datas = array(
            "app_id" 		=> $this->cid,
            "method" 		=> 'alipay.fund.trans.order.query',
            "charset" 		=> $this->postCharset,
            "sign_type" 	=> $this->signType,
            "app_cert_sn" => $app_crt,
            "alipay_root_cert_sn" => $root_crt,
            "timestamp" 	=> $this->timestamp,//yyyy-MM-dd HH:mm:ss
            "version" 		=> $this->apiVersion ,
            "biz_content" 	=> json_encode($biz_content),
        );
        $datas['sign'] = $this->sign($datas);
        return $datas;
    }

	private function _getErrorStr($code)
	{
		$error =  [
			20000 => '服务不可用',
			20001 => '授权权限不足',
			40001 => '缺少必选参数',
			40002 => '非法的参数',
			40004 => '业务处理失败',
			40006 => '权限不足',
		];
		return $error[$code];
	}
}