<?php

/**
 * 小鼎支付宝代付
 */
class XDINGZFB {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $userInfos 	   = $params['bank_infos'];
        if(empty($userInfos['ali']) || empty($userInfos['real_name'])){
            return false;
        }
        //使用测试账号
//        $userInfos['ali'] = '13602657124';
//        $userInfos['real_name'] = '史狄锋';
//        $exchangeInfos['amount'] = 10;
//        $exchangeInfos['mobile'] = "17810648053";
        $datas = [
            'mchId' => $config['partner_id'],//商户号
            'mchOrderNo' => $params['order_num'],//商户订单号
            'amount' => bcmul($exchangeInfos['amount'], '100'), // 代付金额,单位:分
            'accountName' => $userInfos['real_name'],//支付宝姓名
            'accountNo' => $userInfos['ali'],//支付宝账户
            'bankName' => '支付宝',//开户行
            'remark' => '代付备注',//备注
            'reqTime' => date('YmdHis'),//请求时间
        ];
        $datas['sign'] = $this->getSign($datas, $config['key']);
//        $datas['notifyURL'] = $config['url_notify'];//回调地址不参与签名
        return $datas;
    }

    public function getSign($array, $key) {
        ksort($array);
        $signPars = "";
        foreach($array as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $sign = strtoupper(md5($signPars.'key='.$key));
        return $sign;
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定支付宝账户信息',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/api/agentpay/apply', $data);
        //status 状态:0-待处理,1-处理中,2-成功,3-失败
        //{"transMsg":"代付异常","fee":100,"sign":"3F0461A876EC4A3B76B931BE510360C8","resCode":"SUCCESS","retCode":"SUCCESS","agentpayOrderId":"G01202005031445309470006","retMsg":"","status":3}
        //{"fee":100,"sign":"E00CBF945A506340299ED50C70B45379","resCode":"SUCCESS","retCode":"SUCCESS","agentpayOrderId":"G01202005022315506600004","retMsg":"","status":3}
        //{"fee":100,"sign":"034A55B033D0A1F9EC1131AED54F2C2D","resCode":"SUCCESS","retCode":"SUCCESS","agentpayOrderId":"G01202005051702500870001","retMsg":"","status":1}
        //{"retCode":"FAIL","retMsg":"验证签名不通过."}
        //{"retCode":"FAIL","retMsg":"可用余额不足"}
        $result = json_decode($result,true);
        $msg = '';
        if(isset($result['retCode']) && $result['retCode'] == "FAIL"){//代付失败
            $status = false;
            $withdraw_status = 5;
            $msg = $result['retMsg'] ? $result['retMsg'] : '';
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['agentpayOrderId'] ? $result['agentpayOrderId'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data,$config){
        $req_data = [
            'mchId' => $config['partner_id'],
            'mchOrderNo' => $data['order_number'],
            'reqTime' => date('YmdHis'),
        ];
        $req_data['sign'] = $this->getSign($req_data, $config['key']);
        $result = $this->_curl($config['request_url'].'/api/agentpay/query_order', $req_data);
        $result = json_decode($result,true);
        //{"fee":"100","amount":"1000","mchOrderNo":"3362967870200029","transMsg":"","status":"2","retCode":"SUCCESS",
        //  "agentpayOrderId":"G01202005051702500870001","sign":"AC9FA09EEB06459EC0FAD4EA5DE3CA48"}
        //{"fee":"100","amount":"1000","mchOrderNo":"6425356769200029","transMsg":"","status":"3","retCode":"SUCCESS","
        //  agentpayOrderId":"G01202005022315506600004","sign":"7F119743056F7BED03F1AAB9BB9C4B87"}
        //{"retCode":"FAIL","retMsg":"代付订单不存在"}
        $status = 2;
        if(isset($result['retCode']) && $result['retCode'] == "SUCCESS") {
            //状态:0-待处理,1-处理中,2-成功,3-失败
            switch ($result['status']) {
                case "2"://代付完成
                    $status = 1;
                    break;
                case "3"://代付失败
                    $status = 5;
                    break;
            }
        }else if($result['retCode'] == "FAIL" && $result['retMsg'] == '代付订单不存在'){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 小鼎支付宝代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($para) . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        exit('SUCCESS');
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/xdingzfb.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}