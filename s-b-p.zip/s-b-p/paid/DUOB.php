<?php

/**
 * 多宝
 */
class DUOB {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];
        $datas = [
            'parter' => $config['partner_id'],
            'orderid' => $params['order_num'],
            'value' => intval($exchangeInfos['amount']),
            'payeebank' => $bank_name,
            'account' => $bankInfos['bank_num'],
            'cardname' => $bankInfos['user_name'],
        ];
        $datas['sign'] = md5($this->arrayToURL($datas).$config['key']);
        $datas['signtype'] = 'MD5';
        return $datas;
    }

    public function arrayToURL($data) {
        $signPars = "";
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        return $signPars;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/interface/transfer/index.aspx',$data);
        $result = explode('&',$result);
        if(isset($result[0]) && $result[0] == 'error'){
            $status = false;
            $withdraw_status = 5;
            $msg = $result[1];
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => '',
            'msg' 			  => $msg ?? '',
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>'ICBC' , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>'ABC' , 'name' => '中国农业银行'],
            'BOC' => ['code'=>'BOC' , 'name' => '中国银行'],
            'CCB' => ['code'=>'CCB' , 'name' => '中国建设银行'],
            'BCM' => ['code'=>'BCM' , 'name' => '中国交通银行'],
            'CNCB' => ['code'=>'CNCB' , 'name' => '中信银行'],
            'CEB' => ['code'=>'CEB' , 'name' => '中国光大银行'],
            'HXB' => ['code'=>'HXB' , 'name' => '华夏银行'],
            'CMBC' => ['code'=>'CMBC' , 'name' => '中国民生银行'],
            'GDB' => ['code'=>'GDB' , 'name' => '广东发展银行'],
            'PAB' => ['code'=>'PAB' , 'name' => '平安银行'],
            'CMB' => ['code'=>'CMB' , 'name' => '招商银行'],
            'CIB' => ['code'=>'CIB' , 'name' => '兴业银行'],
            'SPDB' => ['code'=>'SPDB' , 'name' => '浦发银行'],
//            'BCCB' => ['code'=>'BCCB' , 'name' => '北京银行'],
//            'SHB' => ['code'=>'SHB' , 'name' => '上海银行'],
            'PSBC' => ['code'=>'PSBC' , 'name' => '中国邮政储蓄银行'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
//            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    // 1413295644200102
    public function searchTransfer($data,$config){
        $data = [
            'disOrderid' 	=> $data['order_number'],
            'parter' => $config['partner_id'],
        ];
        $data['sign'] = md5($this->arrayToURL($data).$config['key']);
        $result = $this->_curl($config['request_url'].'/interface/transfer/query.aspx',$data);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['status'])) {
            switch ($result['status']) {
                case 'success' :
                    $status = 1;
                    break;
                case 'fail' :
                    $status = 5;
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;

    }
}