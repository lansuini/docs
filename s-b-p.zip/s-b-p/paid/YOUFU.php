<?php
/**
 * 友付代付
 * @author Taylor 2019-04-08
 */
class YOUFU {
    /**
     * 配置
     */
    private $config;
    /**
     * 商户号
     */
    private $app_key;


    /**
     * md5key
     */
    private $md5_key;

    /**
     * 请求地址
     */
    private $api_url;

    /**
     * 回调地址
     */
    private $callback_url;

    /**
     * 实例化
     */
    public function __construct()
    {
        //config/config.pay.php
        $this->config = cfg::comm('pay');
        $this->api_url  = $this->config['YOUFU']['api_url'];//请求地址
        $this->app_key  = $this->config['YOUFU']['pay_merberid'];//商户号
        $this->md5_key   = $this->config['YOUFU']['md5_key'];//密钥
        $this->callback_url   = $this->config['YOUFU']['callback_url'];//回调地址
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];//提现订单信息
        $bankInfos 	   = $params['bank_infos'];//银行信息
//        $bank_name = $bankInfos['bank_name'];
//        $bankInfos['bank_code'] = "ABC";
        $bank_code = $this->_getBankCode($bankInfos['bank_code']);
//        使用测试账号
//        $bankInfos['user_name'] = "黄毅峰";
//        $bankInfos['bank_num'] = "6230520830036198578";
//        $exchangeInfos['mobile'] = "17810648053";
//        $exchangeInfos['amount'] = 1;
        $data = [
            "version" => "2.0",//版本号
            "charset" => "UTF-8",//字符集
            "spid" => $this->app_key,//商户号
            "spbillno" => $params['order_num'],//商户代付单号
//            "amount" => sprintf("%.2f", $exchangeInfos['amount']),
            "tranAmt" => $exchangeInfos['amount'] * 100,//交易金额，单位为分
            "acctName"=> $bankInfos['user_name'],//收款人姓名
            "acctId"=> $bankInfos['bank_num'],//收款人账号
            "acctType"=> "0",//账号类型，0-借记卡 1-贷记卡 2-对公 暂不支持贷记卡
            "certType"=> "1",//1-身份证 对私必传
            "certId"=> "422823197401237843",//证件号码 对私必传
            "mobile"=> $exchangeInfos['mobile'],//银行预留手机号
            "bankName"=> $bank_code ? $bank_code[0] : "",//开户行名称
            "bankCode"=> $bank_code ? $bank_code[1] : "",//银行编码
            "accountNo"=> $this->get_account_no($params),//账户编号
            "notifyUrl"=> $this->callback_url,//后台通知地址
            "signType"=> "MD5",//签名类型
        ];
        $data['sign'] = $this->_createSign($data);
        $return = $this->toXml($data);

        return $return;
    }

    //获取账户编号，因为存在多账户问题
    private function get_account_no($params){
        $data = [
            "version" => "2.0",//版本号
            "charset" => "UTF-8",//字符集
            "spid" => $this->app_key,//商户号
            "spbillno" => 'YE'.$params['order_num'],//商户代付单号
            "signType"=> "MD5",//签名类型
        ];
        $data['sign'] = $this->_createSign($data);
        $return = $this->toXml($data);
        $url = 'https://paymentv2.surperpay.com/payment/balance';
        $http_result = $this->_httpUrl($return, $url);
        if($http_result['retcode'] == '0'){
            $account = $http_result['accountDetail'];
            if(!empty($account[0]['accountNo'])){//二个账户，二维数组
                $acc_no = $account[0]['accountNo'];
                $acc_amount = $account[0]['amount'];
                foreach($account as $d){
                    if($d['amount'] > $acc_amount){
                        $acc_no = $d['accountNo'];
                        $acc_amount = $d['amount'];
                    }
                }
                return $acc_no;
            }else{//只有一个账户
                return $account['accountNo'];
            }
        }
    }

    /**
     * 生成sign
     */
    private function _createSign($data)
    {
//        $data = [
//            "version" => "2.0",
//            "charset" => "UTF-8",
//            "spid" => "C1554533772018",
//            "spbillno" => "5028468245200029",
//            "tranAmt" => 100,
//            "acctName" => "黄毅峰",
//            "acctId" => "6230520830036198578",
//            "acctType" => "0",
//            "certType" => "1",
//            "certId" => "422823197401237843",
//            "mobile" => "17810648053",
//            "bankName"=> "农业银行",
//            "bankCode" => "1002",
//            "accountNo"=> "MP-90243234",
//            "notifyUrl"=> "https://analysis-api.hniba.com/gateway.php?_env=product&_sid=4100&mod=callback&act=wuxingPay",
//            "signType"=> "MD5",
//        ];
        if(isset($data['signType'])){
            unset($data['signType']);
        }
        ksort($data);
        $string = '';
        foreach ($data as $key=>$val)
        {
            if ($val != ''){
                $string = $string ? $string.'&'.$key.'='.$val : $key.'='.$val;
            }
        }
        $md5_str = md5($string.'&key='.$this->md5_key);

        return strtoupper($md5_str);
    }

    /**
     * 将数据转为XML
     */
    public function toXml(array $array){
        $xml = '<xml>';
        forEach($array as $k=>$v){
            $xml.='<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
        }
        $xml.='</xml>';
        return $xml;
    }

    //将XML转为array
    public function xmlToArray($xml){
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $values;
    }

    /**
     * XML解析成数组
     */
    public function parseXML($xmlSrc){
        if(empty($xmlSrc)){
            return false;
        }
        $array = array();
        $xml = simplexml_load_string($xmlSrc);
        $encode = $this->getXmlEncode($xmlSrc);
        if($xml && $xml->children()) {
            foreach ($xml->children() as $node){
                //有子节点
                if($node->children()) {
                    $k = $node->getName();
                    $nodeXml = $node->asXML();
                    $v = $this->parseXML($nodeXml);
                } else {
                    $k = $node->getName();
                    $v = (string)$node;
                }
                if($encode!="" && strpos($encode,"UTF-8") === FALSE ) {
                    $k = iconv("UTF-8", $encode, $k);
                    $v = iconv("UTF-8", $encode, $v);
                }
                $array[$k] = $v;
            }
        }
        return $array;
    }

    //获取xml编码
    public function getXmlEncode($xml) {
        $ret = preg_match ("/<?xml[^>]* encoding=\"(.*)\"[^>]* ?>/i", $xml, $arr);
        if($ret) {
            return strtoupper ( $arr[1] );
        } else {
            return "";
        }
    }

    public function _httpUrl($xmlData, $url)
    {
        $header[] = "Content-type:text/xml";
        $header[] = "charset:utf-8";
        $header[] = "User-Agent:Mozilla/5.0 (Windows NT 6.2; Win64; x64) 		AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";
        $ch = curl_init ($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $xmlData);
        $response = curl_exec($ch);
        if(!empty($response)){
            return $this->xmlToArray($response);
        }else{
            return false;
        }
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params)
    {
        $data = $this->_parseParams($params);
        //var_dump($data);exit;

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $http_result = $this->_httpUrl($data, $this->api_url);
//        $http_result = ["retcode"=> "10040", "retmsg"=> "请求IP错误"];
//        $http_result = ["retcode"=> "0", "retmsg"=> "操作成功", "version"=> "2.0", "charset"=> "UTF-8", "signType"=> "MD5", "spid"=> "C1554533772018", "spbillno"=> "4418314084200029", "transactionId"=> "267688483445800960", "tranAmt"=> "100", "result"=> "processreview", "msg"=> "转账申请成功", "sign"=> "E07E4FDDE7D32B898FC3A8FC115625FC"];

        if ($http_result['retcode'] == 0 && isset($http_result['sign'])){
            //提交代付订单成功
            $res = [
                'status' => true ,
                'withdraw_status' => 4,
                'out_order_num' => $http_result['transactionId'],
                'msg' => 'success',
            ];
            return $res;
        }else{
            //调用第三方代付失败
            $res = [
                'status' => false,
                'withdraw_status' => 5,
                'out_order_num' => '',
                'msg' =>$http_result['retcode'].":".$http_result['retmsg'],
            ];
            return $res;
        }
    }

    public function verifySign($data)
    {
        $return_sign = $data['sign'];
        unset($data['sign']);
        $sign = $this->_createSign($data);
        if ($return_sign == $sign){
            return true;
        }
        return false;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['工商银行', 1001],
            'ABC' => ['农业银行', 1002],
            'CCB' => ['建设银行', 1004],
            'SPDB' => ['浦发银行', 1014],
            'CIB' => ['兴业银行', 1029],
            'CMBC' => ['民生银行', 1010],
            'BCM' => ['交通银行', 1005],
            'CNCB' => ['中信银行', 1007],
            'CEB' => ['光大银行', 1008],
            'BCCB' => ['北京银行', 1016],
            'CMB' => ['招商银行', 1012],
            'GDB' => ['广发银行', 1017],
            'SHB' => ['上海银行', 1025],
            'BOC' => ['中国银行', 1003],
            'HXB' => ['华夏银行', 1009],
            'PAB' => ['平安银行', 1011],
            'PSBC' => ['邮储银行', 1006],
//            'SDB' => ['深圳发展银行', 1006],
//            'RCC' => ['农村信用社', 1006],
//            'HSB' => ['微商银行', 1006],
        ];
        return $bank_list[$code];
//        $code = '';
//        foreach($bank_list as $key=>$val)
//        {
//            if (trim($val) == trim($name)){
//                $code = $key;
//                break;
//            }
//        }
//        return $code;
    }

    private function _getErrorStr($code)
    {
        $error =  [
            1001 => '扣减金额大于可提现金额',
            1002 => '可结算金额不足',
            2001 => 'Ip白名单不存在',
            2002 => '参数为空',
            2003 => '签名错误',
            2004 => '商户不存在',
            2005 => '商户账户不存在',
            2006 => '账户被冻结',
            2007 => '订单重复',
            2009 => '业务未开通',
            2010 => '银行卡未设置白名单',
            2012 => '金额超限',
            2013 => '不支持的银行',
            9999 => '未知错误',
        ];

        return $error[$code];
    }


}