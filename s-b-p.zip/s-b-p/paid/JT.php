<?php
header("Content-type:text/html;charset=utf-8");
/**
 * 久通
 */
class JT {

    private $merNo;
    /**
     * 密钥key
     */
    private $key;

    /**
     * api_url
     */
    private $api_url;
    private $callBackUrl;
    private $remit_public_key_str;
    private $private_key_str;
    /**
     * 实例化
     */
    public function __construct()
    {
        $this->config = cfg::comm('pay');
        $this->merNo  = $this->config['JT']['merNo'];
        $this->key   = $this->config['JT']['key'];
        $this->api_url  = $this->config['JT']['api_url'];
        $this->remit_public_key_str  = $this->config['JT']['remit_public_key_str'];
        $this->callBackUrl  = $this->config['JT']['callBackUrl'];
        $this->private_key_str =  $this->config['JT']['private_key_str'];
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos     = $params['bank_infos'];
        // $bank_name = $bankInfos['bank_name'];
        // $bank_code = $this->_getBankCode($bank_name);

        $time = time();
        $data = [       
            "amount" => (string)($exchangeInfos['amount']*100),
            //"bankAccountName" => "陈亮亮",
            "bankAccountName" => $bankInfos['user_name'],
            "bankAccountNo" => $bankInfos['bank_num'],
            "bankCode" => $bankInfos['bank_code'],
            "callBackUrl" => $this->callBackUrl,
            "charset"  =>'UTF-8', 
            "merNo" => $this->merNo,
            "version" => 'V3.1.0.0',
            "orderNum" => $params['order_num'],     
        ]; 
        //echo $this->key;    
        //var_dump($data);
        $data['sign'] = $this->_sign($data,$this->key);
        return $data;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json 
     */
    public function withdraw($params)
    {
        $data = $this->_parseParams($params);
        $data_string = json_encode($data,JSON_UNESCAPED_UNICODE);
        $dataStr =$this->encode_pay($data_string,$this->remit_public_key_str);
        $param = 'data=' . urlencode($dataStr) . '&merchNo=' . $this->merNo . '&version=V3.1.0.0';
        //var_dump($param);

        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->api_url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        //var_dump($result);exit;
        $result = json_decode($result, true);
        $res = [
            'status' => $result['stateCode']=='00' ? 1 : 0,
            'withdraw_status' => ($result['stateCode']=='00') ? 4 : 5,
            'out_order_num' => $data['orderNum'],
            'msg' => $result['msg'],
        ];

        return $res;
    }

    /**
     * 生成sign
     */
    private function _sign($data, $key)
    {
        ksort($data);
        $sign = strtoupper(md5($this->json_encode_ex($data) . $key));
        return $sign;
    }

    //加密
    public function encode_pay($data,$remit_public_key_str){#加密//  
        $remit_public_key = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($remit_public_key_str,64) as $str){
            $remit_public_key .=  $str . "\r\n";
        }
        $remit_public_key .= "-----END PUBLIC KEY-----";   
        $pu_key =  openssl_pkey_get_public($remit_public_key);
        if ($pu_key == false){
            echo "打开密钥出错";
            die;
        }
        $encryptData = '';
        $crypto = '';
        foreach (str_split($data, 117) as $chunk) {            
            openssl_public_encrypt($chunk, $encryptData, $pu_key);  
            $crypto = $crypto . $encryptData;
        }

        $crypto = base64_encode($crypto);
        return $crypto;

    }

    public function verifySign($json)
    {   
        $private_key = "-----BEGIN PRIVATE KEY-----\r\n";
        foreach (str_split($this->private_key_str,64) as $str){
            $private_key .= $str . "\r\n";
        }
        $private_key .="-----END PRIVATE KEY-----";
        $data = decode($json,$private_key);
        $array = json_decode($data,true);       
        $sign_string = $array['sign'];
        ksort($array);
        $sign_array = array();
        foreach ($array as $k => $v) {
            if ($k !== 'sign'){
                $sign_array[$k] = $v;
            }
        }

        $md5 =  strtoupper(md5(json_encode($sign_array) . $this->key));
        if ($md5 == $sign_string){
            return $sign_array;
        }else{
            $result = array();
            $result['payResult'] = '99';
            $result['msg'] = '返回签名验证失败';
            return $result;
        }
    }

    public  function decode($data,$private_key_str)
    {  
        //读取秘钥
        $pr_key = openssl_pkey_get_private($private_key);
            
        if ($pr_key == false){
            echo "打开密钥出错";
            die;
        }
        $data = base64_decode($data);           
        $crypto = '';
        //分段解密   
        foreach (str_split($data, 128) as $chunk) {
            openssl_private_decrypt($chunk, $decryptData, $pr_key);
            $crypto .= $decryptData;
        }
        return $crypto;
    }

    //判断 php版本 编译成 json字符串
    function json_encode_ex($value){
         if (version_compare(PHP_VERSION,'5.4.0','<')){
            $str = json_encode($value);
            $str = preg_replace_callback("#\\\u([0-9a-f]{4})#i","replace_unicode_escape_sequence",$str);
            $str = stripslashes($str);
            return $str;
        }else{
            return json_encode($value,320);
        }
    }
    
    function replace_unicode_escape_sequence($match) {
        return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
    }

}