<?php

/**
 * 畅汇代付
 */
class CH {
	/**
	 * 密钥key
	 */
	private $cid;
	/**
	 * 密钥key
	 */
	private $apikey;

	/**
	 * marchant 私钥
	 */
	private $privateKey;

	/**
	 * 请求地址
	 */
	private $apiUrl;

	/**
	 * 回调地址，可有可无，文档没有说明若有回调地址的情况
	 */
	private $callbackUrl;

	/**
	 * 实例化
	 */
	public function __construct()
	{
		$this->config = cfg::comm('pay');
		$this->cid  = $this->config['CH']['cid'];
		$this->apikey   = $this->config['CH']['apikey'];
		$this->privateKey   = $this->config['CH']['rsa_owner_private_key'];
		$this->apiUrl  = $this->config['CH']['api_url'];
		$this->callbackUrl  = $this->config['CH']['callback_url'];
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params)
	{
		$exchangeInfos = $params['exchange_infos'];
		$bankInfos 	   = $params['bank_infos'];

		$data = [
			"p0_Cmd" => 'TransPay',
			"p1_MerId" => $this->cid,
			"p2_Order" => $params['order_num'],
			"p3_CardNo" => $bankInfos['bank_num'],
			"p4_BankName" => $bankInfos['bank_name'],
			"p5_AtName" => $bankInfos['user_name'],
			"p6_Amt" => sprintf("%.2f", $exchangeInfos['amount']),
			"pb_CusUserId" => $exchangeInfos['uid'],
			"pc_NewType" => 'PRIVATE',
			"pd_BranchBankName" => '',
			"pe_Province" => '',
			"pf_City" => '',
			"pg_Url" => $this->callbackUrl ? $this->callbackUrl : '',
		];

		// var_dump($data);exit;

		$data['hmac'] = $this->_createHmac($data);

		return $data;
	}

	/**
	 * 生成hmac
	 */
	private function _createHmac($data)
	{
		$merchantPrivateKey = chunk_split($this->privateKey, 64, "\n");
		$merchantPrivateKey = "-----BEGIN RSA PRIVATE KEY-----\n$merchantPrivateKey-----END RSA PRIVATE KEY-----\n";

		$str = '';
		foreach ($data as $key => $value) {
			$str .= $value;
		}

		$signature ='';

		openssl_sign($str, $signature, $merchantPrivateKey);

		return base64_encode($signature);
	}

	/**
	 * 解析返回的字符串
	 */
	private function _parseRe($res)
	{
		$res = preg_split("/\s+/",$res);

		foreach ($res as $v) {
		   $result[substr($v, 0, strpos($v, '='))] = substr($v, strpos($v, '=') + 1);
		}

		return $result;
	}

	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params)
	{
		$data = $this->_parseParams($params);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

		$post_string = http_build_query($data);
		// var_dump($post_string);exit;
		$ch = curl_init($this->apiUrl);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		$result = curl_exec($ch);
		curl_close($ch);

		$result = $this->_parseRe($result);

		// var_dump($result);exit;

		$res = [
			'status' => $result['r1_Code'] == '0000' ? true : false,
			'withdraw_status' => $result['r1_Code'] == '0000' ? 1 : 5,
			'out_order_num' => $result['r2_TrxId'] ?? '',
			'msg' => $result['r7_Desc'] == null ? $this->_getErrorStr($result['r1_Code']) : $result['r7_Desc'],
		];

		return $res;
	}

	private function _getErrorStr($code)
	{
		$error =  [
			1001 => '扣减金额大于可提现金额',
			1002 => '可结算金额不足',
			2001 => 'Ip白名单不存在',
			2002 => '参数为空',
			2003 => '签名错误',
			2004 => '商户不存在',
			2005 => '商户账户不存在',
			2006 => '账户被冻结',
			2007 => '订单重复',
			2009 => '业务未开通',
			2010 => '银行卡未设置白名单',
			2012 => '金额超限',
			2013 => '不支持的银行',
			9999 => '未知错误',
		];

		return $error[$code];
	}


}