<?php
/**
 * 迪奥代付
 */
class DIOR {
    protected $config;//代付通道配置
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {

    }

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){
        $data = $this->paraFilter($data);
        $data = $this->argSort($data);
        $data_signstr = "";
        foreach ($data as $k => $v) {
            $data_signstr .= $k . '=' . $v . '&';
        }
        $data_signstr .= 'key='.$this->config['app_secret'];
        return strtoupper(md5($data_signstr));
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return json
     */
    public function withdraw($params, $config){

        $this->config = $config;
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息
        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
        if(!$tmp_bank){
            $tmp_bank = $this->_getBankCode($bankInfos['bank_name']);
        }

        if($tmp_bank === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }

        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];

        $param = array(
            'MerchantCode'    => $config['partner_id'],
            'OrderId'       => $params['order_num'],
            'BankCardNum'    => $bankInfos['bank_num'],
            'BankCardName'    => $bankInfos['user_name'],
            'Province'    => '未知',
            'City'    => '未知',
            'Area'    => '未知',
            'Branch'    => '未知',
            'BankCode'    => $bank_code,
            'Amount'       => number_format($exchangeInfos['amount'],2,'.',''),
            'OrderDate'       => time()*1000
        );
//        print_r($param);
        $signStr = "Amount=".$param['Amount'].
            "&BankCardName=".$param['BankCardName'].
            "&BankCardNum=".$param['BankCardNum'].
            "&BankCode=".$param['BankCode'].
            "&Branch=".$param['Branch'].
            "&MerchantCode=".$param['MerchantCode'].
            "&OrderDate=".$param['OrderDate'].
            "&OrderId=".$param['OrderId'].
            "&Key=".$this->config['key'];
        $param['Sign'] = MD5($signStr);
//        $data = $this->_parseParams($params);

//        var_dump($param);

        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $result = $this->request($param,$this->config['request_url'] . '/api/withdraw');
//        var_dump($result);
//
//        exit;

        $this->addLog("下单请求参数:".json_encode($param,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);

        if(empty($result)){
            $res = [
                'status' 		    => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '超时，返回数据为空',
            ];
            return $res;
        }

        if(isset($result['resultCode']) && $result['success'] === false){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['resultMsg'];
        }else if(isset($result['resultCode']) && $result['success'] === true){
            $status = true;
            $withdraw_status = 4;//成功
            $msg = '';
        }else{
            $status = 1;
            $withdraw_status = 4;//默认处理中
            $msg = $result['resultMsg'];
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($result['data']['orderId']) ? $result['data']['orderId'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'ICBC' => ['code'=>'ICBC' , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>'ABC' , 'name' => '中国农业银行'],
            'BOC' => ['code'=>'BOC' , 'name' => '中国银行'],
            'CCB' => ['code'=>'CCB' , 'name' => '中国建设银行'],
            'BCM' => ['code'=>'BOCM' , 'name' => '中国交通银行'],
            'CNCB' => ['code'=>'ECITIC' , 'name' => '中信银行'],
            'CEB' => ['code'=>'CEB' , 'name' => '中国光大银行'],
            'HXB' => ['code'=>'HXB' , 'name' => '华夏银行'],
            'CMBC' => ['code'=>'CMBC' , 'name' => '中国民生银行'],
            'GDB' => ['code'=>'GDB' , 'name' => '广东发展银行'],
            'PAB' => ['code'=>'PAB' , 'name' => '平安银行'],
            'CMB' => ['code'=>'CMB' , 'name' => '招商银行'],
            'CIB' => ['code'=>'CIB' , 'name' => '兴业银行'],
            'SPDB' => ['code'=>'SPDB' , 'name' => '浦发银行'],
            'BCCB' => ['code'=>'BOB' , 'name' => '北京银行'],
            'SHB' => ['code'=>'SHB' , 'name' => '上海银行'],
            'PSBC' => ['code'=>'PSBC' , 'name' => '中国邮政储蓄银行'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($bankName = '')
    {
        if(!$bankName) return false;
        $bank_list = [
            '工商银行' => ['name' => '工商银行', 'code'=>'ICBC'],
            '农业银行' => ['name' => '农业银行', 'code'=>'ABC'],
            '中国银行' => ['name' => '中国银行', 'code'=>'BOC'],
            '建设银行' => ['name' => '建设银行', 'code'=>'CCB'],
            '交通银行' => ['name' => '交通银行', 'code'=>'COMM'],
            '中信银行' => ['name' => '中信银行', 'code'=>'CITIC'],
            '光大银行' => ['name' => '光大银行', 'code'=>'CEB'],
            '华夏银行' => ['name' => '华夏银行', 'code'=>'HXB'],
            '民生银行' => ['name' => '民生银行', 'code'=>'CMBC'],
            '广发银行' => ['name' => '广东发展银行', 'code'=>'GDB'],
            '平安银行' => ['name' => '平安银行', 'code'=>'SZPAB'],
            '招商银行' => ['name' => '招商银行', 'code'=>'CMB'],
            '兴业银行' => ['name' => '兴业银行', 'code'=>'CIB'],
            '浦发银行' => ['name' => '浦东发展银行', 'code'=>'SPDB'],
            '北京银行' => ['name' => '北京银行', 'code'=>'BCCB'],
            '上海银行' => ['name' => '上海银行', 'code'=>'BOS'],
            '中国邮政' => ['name' => '中国邮储银行', 'code'=>'PSBC'],
            '深圳发展银行' => ['name' => '深圳发展银行', 'code'=>'SDB'],
            '徽商银行' => ['name' => '微商银行', 'code'=>'HSBANK'],
//            '农村信用社' => ['name' => '农村信用社', 'code'=>'RCC'],
        ];
        return isset($bank_list[$bankName]) ? $bank_list[$bankName] : false;
    }

    //异步回调
    public function callback(){
        exit('OK');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){

        $params = [
            'MerchantCode'    => $config['partner_id'],
            'OrderId'       => $data['order_number'],
            'Time'    => time()*1000,
        ];
        $signStr = "MerchantCode=".$params['MerchantCode'].
            "&OrderId=".$params['OrderId'].
            "&Time=".$params['Time'].
            "&Key=".$config['key'];
        $params['Sign'] = MD5($signStr);
        $result = $this->request($params,$config['request_url'].'/api/withdrawquery');
        $this->addLog($result);
        $result = json_decode($result,true);

        $status = 2;//处理中
        if(isset($result['resultCode']) && $result['resultCode'] == 200 && $result['success'] == false){
            //订单不存在，请求订单超时造成  {"resultCode" : "200", "resultMsg" : "出款單未查詢到！", "success" : false, "data" : null}
            return ['status' => 5];
        }

        if(isset($result['data']['data']['status'])) {
            switch ($result['data']['data']['status']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case '2' :
                    $status = 1;//成功
                    break;
                case '3' :
                    $status = 5;//失败
                    break;
                default:
                    $status=2;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($params,$url){

        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);//指定网址
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/dior.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}