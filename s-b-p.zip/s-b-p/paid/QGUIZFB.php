<?php

/**
 * 钱柜支付宝代付
 */
class QGUIZFB {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $userInfos 	   = $params['bank_infos'];
        if(empty($userInfos['ali']) || empty($userInfos['real_name'])){
            return false;
        }
        //使用测试账号
//        $userInfos['ali'] = '13602657124';
//        $userInfos['real_name'] = '史狄锋';
//        $exchangeInfos['amount'] = 100;
//        $exchangeInfos['mobile'] = "17810648053";
        $datas = [
            'appId' => $config['partner_id'],//APP应用ID 即商户号
            'orderNo' => $params['order_num'],//订单号
            'orderAmt' => $exchangeInfos['amount'],//金额 单位:元
            'orderType' => '103', //订单类型(101-银行卡 102-微信 103-支付宝)
            'accNo' => $userInfos['ali'],//支付宝账户
            'accName' => $userInfos['real_name'],//支付宝姓名
        ];
        $datas['sign'] = $this->getSign($datas, $config['key']);
        $datas['notifyURL'] = $config['url_notify'];//回调地址不参与签名
        return $datas;
    }

    public function getSign($array, $key) {
        ksort($array);
        $arg = "";
        foreach ($array as $k => $v) {
            $arg .=  $v;
        }
        return strtoupper(md5($arg . $key));
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定支付宝账户信息',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/RaccPay/crtOrder.do', $data);
        //返回结果code 值0000表示正常 其他表示失败
        //{"code":"1009","msg":"当前非工作时间或非法金额，请重新操作.","data":null}
        //{"code":"500","msg":"服务端异常","data":null}
        //{"code":"0000","msg":"success","data":""}
        $result = json_decode($result,true);
        $msg = '';
        if(isset($result['code']) && $result['code'] != "0000"){//代付失败
            $status = false;
            $withdraw_status = 5;
            $msg = $result['msg'] ? $result['msg'] : '';
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data,$config){
        $req_data = [
            'appId' => $config['partner_id'],
            'orderNo' => $data['order_number'],
        ];
        $req_data['sign'] = $this->getSign($req_data, $config['key']);
        $result = $this->_curl($config['request_url'].'/RaccPay/selOrder.do', $req_data);
        $result = json_decode($result,true);
        //{"code":"0000","msg":"success","data":{"orderNo":"JY20200502140327","appOrderNo":"4413216268200029","orderTime":"20200502150925",
        //  "sign":"EC5A47355AA17CA49B3EE6A2CA4291D2","orderStatus":"00","orderAmt":100.0}}
        //{"code":"500","msg":"服务端异常","data":null}
        $status = 2;
        if(isset($result['code']) && $result['code'] == "0000") {
            //代付状态 （00-成功  01-处理中 99-失败）
            switch ($result['data']['orderStatus']) {
                case "00"://代付完成
                    $status = 1;
                    break;
                case "99"://代付失败
                    $status = 5;
                    break;
            }
        }else if($result['code'] == "500" && $result['msg'] == '服务端异常'){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 钱柜支付宝代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($para) . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        exit('SUCCESS');
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/qguizfb.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}