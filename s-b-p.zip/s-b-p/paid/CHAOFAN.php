<?php

/**
 * 富翁的超凡代付
 */
class CHAOFAN{

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code){
        $bank_list = [
            '工商银行' => ['中国工商银行', '0102'],
            '农业银行' => ['中国农业银行', '0103'],
            '中国银行' => ['中国银行', '0104'],
            '建设银行' => ['中国建设银行', '0105'],
            '交通银行' => ['交通银行', '0301'],
            '中信银行' => ['中信银行', '0302'],
            '光大银行' => ['中国光大银行', '0303'],
            '华夏银行' => ['华夏银行', '0304'],
            '民生银行' => ['中国民生银行', '0305'],
            '广发银行' => ['广发银行', '0306'],
            '平安银行' => ['平安银行', '0307'],
            '招商银行' => ['招商银行', '0308'],
            '兴业银行' => ['兴业银行', '0309'],
            '浦发银行' => ['上海浦东发展银行', '0310'],
            '北京银行' => ['北京银行', '0350'],
            '上海银行' => ['上海银行', '0325'],
            '中国邮政' => ['中国邮政储蓄银行', '0403'],
            '深圳发展银行' => ['平安银行', '0307'],
            '徽商银行' => ['微商银行', '0319'],
//            '农村信用社' => ['农村信用社', 'RCC'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    /**
     * 解析第三方参数 openssl_pkey_get_private
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];

//        $bankInfos['bank_name'] = '工商银行';
//        $bankInfos['bank_num'] = '6215580912003889146';
//        $bankInfos['user_name'] = '郝秀林';
        $bank_code = $this->_getBankCode(trim($bankInfos['bank_name']));//根据银行名称来查询，因为代理兑换的bank_code可能为空
        if($bank_code === false) {
            return false;
        }
        $datas = [
            'service' => 'trade.payment',//接口类型
            'version' => '1.0',//版本号
            'merchantId' => $config['partner_id'],//商户ID
            'orderNo' => $params['order_num'], //商户订单号
            'tradeDate' => date('Ymd'),//查询交易日期
            'tradeTime' => date('His'),//查询交易时间
            'amount' => $exchangeInfos['amount'] * 100,//交易金额（单位：分）
            'clientIp' => fn::getip(),//客户端IP
            'bankCode' => $bank_code[1],//开户行行别，四位行别
            'bankBranchName' => $bankInfos['bank_detail'] ? $bankInfos['bank_detail'] : '深圳支行',//支行名称
            'province' => '广东省',//开户省
            'city' => '深圳市',//开户市
            'benAcc' => $bankInfos['bank_num'],//收款人账号，收款卡号
            'benName'=> $bankInfos['user_name'],//收款人账户户名
            'accType'=> '1',//账户类型 1：对私账号 2：对公账号
            'cellPhone'=> $exchangeInfos['mobile'],//收款人手机号
            'identityType'=> '01',//收款人证件类型，收款人证件类型 01: 身份证目前只支持身份证
            'identityNo'=> '450703198409092754',//收款人证件号码
            'release'=> '1',//放行状态，0: 人工放行 1: 自动放行
            'notifyUrl'=> $config['url_notify'],//商户接收后台返回结果的地址
//            'attach' => 'transfer',//用途/备注
        ];
        return $datas;
    }

    //请求参数
    public function createSign($dataArr, $config){
        $params = $dataArr;
        $params['key'] = $config["key"];
        $signPars = "";
        ksort($params);
        foreach ($params as $k => $v) {
            if ("" != $v && "sign" != $k) {
                $signPars .= $k . "=" . $v . "&";
            }
        }
        $signPars = substr($signPars, 0, strlen($signPars) - 1);
        $dataArr['sign'] = strtolower(md5($signPars));
        return $dataArr;
    }

    //设置原始内容
    function textArr($content) {
        foreach (explode('&', $content) as $couple) {
            list ($key, $val) = explode('=', $couple);
            $parameters[$key] = $val;
        }
        return $parameters;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config){
        $dataArr = $this->_parseParams($params, $config);//业务参数
        if($dataArr === false) {
            $res = [
                'status' 		  => false, // 银行不存在
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该银行卡代付',
            ];
            return $res;
        }
        $postdatas = $this->createSign($dataArr, $config);
        $request_url = $config['request_url'];

        if($e = oo::withdraw()->error($params,$postdatas)){
            return $e;
        }

        $resultStr = $this->_curl($request_url, $postdatas);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 超凡代付提交订单 ' .'请求地址：'. $request_url .
            '；请求参数：'.json_encode($postdatas).'；返回参数：'.$resultStr);
        $status = true;
        $withdraw_status = 4;
        if(!empty($resultStr)){
            $result = $this->textArr($resultStr);
            if (isset($result['repCode']) && $result['repCode'] != '0001' ) {
                $status = false;
                $withdraw_status = 5;//失败
            }
        }
//        else{//请求超时，默认处理中，通过查询订单来判断最终代付状态
//            $status = true;
//            $withdraw_status=4;
//        }

        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' => isset($result['orderNo']) ? $result['orderNo'] : $params['order_num'],
            'msg' => isset($result['repMsg']) ? $result['repMsg'] : '',
        ];
        return $res;
    }

    // 查询代付结果
    public function searchTransfer($data, $config){
        $dataArr = [
            'service' => 'trade.payment.query',//接口类型
            'version' => '1.0',//版本号
            'merchantId' => $config['partner_id'],//商户ID
            "orderNo" => $data['order_number'],//商户订单号
            'tradeDate' => date('Ymd'),//查询交易日期
            'tradeTime' => date('His'),//查询交易时间
        ];
        $postdatas = $this->createSign($dataArr, $config);
        $request_url = $config['request_url'];
        $resultStr = $this->_curl($request_url, $postdatas);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 超凡代付查询结果 ' .'请求地址：'. $request_url .
            '；请求参数：'.json_encode($postdatas).'；返回参数：'.$resultStr);

        $status = 2;//默认转账中
        if(!empty($resultStr)){
            $result = $this->textArr($resultStr);
//            返回报文amount=5000,outAmout=5000，outCount=1，resultCode=2 这样才算成功
//            resultCode=2 只能叫处理完，不叫处理成功
//            resultCode=2，那amount==outAmount并且totalCount==outCount判断代付成功，那amount!=outAmount并且totalCount!=outCount判断代付失败
            if (isset($result['repCode'])) {
                if ($result['repCode'] == '0001') {
                    switch ($result['resultCode']) {
                        case '2'://已处理
                            if ($result['amount'] == $result['outAmount'] && $result['totalCount'] == $result['outCount']){
                                $status = 1;//成功
                            }else if($result['amount'] != $result['outAmount'] && $result['totalCount'] != $result['outCount']){
                                $status = 5;//失败
                            }
                            break;
                        case '4'://汇出失败
                            $status = 5;//失败
                            break;
                        case '5'://订单不存在
                            $status = 5;//失败
                            break;
                    }
                }
            }
        }
        return ['status' => $status];// status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        if(is_array($para)){
            $para = http_build_query($para);
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
//        var_dump($test,$response);
        return $response;
    }

    public function callback(){
        echo 'success';
    }

    // 日志管理
    public function addLog($str){
        $filename = '/data/logs/php/chaofan.txt';
        $stream = @fopen($filename, "aw+");
        $mod = substr(base_convert(@fileperms($filename),10,8),-4);
        if($mod != '0777'){
            chmod($filename, 0777);
        }
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}