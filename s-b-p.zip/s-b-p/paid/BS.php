<?php

/**
 * 博顺代付
 */
class BS {
	private $merId;

	private $key;

	private $pubKey;

	private $payKey;

	private $signKey;

	private $apiUrl;

	private $callbackUrl;

	public function __construct()
	{
		$config = cfg::comm('pay')['BS'];
        $this->merId  = $config['merId'];
		$this->key   = $config['private_key'];
		$this->pubKey   = $config['public_key'];
		$this->payKey   = $config['payKey'];
		$this->signKey   = $config['signKey'];
		$this->apiUrl  = $config['gateway'];
		$this->callbackUrl  = $config['callback_url'];
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params)
	{
		$exchangeInfos = $params['exchange_infos'];
		$bankInfos 	   = $params['bank_infos'];
//        $exchangeInfos['amount'] = 10;
		$data = [
			"payKey" => $this->payKey,
            "cardNo" => $bankInfos['bank_num'],
            "cardName" => $bankInfos['user_name'],
//            "cardNo" => 6230525020008418577,
//            "cardName" => '谢立海',
//            "noticeUrl" => $this->callbackUrl,
            "noticeUrl" => '',
            "orderNo" => $params['order_num'],
			"tranTime" => date('YmdHis'),
            "tranAmt" => sprintf("%.2f", $exchangeInfos['amount'])*100,
		];
        $this->pubKey  = "-----BEGIN PUBLIC KEY-----\n".wordwrap($this->pubKey, 64, "\n", TRUE)."\n-----END PUBLIC KEY-----";
        $str = json_encode($data);
        $res['merId'] = md5($this->merId);
        $res['encryptData'] = $this->pukOpenssl($str);
        $res['signData'] = $this->sign($data);
        return $res;
	}
    //公钥加密
    public function pukOpenssl($str,$length=117){
        $encryptData = '';
        $crypto = '';
        foreach (str_split($str, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $this->pubKey);
            $crypto = $crypto . $encryptData;
        }

        $crypto = base64_encode($crypto);
        return $crypto;
    }
    //私钥解密
    public function privateDecrypt($encrypted = null,$length = 128){
        $encrypted = base64_decode($encrypted);
        $this->key = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($this->key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $crypto = '';
        foreach (str_split($encrypted, $length) as $chunk) {

            openssl_private_decrypt($chunk, $decryptData, $this->key,OPENSSL_ALGO_MD5);

            $crypto .= $decryptData;

        }
        return $crypto;
    }
	public function sign($data){
        $data = array_filter($data);
        ksort($data);
        $str = '';
	    foreach ($data as $key=>$val) {
	        $str .= $key.'='.$val.'&';
        }
        $str = $str .'paySecret='.$this->signKey;
        return strtoupper(md5($str));
    }

	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params)
	{
		$data = $this->_parseParams($params);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $para = json_encode($data, JSON_UNESCAPED_UNICODE);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);          //单位 秒，也可以使用
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        $response = $this->privateDecrypt($response);
		$result = json_decode($response,true);

		$res = [
			'status' => $result['respCode'] == '0000' ? true : false,
			'withdraw_status' => isset($result['resultFlag']) && $result['resultFlag'] == 2 ? 1 : 5,
			'out_order_num' => $result['bsSerial'] ?? '',
			'msg' => $result['respDesc'] ?? '',
		];

		return $res;
	}


    /**
     * 海简法回调通知
     */
    public function callback($request_str = null)
    {
        $str = $_SERVER['HTTP_TRANSDATA'];
        $this->addLog($str);
        $str = $this->privateDecrypt($str);
        $this->addLog($str);
        $data = json_encode($str,true);
        // 处理提现回调
        if ($data['respCode'] == '0000') {
            switch ($data['resultFlag']) {
                case 0:$status = 1;break;
                case 1:$status = 2;break;
                default:$status = 3;
            }
            $updateData = [
                'real_amount' => 0,
                'trans_fee' => $data['tranFee'],
                'status' => $status,
                'verified_time' => date('Y-m-d H:i:s', $data['tranTime'])
            ];
            $orderInfos = oo::withdraw()->getOrderByOrderId($data['orderNo']);

            if ($orderInfos) {
                oo::withdraw()->updateOrder($data['orderNo'], $updateData);
                if ($orderInfos['exchange_type'] == 'user') {
                    oo::db('log_comm')->query(sprintf("UPDATE exchange SET withdraw_status = %s WHERE id = %s", $status, $orderInfos['exchange_id']));
                    //更新实时在线时间
                    oo::withdraw()->updateAccounttoday($orderInfos['uid'], $updateData['real_amount']);
                    // oo::withdraw()->updateAccountDataDetails($orderInfos['uid'], $updateData['real_amount']);
                } elseif ($orderInfos['exchange_type'] == 'agent') {
                    oo::db('jinliu_agent2')->query(sprintf("UPDATE spread_tx SET pay_status = %s , pay_time = '%s' WHERE tx_id = %s", $status, date('Y-m-d H:i:s'), $orderInfos['exchange_id']));
                    // oo::withdraw()->updateAccountDataDetailsByAgent($orderInfos['uid'], $updateData['real_amount']);
                }

                echo 'success';exit;
            } else {
                echo 'false';exit;
            }
        }
    }
    function addLog($str){
        $stream = @fopen('/data/logs/php/wuxing_pay_logs.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }
}