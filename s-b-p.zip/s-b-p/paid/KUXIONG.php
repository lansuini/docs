<?php

/**
 * 酷熊银行卡代付
 */
class KUXIONG {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        if(empty($bankInfos['user_name']) || empty($bankInfos['bank_num'])){
            return false;
        }
        //        使用测试账号
//        $bankInfos['user_name'] = '章宗旭';
//        $bankInfos['bank_name'] = '建设银行';
//        $bankInfos['bank_num'] = "6236681420025037698";
//        $exchangeInfos['amount'] = 0.1;

//        $exchangeInfos['mobile'] = "17810648053";
//        $bank_code = $bankInfos['bank_code'];
//        $bank_name = $bankInfos['bank_name'];
        $datas = [
            'requestNo' => date('YmdHis'), //请求流水号
            'version' => 'V1.0', //版本号
            'productId' => '0201',//产品类型
            'transId' => '07',//交易类型
            'merNo' => $config['partner_id'], //商户号
            'orderDate' => date('Ymd'),//订单日期
            'orderNo' => $params['order_num'], //订单号
            'notifyUrl' => $config['url_notify'], //回调地址
            'transAmt' => bcmul($exchangeInfos['amount'], '100'), // 代付金额,单位:分
            'isCompay' => 0,//对公对私标识0为对私，1为对公
            'customerName' => $bankInfos['user_name'], //账户名，真实姓名
            'acctNo' => $bankInfos['bank_num'], //银行卡号
//            'bank_name' => $bankInfos['bank_name'], //银行名称
        ];
        $datas['signature'] = $this->getSign($datas, $config);
        return $datas;
    }

    public function getSign($data, $config) {
        ksort($data);
        $buffer = '';
        foreach($data as $key => $value){
            if($value === '') continue;
            $buffer .= "$key=$value&";
        }
        $sign_str = rtrim($buffer, '&');

        $priKey = $config['key'];
        $res = "-----BEGIN RSA PRIVATE KEY-----\n".wordwrap($priKey, 64, "\n", true)."\n-----END RSA PRIVATE KEY-----";
        $private_key = openssl_pkey_get_private($res, $config['app_secret']);
        openssl_sign($sign_str, $signature, $private_key, OPENSSL_ALGO_SHA1);
        return base64_encode($signature);
    }

    public function format($result){
        $result = explode('&', $result);
        $data = array();
        foreach($result as $item){
            $item = explode('=', $item);
            $data[$item[0]] = $item[1];
        }
        return $data;

    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定银行卡信息',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params, $data)){
            return $e;
        }

        $http_result = $this->form_post($config['request_url'].'/kuxiong/gateway/api/backTransReq', $data);
//        $http_result['result'] = 'acctNo=6236681420025037698&customerName=章宗旭&isCompay=0&merNo=800440058112370&notifyUrl=http://analysis-api.lqtest00.com/gateway.php?_sid=4100&_env=dev&mod=callback&act=result&platform=KUXIONG&orderDate=20200609&orderNo=5106538007200029&productId=0201&requestNo=20200609191505&respCode=P000&respDesc=交易处理中&transAmt=10&transId=07&version=V1.0&signature=m3lLu4lBCrar8ctItdUbnxuFk9lytnrnP1+u5shR+4hpddta/QydQnnc2WtnkN4AB+OihyezUKjqsWIbNSjBCWS3lQJHJE2MFx4+xMpWo8CLBsTApoKFzXXQBE9MSTNXYqDR3s2Bv58/RjTJq9gGnuxn+kRhwH+F6+SQksb6qTp/MECi6ZHxGkSNyWRxuIzIElZffD7aUPvQ6Nx3caxJPkWWwCyNh1e6JM9Euo4DWj3UkXDVgtmDf6LVh/bEl6O1LEFeewMb1a/CN7b6WeQkKi4AepQkcKClE2oUuwxRPJ5ehEp5jKm+FcB8nr1trbIAtAKt/K5FhO3WVLQ+jOh6nQ==';
        $result = $this->format($http_result['result']);
        if(isset($result['respCode']) && !in_array($result['respCode'], ["P000", "0000"])){//代付失败
            $status = false;
            $withdraw_status = 5;
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['orderNo'] ?? '',
            'msg' 			  => $result['respDesc'] ?? '',
        ];
        return $res;
    }

    public function searchTransfer($data, $config){
        $post_data = [
            'requestNo' => date('YmdHis'), //请求流水号
            'version' => 'V1.0', //版本号
            'transId' => '04',//交易类型
            'merNo' => $config['partner_id'], //商户号
            'orderNo' => $data['order_number'], //订单号
        ];
        $post_data['signature'] = $this->getSign($post_data, $config);
        $http_result = $this->form_post($config['request_url'].'/kuxiong/gateway/api/backTransReq', $post_data);
        $result = $this->format($http_result['result']);
        $status = 2;
        if($result['respCode'] == "0000" && isset($result['origRespCode'])){
            //提现状态 返回0000或00:成功 2:失败 3:处理中
            if(in_array($result['origRespCode'], ["00", "0000"])){
                $status = 1;//代付成功
            }else if(in_array($result['origRespCode'], ["9999", "9998", "9997", "P000"])){
                $status = 2;//处理中
            }else{
                $status = 5;//代付失败
            }
        }else if($result['respCode'] == "0028" && $result['respDesc'] == "原交易不存在"){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    //form表单提交
    protected function form_post($url, $data, $timeout = 20){
        $start_time = microtime(true);
        $post_string = http_build_query($data);
        //初始化 curl
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded;charset=UTF-8']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch,CURLINFO_HTTP_CODE);//获取请求状态码
        if($result === false){
            $curl_error = curl_error($ch);//获取CURL请求错误
        }else{
            $curl_error = '';
        }
        curl_close($ch);
        $end_time = microtime(true);
        $result =  ['http_code'=>$http_code, 'result'=>$result, 'curl_error'=>$curl_error, 'cost_time'=>bcsub($end_time, $start_time, 2).'s'];
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 酷熊银行卡代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($data) . ' 结果：' . json_encode($result));
        return $result;
    }

    public function callback(){
        echo 'success';exit;
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/kuxiong.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }
}