<?php

/**
 * 综合管理代付/天下支付
 */
class ZHWD {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];
//        商户流水号^银行编号^对公对私^收款人帐号^收款人姓名^付款金额^付款理由^省份^城市^收款支行名称


        $tmp = [
            $params['order_num'],
            $bank_code,
            '0',
            $bankInfos['bank_num'],
            $bankInfos['user_name'],
            $exchangeInfos['amount'],
            'goods',
            '浙江',
            '温州',
            $bank_name
        ];
        $datas = [
            'version' => '001',
            'businessType' => '1900',
            'agent_id' => $config['partner_id'],
            'batch_no' => $params['order_num'],
            'batch_amt' => $exchangeInfos['amount'],
            'batch_num' => 1,
            'detail_data' => implode('^',$tmp),
            'notify_url' => $config['url_notify'],
            'ext_param1' => '',
        ];
        $datas['sign'] = $this->_sign($datas,$config['key']);
        $datas['signType'] = 'MD5';
        return $datas;
    }

    public function _sign($data,$key) {
        $signPars = "";
        ksort($data);
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = $signPars.'key='.$key;
        return strtoupper(md5($signPars));
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'],$data);
        $result = json_decode($result,true);
        $status = true;
        $withdraw_status = 4;
        if(isset($result['status']) && $result['status'] != '00'){
            $status = false;
            $withdraw_status = 5;
        }elseif($result['refCode']){
            switch ($result['refCode']){
                case 1: $withdraw_status = 1;break;
                case 2: $withdraw_status = 4;break;
                default : $status = false;
                    $withdraw_status = 5;
            }
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $data['ksPayOrderId'],
            'msg' 			  => mb_convert_encoding(urldecode($result['refMsg']),'utf-8', 'gbk') ?? '',
        ];
        return $res;
    }

    // 1413295644200102
    public function searchTransfer($order,$config,$p){
        $data = [
            'version' => '001',
            'agent_id' => $config['partner_id'],
            'businessType' => '1901',
            "ksPayOrderId" 	=> '',
        ];
        $data['sign'] = $this->_sign($data,$config['key']);
        $data['signType'] = 'MD5';
        $data['batch_no'] = $order['order_number'];

        //查询 必须 GET请求
        $result = $this->_curl($config['request_url'],$data);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['code']) && $result['code'] != '00'){
            $status = 5;
        }elseif(isset($result['refCode'])) {
            switch ($result['refCode']){
                case 2: $status = 1;break;
                case 1: $status = 2;break;
                default : $status = 5;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;

    }
    public function callback(){
        die("success");
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>'ICBC' , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>'ABC' , 'name' => '中国农业银行'],
            'BOC' => ['code'=>'BOC' , 'name' => '中国银行'],
            'CCB' => ['code'=>'CCB' , 'name' => '中国建设银行'],
            'BCM' => ['code'=>'BCM' , 'name' => '交通银行'],
            'CNCB' => ['code'=>'CNCB' , 'name' => '中信银行'],
            'CEB' => ['code'=>'CEB' , 'name' => '光大银行'],
            'HXB' => ['code'=>'HXB' , 'name' => '华夏银行'],
            'CMBC' => ['code'=>'CMBC' , 'name' => '民生银行'],
            'GDB' => ['code'=>'GDB' , 'name' => '广发银行'],
            'PAB' => ['code'=>'PAB' , 'name' => '平安银行'],
            'CMB' => ['code'=>'CMB' , 'name' => '招商银行'],
            'CIB' => ['code'=>'CIB' , 'name' => '兴业银行'],
            'SPDB' => ['code'=>'SPDB' , 'name' => '浦发银行'],
            'BCCB' => ['code'=>'BCCB' , 'name' => '北京银行'],
            'SHB' => ['code'=>'SHB' , 'name' => '上海银行'],
            'PSBC' => ['code'=>'PSBC' , 'name' => '中国邮政储蓄'],
            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }
}