<?php
/**
 * 环宇支付宝代付
 */
class HYZFB {

    protected $config;//代付通道配置

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){

        ksort($data);
        $data_signstr = "";
        foreach ($data as $k => $v) {
            if ($k == 'bankdata'){
                $v = json_encode($v,JSON_UNESCAPED_UNICODE);
            }
            $data_signstr .= $k . '=' . $v . '&';
        }
        $data_signstr .= 'key='.$this->config['key'];
//        print_r($data_signstr);
        return md5($data_signstr);
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return array
     */
    public function withdraw($params, $config){

        $this->config = $config;
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息

        $param = array(
            'bankdata'    => [
                [
                    'shorderno' =>"{$params['order_num']}",
                    'bankcard' => $bankInfos['ali'],
                    'accountname' => $bankInfos['real_name'] ? $bankInfos['real_name'] : $bankInfos['payee_real_name'],
                    'total_fee' => number_format($exchangeInfos['amount'],2,'.',''),
                ]
            ],
            'usercode'       => $config['partner_id'],
            'payment_type'    => 2,
            'notifyurl'    => $config['url_notify'],

        );
        $param['sign'] = $this->dataSign($param);

//        print_r(json_encode($param));exit;

        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $result = $this->request($param,$this->config['request_url'] . '/Api/CreateOrder');

        $this->addLog("下单请求参数:".json_encode($param,JSON_UNESCAPED_UNICODE).';返回参数：'.json_encode($result, JSON_UNESCAPED_UNICODE));
        $result = json_decode($result['result'],true);
//        var_dump($result);
        if(empty($result)){
            $res = [
                'status' 		    => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => $params['order_num'],
                'msg' 			    => '超时，返回数据为空',
            ];
            return $res;
        }

        if(isset($result['code']) && ($result['code'] != 200 || empty($result['succuess_data']))){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['code'] ==  200 ? $result['fail_data'][0]['msg'] : $result['msg'];
        }else{
            $status = true;
            $withdraw_status = 4;//默认处理中
            $msg = $result['msg'] ;
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => $params['order_num'],
            'msg' 			  => $msg,
        ];
        return $res;
    }


    //异步回调
    public function callback(){
        exit('success');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){

        $this->config = $config;
        $params = [
            'usercode'    => $config['partner_id'],
            'shorderno'       => $data['order_number'],
            'reqtime'       => time(),
        ];

        $params['sign'] = $this->dataSign($params);
        $result = $this->request($params,$config['request_url'].'/Api/OrderQuery');
        $this->addLog("查询订单:".json_encode($params,JSON_UNESCAPED_UNICODE).';返回参数：'.json_encode($result,JSON_UNESCAPED_UNICODE));
        $result = json_decode($result['result'],true);
//        var_dump($result);exit;
        $status = 2;//处理中
        if(isset($result['status']) && $result['status'] === 0 && $result['msg'] == '订单查询失败'){
            //订单不存在，请求订单超时造成  {"status":0,"msg":"订单查询失败"}
            return ['status' => 5];
        }

        if(isset($result['status'])) {
            switch ($result['status']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case 502 :
                    $status = 1;//成功
                    break;
                case 503 :
                    $status = 5;//失败
                    break;
                default:
                    $status=2;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($params,$url, $timeout = 5){
        $start_time = microtime(true);
        $para = json_encode($params, JSON_UNESCAPED_UNICODE);

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_HEADER, 0); // 过滤HTTP头
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
        curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);//超时时间
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 转向
        curl_setopt($curl, CURLOPT_POST, true); // post传输数据
        curl_setopt($curl, CURLOPT_POSTFIELDS, $para);// post传输数据
        $result = curl_exec($curl);
        $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);//获取请求状态码
        if($result === false){
            $curl_error = curl_error($curl);//获取CURL请求错误
        }else{
            $curl_error = '';
        }
        curl_close($curl);
        $end_time = microtime(true);
        return ['http_code'=>$http_code, 'result'=>$result, 'curl_error'=>$curl_error, 'cost_time'=>bcsub($end_time, $start_time, 2).'s'];
//        return $data;
    }


    public function addLog($str){
        $stream = @fopen('/data/logs/php/hyzfb.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, date('Y-m-d H:i:s').'  '.$str);
        @fclose($stream);
    }

}