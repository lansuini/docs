<?php

/**
 * 支付宝代付
 */
class ZFB2 {
	/**
	 * cid
	 */
	private $cid;
	/**
	 * 密钥key
	 */
	private $apikey;

	/**
	 * marchant 私钥
	 */
	private $privateKey;

	/**
	 * 请求地址
	 */
	private $apiUrl;

	/**
	 * 回调地址，可有可无，文档没有说明若有回调地址的情况
	 */
	private $callbackUrl;

	/**
	 * 实例化
	 */
	public function __construct()
	{
		$this->config 			   = cfg::comm('pay');
		$this->apiUrl 			   = $this->config['ZFB2']['api_url'];
		$this->cid  			   = $this->config['ZFB2']['cid'];
		$this->privateKey   	   = $this->config['ZFB2']['rsa_owner_private_key'];
		$this->rsa_third_pub_key   = $this->config['ZFB2']['rsa_third_pub_key'];
		$this->apiVersion   	   = $this->config['ZFB2']['apiVersion'];
		$this->signType   		   = $this->config['ZFB2']['signType'];
		$this->postCharset   	   = $this->config['ZFB2']['postCharset'];
		$this->format   		   = $this->config['ZFB2']['format'];
		$this->timestamp 		   = date('Y-m-d H:i:s');
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params)
	{
		$exchangeInfos = $params['exchange_infos'];
		$userInfos 	   = $params['bank_infos'];
		$biz_content   = [
			"out_biz_no" 	  => $params['order_num'],
			"payee_type" 	  => "ALIPAY_LOGONID",
			"payee_account"   =>$userInfos['ali'],
			"amount" 		  => sprintf("%.2f", $exchangeInfos['amount']),
			"payer_show_name" => '提现',
			"payee_real_name" => $userInfos['real_name'],
			"remark" 		  => "转账备注"
		];
		$datas = array(
			"app_id" 		=> $this ->cid,
			"method" 		=> 'alipay.fund.trans.toaccount.transfer',
			"sign_type" 	=> $this ->signType,
			"version" 		=> $this ->apiVersion ,
			"timestamp" 	=> $this->timestamp,//yyyy-MM-dd HH:mm:ss
			"biz_content" 	=> json_encode($biz_content),
			"charset" 		=> $this ->postCharset
		);
		return $datas;
	}

	/**
	 * 生成签名
	 */
    private function sign($data) {
		ksort($data);
        $string = '';
        if(is_array($data)){
        	foreach ($data as $k => $v){
	            if ($v != '' && $v != null && $k != 'sign'){
	                $string = $string . $k . '=' . $v . '&';
	            }
        	}
        }
      
        $string = substr($string, 0, strlen($string) - 1);
		$priKey=$this->privateKey;
		$res = "-----BEGIN RSA PRIVATE KEY-----\n" .
				wordwrap($priKey, 64, "\n", true) .
				"\n-----END RSA PRIVATE KEY-----";
		($res) or die('您使用的私钥格式错误，请检查私钥配置'); 
		if ("RSA2" == $this->signType) {
			openssl_sign($string, $sign, $res, OPENSSL_ALGO_SHA256);
		} else {
			openssl_sign($string, $sign, $res);
		}
		$sign = base64_encode($sign);
		return $sign;
	}


	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params)
	{	$data=$this->_parseParams($params);
		// var_dump($data);exit;
		$data['sign'] = $this->sign($data);
		ksort($data);
		$post_string = http_build_query($data);
		//初始化 curl
		$ch = curl_init();
		$ch = curl_init($this->apiUrl);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		$result = curl_exec($ch);
		curl_close($ch);
		$result = iconv('GBK', 'UTF-8', $result);
		$arr = json_decode($result, true);
		$result=$arr['alipay_fund_trans_toaccount_transfer_response'];
		$res = [
			'status' 		  => $result['code'] == '10000' ? true : false,
			'withdraw_status' => $result['code'] == '10000' ? 1 : 5,
			'out_order_num'   => $result['out_biz_no'] ?? '',
			'msg' 			  => $result['code'] != '10000' ? $this->_getErrorStr($result['code']) : "Success",
		];
		return $res;
	}

	private function _parseRe($res)
	{
		$res = preg_split("/\s+/",$res);

		foreach ($res as $v) {
		   $result[substr($v, 0, strpos($v, '='))] = substr($v, strpos($v, '=') + 1);
		}

		return $result;
	}

	private function _getErrorStr($code)
	{
		$error =  [
			20000 => '服务不可用',
			20001 => '授权权限不足',
			40001 => '缺少必选参数',
			40002 => '非法的参数',
			40004 => '业务处理失败',
			40006 => '权限不足',
		];
		return $error[$code];
	}
}
