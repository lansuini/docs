<?php
/**
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2018/12/13
 * Time: 10:10
 */
class TB {
    /**
     * 配置
     */
    private $config;
    /**
     * 商户号
     */
    private $merno;


    /**
     * md5key
     */
    private $md5Key;

    /**
     * 请求地址
     */
    private $apiUrl;

    /**
     * 机构号
     */
    private $orgId;
    private $accountcode;

    /**
     * 实例化
     */
    public function __construct()
    {
        $this->config = cfg::comm('pay');
        $this->merno  = $this->config['TB']['pay_merberid'];
        //$this->orgId = $this->config['TB']['orgId'];
        $this->md5Key   = $this->config['TB']['md5_key'];
        $this->apiUrl  = $this->config['TB']['api_url'];
        //$this->accountcode  = $this->config['SY']['accountcode'];
        //$this->callbackUrl  = $this->config['SY']['callback_url'];
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $bank_name = $bankInfos['bank_name'];
        $bank_code = $this->_getBankCode($bank_name);

        $time = time();
        $data = [
            "pay_merberid" => $this->merno,
            "pay_ordertime" => date('Y-m-d H:s:i',$time),
            "pay_amount" => sprintf("%.2f", $exchangeInfos['amount']),
            "pay_orderno" => $params['order_num'],
            "pay_bankcode" => $bank_code,
            "account_number" => $bankInfos['bank_num'],
            "account_name" => $bankInfos['user_name'],
        ];
        // var_dump($data);exit;

        $data['sign'] = $this->_createSign($data);

        return $data;
    }

    /**
     * 生成sign
     */
    private function _createSign($data)
    {
        ksort($data);
        $string = '';
        foreach ($data as $key=>$val)
        {
            if ($val){
                $string = $string?$string.'&'.$key.'='.$val:$key.'='.$val;
            }
        }
        $string = $string.'&key='.$this->md5Key;
        $md5_str = md5($string);

        return $md5_str;
    }


    public function _httpUrl($data,$url='')
    {
        //$post_string = http_build_query($data);
        /*$ch = curl_init($this->apiUrl.$url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        curl_close($ch);*/
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        if(!empty($data)){
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params)
    {
        $data = $this->_parseParams($params);
        //var_dump($data);exit;

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $http_result = $this->_httpUrl($data);
        $result = json_decode($http_result,true);
        //var_dump($result);exit;

        if ($result['status'] == 'success'){
            //提交代付订单成功
            $result_sign = $result['sign'];
            unset($result['sign']);
            $check_sign = $this->_createSign($result);
            if ($result_sign == $check_sign){
                //付款状态
                if ($result['pay_status'] == '2' || $result['pay_status'] == '1'){
                    //成功
                    //代付业务成功
                    $res = [
                        'status' => true ,
                        'withdraw_status' => 1,
                        'out_order_num' => $result['pay_tranid'],
                        'msg' => $result['result_msg'],
                    ];
                    return $res;
                }else{
                    //第三方代付失败
                    $res = [
                        'status' => false,
                        'withdraw_status' => 5,
                        'out_order_num' => $result['pay_tranid'],
                        'msg' =>$result['result_msg'],
                    ];
                    return $res;
                }
                /*elseif ($result['pay_status'] == '1'){
                    //申请成功，待处理
                    $res = [
                        'status' => true ,
                        'withdraw_status' => 4,
                        'out_order_num' => $result['pay_tranid'],
                        'msg' => $result['result_msg'],
                    ];
                    return $res;
                }*/

            }else{
                //代付回应数据签名失败
                $res = [
                    'status' => false,
                    'withdraw_status' => 5,
                    'out_order_num' => '',
                    'msg' =>'签名验证失败',
                ];
                return $res;
            }
        }else{
            //调用第三方代付失败
            $res = [
                'status' => false,
                'withdraw_status' => 5,
                'out_order_num' => '',
                'msg' =>$result['result_msg'],
            ];
            return $res;
        }
    }

    /**
     * 查询账户余额，获取数字编号
     */
    private function _checkAccountBanlance()
    {
        $business_data = [
            'merno' => $this->merno,
            'method' => 'payment.loadBanlance',
        ];
        $data = [
            'requestId' => 'invoke'.time().mt_rand(11111,99999),
            'orgId' => $this->orgId,
            'timestamp' => date('YmdHis',time()),
            'productId' => '9500',
            'businessData' => json_encode($business_data),
        ];
        $data['signData'] = $this->_createSign($data);
        $result = $this->_httpUrl($data,'/payment/invoke');
        return json_decode($result,true);
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($name)
    {
        $bank_list = [
            'ICBC' => '工商银行',
            'ABC' => '农业银行',
            'BOC' => '中国银行',
            'CCB' => '建设银行',
            'BOCOM' => '交通银行',
            'ECITIC' => '中信银行',
            'CEBBANK' => '光大银行',
            'HXB' => '华夏银行',
            'CMBCS' => '民生银行',
            'CGB' => '广发银行',
            'PINGAN' => '平安银行',
            'CMBC' => '招商银行',
            'CIB' => '兴业银行',
            'SPDB' => '浦发银行',
            'BJBANK' => '北京银行',
            'BOS' => '上海银行',
            'PSBC' => '中国邮政',
        ];
        $code = '';
        foreach($bank_list as $key=>$val)
        {
            if ($val == $name){
                $code = $key;
                break;
            }
        }
        return $code;
    }

    private function _getErrorStr($code)
    {
        $error =  [
            1001 => '扣减金额大于可提现金额',
            1002 => '可结算金额不足',
            2001 => 'Ip白名单不存在',
            2002 => '参数为空',
            2003 => '签名错误',
            2004 => '商户不存在',
            2005 => '商户账户不存在',
            2006 => '账户被冻结',
            2007 => '订单重复',
            2009 => '业务未开通',
            2010 => '银行卡未设置白名单',
            2012 => '金额超限',
            2013 => '不支持的银行',
            9999 => '未知错误',
        ];

        return $error[$code];
    }


}