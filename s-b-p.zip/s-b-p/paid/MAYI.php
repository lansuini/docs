<?php
/**
 * 蚂蚁代付
 * @author Taylor 2019-05-14
 */
class MAYI {
    protected $config;//代付通道配置
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];//订单信息
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }
        //10101添加转账任务
        $en_str = array(
            'business'=>'Transfer',//业务固定值
            'business_type'=>10101,//业务编码
            'api_sn'=>$params['order_num'],//Api订单号
            'notify_url'=>urlencode($this->config['url_notify']),//异步通知地址
            'money'=>(string)$exchangeInfos['amount'],//转账金额，元为单位
            'bene_no'=>$bankInfos['bank_num'],//收款卡号
            'bank_id'=>$tmp_bank,//收款银行卡编码(查看附bank_id)
            'payee'=>urlencode($bankInfos['user_name']),//收款人(需urlencode编码)
//            'phone'=>$bankInfos['mobile'],//[选填]收款人手机号
            'timestamp'=>time(),//时间戳
        );
        $en_str['sign'] = $this->dataSign($en_str);//生成签名
        return $en_str;
    }

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){
        $data = $this->paraFilter($data);
        $data = $this->argSort($data);
        $data_signstr = "";
        foreach ($data as $k => $v) {
            $data_signstr .= $k . '=' . $v . '&';
        }
        $data_signstr .= 'key='.$this->config['app_secret'];
        return strtoupper(md5($data_signstr));
    }

    /**
     * 对数组排序
     * @param $para 排序前的数组
     * return 排序后的数组
     */
    public function argSort($para){
        ksort($para);
        reset($para);
        return $para;
    }

    /**
     * 除去数组中的空值和签名参数
     * @param $para 签名参数组
     * return 去掉空值与签名参数后的新签名参数组
     */
    public function paraFilter($para){
        $para_filter = array();
        foreach ($para as $k=>$v){
            if($k == "sign" ) continue;
            else $para_filter[$k] = $para[$k];
        }
        return $para_filter;
    }

    //3des加密 OPENSSL_RAW_DATA 为Pkcs7填充模式
    public function des_encrypt($data)
    {
        $cipher = "DES-EDE3-CBC";
        $key = $this->config['app_secret'];
        $encrypted = @openssl_encrypt($data, $cipher, $key, OPENSSL_RAW_DATA, $key);
        $encrypt_msg = base64_encode($encrypted);
        return $encrypt_msg;
    }

    //3des解密  OPENSSL_RAW_DATA 为Pkcs7填充模式
    function des_decrypt($data)
    {
        $data = base64_decode($data);
        $key = $this->config['app_secret'];                //32位长度
        $iv = $this->config['app_secret'];        //取前8位
        $str = openssl_decrypt($data, 'DES-EDE3-CBC', $key, OPENSSL_RAW_DATA, $iv);
        return ($str);
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return json
     */
    public function withdraw($params, $config){
        $this->config = $config;
//        $params['exchange_infos']['amount'] = '10';
//        $params['bank_infos']['bank_name'] = '交通银行';
//        $params['bank_infos']['bank_code'] = 'BCM';
//        $params['bank_infos']['bank_num'] = '6222623710008257003';
//        $params['bank_infos']['user_name'] = '兰素琼';
        $data = $this->_parseParams($params);
        if($data === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 5,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $params = json_encode($data);
        $e_params =  base64_encode($this->des_encrypt($params));
        $result_str = $this->request(['mcode'=>$this->config['app_id'], 'params'=>$e_params], $data);
//        {"status":true,"msg":"","data":{"api_sn":"2889422152200029","order_sn":"JK201905142014259164030","money":0.01}}
//        {"status":true,"msg":"","data":{"api_sn":"123456789","order_sn":"JK201812112246572062085","money":0.01}}
//        {"status":false,"msg":"\u7b7e\u540d\u9519\u8bef","errorCode":1001};
//        {"status":false,"msg":"\u6ca1\u6709\u53ef\u8f6c\u8d26\u7684\u94f6\u884c\u5361","errorCode":1006}
        $result = json_decode($result_str,true);
        if(isset($result['status']) && $result['status'] == false){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['msg'];
        }else{
            $status = true;
            $withdraw_status = 4;//成功
            $msg = '';
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($result['data']['order_sn']) ? $result['data']['order_sn'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>'0' , 'name'=> '工商银行'],
            'ABC' => ['code'=>'1', 'name' => '农业银行'],
            'BOC' => ['code'=>'2' , 'name' => '中国银行'],
            'CCB' => ['code'=>'3' , 'name' => '建设银行'],
            'BCM' => ['code'=>'4' , 'name' => '交通银行'],
            'CNCB' => ['code'=>'5' , 'name' => '中信银行'],
            'CEB' => ['code'=>'6' , 'name' => '光大银行'],
            'HXB' => ['code'=>'7' , 'name' => '华夏银行'],
            'CMBC' => ['code'=>'-1' , 'name' => '民生银行'],
            'GDB' => ['code'=>'8', 'name' => '广发银行'],
            'PAB' => ['code'=>'9', 'name' => '平安银行'],
            'CMB' => ['code'=>'10', 'name' => '招商银行'],
            'CIB' => ['code'=>'11', 'name' => '兴业银行'],
            'SPDB' => ['code'=>'12', 'name' => '浦发银行'],
            'BCCB' => ['code'=>'13', 'name' => '北京银行'],
            'SHB' => ['code'=>'138', 'name' => '上海银行'],
            'PSBC' => ['code'=>'160', 'name' => '邮储银行'],
            'HSB' => ['code'=>'127', 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code]['code'] : false;
    }

    //异步回调
    public function callback(){
        exit('success');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config){
        $this->config = $config;
        //查询转账任务接口
        $en_str = array(
            'business'=>'Query',//业务固定值
            'business_type'=>20102,//业务编码
            'api_sn'=>$data['order_number'],//Api订单号
            'timestamp'=>time(),//时间戳
        );
        $en_str['sign'] = $this->dataSign($en_str);//生成签名
        $params = json_encode($en_str);
        $e_params =  base64_encode($this->des_encrypt($params));
        $result_str = $this->request(['mcode'=>$this->config['app_id'], 'params'=>$e_params], $en_str);
//        $result_str = '{"status":true,"msg":"","data":{"api_sn":"7084498564200029","order_sn":"JK201905142040047574321","money":"10.00","bene_no":"6222623710008257003","bank_id":"4","payee":"\u5170\u7d20\u743c","phone":"","status":"50","ctime":"1557837604","feedback_error":"5000|\u8f6c\u8d26\u6210\u529f","feedback_time":"1557837681"}}';
        $result = json_decode($result_str,true);
        $status = 2;//转账中
        if(isset($result['data']['status'])) {
            switch ($result['data']['status']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case '50' :
                    $status = 1;//成功
                    break;
//                case '30' :
                case '40' :
                    $status = 5;//失败
                    break;
            }
        }else if($result['errorCode'] == 1002){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($param, $txt_param){

        $param = http_build_query($param);
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL, $this->config['request_url']);
        curl_setopt($ch, CURLOPT_POST, 1);
        $header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLINFO_HEADER_OUT, TRUE);

        $data = curl_exec($ch);//运行curl
        curl_close($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 蚂蚁代付：' . '请求地址：' . $this->config['request_url'] . '请求参数：' . json_encode([$param, $txt_param]) . '结果：' . $data);
        return $data;
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/mayi.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}