<?php

/**
 * CK代付
 */
class CK {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $datas = [
            'app_id' => $config['partner_id'],
            'app_secret' => $config['key'],
            'timestamp' => time(),
            'bank_card' => $bankInfos['bank_num'],
            'bank_name' => $bankInfos['user_name'],
            'money' => $exchangeInfos['amount'],
            'order_num' => $params['order_num'],
            'notice_url' => $config['url_notify'],
        ];
        $datas['signature'] = $this->_sign($datas);
        return $datas;
    }

    public function _sign($data) {
        $signPars = "";
        ksort($data);
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        $str = sha1($signPars);
        return strtoupper(md5($str));
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/api/v1/orders',$data);
        $result = json_decode($result,true);
        if(isset($result['code']) && $result['code'] != 0){
            $status = false;
            $withdraw_status = 5;
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => '',
            'msg' 			  => $result['msg'] ?? '',
        ];
        return $res;
    }

    // 1413295644200102
    public function searchTransfer($data,$config){
        $data = [
            'app_id' => $config['partner_id'],
            'app_secret' => $config['key'],
            'timestamp' =>  time(),
            "order_num" 	=> $data['order_number'],
        ];
        $data['signature'] = $this->_sign($data);
        //查询 必须 GET请求
        $result = $this->_get($config['request_url'].'/api/v1/orderselect?'.http_build_query($data));
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['code']) && $result['code'] != 0){
            $status = 5;
        }else {
            switch ($result['data']['state']){
                case 3: $status = 5;break;
                case 4: $status = 1;break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        if(is_array($para)){
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        }
        else{
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->parameter);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;

    }
    public  function _get($url)
    {
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, 0); // 过滤HTTP头
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        $responseText = curl_exec($curl);
        //print_r( curl_error($curl) );//如果执行curl过程中出现异常，可打开此开关，以便查看异常内容
        curl_close($curl);

        return $responseText;
    }
    public function callback(){
        die("success");
    }
}