<?php

/**
 * paipai
 */
class PAIPAI {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return '不支持该银行代付';
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];
        $groupId = $this->getGroupID($config);
        if($groupId === 0){
            return '渠道群组编号获取失败';
        }
        if($groupId === 888888){
            return '代付余额不足请充值';
        }
        $datas = [
            'service' => 'withdraw',
            'merchantID' => $config['partner_id'],
            'accountMobile' => $params['mobile'] ,
            'accountName' => $bankInfos['user_name'],
            'accountNo' => $bankInfos['bank_num'],
            'bankAddress' => $bankInfos['bank_detail'] ? $bankInfos['bank_detail'] : '人民路支行',
            'bankCity' => '温州',
            'bankNo' => $bank_code,
            'bankProvince' => trim($bankInfos['bank_province']) ? $bankInfos['bank_province'] : '浙江',
            'groupID'=> $groupId,
            'orderNo'=> $params['order_num'],
            'tradeAmt'=> $exchangeInfos['amount'],
        ];
        if($groupId == 100){
            $tmp = [
                'service' => 'withdraw',
                'merchantID' => $config['partner_id'],
                'accountName' => $bankInfos['user_name'],
                'accountNo' => $bankInfos['bank_num'],
                'groupID'=> 100,
                'orderNo'=> $params['order_num'],
                'tradeAmt'=> $exchangeInfos['amount'],
            ];
            $datas['sign'] = md5($this->arrayToURL($tmp) . $config['key']);
        }else {
            $datas['sign'] = md5($this->arrayToURL(array_filter($datas)) . $config['key']);
        }
        return $datas;
    }

    public function getGroupID($config){
        $datas = [
            'service' => 'balance',
            'merchantID' => $config['partner_id'],
            'sign' => md5("service=balance&merchantID={$config['partner_id']}{$config['key']}"),
        ];
        $res = json_decode($this->_curl($config['request_url'],$datas),true);
        $group_id = 0;
        if(is_array($res)){
            $tmp = 0;
            foreach ($res['groupList'] as $val){
                if($val['Balance'] >= $tmp){
                    $tmp = $val['Balance'];
                    $group_id = $val['GroupID'];
                }
            }
        }
        return $group_id;
        return isset($tmp) && $tmp <= 0 ? 888888 : $group_id;
    }

    public function arrayToURL($data) {
        $signPars = "";
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        return $signPars;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if(!is_array($data)) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => $data,
            ];
            return $res;
        }
        //该第三方请求下发地址和其它都不同 存储在url_notify中
        $result = $this->_curl($config['url_notify'],$data);
        $result = json_decode($result,true);
        if(isset($result['errcode']) && $result['errcode'] != 0){
            $status = false;
            $withdraw_status = 5;
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['tradeNo'] ?? '',
            'msg' 			  => $result['errmsg'] ?? '',
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>'2001' , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>'2003' , 'name' => '中国农业银行'],
            'BOC' => ['code'=>'2006' , 'name' => '中国银行'],
            'CCB' => ['code'=>'2002' , 'name' => '中国建设银行'],
            'BCM' => ['code'=>'2005' , 'name' => '交通银行'],
            'CNCB' => ['code'=>'2018' , 'name' => '中信银行'],
            'CEB' => ['code'=>'2010' , 'name' => '中国光大银行'],
            'HXB' => ['code'=>'2024' , 'name' => '华夏银行'],
            'CMBC' => ['code'=>'2007' , 'name' => '民生银行'],
            'GDB' => ['code'=>'2019' , 'name' => '广发银行'],
            'PAB' => ['code'=>'2011' , 'name' => '平安银行'],
            'CMB' => ['code'=>'2004' , 'name' => '招商银行'],
            'CIB' => ['code'=>'2009' , 'name' => '兴业银行'],
            'SPDB' => ['code'=>'2021' , 'name' => '上海浦东发展银行'],
            'BCCB' => ['code'=>'2013' , 'name' => '北京银行'],
            'SHB' => ['code'=>'2020' , 'name' => '上海银行'],
            'PSBC' => ['code'=>'2008' , 'name' => '中国邮政储蓄银行'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
//            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    // 1413295644200102
    public function searchTransfer($data,$config){
        $data = [
            'service' 	=> 'withdrawquery',
            'merchantID' => $config['partner_id'],
            'orderNo' 	=> $data['order_number'],
        ];
        $data['sign'] = md5($this->arrayToURL($data).$config['key']);
        $result = $this->_curl($config['request_url'],$data);
        $result = json_decode($result,true);
        if(isset($result['errcode']) && $result['errcode'] !=0){
            $status = 5;
        }else {
            $status = 2;
        }
        if(isset($result['tradestatus'])) {
            switch ($result['tradestatus']) {
                case 3 :
                    $status = 1;
                    break;
                case 2 :
                    $status = 5;
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;
    }

    public function callback()
    {
        echo 'SUCCESS';exit;

    }

}