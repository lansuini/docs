<?php

/**
 * 易收付
 */
class YSF {
	/**
	 * 密钥key
	 */
	private $cid;
	/**
	 * 密钥key
	 */
	private $apikey;

	/**
	 * api_url
	 */
	private $apiUrl;

	/**
	 * 实例化
	 */
	public function __construct()
	{
		$this->config = cfg::comm('pay');
		$this->cid  = $this->config['YSF']['cid'];
		$this->apikey   = $this->config['YSF']['apikey'];
		$this->apiUrl  = $this->config['YSF']['api_url'];
	}

	/**
	 * 生成sign
	 *
	 * @param array $data 参数
	 *
	 * @return string 
	 */
	private function _sign($data, $encode = true)
	{
		$data_string = $encode ? json_encode($data) : $data;
		$sign = base64_encode(hash_hmac('sha1', $data_string, $this->apikey, true));

		return $sign;
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params)
	{
		$exchangeInfos = $params['exchange_infos'];
		$bankInfos 	   = $params['bank_infos'];
		// var_dump($exchangeInfos);exit;
		$res = [
			"uid" => $exchangeInfos['uid'],
			"amount" => $exchangeInfos['amount'], 
			"time" => time(), 
			"order_id" => $params['order_num'],
			"to_bank_flag" => $bankInfos['bank_code'], 
			"to_cardnumber" => $bankInfos['bank_num'], 
			"to_username" => $bankInfos['user_name'],
			"location" => $bankInfos['bank_province'],
			"cid" => $this->cid,
		];

		oo::logs()->debug($res, 'withdraw_ysf');

		return $res;
	}

	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params)
	{
		$data = $this->_parseParams($params);

		$sign = $this->_sign($data);
		$data_string = json_encode($data);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

		$ch = curl_init($this->apiUrl);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:application/json', 'Content-Hmac:' . $sign]); 
		$result = curl_exec($ch);
		curl_close($ch);

		$result = json_decode($result, true);

		$res = [
			'status' => $result['success'],
			'withdraw_status' => $result['success'] ? 4 : 5,
			'out_order_num' => $data['order_id'],
			'msg' => $result['msg'],
		];

		return $res;
	}

	public function verifySign($hmac, $data)
	{
		$sign = $this->_sign($data, false);

		// var_dump($sign);exit;
		if ($hmac == $sign) {
			return true;
		}

		return false;
	}

    //查询代付结果
    //https://docs.google.com/document/d/122Gmxwq9xegDdZRYycaOSq7xth5rvMcrIu7660HQG8k/edit
    public function searchTransfer($data,$config)
    {
        $p_url = parse_url($config['request_url']);
        $this->apikey = $config['app_secret'];//API KEY

        $s_data['cid'] = $config['partner_id'];//商户号
        $s_data['order_id'] = $data['order_number'];//提现订单号
        $s_data['time'] = time();//UNIX时间戳
        $sign = $this->_sign($s_data);//签名

        $api_url = $p_url['scheme'].'://'.$p_url['host'].'/dsdf/api/query_withdraw';
        $ch = curl_init($api_url);//请求地址
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($s_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:application/json', 'Content-Hmac:' . $sign]);
        $result = curl_exec($ch);
        curl_close($ch);

        //{"success":true,"code":200,"order":{"order_id":"4591995400413935","customer_name":"413935","bankflag":"RCC","cardnumber":"623059128801689140","cardname":"张华林","out_cardnumber":null,"out_bankflag":"BANK","out_system":"remit","amount":215,"status":"timeout","created_time":1559556597,"verified_time":0}}
        //{"success":true,"code":200,"order":{"order_id":"5371480960408481","customer_name":"408481","bankflag":"ICBC","cardnumber":"6222082713001476483","cardname":"王雪瑞","out_cardnumber":"6228482848837274372","out_bankflag":"BANK","out_system":"remit","amount":188,"status":"verified","created_time":1559636763,"verified_time":1559636895}}
        //verified 成功 / timeout 超时 / revoked 取消 / created 创建中
        $re_arr = json_decode($result, true);
        if (isset($re_arr['success']) && $re_arr['success']) {
            switch ($re_arr['order']['status']) {
                case 'verified'://交易成功
                    return ['status' => 1];
                    break;
//                case 'F'://交易失败
//                    return ['status' => 5];
//                    break;
                default:
                    return ['status' => 2];
            }
        }
        return ['status' => 2];
    }
}