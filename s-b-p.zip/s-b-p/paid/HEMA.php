<?php
/**
 * 河马代付
 * @author Taylor 2019-06-13
 */
class HEMA {
    /**
     * 配置
     */
    private $config;

    //异步回调
    public function callback(){
        exit('SUCCESS');
    }

    /**
     *  签名sign
     */
    private function  sign($data){
        //私钥参数
        $priKey = $this->config['key'];
        $res = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($priKey, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";

        //判断私钥文件是否可用
        $piKey = openssl_pkey_get_private($res);

        if ($piKey) {
            $res = openssl_get_privatekey($res);
            openssl_sign($data, $sign, $res, 'SHA256');
            $sign = base64_encode($sign);
            return $sign;
        }
    }

    /**
     * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
     *
     * @param array $para 需要拼接的数组
     * return String 拼接完成以后的字符串
     */
    private function createLinkstring(array $para){
        $arg = '';
        foreach ($para as $key => $val){
            $arg .= ($key . '=' . $val . '&');
        }
        //去掉最后一个&字符
        $arg = substr($arg, 0, -1);

        //如果存在转义字符，那么去掉转义
        if(get_magic_quotes_gpc()) $arg = stripslashes($arg);
        return $arg;
    }

    /**
     * 签名字符串，以&符号拼接密钥
     *
     * @param String $prestr 需要签名的字符串
     * @param String $key 私钥
     * return 签名结果
     */
    private function md5Sign($prestr, $key){
        $prestr = $prestr  . '&key=' . $key;
        return md5($prestr);
    }

    /**
     * 对数组排序
     * @param array $para 排序前的数组
     * return array 排序后的数组
     */
    private function argSort(array $para){
        ksort($para);
        reset($para);
        return $para;
    }

    /**
     * 随机字符串
     */
    private function  nonceStr($len = 12){
        $arr = array(
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
            'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
            'U', 'V', 'W', 'X', 'Y', 'Z',
        );
        $str = '';
        for ($i = 1; $i <= $len; $i++) {
            $str .= $arr[mt_rand(0, 35)];
        }
        return $str;
    }

    /**
     * 字符串转16进制编码
     */
    private function String2Hex($string){
        $hex='';
        for ($i=0; $i < strlen($string); $i++){
            $hex .= dechex(ord($string[$i]));
        }
        return $hex;
    }

    /**
     * 16进制编码转字符串
     */
    private function Hex2String($hex){
        $string='';
        for ($i=0; $i < strlen($hex)-1; $i+=2){
            $string .= chr(hexdec($hex[$i].$hex[$i+1]));
        }
        return $string;
    }

    /**
     * 请求数据方法
     */
    private function postJSON($url, $params = NULL, $timeout = 8){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);		// 让cURL自己判断使用哪个版本
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);		// 在HTTP请求中包含一个"User-Agent: "头的字符串。
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $timeout);					// 在发起连接前等待的时间，如果设置为0，则无限等待
        curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);							// 设置cURL允许执行的最长秒数
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);						// 返回原生的（Raw）输出
        curl_setopt($curl, CURLOPT_ENCODING, FALSE);							// HTTP请求头中"Accept-Encoding: "的值。支持的编码有"identity"，"deflate"和"gzip"。如果为空字符串""，请求头会发送所有支持的编码类型。
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);							// 对认证证书来源的检查
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1);							// 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_HEADER, FALSE);								// 启用时会将头文件的信息作为数据流输出
        curl_setopt($curl, CURLOPT_POST, TRUE);
        if (!empty($params) && is_array($params) && count($params) >= 1) {

            $jsonStr = json_encode($params);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($jsonStr),
            ));
            curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonStr);
        }
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLINFO_HEADER_OUT, TRUE);
        $response = curl_exec($curl);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 河马代付：' .'请求地址：'.$url . '请求参数：'.json_encode($params) . '请求结果：'.$response);
        if(curl_error($curl))
        {
            $this->addLog('【'.date('Y-m-d H:i:s').'】 河马代付请求错误：' .curl_error($curl));
        }
        curl_close($curl);
        return $response;
    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/curl.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];//提现订单信息
        $bankInfos 	   = $params['bank_infos'];//银行信息
//        使用测试账号
//        $bankInfos['bank_code'] = "CCB";
//        $bankInfos['user_name'] = "卢勇庭";
//        $bankInfos['bank_num'] = "6217003360009896951";
//        $exchangeInfos['mobile'] = "19833037749";
//        $exchangeInfos['amount'] = 10;
        $bank_code = $this->_getBankCode(trim($bankInfos['bank_name']));//根据银行名称来查询，因为代理兑换的bank_code可能为空
        if($bank_code === false) {
            return false;
        }
        $sys_params = [
            "agtId" => $this->config['app_id'],//机构号
            "merId" => $this->config['partner_id'],//商户号
            "tranCode" => '2101',//交易码
            "orderId" => $params['order_num'],//商户代付单号
            "tranDate" => date('Ymd'),//交易日期
            "nonceStr" => $this->nonceStr(),//随机数
            "txnAmt" => bcmul($exchangeInfos['amount'],100),//交易金额，单位为分
            "accountNo"=> $bankInfos['bank_num'],//银行卡号
            "bankCode"=> $bank_code[1],//银行编码
            "bankName"=> $this->String2Hex($bank_code[0]),//开户行名称
            "accountName"=> $this->String2Hex($bankInfos['user_name']),//收款人姓名
            "cnaps"=> "308290003298",//联行号
            "accountType"=> "1",//账户类型
        ];
        $sys_params = $this->argSort($sys_params);
        $sign = strtoupper($this->md5Sign($this->createLinkstring($sys_params), $this->config['app_secret']));
        $sign = $this->sign($sign);

        $parm = array(
            'REQ_HEAD' => array('sign'=>$sign),
            'REQ_BODY' => $sys_params,
        );

        return $parm;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params, $config)
    {
        $this->config = $config;
        $data = $this->_parseParams($params);
//        var_dump($data);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        if($data === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }
        $rsHttp = $this->postJSON($this->config['request_url'].'/webwt/pay/gateway.do', $data, 15);
//        $rsHttp = '{"REP_HEAD":{"sign":""},"REP_BODY":{"rspcode":"100017","rspmsg":"e4b88de58f97e4bfa1e4bbbbe79a844950e59cb0e59d80"}}';
//        $rsHttp = '{"REP_HEAD":{"sign":""},"REP_BODY":{"rspcode":"600004","rspmsg":"e4bd99e9a29de4b88de8b6b3"}}';
//        $rsHttp = '{"REP_HEAD":{"sign":"YVSpu58XEdR+btCi2QgbI6xOyEPLy3c4bhJWE4Vglne6nZm2smfpkrDfJXH62TfG4B4sEiUESqpSOUBCQLzpzSOQT6JgPyj0j3XdcO1UlXzHN1UfunjD44p8Nf6aata11Def3D6ufJhfehQvmFtGfC4W8LFHTYvnJFwQs3caSy/YYQkMxUaEZjqwaXGl+ptTAaeKg4/p+FVxGnYwL3+mGG/yZDlMcHH9DO5QcLt6aPAU3WpGlhMO/wrI+PFPNAcZCOf2xMNRcACPYrxeQwI48PWwowizj31QZuUip8EOMOJKu69AZL2SBgZNNbIaPgr9eMwSG8cBjEP4KdeF0LJwWQ=="},"REP_BODY":{"rspcode":"000000","subcode":"0000","rspmsg":"e68890e58a9f","submsg":"e4baa4e69893e58f97e79086e68890e58a9f","tranId":"M019061318520516204d9CMZ","orderId":"4649512179200029"}}';
        $rs = json_decode($rsHttp,true);
        $remark = $this->Hex2String($rs['REP_BODY']['rspmsg']);

        if($rs['REP_BODY']['rspcode'] == '000000'){
            $status = true;
            $withdraw_status = 4;//成功
            $msg = '';
        }else{
            $status = true;
            $withdraw_status = 4;//失败,超时也会进入到这里，所以为4
            $msg = $rs['REP_BODY']['rspcode'].":".$remark.$rsHttp;
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($rs['REP_BODY']['tranId']) ? $rs['REP_BODY']['tranId'] : $rs['REP_BODY']['orderId'],
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){
        $this->config = $config;
        //查询转账任务接口
        $sys_params = [
            "agtId" => $this->config['app_id'],//机构号
            "merId" => $this->config['partner_id'],//商户号
            "tranCode" => '2102',//交易码
            "orderId" => $data['order_number'],//商户代付单号
            'tranDate' => date('Ymd'), //交易日期
            'nonceStr' => $this->nonceStr(), //随机字符串
        ];
        $sys_params = $this->argSort($sys_params);
        $sign = strtoupper($this->md5Sign($this->createLinkstring($sys_params), $this->config['app_secret']));
        $sign = $this->sign($sign);

        $parm = array(
            'REQ_HEAD' => array('sign'=>$sign),
            'REQ_BODY' => $sys_params,
        );
        $rsHttp = $this->postJSON($this->config['request_url'].'/webwt/pay/gateway.do', $parm, 30);
//        $rsHttp = '{"REP_HEAD":{"sign":"YDpEZBN6hpEl68PAbFsvsN5VcXmfyB9ciBdUFDRCSo8eUuQekRdfJWJ3B9D9myRHI58hY3Grnk/RGIs8kkMLzxUkLrY9ZTMCBYgE/0HKvsEA1bMmf7H8xlUK+Gr3MrD8XWa4fHXFLfob214LRtspalqsCWbAm+aLbZfP5qAKwxJ5QaMOcnQdx9Dr218cRma4KrouSPE2WgUq4R6jpl0WTyBbs+9sVO17Yhn2EP0/YYxjdl5g0se3/71y9VOoH1l56fFUuSp2U2p2w6a8nywS4L8V9GX5vTSq0KIif0YqXzq6aX5DSlHc3UnqO4hLUAXr1ElvNpFsOYB2V/ebx3A5oQ=="},"REP_BODY":{"rspcode":"000000","subcode":"0000","rspmsg":"e68890e58a9f","submsg":"e68890e58a9f5b303030305d"}}';
        $rs = json_decode($rsHttp,true);
        $remark = $this->Hex2String($rs['REP_BODY']['rspmsg']);

        $status = 2;//转账中
        if($rs['REP_BODY']['rspcode'] == '000000') {
            switch ($rs['REP_BODY']['subcode']) {
                //0 代付成功，-1 订单不存在，1 代付处理中，2 代付失败
                case '0000' :
                    $status = 1;//成功
                    break;
                case 'T010' :
                    $status = 5;//失败
                break;
                case 'T101' :
                    $status = 5;//失败，无此订单
                    break;
                case 'T012' :
                    $status = 5;//代付失败
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            '工商银行' => ['工商银行', 'ICBC'],
            '农业银行' => ['农业银行', 'ABC'],
            '中国银行' => ['中国银行', 'BOC'],
            '建设银行' => ['建设银行', 'CCB'],
            '交通银行' => ['交通银行', 'COMM'],
            '中信银行' => ['中信银行', 'CITIC'],
            '光大银行' => ['光大银行', 'CEB'],
            '华夏银行' => ['华夏银行', 'HXB'],
            '民生银行' => ['民生银行', 'CMBC'],
            '广发银行' => ['广东发展银行', 'GDB'],
            '平安银行' => ['平安银行', 'SZPAB'],
            '招商银行' => ['招商银行', 'CMB'],
            '兴业银行' => ['兴业银行', 'CIB'],
            '浦发银行' => ['浦东发展银行', 'SPDB'],
            '北京银行' => ['北京银行', 'BCCB'],
            '上海银行' => ['上海银行', 'BOS'],
            '中国邮政' => ['中国邮储银行', 'PSBC'],
            '深圳发展银行' => ['深圳发展银行', 'SDB'],
            '徽商银行' => ['微商银行', 'HSBANK'],
            '农村信用社' => ['农村信用社', 'RCC'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

}