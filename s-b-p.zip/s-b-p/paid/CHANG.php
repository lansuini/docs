<?php

/**
 * 畅代付
 */
class CHANG
{

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config)
    {
//        $this->searchTransfer(['order_number' => '7401480539518933'],$config);
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];
        $datas = [
            'mch_id' => $config['partner_id'],
            'mch_order' => $params['order_num'],
            'client_ip' => fn::getip(),
            'amt' => $exchangeInfos['amount'],
            'notify_url' =>$config['url_notify'],
            'bank_card' => $bankInfos['bank_num'],
            'real_name' => $bankInfos['user_name'],
            'created_at' => time(),
            "bank_id"  => $bankInfos['bank_code'],
            'sign_type'=>'md5'
        ];
        $datas['sign'] = $this->_signData($datas, $config['key']);
        return $datas;
    }


    public function _signData($data, $apikey)
    {
        $data['mch_key']=$apikey;
//        var_dump($data);
        ksort($data);
        $md5str = "";
        foreach ($data as $key => $val) {
            if ($val && $key != 'sign') {
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
//        var_dump(rtrim($md5str,'&'));
        $sign = md5(rtrim($md5str,'&'));

        return $sign;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config)
    {
        $dataArr = $this->_parseParams($params, $config);

        if($e = oo::withdraw()->error($params,$dataArr)){
            return $e;
        }

        $result = $this->_curl($config['request_url'] . '/trade/order.api', $dataArr);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 畅代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '请求返回值：' . $result);
        $resqDataArray = json_decode($result, true);
        if(!$result || !$resqDataArray){//返回为空和解析结果为false都默认为处理中
            $status = true;
            $withdraw_status = 4;
        }else{

            if(isset($resqDataArray['code']) && $resqDataArray['code'] != 1){//
                $status = false;
                $withdraw_status = 5;
            }else{
                $status=true;
                switch ($resqDataArray['status']){
                    case '10':case '11': $withdraw_status=1; break;
                    case '20':case '21': case '30': $withdraw_status = 5; break;
                    default: $withdraw_status = 4;  break;
                }
            }
        }


        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' => isset($resqDataArray['data']['mch_order']) ? $resqDataArray['data']['mch_order'] : '',
            'msg' => $resqDataArray['msg'] ?? '',
        ];
        return $res;
    }


    // 查询代付结果
    public function searchTransfer($data, $config)
    {
        $data = [
            'mch_id' => $config['partner_id'],
            'created_at' => time(),
            "mch_order" 	=> $data['order_number'],
            'sign_type'=>'md5'
        ];
        $data['sign'] = $this->_signData($data,$config['key']);
        //查询 必须 GET请求
        $result = $this->_curl($config['request_url'].'/trade/fetch.api',$data);
        $this->addLog('畅代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '查询返回值：' . $result);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['code']) && $result['code'] != 1){
            $status = 5;
        }else{
            switch ($result['data']['status']){
                case '10':case '11': $status=1; break;
                case '20':case '21': case '30': $status = 5; break;
                default: $status = 2;  break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para)
    {
        $headers = array('Content-Type: application/x-www-form-urlencoded');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 畅代付：' .'请求地址：'.$url . '请求参数：'.json_encode($para));
        return $response;

    }

    public function callback()
    {
//        $params = file_get_contents('php://input');
//
//        $params=parse_str($params,$data);
//
//
//        $this->addLog('畅代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '参数：' . $params);
//
//        if (!$data)
//            die('参数错误！');
////        print_r($data);
//        if (!$data || !$data['sign']) {
//            die('参数或签名不通过！');
//        }
//
//        $platform = fn::get('platform');
//        $pSql = sprintf("SELECT * FROM transfer_config WHERE code = '%s'", $platform);
//        $platConf = oo::db('log_comm')->getOne($pSql);
//
//        if (!$this->verifySign($data, $data['sign'], $platConf['key'])) {
//            die('验签不通过！');
//        }
//        $orderInfos = oo::withdraw()->getOrderByOrderId($data['mch_order']);
////        print_r($orderInfos);
//        if (!$orderInfos) {
//            die('订单不存在！');
//        }
//        if ($orderInfos['withdraw_status'] != 0) {
//            die('订单已结束！');
//        }
//        $updateData = [
//            'verified_time' => date('Y-m-d H:i:s')
//        ];
//        // 处理提现回调
//        // status  1 成功   5 失败   2 转账中
//        $status=5;
//        if(isset($data['status'])){
//            switch ($data['status']){
//                case '1': $status=2;  break;
//                case '10':$status=1; break;
//                case '11':$status=1; break;
//                default: $status=5;  break;
//            }
//        }
//
//        $updateData['status'] = $status;
//        oo::withdraw()->updateOrder($data['mch_order'], $updateData);
//        if ($orderInfos['exchange_type'] == 'user') {
//            $p = oo::db('log_comm')->query(sprintf("UPDATE exchange SET withdraw_status = %s WHERE id = %s", $status, $orderInfos['exchange_id']));
//        } elseif ($orderInfos['exchange_type'] == 'agent') {
//            $p = oo::db('jinliu_agent2')->query(sprintf("UPDATE spread_tx SET pay_status = %s , pay_time = '%s' WHERE tx_id = %s", $status, date('Y-m-d H:i:s'), $orderInfos['exchange_id']));
//        }
//        if (isset($data['msg']) && $data['msg']) {
//            oo::db('log_comm')->query(sprintf("UPDATE exchange SET remark = %s WHERE id = %s", $data['msg'], $p['id']));
//        }
        echo 'success';
//        exit;
    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/chang.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    public function verifySign($data, $sign, $key)
    {
        if ($sign != $this->_signData($data, $key)) {
            return false;
        }
        return true;

    }
}