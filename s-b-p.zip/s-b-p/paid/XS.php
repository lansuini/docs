<?php
/**
 * 新生代付
 */
class XS {

    protected $config;//代付通道配置

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){

        ksort($data);
        $data_signstr = "";
        foreach ($data as $k => $v) {
            if ($k == 'list'){
                $v = json_encode($v,JSON_UNESCAPED_UNICODE);
            }
            $data_signstr .= $k . '=' . $v . '&';
        }
        $data_signstr .= 'key='.$this->config['key'];
//        print_r($data_signstr);
        return md5($data_signstr);
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return array
     */
    public function withdraw($params, $config){

        $this->config = $config;
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息

        $param = array(
            'mchid'    => $config['partner_id'],
            'addtime'    => time(),
            'list'    => [
                [
                    'out_trade_id'       => "{$params['order_num']}",
                    'bankcode'    => 'unionpay',
                    'bankno'    => "{$bankInfos['bank_num']}",
                    'bankname'    => $bankInfos['bank_name'],
                    'bankuser'    => $bankInfos['user_name'],
                    'amount'       => number_format($exchangeInfos['amount'],2,'.','')
                    ]
            ],

        );

        $param['sign'] = $this->dataSign($param);

        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $result = $this->request($param,$this->config['request_url'] . '/pay/Apply/create');
//        print_r($result);
        $this->addLog("下单请求参数:".json_encode($param,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);

        $result = json_decode($result,true);
//        var_dump($result);exit;
        if(empty($result)){
            $res = [
                'status' 		    => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => $params['order_num'],
                'msg' 			    => '超时，返回数据为空',
            ];
            return $res;
        }

        if(isset($result['code']) && ($result['code'] != 1 || $result['data']['list'][0]['code'] != 1)){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['data']['list'][0]['errormsg'] ;
        }else{
            $status = true;
            $withdraw_status = 4;//默认处理中
            $msg = $result['data']['list'][0]['errormsg'] ;
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => $params['order_num'],
            'msg' 			  => $msg,
        ];
        return $res;
    }


    //异步回调
    public function callback(){
        exit('ok');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){

        $this->config = $config;
        $params = [
            'mchid'    => $config['partner_id'],
            'out_trade_id'       => $data['order_number'],
            'applytime'       => time(),
        ];

        $params['sign'] = $this->dataSign($params);
        $result = $this->request($params,$config['request_url'].'/pay/Apply/query');
        $this->addLog("查询订单:".json_encode($params,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);
//        var_dump($result);
        $status = 2;//处理中
        if(isset($result['code']) && $result['code'] == 0 && $result['msg'] == '订单不存在'){
            //订单不存在，请求订单超时造成  {"code":0,"msg":"订单不存在"}
            return ['status' => 5];
        }

        if(isset($result['data']['status'])) {
            switch ($result['data']['status']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case 2 :
                    $status = 1;//成功
                    break;
                case 4 :
                    $status = 5;//失败
                    break;
                default:
                    $status=2;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }


    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($params,$url){

        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);//指定网址
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }


    public function addLog($str){
        $stream = @fopen('/data/logs/php/xs.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, date('Y-m-d H:i:s').'  '.$str);
        @fclose($stream);
    }

}