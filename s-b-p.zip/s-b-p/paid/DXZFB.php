<?php
/**
 * 大象支付宝代付
 * @author Taylor
 */
class DXZFB {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config){
        $exchangeInfos = $params['exchange_infos'];
        $userInfos 	   = $params['bank_infos'];
//        $userInfos['ali'] = '18665725052';
//        $userInfos['real_name'] = '岑南敏';
        if(empty($userInfos['ali'])) {
            return false;
        }
        $datas = [
            'mchid'=> $config['partner_id'],//平台分配商户号
            'out_trade_no' => $params['order_num'],//商户订单号
            'money' => $exchangeInfos['amount'],//付款金额，单位元，格式为 Decimal（float），固定填入两位小数，参与签名以固定两位小数格式
//            'money' => sprintf("%.2f", $exchangeInfos['amount']),//付款金额，单位元，格式为 Decimal（float），固定填入两位小数，参与签名以固定两位小数格式
            'bankname' => '支付宝',//银行名称 必填
            'subbranch' => '2',//支行名称，必填
            'accountname' => $userInfos['real_name'],//户名（开户名称）；支付宝填写登录账户；
            'cardnumber' => $userInfos['ali'],//户号（卡号）；支付宝填写登录账户
            'province' => '5',//所属省份 必填
            'city' => '6',//所属城市 必填
            'callbackurl' => $config['url_notify'],//回调地址，回调地址不能带有参数
        ];
        $datas['sign'] = $this->arrayToURL($datas, $config['key']);
        return $datas;
    }

    public function arrayToURL($data, $key) {
        ksort($data);

        $signPars = "";
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        //字符串转大写  md5加密拼接字符串 连接密钥
        $sign = strtoupper(md5($signPars . "key=" . $key));
        return $sign;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params, $config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该支付宝代付或支付宝账户为空',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params, $data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/order/create', $data);
//        $result = '{"status":"error","msg":"商户余额不足"}';
//        $result = '{"status":"success","msg":"提交成功","transaction_id":"20200326163342493985"}';
        $result = json_decode($result,true);
        if($result['status'] == "error" && $result['msg'] == "商户余额不足"){
            $status = false;
            $withdraw_status = 5;//代付失败
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['transaction_id'] ?? '',
            'msg' 			  => $result['msg'] ?? '',
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data, $config){
        $data = [
            'mchid' => $config['partner_id'],//商户 PID
            'out_trade_no' 	=> $data['order_number'],//商户订单号
        ];
        $data['sign'] = $this->arrayToURL($data, $config['key']);
        $result = $this->_curl($config['request_url'].'/order/find_order', $data);
//        {"code":0,"msg":"订单不存在"}
//        {"code":0,"msg":"参数错误"}
//        {"code":1,"msg":"查询成功","out_trade_no":"1408515365200029","status":1,"transaction_id":"20200326163342493985","reason":"","sign":"94589A4C45D9EDCC8BAD184EA7074BF4"}
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['status'])) {
            switch ($result['status']) {
                case '1' ://付款成功
                    $status = 1;
                    break;
                case '3' ://已驳回，付款失败
                    $status = 5;
                    break;
            }
        }else if($result['code'] == 0 && strstr($result['msg'], '订单不存在') != false){
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 大象支付宝代付：' . '请求地址：' . $url . '请求参数：' . json_encode($para) . '结果：' . $response);
        return $response;
    }

    public function callback(){
        echo 'SUCCESS';exit;

    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/daxiang.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}