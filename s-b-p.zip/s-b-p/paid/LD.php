<?php
/**
 * 绿豆代付
 */
class LD {

    protected $config;//代付通道配置

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){

        ksort($data);
        $data_signstr = "";
        foreach ($data as $k => $v) {
            if($v && $v!=''){
                $data_signstr .= $k . '=' . $v . '&';
            }
        }
        $data_signstr=trim($data_signstr,'&') .$this->config['key'];
        return strtoupper(md5($data_signstr));
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return array
     */
    public function withdraw($params, $config){

        $this->config = $config;
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息
        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);

        if($tmp_bank === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该银行卡代付',
            ];
            return $res;
        }

        $param = array(
            'userId'    => $config['partner_id'],
            'outTradeNo'       => $params['order_num'],
            'bankCode'    => $tmp_bank['code'],
            'subbranchName'    => $tmp_bank['name'],
            'subbranchProvince'=>$tmp_bank['name'],
            'bankCardNo'    => $bankInfos['bank_num'],
            'bankAccount'    => $bankInfos['user_name'],
            'orderScore'       =>$exchangeInfos['amount'],
            'notifyUrl'=>$config['url_notify']
        );

        $param['sign'] = $this->dataSign($param);

        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $result = $this->request($param,$this->config['request_url'] . '/api/order/repay');

        $this->addLog("下单请求参数:".json_encode($param,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);

        if(empty($result)){
            $res = [
                'status' 		    => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => $params['order_num'],
                'msg' 			    => '超时，返回数据为空',
            ];
            return $res;
        }

        if(isset($result['code']) && $result['code'] != '0'){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['msg'] ;
        }else{
            $status = true;
            $withdraw_status = 4;//默认处理中
            $msg = $result['msg'] ;
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => $params['order_num'],
            'msg' 			  => $msg,
        ];
        return $res;
    }


    //异步回调
    public function callback(){
        exit('SUCCESS');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){

        $this->config = $config;
        $params = [
            'userId'    => $config['partner_id'],
            'outTradeNo'       => $data['order_number'],
        ];

        $params['sign'] = $this->dataSign($params);
        $result = $this->request($params,$config['request_url'].'/api/order/query');
        $this->addLog("查询订单:".json_encode($params,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);
//        var_dump($result);
        $status = 2;//处理中
        if(isset($result['code'])  && $result['code']== '0' ){
            if(isset($result['data']['orderStatus'])) {
                switch ($result['data']['orderStatus']) {
                    //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                    case 3 :
                        $status = 1;//成功
                        break;
                    case 2 :
                        $status = 5;//失败
                        break;
                    default:
                        $status=2;
                }
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($params,$url){

        $ch = curl_init();
        $data_string = json_encode($params);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Content-Length: ' . strlen($data_string)]);
        $data = curl_exec($ch);

        return $data;
    }

    public function queryBalance($config){
        $this->config = $config;
        $data['merchantId'] = $this->config['partner_id'];
        $data['sign'] = $this->dataSign($data);
        print_r($data);
        $url = $this->config['request_url'] . '/pay/dfPay/balance';
        $res = $this->request($data,$url);
        $this->addLog("余额查询:".json_encode($data,JSON_UNESCAPED_UNICODE).';返回参数：'.$res);
        var_dump(json_decode($res,true));
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'ICBC' => ['code'=>290 , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>296 , 'name' => '中国农业银行'],
            'CCB' => ['code'=>292 , 'name' => '中国建设银行'],
            'SPDB' => ['code'=>204 , 'name' => '上海浦东发展银行'],
            'CIB' => ['code'=>256 , 'name' => '兴业银行'],
            'CMBC' => ['code'=>294 , 'name' => '中国民生银行'],
            'BCM' => ['code'=>136 , 'name' => '交通银行'],
            'CNCB' => ['code'=>301 , 'name' => '中信银行'],
            'CEB' => ['code'=>291 , 'name' => '中国光大银行'],
            'BCCB' => ['code'=>13 , 'name' => '北京银行'],
            'CMB' => ['code'=>277 , 'name' => '招商银行'],
            'GDB' => ['code'=>69 , 'name' => '广发银行'],
            'SHB' => ['code'=>205 , 'name' => '上海银行'],
            'BOC' => ['code'=>298 , 'name' => '中国银行'],
            'HXB' => ['code'=>112 , 'name' => '华夏银行'],
            'PAB' => ['code'=>188 , 'name' => '平安银行'],
            'PSBC' => ['code'=>299 , 'name' => '中国邮政储蓄银行'],
            'HSB' => ['code'=>115 , 'name' => '徽商银行'],
            'RCC' => ['code'=>186 , 'name' => '农村信用社'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }



    public function addLog($str){
        $stream = @fopen('/data/logs/php/ld.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, date('Y-m-d H:i:s').'  '.$str);
        @fclose($stream);
    }

}