<?php

/**
 * 利陛
 */
class LIB {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];
        $datas = [
            'merchantNo' => $config['partner_id'],
            'orderNo' => $params['order_num'],
            'cashAmount' => $exchangeInfos['amount'] * 100,
            'receiveName' => $bankInfos['user_name'],
            'province' => '广东',
            'city' => '广州',
            'bankCode' => $bank_code,
            'bankBranch' => $bankInfos['bank_detail'] ? $bankInfos['bank_detail'] : '人民路支付',
            'cardNo' => $bankInfos['bank_num'],
            'accountType' => '01',
            'timestamp' => date('YmdHis'),
        ];
        $datas['sign'] = strtoupper(md5($this->arrayToURL($datas).$config['key']));
        return $datas;
    }

    public function arrayToURL($data) {
        $signPars = "";
        ksort($data);
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        return $signPars;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/api/defray/apply',$data);
        $result = json_decode($result,true);
        if(isset($result['code']) && $result['code'] != '000000' || isset($result['errMsg']) && !isset($result['code'])){
            $status = false;
            $withdraw_status = 5;
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        if(isset($result['data']['defrayStatus'])) {
            switch ($result['data']['defrayStatus']) {
                case 1 :
                    $withdraw_status = 1;
                    break;
                case -1 :
                    $status = false;
                    $withdraw_status = 5;
                    break;
            }
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['data']['serialNo'] ?? '',
            'msg' 			  => $result['errMsg'] ?? '',
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>102 , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>103 , 'name' => '中国农业银行'],
            'BOC' => ['code'=>104 , 'name' => '中国银行'],
            'CCB' => ['code'=>105 , 'name' => '中国建设银行'],
            'BCM' => ['code'=>301 , 'name' => '交通银行'],
            'CNCB' => ['code'=>302 , 'name' => '中信银行'],
            'CEB' => ['code'=>303 , 'name' => '光大银行'],
            'HXB' => ['code'=>304 , 'name' => '华夏银行'],
            'CMBC' => ['code'=>305 , 'name' => '民生银行'],
            'GDB' => ['code'=>306 , 'name' => '广发银行'],
            'PAB' => ['code'=>307 , 'name' => '平安银行'],
            'CMB' => ['code'=>308 , 'name' => '招商银行'],
            'CIB' => ['code'=>309 , 'name' => '兴业银行'],
            'SPDB' => ['code'=>310 , 'name' => '浦发银行'],
            'BCCB' => ['code'=>370 , 'name' => '北京银行'],
            'SHB' => ['code'=>420 , 'name' => '上海银行'],
            'PSBC' => ['code'=>403 , 'name' => '中国邮政储蓄'],
//            'RCC' => ['code'=>1218 , 'name' => '河北省农村信用社联合社'],
            'HSB' => ['code'=>319 , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    // 1413295644200102
    public function searchTransfer($data,$config){
        $data = [
            'timestamp' => date('YmdHis'),
            'merchantNo' => $config['partner_id'],
            "orderNo" 	=> $data['order_number'],
        ];
        $data['sign'] = strtoupper(md5($this->arrayToURL($data).$config['key']));
        $result = $this->_curl($config['request_url'].'/api/defray/query',$data);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['errMsg']) && !isset($result['data']['defrayStatus'])){
            $status = 5;
        }elseif(isset($result['data']['defrayStatus'])) {
            switch ($result['data']['defrayStatus']) {
                case 1 :
                    $status = 1;
                    break;
                case -1 :
                    $status = 5;
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /**
     * 将数据转为XML
     */
    public function toXml(array $array){
        $xml = '<xml>';
        forEach($array as $k=>$v){
            $xml.='<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
        }
        $xml.='</xml>';
        return $xml;
    }

    public function _curl($url,$para){
        $para = json_encode($para);
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_HEADER, 0); // 过滤HTTP头
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 转向
        curl_setopt($curl, CURLOPT_POST, true); // post传输数据
        curl_setopt($curl, CURLOPT_POSTFIELDS, $para);// post传输数据
        $result = curl_exec($curl);
//        print_r(curl_error($curl));
        curl_close($curl);

        return $result;
    }
}