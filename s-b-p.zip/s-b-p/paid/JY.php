<?php
/**
 * 聚赢代付
 */
class JY {

    protected $config;//代付通道配置

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){

        ksort($data);
        $data_signstr = "";
        foreach ($data as $k => $v) {
            $data_signstr .= $k . '=' . $v . '&';
        }
        $data_signstr .= 'key='.$this->config['key'];
        return strtoupper(md5($data_signstr));
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return array
     */
    public function withdraw($params, $config){

        $this->config = $config;
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息
        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);

        if($tmp_bank === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '不支付该银行卡代付',
            ];
            return $res;
        }

        $param = array(
            'merchantId'    => $config['partner_id'],
            'orderId'       => $params['order_num'],
            'bankCardNo'    => $bankInfos['bank_num'],
            'cardHolder'    => $bankInfos['user_name'],
            'bankCode'    => $tmp_bank['code'],
            'bankName'    => $tmp_bank['name'],
            'amount'       => number_format($exchangeInfos['amount'],2,'.',''),
        );

        $param['sign'] = $this->dataSign($param);


        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $result = $this->request($param,$this->config['request_url'] . '/pay/dfPay/pay');

        $this->addLog("下单请求参数:".json_encode($param,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);
//        var_dump($result);
        if(empty($result)){
            $res = [
                'status' 		    => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => $params['order_num'],
                'msg' 			    => '超时，返回数据为空',
            ];
            return $res;
        }

        if(isset($result['retCode']) && $result['retCode'] != '10000'){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['retMsg'] ;
        }else{
            $status = true;
            $withdraw_status = 4;//默认处理中
            $msg = $result['retMsg'] ;
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => $params['order_num'],
            'msg' 			  => $msg,
        ];
        return $res;
    }


    //异步回调
    public function callback(){
        exit('success');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){

        $this->config = $config;
        $params = [
            'merchantId'    => $config['partner_id'],
            'orderId'       => $data['order_number'],
        ];

        $params['sign'] = $this->dataSign($params);
        $result = $this->request($params,$config['request_url'].'/pay/dfPay/query');
        $this->addLog("查询订单:".json_encode($params,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);
//        var_dump($result);
        $status = 2;//处理中
        if(isset($result['retCode']) && $result['retCode'] == '90008' && $result['retMsg'] == '订单不存在，请检查请求参数'){
            //订单不存在，请求订单超时造成  {"retCode":90008,"retMsg":"订单不存在，请检查请求参数"}
            return ['status' => 5];
        }

        if(isset($result['status'])) {
            switch ($result['status']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case 1 :
                    $status = 1;//成功
                    break;
                case 2 :
                    $status = 5;//失败
                    break;
                default:
                    $status=2;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($params,$url){

        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);//指定网址
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    public function queryBalance($config){
        $this->config = $config;
        $data['merchantId'] = $this->config['partner_id'];
        $data['sign'] = $this->dataSign($data);
        print_r($data);
        $url = $this->config['request_url'] . '/pay/dfPay/balance';
        $res = $this->request($data,$url);
        $this->addLog("余额查询:".json_encode($data,JSON_UNESCAPED_UNICODE).';返回参数：'.$res);
        var_dump(json_decode($res,true));
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'ICBC' => ['code'=>9 , 'name'=> '中国工商银行'],
            'ABC' => ['code'=>5 , 'name' => '中国农业银行'],
            'BOC' => ['code'=>4 , 'name' => '中国银行'],
            'CMBC' => ['code'=>6 , 'name' => '中国民生银行'],
            'CCB' => ['code'=>7 , 'name' => '中国建设银行'],
            'BCM' => ['code'=>10 , 'name' => '中国交通银行'],
            'CNCB' => ['code'=>25 , 'name' => '中信银行'],
            'CEB' => ['code'=>24 , 'name' => '中国光大银行'],
            'HXB' => ['code'=>13 , 'name' => '华夏银行'],
            'GDB' => ['code'=>31 , 'name' => '广发银行'],
            'PAB' => ['code'=>20 , 'name' => '平安银行'],
            'CMB' => ['code'=>8 , 'name' => '中国招商银行'],
            'CIB' => ['code'=>12 , 'name' => '中国兴业银行'],
            'SPDB' => ['code'=>14 , 'name' => '浦发银行'],
            'BCCB' => ['code'=>19 , 'name' => '北京银行'],
            'SHB' => ['code'=>30 , 'name' => '上海银行'],
            'PSBC' => ['code'=>11 , 'name' => '中国邮政银行'],
            'HSB' => ['code'=>38 , 'name' => '徽商银行'],
            'CNAPS' => ['code'=>15 , 'name' => '广州银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }



    public function addLog($str){
        $stream = @fopen('/data/logs/php/jy.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, date('Y-m-d H:i:s').'  '.$str);
        @fclose($stream);
    }

}