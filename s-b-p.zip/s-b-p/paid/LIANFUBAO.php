<?php

/**
 * 联付宝代付
 */
class LIANFUBAO
{

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config)
    {
//        $res=$this->searchTransfer(['order_number' => '3179319618200206'],$config);
//        var_dump($res);
//        die;
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];

        $data = [
            'merOrderNo' => $params['order_num'],
            'amount' => $exchangeInfos['amount'],
            'submitTime' => time() * 1000,
            'notifyUrl' => $config['url_notify'],
            "bankCode" => $this->_getBankCode($bankInfos['bank_code'])['code'],
            'bankAccountNo' => $bankInfos['bank_num'],
            'bankAccountName' => $bankInfos['user_name'],
        ];

        $data['sign'] = $this->_signData($data, $config['app_secret']);//app_secret为代付签名秘钥


        $datas = [
            'merId' => $config['partner_id'],
            'version' => $config['ver'] ? $config['ver'] : 1.1,
            'data' => $this->getRsaData($data, $config['pub_key']),
        ];

        return $datas;
    }


    public function _signData($data, $apikey)
    {
        ksort($data);
        $md5str = "";
        foreach ($data as $key => $val) {
            if ($val && $key != 'sign') {
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $str = $md5str . 'key=' . $apikey;
        $sign = strtoupper(md5($str));
        return $sign;
    }

    //公钥加密
    public function getRsaData($data, $pubKey)
    {
        $str = json_encode($data, JSON_UNESCAPED_UNICODE);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 联付宝代付：'  . '未加密前参数：' . $str);

        $pubKey = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($pubKey, 64, "\n", TRUE) . "\n-----END PUBLIC KEY-----";
        $encryptData = '';
        $crypto = '';
        foreach (str_split($str, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $pubKey);
            $crypto = $crypto . $encryptData;
        }
        $crypto = base64_encode($crypto);
        return $crypto;
    }

    //私钥解密
    public function privateDecrypt($encrypted = null, $length = 128)
    {
        $encrypted = base64_decode($encrypted);
        $this->key = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($this->key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $crypto = '';
        foreach (str_split($encrypted, $length) as $chunk) {

            openssl_private_decrypt($chunk, $decryptData, $this->key, OPENSSL_ALGO_MD5);

            $crypto .= $decryptData;

        }
        return $crypto;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config)
    {
        $dataArr = $this->_parseParams($params, $config);
        if ($e = oo::withdraw()->error($params, $dataArr)) {
            return $e;
        }

        $result = $this->_curl($config['request_url'] . '/api/remitOrder/submit', $dataArr);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 联付宝代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '请求返回值：' . $result);
        $resqDataArray = json_decode($result, true);
        $withdraw_status = 4;
        if (!$result || !$resqDataArray) {//返回为空和解析结果为false都默认为处理中
            $status = true;
        } else {
            if (isset($resqDataArray['code']) && $resqDataArray['code'] == 200) {//请求成功
                $status = true;
            } else {
                $status = false;
                if ($resqDataArray['code'] == 559) {
                    $withdraw_status = 3;
                }
            }
        }


        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' => $params['order_num'],
            'msg' => $resqDataArray['message'] ?? '',
        ];
        return $res;
    }


    // 查询代付结果
    public function searchTransfer($data, $config, $p = '')
    {
        $sql = sprintf("SELECT * FROM withdraw WHERE order_number = '%s' ", $data['order_number']);
        $c_data = oo::db('recharge')->getOne($sql);

        $dataParam = [
            "merOrderNo" => $data['order_number'],
            'submitTime' => strtotime($c_data['created_time']) * 1000,
//            'submitTime' =>  '1576840794000',
        ];
        $dataParam['sign'] = $this->_signData($dataParam, $config['app_secret']);

        $datas = [
            'merId' => $config['partner_id'],
            'version' => $config['ver'] ? $config['ver'] : 1.1,
            'data' => $this->getRsaData($dataParam, $config['pub_key']),
        ];


        $result = $this->_curl($config['request_url'] . '/api/remitOrder/query', $datas);
        $this->addLog('联付宝代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '查询返回值：' . $result);
        $result = json_decode($result, true);
        $status = 2;
        if (!$result || !isset($result['code']) || $result['code'] != 200) { //超时，格式错误，或code不等于200均为请求有问题
            return ['status' => $status];
        } else {
            switch ($result['data']['orderState']) {
                case 0 :
                    $status = 2;
                    break;  //处理中
                case 1 :
                    $status = 1;
                    break;  //成功
                case 2 :
                    $status = 5;
                    break; //失败
                default:
                    $status = 2;
                    break;
            }
        }
        return ['status' => $status, 'msg' => $result['message'] ?? ''];  // status  1 成功   5 失败   2 转账中
    }

    //查余额
    public function queryBalance($config = [])
    {

        $params['merId'] = $config['partner_id'];
        $params['version'] = $config['ver'] ? $config['ver'] : 1.1;
        $map['merId'] = $config['partner_id'];
        $map['sign'] = $this->_signData($map, $config['app_secret']);
        //公钥加密需开启openssl扩展 公钥和私钥需要按照上面的格式缩进否则无法识别
        $rsa = $this->getRsaData($map, $config['pub_key']);
        $params['data'] = $rsa;
        $url = $config['request_url'] . '/api/balance/query';
        $result = $this->_curl($url, $params);
        print_r($result);
        exit;
    }

    public function _curl($url, $data)
    {
        $ch = curl_init($url);
        $data = json_encode($data, JSON_UNESCAPED_UNICODE);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data))
        );
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 联付宝代付：' . '请求地址：' . $url . '请求参数：' . $data . '结果：' . $response);
        return $response;

    }

    public function callback()
    {
        echo 'success';
        exit;
    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/lianfubao.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    public function verifySign($data, $sign, $key)
    {
        if ($sign != $this->_signData($data, $key)) {
            return false;
        }
        return true;

    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code' => 'ICBC', 'name' => '中国工商银行'],
            'ABC' => ['code' => 'ABC', 'name' => '农业银行'],
            'BOC' => ['code' => 'BOC', 'name' => '中国银行'],
            'CCB' => ['code' => 'CCB', 'name' => '建设银行'],
            'BCM' => ['code' => 'BOCO', 'name' => '交通银行'],
            'CNCB' => ['code' => 'CTTIC', 'name' => '中信银行'],
            'CEB' => ['code' => 'CEB', 'name' => '光大银行'],
            'HXB' => ['code' => 'HXB', 'name' => '华夏银行'],
            'CMBC' => ['code' => 'CMBC', 'name' => '民生银行'],
            'GDB' => ['code' => 'GDB', 'name' => '广东发展银行'],
            'SDB' => ['code' => 'SDB', 'name' => '深圳发展银行'],
            'PAB' => ['code' => 'PINGANBANK', 'name' => '平安银行'],
            'CMB' => ['code' => 'CMB', 'name' => '招商银行'],
            'CIB' => ['code' => 'CIB', 'name' => '兴业银行'],
            'SPDB' => ['code' => 'SPDB', 'name' => '浦东发展银行'],
            'BCCB' => ['code' => 'BCCB', 'name' => '北京银行'],
            'SHB' => ['code' => 'SHB', 'name' => '上海银行'],
            'PSBC' => ['code' => 'PSBS', 'name' => '邮政储蓄银行'],
            'NBCB' => ['code' => 'NBB', 'name' => '宁波银行'],
            'BJRCB' => ['code' => 'BJRCB', 'name' => '北京农村商业银行'],
            'CZB' => ['code' => 'CZB', 'name' => '浙商银行'],
            'HZCB' => ['code' => 'HZCB', 'name' => '杭州银行'],
            'NJCB' => ['code' => 'NJCB', 'name' => '南京银行'],
            'SRCB' => ['code' => 'SRCB', 'name' => '上海农商银行'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
//            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

}