<?php

/**
 * 万邦聚合银行卡代付
 */
class WBJH {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        //        使用测试账号
//        $bankInfos['user_name'] = '张清清';
//        $bankInfos['bank_name'] = '建设银行';
//        $bankInfos['bank_code'] = 'CCB';
//        $bankInfos['bank_num'] = "6217001830018938988";
//        $exchangeInfos['amount'] = 1;
//        $exchangeInfos['mobile'] = "17810648053";
        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
        if(!$tmp_bank){
            $tmp_bank = $this->_getBankCode($bankInfos['bank_name']);
        }
        if($tmp_bank === false) {
            return false;
        }
//        if(empty($bankInfos['bank_code']) || empty($bankInfos['bank_name'])){
//            return false;
//        }
        $datas = [
            'inputCharset'=>'UTF-8',//参数字符集编码
            'merchantId' => $config['partner_id'],//APP应用ID 即商户号
            'payAmount' => $exchangeInfos['amount'],//金额 单位:元
            'transId' => $params['order_num'],//订单号
            'payTime' => date('Y-m-d H:i:s'),//代付时间
            'bankCode' => $tmp_bank['code'],//银行代码
            'cardName' => $bankInfos['user_name'],//银行卡姓名
            'cardNumber' => $bankInfos['bank_num'],//银行卡号
//            'bankName' => $bankInfos['bank_name'],//银行名称
        ];
        $datas['sign'] = $this->getSign($datas, $config['key']);
//        $datas['notifyURL'] = $config['url_notify'];//回调地址不参与签名
        return $datas;
    }

    public function getSign($array, $key) {
        ksort($array);
        $signPars = "";
        foreach($array as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $sign = md5($signPars.'key='.$key);
        return $sign;
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定银行卡信息或不支持'.$params['bank_infos']['bank_name'],
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/wanbang/hlbgateway/singleAgentPay.html', $data);
        //{"retCode":"0004","retMsg":"出款ip未设置"}
        //{"orderId":"202005071207147582098643","retCode":"0000","retMsg":"操作成功","sign":"cb2de9dd4da5c71dde7de756de5ffbae","status":0,"transId":"7469438444200029"}
        $result = json_decode($result,true);
        $msg = '';
        if(isset($result['retCode']) && $result['retCode'] != "0000" && $result['retCode'] != "9999"){//代付失败
            $status = false;
            $withdraw_status = 5;
            $msg = $result['retMsg'] ? $result['retMsg'] : '';
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['orderId'] ? $result['orderId'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'ICBC' => ['code'=>'ICBC' , 'name'=> '中国工商银行'],//
            'ABC' => ['code'=>'ABC' , 'name' => '中国农业银行'],//
            'BOC' => ['code'=>'BOC' , 'name' => '中国银行'],//
            'CCB' => ['code'=>'CCB' , 'name' => '中国建设银行'],//
            'BCM' => ['code'=>'COMM' , 'name' => '交通银行'],//
            'CNCB' => ['code'=>'ECITIC' , 'name' => '中信银行'],//
            'CEB' => ['code'=>'CEBBANK' , 'name' => '中国光大银行'],//
            'HXB' => ['code'=>'HXBANK' , 'name' => '华夏银行'],//
            'CMBC' => ['code'=>'CMBC' , 'name' => '中国民生银行'],//
            'GDB' => ['code'=>'GDB' , 'name' => '广发银行'],//
            'PAB' => ['code'=>'SPABANK' , 'name' => '平安银行'],//
            'CMB' => ['code'=>'CMB' , 'name' => '招商银行'],//
            'CIB' => ['code'=>'CIB' , 'name' => '兴业银行'],//
            'SPDB' => ['code'=>'SPDB' , 'name' => '浦发银行'],//
            'BCCB' => ['code'=>'BJBANK' , 'name' => '北京银行'],//
            'SHB' => ['code'=>'SHBANK' , 'name' => '上海银行'],//
            'PSBC' => ['code'=>'PSBC' , 'name' => '中国邮政储蓄银行'],//
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
//            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($bankName = '')
    {
        if(!$bankName) return false;
        $bank_list = [
            '工商银行' => ['name' => '中国工商银行', 'code'=>'ICBC'],
            '农业银行' => ['name' => '中国农业银行', 'code'=>'ABC'],
            '中国银行' => ['name' => '中国银行', 'code'=>'BOC'],
            '建设银行' => ['name' => '中国建设银行', 'code'=>'CCB'],
            '交通银行' => ['name' => '交通银行', 'code'=>'COMM'],
            '中信银行' => ['name' => '中信银行', 'code'=>'ECITIC'],
            '光大银行' => ['name' => '中国光大银行', 'code'=>'CEBBANK'],
            '华夏银行' => ['name' => '华夏银行', 'code'=>'HXBANK'],
            '民生银行' => ['name' => '中国民生银行', 'code'=>'CMBC'],
            '广发银行' => ['name' => '广发银行', 'code'=>'GDB'],
            '平安银行' => ['name' => '平安银行', 'code'=>'SPABANK'],
            '招商银行' => ['name' => '招商银行', 'code'=>'CMB'],
            '兴业银行' => ['name' => '兴业银行', 'code'=>'CIB'],
            '浦发银行' => ['name' => '浦发银行', 'code'=>'SPDB'],
            '北京银行' => ['name' => '北京银行', 'code'=>'BJBANK'],
            '上海银行' => ['name' => '上海银行', 'code'=>'SHBANK'],
            '中国邮政' => ['name' => '中国邮政储蓄银行', 'code'=>'PSBC'],
//            '深圳发展银行' => ['name' => '深圳发展银行', 'code'=>'SDB'],
//            '徽商银行' => ['name' => '微商银行', 'code'=>'HSBANK'],
//            '农村信用社' => ['name' => '农村信用社', 'code'=>'RCC'],
        ];
        return isset($bank_list[$bankName]) ? $bank_list[$bankName] : false;
    }

    // 代付查询
    public function searchTransfer($data,$config){
        $req_data = [
            'inputCharset'=>'UTF-8',//参数字符集编码
            'merchantId' => $config['partner_id'],
            'queryTime' => date('Y-m-d H:i:s'),
            'transId' => $data['order_number'],
        ];
        $req_data['sign'] = $this->getSign($req_data, $config['key']);
        $result = $this->_curl($config['request_url'].'/wanbang/hlbgateway/queryAgentPay.html', $req_data);
        //{"retCode":"0001","retMsg":"字符集编码非空"}
        //{"retCode":"0017","retMsg":"无此订单号对应的订单"}
        //{"orderId":"202005071207147582098643","retCode":"0000","retMsg":"查询成功","sign":"b72a80f126acee9e165dbdab1a44b70b","status":"2","transId":"7469438444200029"}
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['retCode']) && $result['retCode'] == "0000") {
            //代付状态 0:接受成功，1：银行处理中 2: 已打款 3: 失败
            switch ($result['status']) {
                case "2"://代付完成
                    $status = 1;
                    break;
                case "3"://代付失败
                    $status = 5;
                    break;
            }
        }else if($result['retCode'] == "0017" && $result['retMsg'] == '无此订单号对应的订单'){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 万邦聚合银行卡代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($para) . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        exit('SUCCESS');
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/wbjh.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}