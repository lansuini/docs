<?php

/**
 * TigerPay代付（支付宝类型）
 */
class TIGERPAY
{
    private $message=[
        '00'=>'Remittance request processed successfully.',
        '01'=>'The receiving account is limited for accepting this payment.',
        '02'=>'Amount error （Insufficient balance or parameter error）',
        '03'=>'The sending account is limited for this function or parameter error',
        '90'=>'REJECT （Unable to connect）: Signature Error',
        '92'=>'REJECT (Unable to connect): Incorrect IP address, or insufficient referrer 
information',
        '99'=>'Unknown parameter error',
    ];


    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];
        $datas = [
            'p_num' => $config['partner_id'],
            'from_account' =>$config['request_code'],
            'to_account' => $bankInfos['ali'],
            'currency'=>'USD',
            'amount' => $exchangeInfos['amount'],
            'debit_currency'=>'USD',
            'trans_id' => $params['order_num'],
        ];
        $datas['signature'] =  hash('sha256', $datas['from_account'] . $config['key'] . $datas['p_num'].$datas['amount']);
//        var_dump($datas);
        return $datas;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config)
    {
        $dataArr = $this->_parseParams($params, $config);

        if($e = oo::withdraw()->error($params,$dataArr)){
            return $e;
        }

        $result = $this->_curl($config['request_url'] . '/api/MoneyRequest.php', $dataArr);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 TigerPay代付：' . 'URI：' . $config['request_url'] . '/api/MoneyRequest.php' . '请求返回值：' . $result);
        $resqDataArray = json_decode($result, true);
        if(!$result || !$resqDataArray){//返回为空和解析结果为false都默认为处理中
            $status = true;
            $withdraw_status = 4;
        }else{
            if(isset($resqDataArray['status']) && $resqDataArray['status'] =='ERROR'){//
                $status = false;
                $withdraw_status = 5;
            }else{

                if(isset($resqDataArray['result'])){
                    switch ($resqDataArray['result']){
                        case '01':case '02': case '03': case '90': case '92': case '99':$status=false;$withdraw_status = 5; break;
                        default:  $status = true;$withdraw_status = 4;  break;
                    }
                }else{
                    $status = true;
                    $withdraw_status = 4;
                }
            }
        }


        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' => isset($resqDataArray['transaction_number']) ? $resqDataArray['transaction_number'] : '',
            'msg' => $this->message[$resqDataArray['result']] ?? '',
        ];
        return $res;
    }


    // 查询代付结果
    public function searchTransfer($data, $config)
    {
        $dataParam = [
            'p_num' => $config['partner_id'],
            "txs" 	=> $data['order_number'],
        ];
        $dataParam['signature'] = hash_hmac('sha512','MoneyRequest_result'.$dataParam['txs'],$config['key']);
        $result = $this->_curl($config['request_url'].'/api/MoneyRequest_result.php',$dataParam);
        $this->addLog('TigerPay代付：' . 'URI：' . $config['request_url'].'/api/MoneyRequest_result.php' . '查询返回值：' . $result);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['status']) && $result['status']=='OK'){
            if((isset($result['result']) && $result['result']=='00') && (isset($result['status']) && $result['status']=='OK')){
                if(isset($result['txs'][$data['order_number']]['result']) && $result['txs'][$data['order_number']]['result']=='00'){
                    $status=1;
                }else if(isset($result['txs'][$data['order_number']]['status']) && $result['txs'][$data['order_number']]['status']=='ERROR'){
                    $status = 5;
                }
            }else if(in_array($result['status'],['01','02','03','04','05','06','08','09'])){
                $status = 2;
            }else{
                $status = 5;
            }
        }
        if(isset($result['result'])&& $result['result']=='07' && $result['status']=='Transaction Data not found'){//07:交易不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para)
    {
//        $headers = array('Content-Type: application/x-www-form-urlencoded');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 TigerPay代付：' .'请求地址：'.$url . '请求参数：'.json_encode($para));
        return $response;

    }

    public function callback()
    {

        echo 'success';
//        exit;
    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/TigerPay'.date('Ymd').'.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}