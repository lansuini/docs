<?php

/**
 *汇付银行卡代付
 */
class HFDF {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        if(empty($bankInfos['bank_num'] )){
            return false;
        }
        //        使用测试账号
//        $bankInfos['user_name'] = '王园月';
//        $bankInfos['bank_name'] = '农业银行';
//        $bankInfos['bank_num'] = "6230521710022874979";
//        $bankInfos['bank_detail'] = "永州国贸支行";
//        $exchangeInfos['amount'] = 100;


        $datas = [
            'merid' => $config['partner_id'], //商户号
            'orderno' => $params['order_num'], //订单号
            'paytype' => 1, //账户类型 1 银行卡 2 支付宝
            'money' => bcmul($exchangeInfos['amount'], '100'), // 代付金额,单位:分
            'notifyurl' => $config['url_notify'], //回调地址
            'deviceip' => '127.0.0.1', //回调地址
            'deviceid' => '未知', //回调地址
            'devicetype' => '1', //回调地址
            'bankid' => $bankInfos['bank_code'], //银行卡
            'bankno'=>$bankInfos['bank_num'],
            'bankprovince'=>$bankInfos['bank_detail'],
            'bankcity'=>$bankInfos['bank_detail'],
            'bankopen'=>$bankInfos['bank_detail'],
            'realname' => $bankInfos['user_name'], //账户名，真实姓名
            'user_id' => '1',
            'tel' => '123456789', //账户名，真实姓名
            'attach' => 'YN', //账户名，真实姓名,
            'time'=>time()
        ];
        $datas['sign'] = $this->getSign($datas, $config['key']);
        return $datas;
    }

    public function getSign($datas, $key) {
        $signPars=$datas['merid'].$datas['orderno'].$datas['paytype'].$datas['bankno'].$datas['realname'].$datas['money'].$datas['time'];
        $sign = md5($signPars.$key);
        return $sign;
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
//        $data['order_number']='6568799151336186';
//        $data['exchange_type']='agent';
//        $str=$this->searchTransfer($data,$config);
//        var_dump($str);
//        die;

        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定银行卡信息',
            ];
            return $res;
        }


        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }
        $result = $this->_curl($config['request_url'].'/cash/bank.html', $data);
        $result = json_decode($result,true);
        if(isset($result['status']) && $result['status'] == 1){//代付失败
            $status = true;
            $withdraw_status = 4;
        }else{
            $status = false;
            $withdraw_status = 5;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['orderno'] ?? '',
            'msg' 			  => isset($result['msg']) ? $result['text'].':'. $result['msg']:$result['text'],
        ];
        return $res;
    }

    public function searchTransfer($data,$config){
        if($data['exchange_type']=='user'){
            $sql = sprintf("SELECT * FROM exchange WHERE order_num = '%s' ", $data['order_number']);
            $c_data = oo::db('log_comm')->getOne($sql);
        }else{
            $sql = sprintf("SELECT * FROM spread_tx WHERE order_num = '%s' ", $data['order_number']);
            $c_data = oo::db('jinliu_agent2')->getOne($sql);
        }

        $post_data = [
            'merid' => $config['partner_id'],
            'orderno' => $c_data['out_order_num'],
            'time'=>time()
        ];
        $str=$post_data['merid'].$post_data['orderno'].$post_data['time'].$config['key'];
        $post_data['sign'] = md5($str);
        $result = $this->_curl($config['request_url'].'/cash/getorderinfo.html', $post_data);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['status']) ) {
            switch ($result['status']) {
                case 2 ://代付成功
                    $status = 1;
                    break;
                case 3 : ///代付失败
                    $status = 5;
                    break;
            }
        }
        if($result['status']==0 && $result['msg']=='订单号不能为空'){
            $status = 2; 
        }

        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        $header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $response = trim($response);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 汇付代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($para) . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        echo 'SUCCESS';exit;
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/hfdf.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}