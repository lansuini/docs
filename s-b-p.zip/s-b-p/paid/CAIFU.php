<?php

/**
 * 财富银行卡代付
 */
class CAIFU {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
//        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
//        if(!$tmp_bank){
//            $tmp_bank = $this->_getBankCode($bankInfos['bank_name']);
//        }
//        if($tmp_bank === false) {
//            return false;
//        }
        if(empty($bankInfos['bank_code']) || empty($bankInfos['bank_name'])){
            return false;
        }
//        使用测试账号
//        $bankInfos['user_name'] = '梁淑云';
//        $bankInfos['bank_name'] = '建设银行';
//        $bankInfos['bank_num'] = "6217000130056788275";
//        $exchangeInfos['amount'] = 1;
//        $exchangeInfos['mobile'] = "17810648053";
        $datas = [
            'mchid' => $config['partner_id'],//商户渠道id
            'out_trade_no' => $params['order_num'],//订单ID
            'money' => $exchangeInfos['amount'],//金额 单位:元
            'bankname' => $bankInfos['bank_name'],//开户行名称
            'subbranch' => '北京城东支行',//支行名称
            'accountname' => $bankInfos['user_name'],//开户名
            'cardnumber' => $bankInfos['bank_num'],//银行卡号
            'province' => '北京市',//省份
            'city' => '朝阳区',//城市
            'idcard'=> '100010009999ABC',//身份证
            'sj'=> '13099998888',//手机号
            'notifyurl' => $config['url_notify'],//服务端通知
        ];
        $datas['pay_md5sign'] = $this->getSign($datas, $config['key']);
        return $datas;
    }

    public function getSign($array, $key) {
        ksort($array);
        $signPars = "";
        foreach($array as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $sign = strtoupper(md5($signPars.'key='.$key));
        return $sign;
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定银行卡信息',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/DaiFu/', $data);
        //{"status":"error","msg":"金额错误，可用余额不足!","data":[]}
        //{"status":"success","msg":"代付申请成功","transaction_id":"J0503097122683248"}
        $result = json_decode($result,true);
        $msg = '';
        if(isset($result['status']) && $result['status'] == 'error'){//代付失败
            $status = false;
            $withdraw_status = 5;
            $msg = $result['msg'] ? $result['msg'] : '';
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['transaction_id'] ? $result['transaction_id'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data,$config){
        $req_data = [
            'mchid' => $config['partner_id'],//渠道商户号
            'out_trade_no' => $data['order_number'],//商户订单号
        ];
        $req_data['pay_md5sign'] = $this->getSign($req_data, $config['key']);
        $result = $this->_curl($config['request_url'].'/DaiFu/', $req_data);
        //{"status":"success","msg":"\u8bf7\u6c42\u6210\u529f","mchid":"10016","out_trade_no":"4509627832200029","amount":"1.0000",
        //  "transaction_id":"J0503097122683248","refCode":"1","refMsg":"\u6210\u529f","success_time":"2020-05-03 20:42:24","sign":"C735C6BBF0F854C4925F6152FF1A0B9B"}
//        $result = '{"status":"error","msg":"\u8bf7\u6c42\u6210\u529f","refCode":"7","refMsg":"\u4ea4\u6613\u4e0d\u5b58\u5728"}';
        $result = json_decode($result,true);
        $status = 2;
        //代付状态 1 成功, 2 失败,3 处理中,4	待处理,5 审核驳回,6 待审核,7 交易不存在,8 未知状态
        //refCode=1 确定是成功的，2 7 8确定是失败的
        if($result['status'] == 'success' && $result['refCode'] == "1") {
            //代付完成
            $status = 1;
        }else if(in_array($result['refCode'], ["2", "7", "8"])){
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 财富银行卡代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($para) . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        exit('ok');
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/caifu.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}