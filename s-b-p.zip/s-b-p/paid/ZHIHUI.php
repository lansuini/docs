<?php

/**
 * 誉代付新系统对应的智慧支付
 */
class ZHIHUI{
    private $bank_list = [
        'ICBC' => ['code'=>102 , 'name'=> '工商银行'],
        'ABC' => ['code'=>103 , 'name' => '农业银行'],
        'BOC' => ['code'=>104 , 'name' => '中国银行'],
        'CCB' => ['code'=>105 , 'name' => '建设银行'],
        'CNCB' => ['code'=>302 , 'name' => '中信银行'],
        'CIB' => ['code'=>309 , 'name' => '兴业银行'],
        'PSBC' => ['code'=>403 , 'name' => '邮储银行'],
        'CMB' => ['code'=>308 , 'name' => '招商银行'],
        'GDB' => ['code'=>306 , 'name' => '广发银行'],
        'CEB' => ['code'=>303 , 'name' => '光大银行'],
        'PAB' => ['code'=>307 , 'name' => '平安银行'],
        'BCM' => ['code'=>301 , 'name' => '交通银行'],
        'CMBC' => ['code'=>305 , 'name' => '民生银行'],
        'BCCB' => ['code'=>370 , 'name' => '北京银行'],
        'HXB' => ['code'=>304 , 'name' => '华夏银行'],
        'SPDB' => ['code'=>310 , 'name' => '浦发银行'],
        'SHB' => ['code'=>420 , 'name' => '上海银行'],
        'HSB' => ['code'=>319 , 'name' => '徽商银行'],
        'BJRCB' => ['code'=>402 , 'name' => '北京农商银行'],
        'NBCB' => ['code'=>512 , 'name' => '宁波银行'],
    ];

    /**
     * 解析第三方参数openssl_pkey_get_private
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];
//        $bankInfos['bank_num'] = '6228430338052656670';
//        $bankInfos['user_name'] = '李霞';
        $datas = [
            'orderNumber' => $params['order_num'], //订单号
            'merchantCode' => $config['partner_id'],//商户号
            'totalAmount' => $exchangeInfos['amount'],//订单金额
            'accountNo' => $bankInfos['bank_num'],//收款卡号
            'accountName'=> $bankInfos['user_name'],//收款户名
            'remark' => 'transfer',//用途/备注
            'reqTime' => date('Y-m-d H:i:s'),//请求时间

//            'tranCode' => '100',
//            'bankCode'=>$this->bank_list[$bankInfos['bank_code']]['code'],
//            'bankName'=>$this->bank_list[$bankInfos['bank_code']]['name'],
        ];
        return $datas;
    }

    public function jsonEncodeWithUnescapedUnicode($arr){
        $encoded = json_encode($arr);
        $encoded = iconv(mb_detect_encoding($encoded), 'UTF-8', $encoded);
        $unescaped = preg_replace_callback('/(?<!\\\\)\\\\u(\w{4})/', function ($matches) {
            return html_entity_decode('&#x' . $matches[1] . ';', ENT_COMPAT, 'UTF-8');
        }, $encoded);
        $unescaped = str_replace("\\/", "/", $unescaped);
        return $unescaped;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config){
        $dataArr = $this->_parseParams($params, $config);//业务参数
        $postdatas = $this->utilParams($dataArr, $config);
        $request_url = $config['request_url'].'/remote/pay/sendPay';
        $resultStr = $this->_curl($request_url, $postdatas);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 智慧代付提交订单 ' .'请求地址：'. $request_url .
            '；请求参数：'.json_encode($dataArr).'；加密参数：'.$postdatas.'；返回参数：'.$resultStr);
//        $resultStr = '{ "code" : 200, "data" : "", "msg" : "提交付款订单成功"}';
//        $resultStr = '{ "code" : 500, "data" : "", "msg" : "请求参数不完整，请检查【content】【encrtpKey】【merchantCode】"}"';
        $status = true;
        $withdraw_status = 4;
        if(!empty($resultStr)){
            $result = json_decode($resultStr,true);
            if (isset($result['code']) && $result['code'] == '500' ) {
                $status = false;
                $withdraw_status = 5;//失败
            }
        }
//        else{//请求超时，默认处理中，通过查询订单来判断最终代付状态
//            $status = true;
//            $withdraw_status=4;
//        }

        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' => $params['order_num'],
            'msg' => isset($result['msg']) ? $result['msg'] : '',
        ];
        return $res;
    }

    // 查询代付结果
    public function searchTransfer($data, $config){
        $dataArr = [
            "orderNumber" => $data['order_number'],//商户订单号
            'reqTime' => date('Y-m-d H:i:s'),//请求时间
        ];
        $postdatas = $this->utilParams($dataArr, $config);
        $request_url = $config['request_url'].'/remote/pay/sendPayQuery';
        $resultStr = $this->_curl($request_url, $postdatas);
        $this->addLog('【'.date('Y-m-d H:i:s').'】 智慧代付查询结果 ' .'请求地址：'. $request_url .
            '；请求参数：'.json_encode($dataArr).'；加密参数：'.$postdatas.'；返回参数：'.$resultStr);

        $status = 2;//默认转账中
        if(!empty($resultStr)){
            $result = json_decode($resultStr,true);
            if (isset($result['code'])) {
                if ($result['code'] == '200') {
                    switch ($result['respType']){
                        case 'S':
                            $status = 1;//成功
                            break;
                        case 'E':
                            $status = 5;//失败
                            break;
                        case 'R':
                            $status = 2;//转账中
                            break;
                    }
                }else if($result['code'] == '500' && $result['msg'] == '无此订单信息'){
                    $status = 5;//失败
                }
            }
        }
        return ['status' => $status];// status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
//        var_dump($test,$response);
        return $response;
    }

    public function callback(){
        echo 'success';
    }

    //请求参数
    public function utilParams($dataArr, $config){
        $postd['merchantCode'] = $config['partner_id'];//商户号
        //生成AES秘钥
        $cooperatorAESKey = $this->getRandom(16);

        //用RSA私钥对AES的密钥进行加密
        $res = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($config["key"], 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $pi_key = openssl_pkey_get_private($res);
        openssl_private_encrypt($cooperatorAESKey, $encrypted, $pi_key);
        $postd['encryptKey'] = base64_encode($encrypted);//base64编码

        //用AES密钥对真实内容进行加密
        $postd['content'] = self::encrypt($this->jsonEncodeWithUnescapedUnicode($dataArr), $cooperatorAESKey);

        $postdatas = "content=".urlencode($postd['content'])."&encryptKey=".urlencode($postd['encryptKey'])."&merchantCode=".$postd['merchantCode'];
        return $postdatas;
    }

    // 日志管理
    public function addLog($str){
        $filename = '/data/logs/php/zhihui.txt';
        $stream = @fopen($filename, "aw+");
        $mod = substr(base_convert(@fileperms($filename),10,8),-4);
        if($mod != '0777'){
            chmod($filename, 0777);
        }
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    public function getRandom($param){
        $str = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $key = "";
        for ($i = 0; $i < $param; $i++) {
            $key .= $str{mt_rand(0, 32)};
        }
        return $key;
    }

    public static function encrypt($input, $key){
        $size = @mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB);
        $input = self::pkcs5_pad($input, $size);
        $td = @mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_ECB, '');
        $iv = @mcrypt_create_iv(@mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        @mcrypt_generic_init($td, $key, $iv);
        $data = @mcrypt_generic($td, $input);
        @mcrypt_generic_deinit($td);
        @mcrypt_module_close($td);
        $data = base64_encode($data);
        return $data;
    }

    private static function pkcs5_pad($text, $blocksize){
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    public static function decrypt($sStr, $sKey){
        $decrypted = @mcrypt_decrypt(
            MCRYPT_RIJNDAEL_128,
            $sKey,
            base64_decode($sStr),
            MCRYPT_MODE_ECB
        );

        $dec_s = strlen($decrypted);
        $padding = ord($decrypted[$dec_s - 1]);
        $decrypted = substr($decrypted, 0, -$padding);
        return $decrypted;
    }

}