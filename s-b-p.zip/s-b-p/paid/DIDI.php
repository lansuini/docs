<?php
/**
 * 迪奥代付
 */
class DIDI {
    protected $config;//代付通道配置
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {

    }

    /**
     * 生成签名
     * @param array $data 签名数组
     * return string 签名后的字符串
     */
    public function dataSign($data){
        ksort($data);
        $data_signstr = '';
        foreach ($data as $k => $v) {
            $data_signstr .= $k . '=' . $v . '&';
        }
        $data_signstr =  trim($data_signstr,'&');
        $data_signstr .= $this->config['key'];

        return strtoupper(md5($data_signstr));
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return json
     */
    public function withdraw($params, $config){

        $this->config = $config;
        $bankInfos 	   = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息
        $tmp_bank = $this->_getBank($bankInfos['bank_code']);

        if($tmp_bank === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }

        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];

        $param = array(
            'mchntCode'    => $config['partner_id'],
            'channelCode'    => $config['request_code'],
            'mchntOrderNo'       => $params['order_num'],
            'orderAmount'       => intval($exchangeInfos['amount']*100), //分
            'accountName'    => $bankInfos['user_name'],
            'accountNo'    => $bankInfos['bank_num'],
            'accountType'    => 1,
            'phone'    => 13838380438,
            'bankName'    => $bank_name,
            'bankCode'    => $bank_code,
            'orderSummary'    => $bankInfos['user_name'].'账款',
            'orderTime'       => date('YmdHis'),
        );
        $param['sign'] = $this->dataSign($param);

//        var_dump($param);exit;

        if($e = oo::withdraw()->error($params,$param)){
            return $e;
        }

        $result = $this->request($param,$this->config['request_url'] . '/payGateway/advancePay/v2');


//        var_dump($result);exit;

        $this->addLog("下单请求参数:".json_encode($param,JSON_UNESCAPED_UNICODE).';返回参数：'.$result);
        $result = json_decode($result,true);

        if(empty($result)){
            $res = [
                'status' 		    => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '超时，返回数据为空',
            ];
            return $res;
        }

        if(isset($result['retCode']) && $result['retCode'] != '0000'){
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['retMsg'];
        }else if(isset($result['retCode']) && $result['retCode'] == '0000'){
            $status = true;
            $withdraw_status = 4;//成功
            $msg = $result['retMsg'];
        }else{
            $status = 1;
            $withdraw_status = 4;//默认处理中
            $msg = $result['retMsg'];
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($result['sysOrderNo']) ? $result['sysOrderNo'] : '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBank($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'CCB' => ['code'=>'CBC' , 'name' => '建设银行'],
            'ABC' => ['code'=>'ABC' , 'name' => '农业银行'],
            'ICBC' => ['code'=>'ICBC' , 'name'=> '工商银行'],
            'BOC' => ['code'=>'BOC' , 'name' => '中国银行'],
            'SPDB' => ['code'=>'SPDB' , 'name' => '浦发银行'],
            'CEB' => ['code'=>'CEB' , 'name' => '光大银行'],
            'PAB' => ['code'=>'PINGAN' , 'name' => '平安银行'],
            'CIB' => ['code'=>'CIB' , 'name' => '兴业银行'],
            'PSBC' => ['code'=>'POST' , 'name' => '邮政储蓄银行'],
            'CNCB' => ['code'=>'ECITIC' , 'name' => '中信银行'],
            'HXB' => ['code'=>'HXB' , 'name' => '华夏银行'],
            'CMB' => ['code'=>'CMBC' , 'name' => '招商银行'],
            'GDB' => ['code'=>'CGB' , 'name' => '广发银行'],
            'BCCB' => ['code'=>'BCCB' , 'name' => '北京银行'],
            'SHB' => ['code'=>'SHB' , 'name' => '上海银行'],
            'CMBC' => ['code'=>'CMSB' , 'name' => '民生银行'],
            'BCM' => ['code'=>'BOCO' , 'name' => '交通银行'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
//            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    //异步回调
    public function callback(){
        exit('OK');
    }

    /**
     * 订单查询  6462445676200130
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){
        $this->config = $config;
        $params = [
            'mchntCode'    => $config['partner_id'],
            'channelCode'    => $config['request_code'],
            'ts'       => date('YmdHis').'001',
            'mchntOrderNo'       => $data['order_number'],
        ];
        $params['sign'] = $this->dataSign($params);
        $result = $this->request($params,$config['request_url'].'/payGateway/order/query/v2');
        $this->addLog($result);
        $result = json_decode($result,true);

        $status = 2;//处理中

        //订单号不存在 制为失败
        if(isset($result['retCode']) && $result['retCode'] == '1002'){
            $status = 5;//失败
        }elseif(isset($result['orderState'])) {
            switch ($result['orderState']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case '1' :
                    $status = 1;//成功
                    break;
                case '2' :
                    $status = 5;//失败
                    break;
                default:
                    $status=2;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($para,$url)
    {
        $data_string = json_encode($para, JSON_UNESCAPED_UNICODE);
        $data_string = str_replace("\\/", "/", $data_string);//去除转义问题
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data_string)
            )
        );
//        echo  PHP_EOL,$data_string,PHP_EOL;
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/didi.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}