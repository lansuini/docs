<?php

/**
 * 天下银行卡代付
 */
class TIANXIA {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
//        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
//        if(!$tmp_bank){
//            $tmp_bank = $this->_getBankCode($bankInfos['bank_name']);
//        }
//        if($tmp_bank === false) {
//            return false;
//        }
        if(empty($bankInfos['bank_code']) || empty($bankInfos['bank_name'])){
            return false;
        }
        //        使用测试账号
//        $bankInfos['user_name'] = '张清清';
//        $bankInfos['bank_name'] = '中国建设银行';
//        $bankInfos['bank_num'] = "6217001830018938988";
//        $exchangeInfos['amount'] = 10;
//        $exchangeInfos['mobile'] = "17810648053";
        $datas = [
            'v' => 1.01,//协议版本
            'chennelID' => $config['partner_id'],//商户渠道id
            'pay_id' => $params['order_num'],//订单ID
            'bank_no' => $bankInfos['bank_num'],//银行卡号
            'money' => $exchangeInfos['amount'],//金额 单位:元
        ];
        $datas['sign'] = $this->getSign($datas, $config['key']);
        $datas['bank_name'] = $bankInfos['bank_name'];//收款银行
        $datas['name'] = $bankInfos['user_name'];//银行卡姓名
//        $datas['notifyURL'] = $config['url_notify'];//回调地址不参与签名
        return $datas;
    }

    public function getSign($array, $key) {
        ksort($array);
        $signPars = "";
        foreach($array as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $sign = strtoupper(md5($signPars.$key));
        return $sign;
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定银行卡信息',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/api_addOrder', $data);
        $result = json_decode($result,true);
        //{"code":0,"msg":"余额不足！"}
        //{"code":0,"路径":"/api_addOrder","msg":"代付金额不可小于10"}
        //{"code":200,"msg":"下单成功"}
        $msg = '';
        if(isset($result['code']) && $result['code'] != 200){//代付失败
            $status = false;
            $withdraw_status = 5;
            $msg = $result['msg'] ? $result['msg'] : '';
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data,$config){
        $req_data = [
            'v' => 1.01,//协议版本
            'chennelID' => $config['partner_id'],//渠道id
            'pay_id' => $data['order_number'],
        ];
        $req_data['sign'] = $this->getSign($req_data, $config['key']);
        $result = $this->_curl($config['request_url'].'/api_getOrderType', $req_data);
        $result = json_decode($result,true);
        //{"code":0,"msg":"订单id(43834461072000291)不存在！"}
        //{"code":200,"pay_id":"4383446107200029","ispay":1,"error_note":""}
        $status = 2;
        if(isset($result['code']) && $result['code'] == 200) {
            //代付状态 1=成功,2=失败,0=等待处理
            switch ($result['ispay']) {
                case 1://代付完成
                    $status = 1;
                    break;
                case 2://代付失败
                    $status = 5;
                    break;
            }
        }else if($result['code'] == 0 && $result['msg'] == "订单id({$req_data['pay_id']})不存在！"){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 天下银行卡代付：' . '请求地址：' . $url . ' 请求参数：' . json_encode($para) . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        exit('ok');
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/tianxia.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}