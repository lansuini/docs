<?php

/**
 * 火箭代付
 */
class HUOJIAN
{

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params, $config)
    {
//        $this->searchTransfer(['order_number' => '7401480539518933'],$config);
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos = $params['bank_infos'];

        $pubParams = [
            'Merch_Id' => $config['partner_id'],
            'Sign_Type' => 'MD5',
            'Char_Type' => 'UTF-8',
            'Version' => 'V1.0.0',
            'Cryp_Type' => 'RSA',
        ];

        $data = [
            'pay_order_id' => $params['order_num'],
            'pay_secret' => $config['app_secret'],//支付密码
            'pay_card' => $bankInfos['bank_num'],
            'pay_money' => $exchangeInfos['amount']*100,//第三方金额单位为分
            'pay_name' => $bankInfos['user_name'],
            'pay_bankname' => $this->_getBankName($bankInfos['bank_code'])['name'],
            "pay_bankcode" => $this->_getBankName($bankInfos['bank_code'])['code'],
            'return_url' => $config['url_notify'],
        ];
        //$config['app_id']为MD5秘钥
        $data['sign'] = $this->_signData($data, $config['app_id']);
        $pubParams['Data'] = $this->getRsaData($data, $config['pub_key']);
        return $pubParams;
    }


    public function _signData($data, $apikey)
    {
        ksort($data);
        $md5str = "";
        foreach ($data as $key => $val) {
            if ($val && $key != 'sign') {
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $sign = md5($md5str . 'key=' . $apikey);
        return strtoupper($sign);
    }

    //公钥加密
    public function getRsaData($data, $pubKey)
    {
        $str = json_encode($data);
        $pubKey = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($pubKey, 64, "\n", TRUE) . "\n-----END PUBLIC KEY-----";
        $encryptData = '';
        $crypto = '';
        foreach (str_split($str, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $pubKey);
            $crypto = $crypto . $encryptData;
        }
        $crypto = base64_encode($crypto);
        return $crypto;
    }

    //私钥解密
    public function privateDecrypt($encrypted = null, $length = 128)
    {
        $encrypted = base64_decode($encrypted);
        $this->key = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($this->key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $crypto = '';
        foreach (str_split($encrypted, $length) as $chunk) {

            openssl_private_decrypt($chunk, $decryptData, $this->key, OPENSSL_ALGO_MD5);

            $crypto .= $decryptData;

        }
        return $crypto;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return array
     */
    public function withdraw($params, $config)
    {
        $dataArr = $this->_parseParams($params, $config);
//http://vip.12358vip.com
        $result = $this->_curl($config['request_url'] . '/api/Payment', $dataArr);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 火箭代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '请求返回值：' . $result);
        $resqDataArray = json_decode($result, true);
        if (!$result || !$resqDataArray) {//返回为空和解析结果为false都默认为处理中
            $status = true;
            $withdraw_status = 4;
        } else {
            if (isset($resqDataArray['resCode']) && $resqDataArray['resCode'] == 'FF') {
                $status = false;
                $withdraw_status = 5;
            } else {
                $status = true;
                $withdraw_status = 4;
            }
        }
        $res = [
            'status' => $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num' =>'',
            'msg' => $resqDataArray['msg'] ?? '',
        ];
        return $res;
    }


    // 查询代付结果
    public function searchTransfer($data, $config)
    {
        $pubParams = [
            'Merch_Id' => $config['partner_id'],
            'Sign_Type' => 'MD5',
            'Char_Type' => 'UTF-8',
            'Version' => 'V1.0.0',
            'Cryp_Type' => 'RSA',
        ];
        $data = [
            "Pay_Order_Id" => $data['order_number'],
        ];
        $data['Sign'] = $this->_signData($data, $config['app_id']);
        $pubParams['Data']=$this->getRsaData($data,$config['pub_key']);
        //查询 必须 GET请求
        $result = $this->_curl($config['request_url'] . '/api/PaymentQuery', $pubParams);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 火箭代付：' . 'URI：' . $_SERVER["REQUEST_URI"] . '查询返回值：' . $result);
        $result = json_decode($result, true);
        $status=2;
        if (isset($result['Err_Code']) && $result['Err_Code'] != '0') {
            $status = 5;
        } else {
            if($result['Result']=='SUCCESS'){
                $status=1;
            }
            if($result['Result']=='ERROR'){
                $status=5;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para)
    {
        $headers = array('Content-Type: application/x-www-form-urlencoded');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 火箭代付：' . '请求地址：' . $url . '请求参数：' . json_encode($para));
        return $response;

    }

    public function callback()
    {
        echo 'SUCCESS';
    }

    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/huojian.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if (!$code) return false;
        $bank_list = [
            'CCB' => ['code' => 'CCB', 'name' => '中国建设银行'],
            'ABC' => ['code' => 'ABC', 'name' => '中国农业银行'],
            'ICBC' => ['code' => 'ICBC', 'name' => '中国工商银行'],
            'BOC' => ['code' => 'BOC', 'name' => '中国银行'],
            'SPDB' => ['code' => 'SPDB', 'name' => '浦发银行'],
            'CEB' => ['code' => 'CEB', 'name' => '光大银行'],
            'PAB' => ['code' => 'PINGAN', 'name' => '平安银行'],
            'CIB' => ['code' => 'CIB', 'name' => '兴业银行'],
            'PSBC' => ['code' => 'PSBC', 'name' => '邮政储蓄银行'],
            'CNCB' => ['code' => 'CITIC', 'name' => '中信银行'],
            'CMB' => ['code' => 'CMB', 'name' => '招商银行'],
            'GDB' => ['code' => 'CGB', 'name' => '广发银行'],
            'BCCB' => ['code' => 'BCCB', 'name' => '北京银行'],
            'SHB' => ['code' => 'SHB', 'name' => '上海银行'],
            'CMBC' => ['code' => 'CMBC', 'name' => '中国民生银行'],
            'BCM' => ['code' => 'BCM', 'name' => '中国交通银行'],
            'HSB' => ['code' => 'HSB', 'name' => '徽商银行'],
            'NBCB' => ['code' => 'NBB', 'name' => '宁波银行'],
            'BJRCB' => ['code' => 'BJNCSY', 'name' => '北京农村商业银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }
}