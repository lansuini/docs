<?php

/**
 * 代付中转平台公共类
 */
class COMMON {
    //json提交
    protected function json_post($url, $data, $timeout = 20){
        $start_time = microtime(true);
        $data_string = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json;charset=UTF-8', 'Content-Length: ' . strlen($data_string)]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch,CURLINFO_HTTP_CODE);//获取请求状态码
        if($result === false){
            $curl_error = curl_error($ch);//获取CURL请求错误
        }else{
            $curl_error = '';
        }
        curl_close($ch);
        $end_time = microtime(true);
        return ['http_code'=>$http_code, 'result'=>$result, 'curl_error'=>$curl_error, 'cost_time'=>bcsub($end_time, $start_time, 2).'s'];
    }

    /**
     * 长字符串的加密（由于秘钥有长度限制比如1024，2048，约长表示接受的加密数据越多，否则会有超长加密不成功的问题）
     * 117表示长度，加密的时候可以从这开始分割加密（解密的时候从128开始解密即可）公钥加密
     */
    protected function rsa_encrypt($data, $public_key){
        if(is_array($data)){
            $data = json_encode($data);
        }
        $public_key = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($public_key, 64, "\n", true) . "\n-----END PUBLIC KEY-----";
        $public_res = openssl_pkey_get_public($public_key);//从证书中解析公钥
        if($public_res === false){
            return false;
        }
        $result = '';
        $part_len = 2048 / 8 - 11;//密钥是支付宝密钥工具生成的(RSA2 PKCS8)
        $data = str_split($data, $part_len);
        foreach ($data as $block) {
            openssl_public_encrypt($block, $encrypted, $public_res);
            $result .= $encrypted;
        }
        openssl_free_key($public_res);
        if(empty($result)){
            return false;
        }
        return base64_encode($result);
    }

    /**
     * 提现下单操作
     * @param array $data 参数
     * @return array
     */
    public function withdraw($params, $config){
        $current_time = date('Y-m-d H:i:s');
        $post_data = [
            "method" => "order_settlement",
            "req_time" => $current_time,//请求时间，上下3分钟内有效
            "app_id" => $config['partner_id'],//中转平台唯一标识
            "order_number" => $params['order_num'],//商户订单号
            "order_amount" => $params['exchange_infos']['amount'],//金额
//            "order_amount" => '0.11',//单位：元
            "account_no" => "",
            "account_name" => "",
            "bank_code" => "",
            "bank_name" => "",
        ];
        if($params['exchange_infos']['type'] == 2 || $params['exchange_infos']['type_id'] == 1){//用户兑换的银行卡代付，代理兑换的银行卡代付
            $post_data['bank_name'] = $params['bank_infos']['bank_name'];//开户行
            $post_data['bank_code'] = $params['bank_infos']['bank_code'];//银行编码
            $post_data['account_no'] = $params['bank_infos']['bank_num'];//银行卡号
            $post_data['account_name'] = $params['bank_infos']['user_name'];//开户名
            $emsg = '没有银行卡绑定信息';
        }else if($params['exchange_infos']['type'] == 10 || $params['exchange_infos']['type_id'] == 10){//用户或者代理兑换的USDT兑换
            $post_data['bank_name'] = $params['bank_infos']['usdt_type'];//开户行
            $post_data['bank_code'] = 'USDT';//USDT 钱包链类型
            $post_data['account_no'] = $params['bank_infos']['usdt_address'];//USDT钱包地址
            $post_data['account_name'] ='usdt';//开户名
            $emsg = '没有USDT绑定信息';
        }else{//支付宝
            $post_data['bank_name'] = "支付宝";
            $post_data['bank_code'] = "ALIPAY";
            $post_data['account_no'] = $params['bank_infos']['ali'];//支付宝账号
//            $post_data['account_no'] = '18359749447';//支付宝账号
            $post_data['account_name'] = $params['bank_infos']['real_name'];//支付宝姓名
//            $post_data['account_name'] = '黄翊宸';//支付宝姓名
            $emsg = '没有支付宝绑定信息';
        }

        if(empty($post_data['account_no']) || empty($post_data['account_name'])){
            return [
                'status' 		  => false,//直接返回失败
                'withdraw_status' => 5,//代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			  => $emsg,
                'params'         =>''
            ];
        }
        $res = $this->rsa_encrypt($post_data, $config['pub_key']);//参数加密
        if($res === false){
            return [
                'status' 		  => false,//直接返回失败
                'withdraw_status' => 5,//代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			  => '公钥未配置或加密失败',
                'params'         =>''
            ];
        }
        $request_url =getEnv('WITHDRAW_REQUEST_URL');
        if(empty($request_url)){
            return [
                'status' 		  => false,//直接返回失败
                'withdraw_status' => 5,//代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			  => '未配置中转平台请求地址',
                'params'         =>''
            ];
        }
        $this->add_log($config['partner_id'], $current_time." 向中转平台发起代付请求：{$params['order_num']},{$request_url},请求报文;".json_encode($post_data).";enstr,".$res);
        $rsp = $this->json_post($request_url, ["enstr"=>$res]);
        $this->add_log($config['partner_id'],date('Y-m-d H:i:s')." 中转平台回复：{$params['order_num']},响应报文;".json_encode($rsp));
        //超时默认成功处理中
        if(empty($rsp['result']) || $rsp['http_code'] != 200){//有时候是502
            return [
                'status' 		  => true,
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			  => '超时默认成功',
                'params'         =>''
            ];
        }
        $result = json_decode($rsp['result'], true);
        $res = [
            'status' 		  => $result['code'] == 'SUCCESS' ? true : false,
            'withdraw_status' => $result['code'] == 'SUCCESS' ? 4 : 5,
            'out_order_num'   => $result['biz']['third_order'] ?? $params['order_num'],//第三方平台订单号
            'msg' 			  => $result['code'] != 'SUCCESS' ? $result['msg'] : '',
            'params'         =>isset($result['biz']['params']) ?$result['biz']['params']:''
        ];
        return $res;
    }

    public function searchTransfer($data, $config){

        $current_time = date('Y-m-d H:i:s');
        $post_data = [
            "method" => "order_query",
            "req_time" => $current_time,//请求时间，上下3分钟内有效
            "app_id" => $config['partner_id'],//中转平台唯一标识
            "order_number" => $data['order_number'],//商户订单号
        ];
        $res = $this->rsa_encrypt($post_data, $config['pub_key']);//参数加密
        $request_url = getEnv('WITHDRAW_REQUEST_URL');
        $this->add_log($config['partner_id'], $current_time." 向中转平台发起代付查询请求：{$data['order_number']},{$request_url},请求报文;".json_encode($post_data).";enstr,".$res);
        $rsp = $this->json_post($request_url, ["enstr"=>$res]);
        $this->add_log($config['partner_id'],date('Y-m-d H:i:s')." 中转平台查询回复：{$data['order_number']},响应报文;".json_encode($rsp));

        $result = json_decode($rsp['result'], true);

        $status = 2;
        if(isset($result['biz']['order_status'])) {
            switch ($result['biz']['order_status']) {
                case 'success' ://成功
                    $status = 1;
                    break;
                case 'failed' ://失败
                    $status = 5;
                    break;
            }
        }else if($result['code'] == "E008"){//中转平台没有生成订单
            $status = 5;
        }
        return ['status' => $status, 'third_order'=>$result['biz']['third_order'] ? $result['biz']['third_order'] : ''];// status  1 成功   5 失败   2 转账中
    }


    /**
     * 查询宝余额
     */
    public function queryBalance( $config){
        $current_time = date('Y-m-d H:i:s');
        $post_data = [
            "method" => "balance_query",
            "req_time" => $current_time,//请求时间，上下3分钟内有效
            "app_id" => $config['partner_id'],//中转平台唯一标识
        ];
        $res = $this->rsa_encrypt($post_data, $config['pub_key']);//参数加密
        $request_url = getEnv('WITHDRAW_REQUEST_URL');
        $this->add_log($config['partner_id'], $current_time." 向中转平台发起代付余额查询请求：{$config['partner_id']},{$request_url},请求报文;".json_encode($post_data).";enstr,".$res);
        $rsp = $this->json_post($request_url, ["enstr"=>$res]);
        $this->add_log($config['partner_id'],date('Y-m-d H:i:s')." 中转平台余额查询回复：{$config['partner_id']},响应报文;".json_encode($rsp));
        $result = json_decode($rsp['result'], true);

        // data：total_amount 支付宝账户余额，available_amount 	账户可用余额，freeze_amount 冻结金额
//        return ['status'=>$result['status'],'msg'=>$result['msg'],'balance'=>$result['balance']];

        return ['status'=>$result['status'],'msg'=>$result['msg'],'data'=>['balance'=>$result['balance']]];

    }

    protected function add_log($code, $str){
        $stream = @fopen("/data/logs/php/common-{$code}-".date('Ymd').".txt", "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }
}