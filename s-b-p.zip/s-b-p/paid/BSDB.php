<?php

/**
 * 博顺代付
 */
class BSDB {
	private $merId;

	private $key;

	private $pubKey;

	private $payKey;

	private $signKey;

	private $apiUrl;

	private $callbackUrl;

	public function initData($config)
	{
        $this->merId  = $config['partner_id'];
		$this->key   = $config['key'];
		$this->pubKey   = $config['pub_key'];
		$this->payKey   = $config['app_id'];
		$this->signKey   = $config['app_secret'];
		$this->apiUrl  = $config['request_url'];
		$this->callbackUrl  = $config['url_notify'];
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params,$config)
	{
	    $this->initData($config);
		$exchangeInfos = $params['exchange_infos'];
		$bankInfos 	   = $params['bank_infos'];
		$data = [
			"payKey" => $this->payKey,
            "cardNo" => $bankInfos['bank_num'],
            "cardName" => $bankInfos['user_name'],
            "noticeUrl" => '',
            "orderNo" => $params['order_num'],
			"tranTime" => date('YmdHis'),
            "tranAmt" => sprintf("%.2f", $exchangeInfos['amount'])*100,
		];
        $this->pubKey  = "-----BEGIN PUBLIC KEY-----\n".wordwrap($this->pubKey, 64, "\n", TRUE)."\n-----END PUBLIC KEY-----";
        $str = json_encode($data);
        $res['merId'] = md5($this->merId);
        $res['encryptData'] = $this->pukOpenssl($str);
        $res['signData'] = $this->sign($data);
        return $res;
	}
    //公钥加密
    public function pukOpenssl($str,$length=117){
        $encryptData = '';
        $crypto = '';
        foreach (str_split($str, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $this->pubKey);
            $crypto = $crypto . $encryptData;
        }

        $crypto = base64_encode($crypto);
        return $crypto;
    }
    //私钥解密
    public function privateDecrypt($encrypted = null,$length = 128){
        $encrypted = base64_decode($encrypted);
        $this->key = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($this->key, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $crypto = '';
        foreach (str_split($encrypted, $length) as $chunk) {

            openssl_private_decrypt($chunk, $decryptData, $this->key,OPENSSL_ALGO_MD5);

            $crypto .= $decryptData;

        }
        return $crypto;
    }
	public function sign($data){
        $data = array_filter($data);
        ksort($data);
        $str = '';
	    foreach ($data as $key=>$val) {
	        $str .= $key.'='.$val.'&';
        }
        $str = $str .'paySecret='.$this->signKey;
        return strtoupper(md5($str));
    }

	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params,$config)
	{
		$data = $this->_parseParams($params,$config);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $response = $this->_curl($this->apiUrl.'/agentpayApi/agentpay',$data);
        $response = $this->privateDecrypt($response);
		$result = json_decode($response,true);

		$res = [
			'status' => $result['respCode'] == '0000' ? true : false,
			'withdraw_status' => isset($result['resultFlag']) && $result['resultFlag'] == 2 ? 1 : 5,
			'out_order_num' => $result['bsSerial'] ?? '',
			'msg' => $result['respDesc'] ?? '',
		];

		return $res;
	}

	public function _curl($url,$para){
        $para = json_encode($para, JSON_UNESCAPED_UNICODE);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);          //单位 秒，也可以使用
        curl_setopt($ch, CURLOPT_POSTFIELDS, $para);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }


    /**
     * 海简法回调通知
     */
    public function callback($request_str = null)
    {
        echo 'success';exit;
    }
    function addLog($str){
        $stream = @fopen('/data/logs/php/wuxing_pay_logs.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    public function searchTransfer($data,$config){
        $data = [
            "payKey" 	=> $config['app_id'],
            "orderNo" 	=> $data['order_number'],
        ];
        $result = $this->_curl($config['request_url'].'/agentpayApi/queryOrder',$data);
        if(isset($result['resultFlag']) && $result['resultFlag']==1){
            return ['status' => 5];
        }elseif(isset($result['resultFlag']) && $result['orderStatus'] == 0){
            return ['status' => 1];
        }
        return ['status' => 2];
    }
}