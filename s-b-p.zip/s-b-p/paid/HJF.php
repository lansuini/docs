<?php
header("content-type:text/html;charset=utf-8");
class HJF {
    /**
     * 配置
     */
    private $config;
    private $nodeId;//节点号
    private $gateway;//请求地址
    private $orgId;//商户号
    private $base64edAESKey;
    private $private_key;
    private $public_key;
    private $callbackUrl;

    /**
     * 实例化
     */
    public function __construct()
    {
        $this->config = cfg::comm('pay');
        $this->nodeId  = $this->config['HJF']['nodeId'];
        $this->orgId = $this->config['HJF']['orgId'];
        $this->base64edAESKey   = $this->config['HJF']['base64edAESKey'];
        $this->private_key   = $this->config['HJF']['private_key'];
        $this->public_key   = $this->config['HJF']['public_key'];
        $this->gateway  = $this->config['HJF']['gateway'];
        $this->callbackUrl  = $this->config['HJF']['callback_url'];
    }

    /**
     * 解析第三方参数
     *
     * @param 通用参数
     */
    private function _parseParams($getdata)
    {
        $exchangeInfos = $getdata['exchange_infos'];
        $bankInfos 	   = $getdata['bank_infos'];
        $bank_name = $bankInfos['bank_name'];
        //$order_num = $getdata['order_num'];
                //var_dump($exchangeInfos);exit;
        $data = [
            'version'    => '1.0',
            'nodeId'     => $this->nodeId,
            'orgId'      => $this->orgId,
            'orderTime'  => date('YmdHis'),
            'txnType'    => 'T30242',
            'signType'   => 'RSA',
            'charset'    => 'UTF-8',
            'bizContext' => '',
            'sign'       => '',
        ];
        $bizContext = [
            'outTradeNo'  => $getdata['order_num'],
            'totalAmount' => sprintf("%.2f", $exchangeInfos["amount"]),
            'payeeBankName'    => $bank_name,
            'payeeSubBranchName' =>'高新园分行',
            'payeeAcc'     => $bankInfos['bank_num'],
            'payeeName'    => $bankInfos['user_name'],
            'privateFlag'  =>'S',
            'currency'     =>'CNY',
            'chargeType'   =>1,
            'notifyUrl'   => $this->callbackUrl,
        ];
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\n".wordwrap($this->private_key, 64, "\n", TRUE)."\n-----END RSA PRIVATE KEY-----";
        // 1. 业务参数 json 编码
        $bizContextJson = json_encode($bizContext);
        // 2. 业务参数签名
        $bizContextSign = $this->rsaSHA1Sign($bizContextJson,$private_key);
        // 3. 业务参数加密
        $bizContextAESEncrypt = $this->AESEncrypt($bizContextJson,$this->base64edAESKey);

        $data['sign']       = $bizContextSign;
        $data['bizContext'] = $bizContextAESEncrypt;
        return $data;
    }

    public  function rsaSHA1Sign($data, $privateKey) {
        $signature = '';
        openssl_sign($data, $signature, $privateKey, OPENSSL_ALGO_SHA1);

        return base64_encode($signature);
    }

    public  function AESEncrypt($preEncryptString, $aesKey) {
        $aesKey = base64_decode($aesKey);
        $size             = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB);
        $preEncryptString = $this->pkcs5_pad($preEncryptString, $size);
        $td               = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_ECB, '');
        $iv               = mcrypt_create_iv(mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        mcrypt_generic_init($td, $aesKey, $iv);
        $encryptData = mcrypt_generic($td, $preEncryptString);
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);

        $encryptData = base64_encode($encryptData);

        return $encryptData;
    }

    public  function AESDecrypt($encrypted,$charset = 'UTF-8') {
        $aesKey    = $this->base64edAESKey;
        $aesKey    = base64_decode($aesKey);  
        $encrypted = base64_decode(urldecode($encrypted));
        $decrypted = mcrypt_decrypt(
            MCRYPT_RIJNDAEL_128,
            $aesKey,
            $encrypted,
            MCRYPT_MODE_ECB
        );
        $decrypted = $this->pkcs5_unpad($decrypted); 
        return $decrypted;
    }

    public  function pkcs5_unpad($decrypted) {
        $len       = strlen($decrypted);
        $padding   = ord($decrypted[$len-1]);
        $decrypted = substr($decrypted, 0, -$padding);

        return $decrypted;
    }

    private function pkcs5_pad($text, $blocksize) {
        $pad = $blocksize-(strlen($text)%$blocksize);

        return $text.str_repeat(chr($pad), $pad);
    }
    /**
     * 验签  验证签名  基于sha1withRSA
     *
     * @param string $data      签名前的原字符串
     * @param string $signature 签名串
     * @param string $publicKey
     *
     * @return int
     */
    public  function rsaSHA1Verify($data, $signature) {
        $str        = chunk_split($this->public_key, 64, "\n");
        $public_key  = "-----BEGIN PUBLIC KEY-----\n".wordwrap($str, 64, "\n", TRUE)."-----END PUBLIC KEY-----";
        $signature = base64_decode(urldecode($signature));
        $result = openssl_verify($data, $signature, $public_key, OPENSSL_ALGO_SHA1);//openssl_verify 验签成功返回 1，失败 0，错误返回 -1
        return $result;
    }

    public function postForm($url, $data) {
        $headerArr = array();
        if (is_array($headers)) {
            foreach ($headers as $k => $v) {
                $headerArr[] = $k.': '.$v;
            }
        }
        $headerArr[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArr);
        if ($referer) {
            curl_setopt($ch, CURLOPT_REFERER, "http://{$referer}/");
        }
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

     public  function Decrypt($encrypted,$charset = 'UTF-8') {
        $aesKey    = $this->base64edAESKey;
        $aesKey    = base64_decode($aesKey);  
        $encrypted = base64_decode($encrypted);
        $decrypted = mcrypt_decrypt(
            MCRYPT_RIJNDAEL_128,
            $aesKey,
            $encrypted,
            MCRYPT_MODE_ECB
        );
        $decrypted = $this->pkcs5_unpad($decrypted); 
        return $decrypted;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params)
    {

        $data = $this->_parseParams($params);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $http_result = $this->postForm($this->gateway,$data);
        $result = json_decode($http_result,true);
        // var_dump($result);
        $bizContextAESDecrypt = $this->Decrypt($result['bizContext']);
        $bizContextAESDecrypt = json_decode($bizContextAESDecrypt,true);
        if ($result['code'] == 'SUCCESS'){ 
            if($bizContextAESDecrypt['retCode'] == 'RC0000' || $bizContextAESDecrypt['retCode'] == 'RC0001' ||$bizContextAESDecrypt['retCode'] == 'RC0002'){
                $res = [
                    'status' => true ,
                    'withdraw_status' => 4,
                    'out_order_num' => $bizContextAESDecrypt['outTradeNo'],
                    'msg' => $result['msg'],
                ];
                return $res;
            }else{
                  $res = [
                    'status' => true ,
                    'withdraw_status' => 5,
                    'out_order_num' => $bizContextAESDecrypt['outTradeNo'],
                    'msg' => $result['msg'],
                ];
                return $res;
            }
        }else{
            //调用第三方代付失败
            $res = [
                'status' => false,
                'withdraw_status' => 5,
                'out_order_num' => '',
                'msg' =>$result['msg'],
            ];
            return $res;
        }
    }
}