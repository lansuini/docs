<?php
/**
 * 五星代付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2018/12/28
 * Time: 10:20
 */
class WX {
    /**
     * 配置
     */
    private $config;
    /**
     * 商户号
     */
    private $app_key;


    /**
     * md5key
     */
    private $md5Key;

    /**
     * 请求地址
     */
    private $apiUrl;

    /**
     * 机构号
     */
    private $orgId;
    private $accountcode;

    /**
     * 实例化
     */
    public function __construct()
    {
        $this->config = cfg::comm('pay');
        $this->app_key  = $this->config['WX']['app_key'];
        //$this->orgId = $this->config['TB']['orgId'];
        $this->md5Key   = $this->config['WX']['md5_key'];
        $this->apiUrl  = $this->config['WX']['api_url'];
        //$this->accountcode  = $this->config['SY']['accountcode'];
        //$this->callbackUrl  = $this->config['SY']['callback_url'];
    }

    public function initData($config)
    {
        $this->app_key  = $config['app_secret'] ? $config['app_secret'] : $this->app_key;
        $this->md5Key   = $config['key'] ? $config['key'] : $this->md5Key;
        $this->apiUrl  = $config['request_url'] ? $config['request_url'] : $this->apiUrl;
    }
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config = [])
    {
        if($config) {
            $this->initData($config);
        }
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $bank_name = $bankInfos['bank_name'];
        $bank_code = $this->_getBankCode($bank_name);
        if(!$bank_code){
            $bank_code = $bankInfos['bank_code'];
        }
        $time = time();
        $data = [
            "signTime" => strftime("%Y%m%d%H%M%S",$time),
            "amount" => sprintf("%.2f", $exchangeInfos['amount']),
            "orderId" => $params['order_num'],
            "toBankCode" => $bank_code,
            "toBankAccNumber" => $bankInfos['bank_num'],
            "toBankAccName" => $bankInfos['user_name'],
            'signType' => 'hmacsha256',
            'version' => '01'
        ];
        // var_dump($data);exit;

        $data['sign'] = $this->_createSign($data);
//        /*$return = [
//            'merchantPayReq' => json_encode($data),
//        ];*/
        $return = json_encode($data);

        return $return;
    }

    /**
     * 生成sign
     */
    private function _createSign($data)
    {
        ksort($data);
        $string = '';
        foreach ($data as $key=>$val)
        {
            //if ($val){
                $string = $string?$string.'&'.$key.'='.$val:$key.'='.$val;
           // }
        }
        $md5_str = hash_hmac('sha256', $string, $this->md5Key);

        return $md5_str;
    }


    public function _httpUrl($data,$url='')
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','api_key:'.$this->app_key));
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        // 获得响应结果里的code
        $headercode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $arr = [
            'res' => $result,
            'code'=>$headercode
        ];
        //解释header参数
        list($header, $body) = explode("\r\n\r\n", $result, 2);

        $headers = explode("\r\n", $header);
        $headList = array();
        foreach ($headers as $head) {
            $value = explode(':', $head);
            $headList[$value[0]] = $value[1];
        }

        $arr['header'] = $headList;
        $arr['content'] = $body;
        return $arr;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config)
    {
        $data = $this->_parseParams($params,$config);
        //var_dump($data);exit;

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $http_result = $this->_httpUrl($data,$this->apiUrl.'/api/merchant/pay');
        $result = json_decode($http_result['content'],true);
        //var_dump($http_result);exit;

        if (!$result || $http_result['code'] == 200 && isset($result['sign'])){
            //提交代付订单成功
            $res = [
                'status' => true ,
                'withdraw_status' => 4,
                'out_order_num' => '',
                'msg' => 'success',
            ];
            return $res;
        }else{
            //调用第三方代付失败
            $res = [
                'status' => false,
                'withdraw_status' => 5,
                'out_order_num' => '',
                'msg' =>$result['code'].$result['msg'],
            ];
            return $res;
        }
    }

    public function verifySign($data)
    {
        $return_sign = $data['sign'];
        unset($data['sign']);
        $sign = $this->_createSign($data);
        if ($return_sign == $sign){
            return true;
        }
        return false;
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($name)
    {
        $bank_list = [
            'ICBC' => '工商银行',
            'ABC' => '农业银行',
            'BOC' => '中国银行',
            'CCB' => '建设银行',
            'BOCOM' => '交通银行',
            'CITIC' => '中信银行',
            'CEB' => '光大银行',
            'HXB' => '华夏银行',
            'CMBC' => '民生银行',
            'GDB' => '广发银行',
            'PINAN' => '平安银行',
            'CMB' => '招商银行',
            'CIB' => '兴业银行',
            'SPDB' => '浦发银行',
            'BCCB' => '北京银行',
            'BOS' => '上海银行',
            'PSBC' => '中国邮政',
            'RCC' =>'农村信用社',
        ];
        $code = '';
        foreach($bank_list as $key=>$val)
        {
            if (trim($val) == trim($name)){
                $code = $key;
                break;
            }
        }
        return $code;
    }

    private function _getErrorStr($code)
    {
        $error =  [
            1001 => '扣减金额大于可提现金额',
            1002 => '可结算金额不足',
            2001 => 'Ip白名单不存在',
            2002 => '参数为空',
            2003 => '签名错误',
            2004 => '商户不存在',
            2005 => '商户账户不存在',
            2006 => '账户被冻结',
            2007 => '订单重复',
            2009 => '业务未开通',
            2010 => '银行卡未设置白名单',
            2012 => '金额超限',
            2013 => '不支持的银行',
            9999 => '未知错误',
        ];

        return $error[$code];
    }

    //查询代付结果
    public function searchTransfer($data,$config)
    {
        $this->initData($config);
        $s_data['orderId'] = $data['order_number'];
        $s_data['signTime'] = date('YmdHis');//signTime需要加入签名
        $s_data['sign']= $this->_createSign($s_data);
        $re = $this->_httpUrl(json_encode($s_data),$this->apiUrl.'/api/merchant/order_query');
        $re_arr = json_decode($re['content'], true);
        if (isset($re['code']) && $re['code'] == 200) {
            switch ($re_arr['status']) {
                case 'S'://交易成功
                    return ['status' => 1];
                    break;
                case 'F'://交易失败
                    return ['status' => 5];
                    break;
                default:
                    return ['status' => 2];
            }
        }
        return ['status' => 2];
    }


}