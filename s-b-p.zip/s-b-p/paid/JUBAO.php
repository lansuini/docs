<?php
/**
 * 聚宝代付
 * @author Taylor 2019-06-18
 */
class JUBAO {
    /**
     * 配置
     */
    private $config;

    //异步回调
//    public function callback(){
//        exit('SUCCESS');
//    }

    //通常MD5加密方法  有些加密需要带key= 有些直接接key
    public function currentMd5($param, string $key = null){
        $signPars = $this->arrayToURL($param);
        $signPars .= $key.$this->config['app_secret'];
        return md5($signPars);
    }

    public function arrayToURL($param) {
        $signPars = "";
        ksort($param);
        foreach($param as $k => $v) {
            //  字符串0  和 0 全过滤了，所以加上
            if(!empty($v) || $v === 0  || $v === "0" ) {
                $signPars .= $k . "=" . $v . "&";
            }
        }
        $signPars = rtrim($signPars,'&');
        return $signPars;
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];//提现订单信息
        $bankInfos 	   = $params['bank_infos'];//银行信息
//        使用测试账号
//        $bankInfos['bank_name'] = '建设银行';
//        $bankInfos['bank_code'] = "CCB";
//        $bankInfos['user_name'] = "卢勇庭";
//        $bankInfos['bank_num'] = "6217003360009896951";
//        $exchangeInfos['mobile'] = "19833037749";
//        $exchangeInfos['amount'] = 0.1;
        $bank_code = $this->_getBankCode(trim($bankInfos['bank_name']));//根据银行名称来查询，因为代理兑换的bank_code可能为空
        if($bank_code === false) {
            return false;
        }
        //业务参数
        $sys_params = [
            "merno" => $this->config['partner_id'],//商户号
            "method" => 'payment.doPayment',//业务编号
//            "accountcode"=> $this->config['token'],//账户数字编号
            "accountcode"=> $this->get_account_no($params),//账户数字编号
            "accounttype" => '0',//账户类型，代付类型 0-从余额代付 1-从T1余额代付
            "amount" => $exchangeInfos['amount'] * 100,//交易金额，单位为分
            "order_id" => $params['order_num'],//商户代付单号
            "cardname"=> $bank_code[0],//开户行名称
            "bank_code"=> $bank_code[0],//银行编码
            "cardno"=> $bankInfos['bank_num'],//银行卡号
            "name"=> $bankInfos['user_name'],//收款人姓名
        ];
        //公共参数
        $comm_params = [
            'requestId' => time().$params['order_num'],//请求订单号
            'orgId' => $this->config['app_id'],//结构号
            'timestamp' => date('YmdHis'),//请求时间戳
            'productId' => '9500',//产品ID
            'businessData' => json_encode($sys_params),//业务数据
        ];
        $sign = strtoupper($this->currentMd5($comm_params));
        $comm_params['signData'] = $sign;//数据签名
        return $comm_params;
    }

    protected function get_account_no($params){
        //查询转账任务接口
        //公共参数
        $sys_params = [
            "merno" => $this->config['partner_id'],//商户号
            "method" => 'payment.loadBanlance',//业务编号
        ];
        $comm_params = [
            'requestId' => rand(100000, 999999).time().$params['exchange_infos']['uid'],//请求订单号
            'orgId' => $this->config['app_id'],//结构号
            'timestamp' => date('YmdHis'),//请求时间戳
            'productId' => '9500',//产品ID
            'businessData' => json_encode($sys_params),//业务数据
        ];
        $sign = strtoupper($this->currentMd5($comm_params));
        $comm_params['signData'] = $sign;//数据签名
//        var_dump($comm_params);
        $rsHttp = $this->postJSON($this->config['request_url'].'/payment/invoke', $comm_params, 60);
//        $rsHttp = [200, '{"key":"00","msg":"账户查询成功","requestId":"1561105205200029","respCode":"00","respMsg":"通讯成功","result":"{\"accountinfo\":[{\"d0can_use\":151018,\"min\":1000,\"d0frozen\":14,\"max\":5000000,\"account_name\":\"HC（唐朝娱乐）纯代付(48301)\",\"t1balance\":0,\"d0balance\":151032,\"accountcode\":4499,\"t1can_use\":0,\"t1frozen\":0},{\"d0can_use\":3480510,\"min\":1000,\"d0frozen\":1,\"max\":5000000,\"account_name\":\"WFTDF（唐朝娱乐）纯代付\",\"t1balance\":0,\"d0balance\":3480511,\"accountcode\":4503,\"t1can_use\":0,\"t1frozen\":0}],\"merno\":\"532019411717064696\",\"method\":\"payment.loadBanlance\",\"skipUpmer\":[]}","status":"1"}'];
        if($rsHttp[0] == 200){
            $rs = json_decode($rsHttp[1],true);
            if($rs['respCode'] == '00' && in_array($rs['key'], ['00', '05'])){
                $result = json_decode($rs['result'], true);
                $account = $result['accountinfo'];
                if(isset($account[0])){//二个账户，二维数组
                    $acc_no = $account[0]['accountcode'];//账户
                    $acc_amount = $account[0]['d0can_use'];//可用金额
                    foreach($account as $d){
                        if($d['d0can_use'] > $acc_amount){
                            $acc_no = $d['accountcode'];
                            $acc_amount = $d['d0can_use'];
                        }
                    }
                    return $acc_no;
                }else{//只有一个账户
                    return $account['accountcode'];
                }
            }
        }
        return $this->config['token'];
    }

    /**
     * 请求数据方法
     */
    private function postJSON($url, $params = NULL, $timeout = 60){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        if(is_array($params)){
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        }else{
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if($http_status == 200){//请求成功
            return [200, $response];
        }else{
            return [$http_status, "http_status:$http_status,response:$response,error:$error"];
        }
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params, $config)
    {
        $this->config = $config;
        $data = $this->_parseParams($params);
//        var_dump($params);
        if($data === false) {
            $res = [
                'status' 		    => false,// 超时也默认提交成功
                'withdraw_status' => 5,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num'   => '',
                'msg' 			    => '不支付该银行卡代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $rsHttp = $this->postJSON($this->config['request_url'].'/payment/invoke', $data, 60);
//        $rsHttp = [200, '{"key":"05","msg":"代付申请成功","requestId":"9236671201200029","respCode":"00","respMsg":"通讯成功","result":"{\"accountcode\":\"4499\",\"accounttype\":\"0\",\"amount\":\"1000\",\"bank_code\":\"建设银行\",\"cardname\":\"建设银行\",\"cardno\":\"6217003360009896951\",\"merno\":\"532019411717064696\",\"method\":\"payment.doPayment\",\"name\":\"卢勇庭\",\"order_id\":\"9236671201200029\",\"skipUpmer\":[]}","status":"3"}'];
        //{"timestamp":1560867349480,"status":405,"error":"Method Not Allowed","exception":"org.springframework.web.HttpRequestMethodNotSupportedException","message":"Request method 'POST' not supported","path":"/open-gateway//webwt/pay/gateway"}
        //{"requestId":"6389448405200029","respCode":"SI","respMsg":"签名错误或业务数据解密失败"}
        //{"key":"500001","msg":"暂无可用通道","requestId":"5023962886200029","respCode":"00","respMsg":"通讯成功","status":"2"}
        //{"key":"05","msg":"代付申请成功","requestId":"9236671201200029","respCode":"00","respMsg":"通讯成功","result":"{\"accountcode\":\"4499\",\"accounttype\":\"0\",\"amount\":\"1000\",\"bank_code\":\"建设银行\",\"cardname\":\"建设银行\",\"cardno\":\"6217003360009896951\",\"merno\":\"532019411717064696\",\"method\":\"payment.doPayment\",\"name\":\"卢勇庭\",\"order_id\":\"9236671201200029\",\"skipUpmer\":[]}","status":"3"}
        if($rsHttp[0] == 200){
            $rs = json_decode($rsHttp[1],true);
            if($rs['respCode'] == '00' && in_array($rs['key'], ['00', '05'])){
                $status = true;
                $withdraw_status = 4;//成功
                $msg = '';
            }else{
                $status = false;
                $withdraw_status = 5;//失败
                $msg = $rs['respCode'].":".$rs['respMsg'].','.$rs['key'].':'.$rs['msg'];
            }
        }else{
            $status = false;
            $withdraw_status = 5;//失败
            $msg = "order_num:{$params['order_num']},".$rsHttp[1];
        }
        $res = [
            'status' 		  =>  $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num'   => isset($rs['requestId']) ? $rs['requestId'] : $params['order_num'],
            'msg' 			  => $msg,
        ];
        return $res;
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = ''){
        $this->config = $config;
        //查询转账任务接口
        //公共参数
        $sys_params = [
            "merno" => $this->config['partner_id'],//商户号
            "method" => 'payment.queryPayment',//业务编号
            "order_id" => $data['order_number'],//订单号
        ];
        $comm_params = [
            'requestId' => rand(10000, 99999).time().$data['uid'],//请求订单号
            'orgId' => $this->config['app_id'],//结构号
            'timestamp' => date('YmdHis'),//请求时间戳
            'productId' => '9500',//产品ID
            'businessData' => json_encode($sys_params),//业务数据
        ];
        $sign = strtoupper($this->currentMd5($comm_params));
        $comm_params['signData'] = $sign;//数据签名
//        var_dump($comm_params);

        $rsHttp = $this->postJSON($this->config['request_url'].'/payment/invoke', $comm_params, 60);
//        {"key":"00","msg":"查询成功","requestId":"1560928508200029","respCode":"00","respMsg":"通讯成功","result":"{\"amount\":\"1000\",\"merno\":\"532019411717064696\",\"method\":\"payment.queryPayment\",\"order_id\":\"9236671201200029\",\"plat_order_sn\":\"20190619115616708aH6\",\"skipUpmer\":[],\"status\":3}","status":"1"}
        $rs = json_decode($rsHttp[1],true);

        $status = 2;//转账中
        if($rs['respCode'] == '00') {
            $result = json_decode($rs['result'],true);
            switch ($result['status']) {
                //1- 处理中 2- 处理失败 3- 代付成功 4- 代付失败
                case 3 :
                    $status = 1;//成功
                    break;
                case 2 :
                case 4 :
                    $status = 5;//失败
                    break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            '工商银行' => ['工商银行', '102', 'ICBC'],
            '农业银行' => ['农业银行', '103', 'ABC'],
            '中国银行' => ['中国银行', '104', 'BOC'],
            '建设银行' => ['建设银行', '105', 'CCB'],
            '交通银行' => ['交通银行', '301', 'COMM'],
            '中信银行' => ['中信银行', '302', 'CITIC'],
            '光大银行' => ['光大银行', '303', 'CEB'],
            '华夏银行' => ['华夏银行', '304', 'HXB'],
            '民生银行' => ['民生银行', '305', 'CMBC'],
            '广发银行' => ['广发银行', '306', 'GDB'],
            '平安银行' => ['平安银行', '307', 'SZPAB'],
            '招商银行' => ['招商银行', '308', 'CMB'],
            '兴业银行' => ['兴业银行', '309', 'CIB'],
            '浦发银行' => ['浦发银行', '310', 'SPDB'],
            '北京银行' => ['北京银行', '313', 'BCCB'],
            '上海银行' => ['上海银行', '325', 'BOS'],
            '中国邮政' => ['邮储银行', '403', 'PSBC'],
            '深圳发展银行' => ['深圳发展银行', 'SDB'],
//            '徽商银行' => ['微商银行', '440', 'HSBANK'],
//            '农村信用社' => ['农村信用社', 'RCC'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

}