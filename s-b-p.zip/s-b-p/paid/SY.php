<?php
/**
 * 双银代付
 * Created by PhpStorm.
 * User: shuidong
 * Date: 2018/11/22
 * Time: 15:07
 */
class SY {
    /**
     * 配置
     */
    private $config;
    /**
     * 商户号
     */
    private $merno;


    /**
     * md5key
     */
    private $md5Key;

    /**
     * 请求地址
     */
    private $apiUrl;

    /**
     * 机构号
     */
    private $orgId;
    private $accountcode;

    /**
     * 实例化
     */
    public function __construct()
    {
        $this->config = cfg::comm('pay');
        $this->merno  = $this->config['SY']['merno'];
        $this->orgId = $this->config['SY']['orgId'];
        $this->md5Key   = $this->config['SY']['md5_key'];
        $this->apiUrl  = $this->config['SY']['api_url'];
        $this->accountcode  = $this->config['SY']['accountcode'];
        //$this->callbackUrl  = $this->config['SY']['callback_url'];
    }

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankCode($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];

        $time = time();
        $business_data = [
            "merno" => $this->merno,
            "method" => 'payment.doPayment',
            "accountcode" => $this->accountcode,
            "accounttype" => 0,
            "amount" => $exchangeInfos['amount']*100,
            "order_id" => $params['order_num'],
            "cardname" => $bank_name,
            "bank_code" => $bank_code,
            "cardno" => $bankInfos['bank_num'],
            "name" => $bankInfos['user_name'],
        ];
        $data = [
            'requestId' => (string)$params['order_num'],
            'orgId' => $this->orgId,
            'timestamp' => date('YmdHis',$time),
            'productId' => '9500',
            'businessData' => json_encode($business_data),
        ];

        $data['signData'] = $this->_createSign($data);

        return $data;
    }

    /**
     * 生成sign
     */
    private function _createSign($data)
    {
        ksort($data);
        $string = '';
        foreach ($data as $key=>$val)
        {
            $string = $string?$string.'&'.$key.'='.$val:$key.'='.$val;
        }
        $string = $string.$this->md5Key;
        $md5_str = md5($string);

        return strtoupper($md5_str);
    }


    public function _httpUrl($data,$url='')
    {
        $post_string = http_build_query($data);
        $ch = curl_init($this->apiUrl.$url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params)
    {
        $data = $this->_parseParams($params);
        if($data === false) {
            //代付业务失败
            $res = [
                'status' => false,
                'withdraw_status' => 5,
                'out_order_num' => '',
                'msg' => 'SY不支付该银行代付',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $http_result = $this->_httpUrl($data);
        $result = json_decode($http_result,true);

        if(!$result) {
            //代付业务成功
            $res = [
                'status' => true ,
                'withdraw_status' => 1,
                'out_order_num' => $params['order_num'],
                'msg' => '超时默认处理中',
            ];
            return $res;
        }
        //var_dump($http_result);exit;

        if ($result['respCode'] == '00'){
            //调用第三方代付成功
            /*if ($result['key'] == '05'){
                //申请成功，待处理
                $res = [
                    'status' => true ,
                    'withdraw_status' => 4,
                    'out_order_num' => $params['order_num'],
                    'msg' => $result['msg'],
                ];
                return $res;

            }else*/
            if($result['key'] == '00' || $result['key'] == '05'){
                //代付业务成功
                $res = [
                    'status' => true ,
                    'withdraw_status' => 1,
                    'out_order_num' => $params['order_num'],
                    'msg' => $result['msg'],
                ];
                return $res;
            }else{
                //代付业务失败
                $res = [
                    'status' => false,
                    'withdraw_status' => 5,
                    'out_order_num' => '',
                    'msg' =>$result['msg'],
                ];
                return $res;
            }
        }else{
            //调用第三方代付失败
            $res = [
                'status' => false,
                'withdraw_status' => 5,
                'out_order_num' => '',
                'msg' =>$result['respMsg'],
            ];
            return $res;
        }
    }

    /**
     * 查询账户余额，获取数字编号
     */
    private function _checkAccountBanlance()
    {
        $business_data = [
            'merno' => $this->merno,
            'method' => 'payment.loadBanlance',
        ];
        $data = [
            'requestId' => 'invoke'.time().mt_rand(11111,99999),
            'orgId' => $this->orgId,
            'timestamp' => date('YmdHis',time()),
            'productId' => '9500',
            'businessData' => json_encode($business_data),
        ];
        $data['signData'] = $this->_createSign($data);
        $result = $this->_httpUrl($data,'/payment/invoke');
        return json_decode($result,true);
    }

    /**
     * 获取代付平台 的银行code
     */
    private function _getBankCode($code)
    {
        $bank_list = [
            'ICBC' => ['code'=>1001 , 'name'=> '工商银行'],
            'ABC' => ['code'=>1002 , 'name' => '农业银行'],
            'BOC' => ['code'=>1003 , 'name' => '中国银行'],
            'CCB' => ['code'=>1004 , 'name' => '建设银行'],
            'BCM' => ['code'=>1005 , 'name' => '交通银行'],
            'CNCB' => ['code'=>1006 , 'name' => '中信银行'],
            'CEB' => ['code'=>1007 , 'name' => '光大银行'],
            'HXB' => ['code'=>1008 , 'name' => '华夏银行'],
            'CMBC' => ['code'=>1009 , 'name' => '民生银行'],
            'GDB' => ['code'=>1010 , 'name' => '广发银行'],
            'PAB' => ['code'=>1011 , 'name' => '平安银行'],
            'CMB' => ['code'=>1012 , 'name' => '招商银行'],
            'CIB' => ['code'=>1013 , 'name' => '兴业银行'],
            'SPDB' => ['code'=>1014 , 'name' => '浦发银行'],
            'BCCB' => ['code'=>1015 , 'name' => '北京银行'],
            //'ICBC' => ['code'=>1016 , 'name' => '天津银行'],
            //'ICBC' => ['code'=>1017 , 'name' => '河北银行'],
            //'ICBC' => ['code'=>1118 , 'name' => '恒丰银行'],
            //316 => '浙商银行',
            //'ICBC' => ['code'=>1121 , 'name' => '渤海银行'],
            'SHB' => ['code'=>1040 , 'name' => '上海银行'],
            'PSBC' => ['code'=>1141 , 'name' => '邮储银行'],
            'RCC' => ['code'=>1218 , 'name' => '河北省农村信用社联合社'],
            //'ICBC' => ['code'=>1088 , 'name' => '广东华兴银行'],
            //'ICBC' => ['code'=>1086 , 'name' => '广州银行'],
            //'ICBC' => ['code'=>1085 , 'name' => '长沙银行'],
            //'ICBC' => ['code'=>1061 , 'name' => '青岛银行'],
            //'HSB' => ['code'=>440 , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : false;
    }

    private function _getErrorStr($code)
    {
        $error =  [
            1001 => '扣减金额大于可提现金额',
            1002 => '可结算金额不足',
            2001 => 'Ip白名单不存在',
            2002 => '参数为空',
            2003 => '签名错误',
            2004 => '商户不存在',
            2005 => '商户账户不存在',
            2006 => '账户被冻结',
            2007 => '订单重复',
            2009 => '业务未开通',
            2010 => '银行卡未设置白名单',
            2012 => '金额超限',
            2013 => '不支持的银行',
            9999 => '未知错误',
        ];

        return $error[$code];
    }


}