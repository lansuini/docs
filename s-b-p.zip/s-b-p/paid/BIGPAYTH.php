<?php

/**
 * BigPay-泰版
 */
class BIGPAYTH
{

    protected $config;//代付通道配置

    public function getSign($data, $api_key)
    {
        //组装签名字段 签名 MD5(merchant_no+params+sign_type+timestamp+Key)-说明key 是商户秘钥
        //Assemble the signature field Signature MD5 (merchant_no+params+sign_type+timestamp+Key)-indicating that the key is the merchant secret key
        $merchant_no = isset($data['merchant_no']) ? $data['merchant_no'] : '';
        $params = isset($data['params']) ? $data['params'] : '';
        $sign_type = isset($data['sign_type']) ? $data['sign_type'] : '';
        $timestamp = isset($data['timestamp']) ? $data['timestamp'] : '';

        $sign_str = $merchant_no . $params . $sign_type . $timestamp . $api_key;
        $sign = md5($sign_str);//MD5签名 不区分大小写  MD5 signature is not case sensitive
        return $sign;
    }


    /**
     * 提现操作
     *
     * @param $params 订单和用户银行卡信息
     * @param $config 代付通道配置信息
     *
     * @return array
     */
    public function withdraw($params, $config)
    {

        $this->config = $config;
        $bankInfos = $params['bank_infos'];//银行卡信息
        $exchangeInfos = $params['exchange_infos'];//订单信息

        //业务请求参数 Business request parameters
        $paramsData = array(
            'merchant_ref' => $params['order_num'],//	是	string	商户订单号 Merchant order number
            'product' => 'ThaiPayout',//	是	integer	产品名称 根据商户后台开通为主 product name Mainly based on the merchant backstage activation
            'amount' => sprintf("%.2f", $exchangeInfos['amount']),//	是	string	金额，单位，保留 2 位小数 Amount, unit, 2 decimal places
        );

        //extra 参数, 可选字段 extra parameter, optional field
        $extra = array(
            'account_name' => $bankInfos['user_name'],//	是	string	持卡人姓名 Cardholder's Name
            'account_no' => $bankInfos['bank_num'],//	是	string	银行卡号 Bank card number
            //$tmp_bank['code'] 暂时用传过来的code，如果第三方有要求在加以转换
            'bank_code' => $bankInfos['bank_code'],//	是	string	提现银行代码 Withdrawal bank code or IFSC or UPI
        );

        //判断 额外参数是否为空 Determine whether the extra parameter is empty
        if ($extra) {
            $paramsData['extra'] = $extra;
        }

        //转换json串 Convert json string
        $params_json = json_encode($paramsData, 320);

        //请求参数 Request parameter
        $data = array(
            'merchant_no' => $config['partner_id'],//	是	string	商户号 business number
            'timestamp' => time(),//	是	integer	发送请求的 10 位时间戳 10-bit timestamp of sending request
            'sign_type' => 'MD5',//	是	string	默认为 MD5 Default is MD5
            'params' => $params_json,//	是	string	请求业务参数组成的 JSON String；若接口对应的业务参数不需要字段传输，该字段的值可为空字符串
        );

        $data['sign'] = $this->getSign($data, $config['key']);//MD5签名 不区分大小写 MD5 signature is not case sensitive


        if ($e = oo::withdraw()->error($params, $data)) {
            return $e;
        }

        $result = $this->request($data, $this->config['request_url'] . '/api/gateway/withdraw');

        $this->addLog("下单请求参数:" . json_encode($data, JSON_UNESCAPED_UNICODE) . ';返回参数：' . $result);
        $result = json_decode($result, true);

        $out_order_num = $params['order_num'];
        if (empty($result)) {
            $res = [
                'status' => true,// 超时也默认提交成功
                'withdraw_status' => 4,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'out_order_num' => $out_order_num,
                'msg' => '超时，返回数据为空',
            ];
            return $res;
        }

        if (isset($result['code']) && $result['code'] != 200) {
            $status = false;
            $withdraw_status = 5;//失败
            $msg = $result['message'];
        } else {//提交代付订单成功
            $paramsRes = json_decode($result['params'], true);
            //订单状态：1：Success； 2: Pending；5: Reject
            if ($paramsRes['status'] == 5) {
                $status = false;
                $withdraw_status = 5;//失败
                $msg = "code:{$result['code']},message:{$result['message']},status:{$paramsRes['status']}";;
            } else {
                $status = true;
                $withdraw_status = 4;//默认处理中
                $msg = $result['msg'];
                $out_order_num = isset($paramsRes['system_ref']) ? $paramsRes['system_ref'] : '';
            }
        }
        $res = [
            'status' => $status,//超时也默认提交成功
            'withdraw_status' => $withdraw_status,//'代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'out_order_num' => $out_order_num,
            'msg' => $msg,
        ];
        return $res;
    }


    //异步回调
    public function callback()
    {
        exit('SUCCESS');
    }

    /**
     * 订单查询
     * @param $data rechage.withdraw 代付通道订单信息
     * @param $config log_comm_jlmj.transfer_config 代付通道配置信息
     * @param $p log_comm_jlmj.exchange 用户提现订单 or jinliu_agent2.spread_tx 代理用户提现订单
     */
    public function searchTransfer($data, $config, $p = '')
    {
        $this->config = $config;

        //需要在商户后台配置 IP 白名单 Need to configure the IP whitelist in the merchant backgroun
        $merchant_refs = [$data['order_number']];

        //业务请求参数 Business request parameters
        $params = array(
            "merchant_refs" => $merchant_refs, //	是	array	商户订单号列表 Merchant order number list
        );

        //转换json串 Convert json string
        $params_json = json_encode($params, 320);

        //请求参数 Request parameter
        $data = array(
            'merchant_no' => $config['partner_id'],//	是	string	商户号 business number
            'timestamp' => time(),//	是	integer	发送请求的 10 位时间戳 10-bit timestamp of sending request
            'sign_type' => 'MD5',//	是	string	默认为 MD5 Default is MD5
            'params' => $params_json,//	是	string	请求业务参数组成的 JSON String；若接口对应的业务参数不需要字段传输，该字段的值可为空字符串
        );

        $data['sign'] = $this->getSign($data, $config['key']);//MD5签名 不区分大小写 MD5 signature is not case sensitive


        $result = $this->request($data, $config['request_url'] . '/api/gateway/batch-query/order');
        $this->addLog("查询订单:" . json_encode($data, JSON_UNESCAPED_UNICODE) . ';返回参数：' . $result);
        $result = json_decode($result, true);
//        var_dump($result);
        $status = 2;//处理中
        $error_msg = $result['message'];
        if (isset($result['params'])) {
            //返回的是个json数组，对应查询的订单号列表
            $params = json_decode($result['params'], true);
            $order = $params[0];//只有一笔，取第一笔就行了
            switch ($order['status']) {
                //10:待执行,20:执行中,30:执行异常,40:失败结束,50:已完成
                case '1' :
                    $status = 1;//成功
                    break;
                case '5' :
                    $status = 5;//失败
                    break;
                default:
                    $status = 2;
            }
        }elseif($result['code'] != 200 && strpos($result['message'], 'Order does not exist') !== false) {//订单号不存在
            $status = 5;//失败
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    /** 发起http请求
     * @param $appID
     * @param $json
     * @param $ext
     * @param $sign
     */
    public function request($params, $url)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;
    }


    public function addLog($str)
    {
        $stream = @fopen('/data/logs/php/BigPayth.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, date('Y-m-d H:i:s') . '  ' . $str);
        @fclose($stream);
    }

}