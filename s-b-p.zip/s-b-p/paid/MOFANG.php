<?php

/**
 * 魔方
 */
class MOFANG {

    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config)
    {
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
        if($tmp_bank === false) {
            return false;
        }
        $bank_name = $tmp_bank['name'];
        $bank_code = $tmp_bank['code'];
        $datas = [
            'versionId' => '1.1',
            'orderAmount' => $exchangeInfos['amount'] * 100,
            'orderDate' => date('YmdHis'),
            'currency' => 'RMB',
            'transType' => '0008',
            'asynNotifyUrl' => $config['url_notify'],
            'signType' => 'MD5',
            'merId' => $config['partner_id'],       //商户编号
            'prdOrdNo' => $params['order_num'],
            'receivableType' => 'D00',
            'isCompay' => '0',
            'phoneNo' => 13284568754,
            'customerName' => $bankInfos['user_name'],
            'cerdId' => '430528198411034268',
            'accBankNo' => $bank_code,
            'accBankName' => $bank_name,
            'acctNo' => $bankInfos['bank_num'],
            'outaccounttype' => '2',
        ];
        ksort($datas);
        $datas['signData'] = md5($this->arrayToURL($datas).'&key='.$config['key']);
        return $datas;
    }

    public function arrayToURL($data) {
        $signPars = "";
        foreach($data as $k => $v) {
            $signPars .= $k . "=" . $v . "&";
        }
        $signPars = rtrim($signPars,'&');
        return $signPars;
    }


    /**
     * 提现操作
     *
     * @param array $data 参数
     *
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '魔方不支付该银行卡代付',
            ];
            return $res;
        }
        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }
        $result = $this->_curl($config['request_url'].'/payment/WithdrawApply.do',$data);
        $result = json_decode($result,true);
        if(isset($result['retCode']) && $result['retCode'] != 1){
            $status = false;
            $withdraw_status = 5;
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => $result['prdOrdNo'] ?? '',
            'msg' 			  => $result['retMsg'] ?? '',
        ];
        return $res;
    }

    /**
     * 获取代付平台 的银行
     */
    private function _getBankName($code = '')
    {
        if(!$code) return false;
        $bank_list = [
            'ICBC' => ['name' => '工商银行', 'code'=>'102'],
            'ABC' => ['name' => '农业银行', 'code'=>'103'],
            'BOC' => ['name' => '中国银行', 'code'=>'104'],
            'CCB' => ['name' => '建设银行', 'code'=>'105'],
            'BCM' => ['name' => '交通银行', 'code'=>'301'],
            'CNCB' => ['name' => '中信银行', 'code'=>'302'],
            'CEB' => ['name' => '光大银行', 'code'=>'303'],
            'HXB' =>  ['name' => '华夏银行', 'code'=>'304'],
            'CMBC' => ['name' => '民生银行', 'code'=>'305'],
            'GDB' => ['name' => '广发银行', 'code'=>'306'],
            'PAB' => ['name' => '平安银行', 'code'=>'307'],
            'CMB' => ['name' => '招商银行', 'code'=>'308'],
            'CIB' => ['name' => '兴业银行', 'code'=>'309'],
            'SPDB' => ['name' => '浦发银行', 'code'=>'310'],
            'BCCB' => ['name' => '北京银行', 'code'=>'314'],
            'SHB' => ['name' => '上海银行', 'code'=>'325'],
            'PSBC' => ['name' => '邮储银行', 'code'=>'403'],
//            'RCC' => ['code'=>'RCC' , 'name' => '农村信用社'],
//            'HSB' => ['code'=>'HSB' , 'name' => '徽商银行'],
        ];
        return isset($bank_list[$code]) ? $bank_list[$code] : '101';
    }

    // 1413295644200102
    public function searchTransfer($data,$config){
        $data = [
            'versionId' 	=> '1.1',
            'signType' 	=> 'MD5',
            'prdOrdNo' 	=> $data['order_number'],
            'merId' => $config['partner_id'],
        ];
        ksort($data);
        $data['signData'] = md5($this->arrayToURL($data).'&key='.$config['key']);
        $result = $this->_curl($config['request_url'].'/payment/OrderStatusQuery.do',$data);
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['orderStatus'])) {
            switch ($result['orderStatus']) {
                case '01' :
                    $status = 1;break;
                case '00' :
                case '22' :
                    $status = 5;break;
//                case '':   //该第三方代付无法区别代付失败原因，只能知道成功与失败
//                    $status = 3;break;
            }
        }
        return ['status' => $status];  // status  1 成功   5 失败   3 失败原因导致该单无法代付  卡号原因，账户没等
    }

    public function _curl($url,$para){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;
    }

    public function callback()
    {
        echo 'SUCCESS';exit;
    }

}