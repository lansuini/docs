<?php

/**
 * 太阳银行卡代付
 */
class TAIYANG {
    /**
     * 解析第三方参数
     *
     * @param array $params 通用参数
     */
    private function _parseParams($params,$config){
        $exchangeInfos = $params['exchange_infos'];
        $bankInfos 	   = $params['bank_infos'];
//        $tmp_bank = $this->_getBankName($bankInfos['bank_code']);
//        if(!$tmp_bank){
//            $tmp_bank = $this->_getBankCode($bankInfos['bank_name']);
//        }
//        if($tmp_bank === false) {
//            return false;
//        }
        if(empty($bankInfos['bank_code']) || empty($bankInfos['bank_name'])){
            return false;
        }
        //        使用测试账号
//        $bankInfos['user_name'] = '梁淑云';
//        $bankInfos['bank_name'] = '建设银行';
//        $bankInfos['bank_num'] = "6217000130056788275";
//        $exchangeInfos['amount'] = 1;
//        $exchangeInfos['mobile'] = "17810648053";
//        $bank_code = $bankInfos['bank_code'];
//        $bank_name = $bankInfos['bank_name'];
        $datas['username'] = $config['partner_id'];//商户号就是登录账户
        $sign_data = [
            'CardName' => $bankInfos['user_name'],//开户名
            'Phone' => '', //开户手机
            'OpenBank' => $bankInfos['bank_name'],//开户行
            'CardNum' => $bankInfos['bank_num'],//银行卡号
            'Amount' => $exchangeInfos['amount'],//金额,单位:元
            'ReturnUrl' => $config['url_notify'],//回调地址
            'OutOrderId' => $params['order_num'],//订单号
        ];
        $datas['data'] = "[".json_encode($sign_data)."]";
        $datas['sign'] = $this->getSign($datas['data'], $config['key']);
        return $datas;
    }

    public function getSign($res_str, $key) {
        return strtoupper(md5($res_str. $key));
    }

    /**
     * 提现操作
     * @param array $data 参数
     * @return json
     */
    public function withdraw($params,$config){
        $data = $this->_parseParams($params,$config);
        if($data === false) {
            $res = [
                'status' 		  => false, // 超时也默认提交成功
                // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
                'withdraw_status' => 5,
                'out_order_num'   => '',
                'msg' 			  => '没有绑定银行卡信息',
            ];
            return $res;
        }

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }

        $result = $this->_curl($config['request_url'].'/api/personnelfiles/order/api', $data);
        //{"msg":"签名无效","code":0,"data":null}
        //{"msg":"success","code":1,"data":"{\"success\":0,\"fail\":1,\"failList\":[\"4230174180200029\"],\"failMsg\":[\"余额不足\"]}"}
        $result = json_decode($result,true);
        $result_data = json_decode($result['data'], true);
        $msg = '';
        if(isset($result['code']) && $result['code'] == 1 && $result_data['success'] == 0){//代付失败
            $status = false;
            $withdraw_status = 5;
            $msg = $result_data['failMsg'] ? $result_data['failMsg'][0] : '';
        }else{
            $status = true;
            $withdraw_status = 4;
        }
        $res = [
            'status' 		  =>  $status, // 超时也默认提交成功
            // '代付结果 0 待支付；4 处理中；1 已提现；2 已撤销；3 已超时；5 失败',
            'withdraw_status' => $withdraw_status,
            'out_order_num'   => '',
            'msg' 			  => $msg,
        ];
        return $res;
    }

    // 代付查询
    public function searchTransfer($data,$config){
        $req_data = [
            'username' => $config['partner_id'],
            'data' => json_encode(['outOrderId'=>$data['order_number']]),//查询只能单条查询把[]去了就可以了"data":"{\"outOrderId\":\"7562545654200029\"}"
        ];
        $req_data['sign'] = $this->getSign($req_data['data'], $config['key']);
        $result = $this->_curl($config['request_url'].'/api/personnelfiles/order/get', $req_data);
        // {"msg":"数据不存在","code":0,"data":null}
        //{"msg":"success","code":1,"data":{"orderId":"T15871153296974692145048","amount":1.0,"fee":1.0,
        // "cardName":"梁淑云","phone":"","openBank":"建设银行","cardNum":"6217000130056788275","cardProvince":null,
        // "cardCity":null,"openSubBank":null,"cardType":null,"status":2,"auditId":"00000000-0000-0000-0000-000000000000",
        // "auditTime":"2020-04-17 17:22:09","payingId":21,"payTime":"2020-04-17 17:50:47","remark":null,
        // "returnUrl":"http://analysis-api.lqtest00.com/gateway.php?_sid=4100&_env=dev&mod=callback&act=result&platform=TAIYANG",
        // "outOrderId":"7562545654200029","isCallback":true,"payingName":null,"createdTime":"2020-04-17 17:22:09",
        // "createdBy":"b9c17370-a7fb-6a3c-1c21-39f4998a74e1","modifiedTime":"2020-04-17 17:50:47",
        // "modifiedBy":"e2e92988-8054-7952-9c60-39f45be541c8","creator":null,"modifier":null,"deleted":false,
        // "deletedTime":"2020-04-17 17:22:09","deletedBy":"00000000-0000-0000-0000-000000000000","deleter":null,"id":8510}}
        $result = json_decode($result,true);
        $status = 2;
        if(isset($result['code']) && $result['code'] == 1) {
            //代付状态 1-代付中 2-代付完成 3-代付失败 4-通过审核
            switch ($result['data']['status']) {
                case 2://代付完成
                    $status = 1;
                    break;
                case 3://代付失败
                    $status = 5;
                    break;
            }
        }else if($result['code'] == 0 && $result['msg'] == '数据不存在'){//订单号不存在
            $status = 5;
        }
        return ['status' => $status];  // status  1 成功   5 失败   2 转账中
    }

    public function _curl($url, $para){
        $ch = curl_init();
        $data_string = json_encode($para);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Content-Length: ' . strlen($data_string)]);
        $response = curl_exec($ch);
        $this->addLog('【' . date('Y-m-d H:i:s') . '】 太阳银行卡代付：' . '请求地址：' . $url . ' 请求参数：' . $data_string . ' 结果：' . $response);
        return $response;
    }

    public function callback(){
        exit('SUCCESS');
    }

    public function addLog($str){
        $stream = @fopen('/data/logs/php/taiyang.txt', "aw+");
        $str .= "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

}