<?php

/**
 * 银牛好利宝代付
 */
header("Content-type:text/html;charset=utf-8");
class HLB {
	/**
	 * cid
	 */
	private $cid;
	/**
	 * 密钥key
	 */
	private $apikey;

	/**
	 * 请求地址
	 */
	private $apiUrl;

	/**
	 * 回调地址，可有可无，文档没有说明若有回调地址的情况
	 */
	private $callbackUrl;

	/**
	 * 实例化
	 */
	public function __construct()
	{
		$this->config = cfg::comm('pay');
		$this->cid  = $this->config['HLB']['cid'];
		$this->apikey   = $this->config['HLB']['apikey'];
		$this->apiUrl  = $this->config['HLB']['api_url'];
	}

	/**
	 * 解析第三方参数
	 *
	 * @param array $params 通用参数
	 */
	private function _parseParams($params)
	{
		$exchangeInfos = $params['exchange_infos'];
		$bankInfos     = $params['bank_infos'];
		$data = [
			"inputCharset"  =>'UTF-8',
			"merchantId" 	=> $this->cid, 
			"payAmount" 	=> sprintf("%.2f", $exchangeInfos['amount']),
			"transId" 		=> $params['order_num'],
			"bankCode" 		=> $bankInfos['bank_code'], 
			"cardNumber" 	=> $bankInfos['bank_num'], 
			"cardName" 		=> $bankInfos['user_name'],
			"payTime" 		=> date('Y-m-d H:m:s'),
		];
		$data['sign'] = $this->_sign($data);
		return $data;
	}

	/**
	 * 生成签名
	 */
    private function _sign($data) {
		ksort($data);
        $string = '';
        if(is_array($data)){
        	foreach ($data as $k => $v){
	            if ($v != '' && $v != null && $k != 'sign'){
	                $string = $string . $k . '=' . $v . '&';
	            }
        	}
        }
        $string = substr($string, 0, strlen($string) - 1);
        $string = $string.'&key='.$this->apikey;
		$sign   = MD5($string);
		return $sign;
	}


	/**
	 * 提现操作
	 *
	 * @param array $data 参数
	 *
	 * @return json 
	 */
	public function withdraw($params)
	{	$data=$this->_parseParams($params);
		$post_string = http_build_query($data);

        if($e = oo::withdraw()->error($params,$data)){
            return $e;
        }


		//初始化 curl
		$ch = curl_init();
		$ch = curl_init($this->apiUrl);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		$result = curl_exec($ch);
		curl_close($ch);
		$result = json_decode($result, true);
		$res = [
			'status' 		  => ($result['status'] == 2) ? true : false,
			'withdraw_status' => ($result['retCode'] == 2) ? 1 : 5,
			'out_order_num'   => $result['orderId'] ?? '',
			'msg' 			  => $result['retMsg'] !== null ? $this->_getErrorStr($result['retCode']) : "Success",
		];
		return $res;
	}


	private function _getErrorStr($code)
	{
		$error =  [
			'0001' => '必传参数不能为空',
			'0002' => '非法的商户号',
			'0003' => '商户未启用',
			'0004' => '出款ip未设置',
			'0005' => '非法的出款ip',
			'0006' => '维护中',
			'0007' => '商户未启用此项功能',
			'0008' => '金额格式不正确',
			'0009' => '时间格式不正确',
			'0010' => '不支持此银行',
			'0011' => '此卡号不能下发',
			'0012' => '超过单笔代付上限',
			'0013' => '订单重复提交',
			'0014' => '签名验证失败',
			'0015' => '余额不足',
			'0016' => '字符集编码有误',
			'0017' => '无此订单号对应的订单',
			'9999' => '操作失败，请发起查询',
		];
		return $error[$code];
	}
}