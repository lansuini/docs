<?php

use Utils\Www\Action;

/**
 * 第三方支付回调入口   金额统一为分操作
 */
return new class() extends Action
{
    public function run()
    {
        // 获取第三方回调传入的基本字段参数
        $thirdParam = \Logic\Define\CallBack::get();
        //都为正规的渠道支付
        switch (CALLBACK){//原生支付宝单独处理
            case 'ZFBORIGIN':
                $thirdParam = [
                    "return"=>"success","param"=>"other",
                    "order_number"=>"out_trade_no","mode"=>"current",
                ];break;
            case 'AB'://爱呗支付回调
                $thirdParam = [
                    "return"=>"SUCCESS","param"=>"json",
                    "order_number"=>"cporderid","mode"=>"current",
                ];break;
            case 'WEIXINPAY'://原生微信支付单独处理
                $thirdParam = [
                    "return"=>"<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>","param"=>"xml",
                    "order_number"=>"out_trade_no","mode"=>"current",
                ];break;
            case 'ALITGHB'://某个支付封闭的支付宝红包
                $thirdParam = [
                    "return"=>"allpay_success","param"=>"json",
                    "order_number"=>"order_id","mode"=>"current",
                ];break;
            case 'ALITGHBS'://某个支付封闭的支付宝红包
                $thirdParam = [
                    "return"=>"SUCCESS","param"=>"json",
                    "order_number"=>"out_trade_no","mode"=>"current",
                ];break;
            case 'DINGSHENG'://鼎盛支付宝
                $thirdParam = [
                    "return"=>"success","param"=>"json",
                    "order_number"=>"out_trade_no","mode"=>"current",
                ];break;
        }

        if (strtolower($this->request->getMethod()) == 'post') {
            $log = $str = file_get_contents('php://input');  //不管啥格式统一用二进制流接收
            if(CALLBACK=='HR'){
                $log = $str = str_replace('NoticeParams=','',$log);
            }
            if ($log == null) {
                $str = $this->request->getParams();  //不管啥格式统一用二进制流接收
                $log = json_encode($str);
                if (!$log) {
                    //处理非utf-8编码
                    $log = \Utils\Utils::json_url_encode($str);
                }
                $str = $log;
            }
        } else {
            $str = $this->request->getParams();  //不管啥格式统一用二进制流接收
            $log = json_encode($str);
            if (!$log) {
                //处理非utf-8编码
                $log = \Utils\Utils::json_url_encode($str);
            }
            $str = $log;
        }
//        if(CALLBACK=='DX'){
//            var_dump($log);die;
//        }
        //第三方异步返回数据写入elk日志文件
        \Logic\Recharge\Recharge::addElkLogByTxt(['third' => CALLBACK, 'date' => date('Y-m-d H:i:s'), 'data' => $log, 'desc' => '第三方异步返回数据']);
//        \Logic\Recharge\Recharge::logger($this, ['third' => CALLBACK, 'date' => date('Y-m-d H:i:s'), 'data' => $log], 'log_callback');
        $data = [];
        if($str && $thirdParam){
            switch ($thirdParam['param']) {
                case 'json' :
                    $data = json_decode($str, true);
                    break;
                case 'xml':
                    $data = \Utils\Utils::parseXML($str);
                    break;
                case 'other':
                    $data = \Utils\Utils::parseStr($str);
                    break;
                default:
                    $data = $str;
            }
        }

        if ($data == null) {
            $data = $this->request->getParams();
        }
        if(is_array($data)){
            unset($data['s']);
        }
        if ($thirdParam && $data) {

            //回调参数重新赋值
            if(CALLBACK=='HFY'){
                $data = $data['data'];
            }
            if(CALLBACK=='BLPAY'){
                $ex_data = explode('type=', $data);
                $data = json_decode($ex_data[1],true);
            }
            if (CALLBACK == 'YTBPAY') {
                $data = json_decode($data['return_type'],true);
            }
//            if(CALLBACK=='LCPAY'){
//                $data = json_decode($data['postdata'],true);
//            }
            // // 易收付代付回调
            // if (CALLBACK == 'YSF' && $data['direction'] == 'out') {
            //     $url = $this->ci->get('settings')['hosts']['withdraw_host'] . '/gateway.php?_sid=4100&_env=preproduct&mod=callback&act=yishoufu';
            //     $ch = curl_init();
            //     curl_setopt($ch, CURLOPT_URL, $url);
            //     curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            //     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //     curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:application/json', 'Content-Hmac:' . $_SERVER['HTTP_CONTENT_HMAC']]); 
            //     $result = curl_exec($ch);
            //     // var_dump(curl_error($ch));exit;
            //     print($result);exit;
            // }

            // $order_number = '';
            $desc = '';
            $re = ['flag' => 0, 'order_number' => ''];
            if(!$data) $data = $str;
            if ($data) {
                // var_dump($data);exit;
                $pay = new Logic\Recharge\Recharge($this->ci);

                if (!$pay->existThirdClass(CALLBACK)) {
                    $desc = '未有该第三方:' . CALLBACK . '类，请技术核查';
                } elseif ($thirdParam['mode'] != 'current') {
                    $re = $pay->returnVerify($data);
                } elseif ($pay->verifyCallBack($thirdParam, $data)) {
                    $re = $pay->returnVerify($data);
                } else {
                    $desc = '第三方:' . CALLBACK . '类，callback定义有误，请技术核查';
                }

                if (empty($desc)) {
                    if ($re['flag'] == 0 && isset($re['msg'])) {
                        $desc = $re['msg'];
                    }
                }
            }

            if ($desc) {//有错误写入elk日志
                \Logic\Recharge\Recharge::addElkLogByTxt(['third' => CALLBACK, 'date' => date('Y-m-d H:i:s'), 'data' => $log, 'desc' => $desc]);
            }
            //写入回调日志表
            $logs = [
                'order_number' => $re['order_number'] ?? $data[$thirdParam['order_number']] ?? '',
                'desc' => $desc,
                'callurl' => $this->request->getUri()->getPath() . DIRECTORY_SEPARATOR . strtolower($this->request->getMethod()),
                'content' => $log,
            ];
            // var_dump($flag);exit;
            \Logic\Recharge\Recharge::addLogBySql($logs, 'log_callback');
            //进入队列失败   说明代码或配置有误 定时器定时跑
            if ($re['flag'] == 0) {
                $url = $this->request->getUri()->getScheme() . '://' . $this->request->getUri()->getHost() . $this->request->getUri()->getPath();
                $repeat = [
                    'url' => $url,
                    'method' => $this->request->getMethod(),
                    'content' => $log
                ];
                \Logic\Recharge\Recharge::addLogBySql($repeat, 'log_callback_failed');
            }
        }
        if ($thirdParam) {
            //如果此次回调返回订单号才视为成功，否则都是无效请求，不该返回给第三方成功
            if (isset($re['order_number'])) {
                $tmp = \Logic\Define\CallBack::getChannelByOrderNumber($re['order_number']);
                if ($tmp) {
                    //共用的支付，但第三方需要的返回值确有差异,以订单对应的渠道配置为准
                    $thirdParam = $tmp;
                }

                // // 给某些标识做特殊处理
                // $thirdParam['return'] = $thirdParam['return'] == "ysf_success" ? json_encode(['success' => true]) : $thirdParam['return'];
                // //支付回调需要特殊标识
                if ($thirdParam['return'] == 'response_json'){
                    $thirdParam['return'] = json_encode(['responseCode'=>'0000']);
                }
                if ($thirdParam['return'] == 'resultCode_json'){
                    $thirdParam['return'] = json_encode(['resultCode'=>'0','resultMsg'=>'接收成功']);
                }
                if ($thirdParam['return'] == 'status_json'){
                    $thirdParam['return'] = json_encode(['status'=>1,'error_msg'=>'']);
                }
                echo htmlspecialchars_decode(trim($thirdParam['return']));
            } else {
                echo 'fail: 缺失参数';
            }
            die();
        } else {
            return false;
        }
    }
};