<?php
use Utils\Www\Action;
return new class extends Action{
    public function run($order_number = '196853245769995542', $money = 2000,$pay_id = 2)
    {
        exit('test aaaaa4');
    }
};