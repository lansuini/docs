<?php
use Utils\Www\Action;

/**
 * 棋牌超管支付配置数据同步数据到厅主
 */
return new class extends Action {

    const TITLE       = '第三方支付列表接口';
    const DESCRIPTION = '获取第三方支付列表';
    const TYPE        = 'text/json';

    public function run(){
        $data = $this->request->getParams();
        $route = $data['route'];
        $s_logic = new \Logic\Recharge\PlatSync($this->ci);
        if(!empty($route) && method_exists($s_logic, $route)){
            $return = $s_logic->$route($data);
            if(empty($return)){
                exit('fail');
            }
            exit($return);
        }
        exit('fail');
    }

};