<?php
use Utils\Www\Action;

/**
 * 棋牌超管支付配置数据同步数据到厅主
 */
return new class extends Action {

    const TITLE       = '第三方支付列表接口';
    const DESCRIPTION = '获取第三方支付列表';
    const TYPE        = 'text/json';

    public function run(){
        $data = $this->request->getParams();
        $s_logic = new \Logic\Recharge\PlatSync($this->ci);
        $return = $s_logic->plat_notify($data);
        exit(json_encode($return));
    }

};