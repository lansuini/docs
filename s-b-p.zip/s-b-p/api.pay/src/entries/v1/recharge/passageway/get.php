<?php
use Utils\Www\Action;
return new class extends Action {
    const TITLE = '平台请求支付通道';
    const QUERY = [
        'type' => 'string(optional) #类型',
    ];
    const TYPE = 'text/json';
    const PARAMs = [];
    const SCHEMAs = [
        200 => [
            'scene' =>'string #通道标识',
            'min_money' => 'int #通道最小金额',
            'max_money' => 'int #通道最大金额',
            'pay_id' => 'int #渠道名',
        ],
    ];
    public function run() {
        $type = $this->request->getParam('type');
        $level = (int)$this->request->getParam('level');
        $channelId = (int)$this->request->getParam('channelId');
        $money = (int)$this->request->getParam('money');
        $uid = (int)$this->request->getParam('uid');
        // 如果存在渠道id则获取渠道中的支付通道
        // $passageway = [];
        $passagewayIds = [];
        if ($channelId || $channelId == 0) {
            $passageway = \DB::connection('jlmj_config')->table('channel_packages')->where('channel_id', $channelId)->first();
            $passagewayIds = $passageway ? explode(',', $passageway->passageway) : [];
        }

        $user_different=1;//默认游客账号
        $userBoolean=\DB::connection('accounts_jlmj')->table('account')->select(['phone_num','account_type'])->where('uid',$uid)->first();

        //绑定了手机号
        if($userBoolean->phone_num !=''){
            $user_different=2;
        }


        $query = \DB::table('passageway AS w')->leftJoin('pay_config AS c','w.pay_config_id','=','c.id')
            ->leftJoin('pay_channel AS p','c.channel_id','=','p.id')
            ->where('w.customer_id',CUSTOMERID)
            ->where('w.status','=','enabled');
        $type && $query->where('w.scene','=',$type);

        // 通过渠道筛选支付通道
        $passagewayIds && $query->whereIn('w.id', $passagewayIds);

        $query->whereRaw("FIND_IN_SET('{$level}',w.level)",'');//添加层级筛选
        $query->whereRaw("FIND_IN_SET('{$user_different}',w.user_different)",'');//添加用户区分筛选

        $passageway = $query->orderBy('w.sort')->get([
            'w.id','w.alias_name','w.show_type','w.scene','w.level','w.user_different','w.min_money',
            'w.max_money','w.sort','w.money_used','w.money_day_used','w.money_day_stop','w.money_stop',
            'p.id as pay_id','p.code','p.name as pay_name','p.rule as pay_rule','p.moneys as pay_moneys']);

        if(!$passageway) return '';
        $data = $passageway->toArray();
        //金额单位分
        if($money) {
            $res = [];
            foreach ($data as $val) {
                $val = (array)$val;
                if ($money < $val['min_money']) continue;
                if ($val['max_money'] != 0 && $money > $val['max_money']) continue;
                $tmp = 0;
                //'0：不限，1：整数，2：小数，3:固定金额,4:整百'
                switch ($val['pay_rule']) {
                    case 1:
                        if ($money % 100 != 0)//不能整除100分(1元)的不是整数
                            $tmp = 1;
                        break;
                    case 2:
                        if ($money % 100 == 0)//能整除100分的不是小数
                            $tmp = 1;
                        break;
                    case 3:
                        $ms = explode(',', $val['pay_moneys']);
                        if (!in_array($money, $ms)) $tmp = 1;
                        break;
                    case 4:
                        if ($money % 10000 != 0)//整百必须能整除10000分
                            $tmp = 1;
                        break;
                }

                if ($tmp) continue;
                $res[] = $val;
            }
        }else{
            $res = $data;
        }

        //直接最原始方式输出给客户端。因为使用框架返回会出现非毕现json格式异常问题
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($res,JSON_UNESCAPED_SLASHES);
        die();
//        if($passageway)
//            return $passageway->toArray();
//        return '';
    }
};