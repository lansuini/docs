<?php
use Utils\Www\Action;
return new class extends Action {
    const TITLE = '平台请求支付页签 ssss';
    const TYPE = 'text/json';
    public function run() {
        $uid = $this->request->getQueryParam('uid');
        $level = $this->request->getQueryParam('level');
        $channelId = (int)$this->request->getParam('channelId');

        // 如果存在渠道id则获取渠道中的支付页签
        $pageSignIds = [];
        if ($channelId || $channelId == 0) {
            $pageSign = \DB::connection('jlmj_config')->table('channel_packages')->where('channel_id', $channelId)->first();
            $pageSignIds = $pageSign ? explode(',', $pageSign->page_sign) : [];
        }

        $user_different=1;//默认游客账号
        $userBoolean=\DB::connection('accounts_jlmj')->table('account')->select(['phone_num','account_type'])->where('uid',$uid)->first();

        //绑定了手机号
        if($userBoolean->phone_num !=''){
            $user_different=2;
        }
        $page_signSql = \DB::table('page_sign')
            ->whereRaw("FIND_IN_SET('{$user_different}',user_different)",'');

        $pageSignIds && $page_signSql->whereIn('id',$pageSignIds);

        $page_sign = $page_signSql->orderBy('sort')
            ->get(['id','desc','sort','status','games_status','proportion', 'level','user_different']);

        if($page_sign) {
            $data = $page_sign->toArray();
            $temp = [];
            foreach ($data as $k => $v) {
                $v = (array) $v;
                $levels = explode(',', $v['level']);
                if (in_array($level, $levels)) {
                    unset($v['level']);
                    $temp[] = $v;
                }

            }
            return $temp;

        }
        return '';
    }
};