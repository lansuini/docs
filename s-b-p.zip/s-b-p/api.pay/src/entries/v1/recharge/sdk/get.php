<?php
use Utils\Www\Action;
use Logic\Recharge\Sdk\Factory;
return new class extends Action {
    const TITLE = '原生支付请求';
    const QUERY = [
        'order_number' => 'string(optional) #订单ID',
        'money' => 'int(optional) #金额：分f',
        'origin_id' => 'int(optional) #通道ID',
        'platform' => 'string(optional) #平台标识 1 ios 0 android',
        'channel_id' => 'int(optional) #渠道ID',
        'client_ip' => 'string(optional) #客户IP地址',
        'uid' => 'string(optional) #uid',
    ];
    const TYPE = 'text/json';
    const PARAMs = [];
    const SCHEMAs = [
        200 => [

        ],
    ];
    public function run() {
        $params = $this->request->getParams();
        return (new Factory($this->ci))->runRequest($params);
    }
};