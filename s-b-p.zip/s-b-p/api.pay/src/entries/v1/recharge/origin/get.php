<?php
use Utils\Www\Action;
return new class extends Action {
    const TITLE = '平台请求原生支付宝页签';
    const TYPE = 'text/json';
    public function run() {
        $level = $this->request->getParam('level');
        $channel = $this->request->getParam('channel');

        $r_status = $this->request->getParam('r_status',8);

        $pay_type = $this->request->getParam('pay_type');

        $channel_where = ' 1 ';
        // if( !empty($channel) ){
        //     $channel_where = "FIND_IN_SET('{$channel}',channel)";
        // }

        if($pay_type!=''){
            $type='';
            switch ($pay_type){
                case 'origin':$type = 1;break;
                case 'weixinpay':$type = 2;break;
                case 'aliredbag':$type = 3;break;
                case 'hbzfb':$type = 4;break;
            }
            if($type){
                $channel_where.=" and type={$type}";
            }
        }

        $query = \DB::table('zfb_config')
            ->where('status',1);

        if($r_status != 8){
            $r_status = $r_status == 1 ? 0 : 1;
            $query->where('control_user_status',$r_status);
        }
        $originInfo = $query->where("customer_id", CUSTOMERID)
            // ->whereRaw("FIND_IN_SET('{$level}',level)")
            ->whereRaw($channel_where)
            ->orderBy("last_recharge_time")
            ->get(["id","alias_name", 'channel',"min_money","max_money","last_recharge_time","level","money_day_used","money_day_stop","interval","zfb_acount as appid"]);
        if ($originInfo) {
            $originInfo = $originInfo->toArray();
            $originInfo = json_encode($originInfo,JSON_UNESCAPED_UNICODE);
            $originInfo = json_decode($originInfo,true);
            $result = [];
            foreach ($originInfo as $k => $v) {
                $channels = explode(',', $v['channel']);

                if (!in_array($channel, $channels)) {
                    continue;
                }

                $levels = explode(',', $v['level']);

                if (!in_array($level, $levels)) {
                    continue;
                }

                // if ((time()-$v['last_recharge_time'] < $v['interval'])) {
                //     continue;
                // }
                if ($originInfo[$k]['money_day_stop'] > 0 && $originInfo[$k]['money_day_stop'] <= $originInfo[$k]['money_day_used']) {
                    continue;
                }
                $v['pay_rule'] = "1";
                if ($v['min_money'] || $v['max_money']) {
                    $v['pay_rule'] = 1;
                }
                $result[] = $v;
            }
        }
        if ($result) {
            return $result;
        }
        return [];
    }
};
