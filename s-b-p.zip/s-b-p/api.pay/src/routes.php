<?php

use Slim\Http\Request;
use Slim\Http\Response;
use Respect\Validation\Validator as V;

// 获取二维码地址
$app->get('/qrcoder', function (Request $request, Response $response, array $args) {
    $templateVariables = [
        'code' => $request->getParam('code'),
        'amount' => $request->getParam('amount'),
        'pay_type' => $request->getParam('pay_type'),
        'host' => $this->ci->settings['oss']['OSS_CDN_DOMAIN'],
    ];
    return $this->renderer->render($response, 'qrcode.html', $templateVariables);
});
