<?php
/**
 * Created by Hans.
 * Date: 2019/6/7
 */

namespace Tests\Functional;

use Logic\Recharge\Pay\LONGXZF;
use Logic\Recharge\Pay\TYZF;
use  Logic\Recharge\Pay\YFPAY;
use Utils\Utils;

class LONGXZFTest extends \PHPUnit_Framework_TestCase
{

    public function testReturnVerify()
    {
        $pay = new YFPAY();
        $test1 = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><xml><version>2.0</version><charset>UTF-8</charset><signType>MD5</signType><retcode>0</retcode><retmsg>操作成功</retmsg><spid>C1557381524780</spid><spbillno>155999016592955</spbillno><transactionId>289466232711675904</transactionId><outTransactionId>1906080000000158743183606703</outTransactionId><tranAmt>30000</tranAmt><payAmt>30000</payAmt><result>pay_success</result><sign>E908BED53C9A07C7D6A86B692ADF26E9</sign></xml>	";
        $test2 = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><xml><version>2.0</version><charset>UTF-8</charset><signType>MD5</signType><retcode>0</retcode><retmsg>操作成功</retmsg><spid>C1557381524780</spid><spbillno>155991036599223</spbillno><transactionId>289131556168007680</transactionId><outTransactionId>1906070000000141269202611748</outTransactionId><tranAmt>20000</tranAmt><payAmt>20000</payAmt><result>pay_success</result><sign>12AB593E3C8EDDFD7D60083143EFFB0C</sign></xml>";
        $data = Utils::parseXML($test1);
        $result = $pay->returnVerify($data);
        var_dump($result);
    }

    public function testTYZF(){
        $pay = new TYZF();
        $test1 = 'memberid=10040&orderid=156048516770154&transaction_id=20190614120617575210&amount=50.0000&datetime=20190614120929&returncode=00&sign=A5C39023654ADC78E6BBA9F19939ACAE&attach=';
        $data = Utils::parseStr($test1);
        $result = $pay->returnVerify($data);
        var_dump($result);

    }

    public function testEncrypt()
    {
        $str = 'tHthdXb+/O4ps1FVHtYugVvogdtWnMP07ujVK8j6eP2oGuEV71umAzj3v8JzRHRX';
        $ret = Utils::XmcryptString($str, false);
        var_dump($ret);
    }

}
