<?php
    //  外部中间跳转文件
    $METHODS = array(
        'POST' => 'form',//表单提交
        'GET' => 'gos',  //直接跳转
        'GET_FORM' => 'form',  //表单提交
        'HTML' => 'html',  //表单提交
        'IMG' => 'img', // 显示图片
    );

    $GATEWAY = $_REQUEST['url'] ?? '';
    $METHOD = isset($_REQUEST['method2']) ? $_REQUEST['method2'] : $_REQUEST['method'];
    $DATA = array();
    unset($_REQUEST['url']);
    if(isset($_REQUEST['method2']))
        unset($_REQUEST['method2']);
    else
        unset($_REQUEST['method']);
    $DATA = $_REQUEST;
    if(isset($METHODS[$METHOD])&&function_exists($METHODS[$METHOD])) {
        $html = $METHODS[$METHOD]($DATA, $GATEWAY);
        echo $html;
        die();
    }else{
        if (isset($METHOD)) {
            addLog($DATA, $GATEWAY);
        }
        echo '参数出错';die();
    }
    function html($data) {
        $htmlEncodeStr = str_replace(" ","+",$data['html']);
        $html = base64_decode($htmlEncodeStr);
        return $html;
    }
    function img($data) {
        return "<body style='width: 100vw;height: 100vh;display: flex;align-items: center;justify-content: center;'><img style='width: 60%;' src='{$data['img']}' /></body>";
    }
    function form($data,$GATEWAY){
        GLOBAL $METHOD;
        $temp = explode('_',$METHOD);
        $m = $temp[0] ?? 'POST';
        $html = "<form method='$m' name='PAY_FORM' action='$GATEWAY'>";
        foreach ($data as $key => $val) {
            $html .= "<input type='hidden' name='$key' value='$val' />";
        }
        $html .= "</form>";
        return $html.'<script> document.PAY_FORM.submit();</script>';
    }
    function gos($data,$GATEWAY){
        $str = urlstring($data);
        if(strpos($GATEWAY,'?' === FALSE))
            return $GATEWAY.'?'.$str;
        else
            return $GATEWAY.'&'.$str;
    }

    function urlstring($parameter){
        ksort($parameter);
        $signStr = '';
        foreach ($parameter as $k=>$v) {
            $signStr .= "$k=$v&";
        }
        $signStr = trim($signStr,'&');
        return $signStr;
    }

    function addLog($data, $GATEWAY){
        $file = "/data/logs/elk/illegal_go.log";
        $stream = @fopen($file, "aw+");

        $json = array(
            "url" => $GATEWAY,
            "params" => http_build_query($data),
            "uri" => $_SERVER['REQUEST_URI'],
            "ip" => getIp(),
            "time" => date('Y-m-d H:i:s')
        );
        $str = json_encode($json, JSON_UNESCAPED_UNICODE) . "\r\n";
        @fwrite($stream, $str);
        @fclose($stream);
    }

    function getIp(){
        if (isset($_SERVER['HTTP_X_REAL_IP']) && $_SERVER['HTTP_X_REAL_IP']) {
            $ip = $_SERVER['HTTP_X_REAL_IP'];
        } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        } else if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } else if (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        if (empty($ip)) {
            return '0.0.0.0';
        } else {
            return (explode(',', $ip))[0];
        }
    }