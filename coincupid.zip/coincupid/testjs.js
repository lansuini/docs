var CryptoJS = require('crypto-js')

const gameResult = (seed, salt) => {
    const nBits = 52; // 要使用的最高有效位数
 
    // 1. HMAC_SHA256(message=seed, key=salt) 
    const hmac = CryptoJS.HmacSHA256(CryptoJS.enc.Hex.parse(seed), salt);
    c = hmac.toString(CryptoJS.enc.Hex);
    console.log("aaaacccc", c) 
    // 2. r = 52 个最高有效位
    c = c.slice(0, nBits / 4);
    const r = parseInt(c, 16);
    
    console.log("cccccccccccc", c)
    console.log("rrrrrrrrrrrr", r)
    // 3. X = r / 2^52
    let X = r / Math.pow(2, nBits); // 均匀分布在 [0; 1)
    X = parseFloat(X.toPrecision(9));
    console.log("X", X);
 
    // 4. X = 99 / (1-X)
    X = 99 / (1 - X);
 
    // 5. return max(trunc(X), 100)
    const result = Math.floor(X);
    return Math.max(1, result / 100);
  };

var hash = "cff2b3808f6b7dc12c353cdea97e83afdbd35e32df13fe8b000c2bec2424f011"
var salt = "000000000000000000030587dd9ded1fcc5d603652da58deb670319bd2e09445"
var a = gameResult(
  hash, 
  salt)


console.log("gameResult:", a)
