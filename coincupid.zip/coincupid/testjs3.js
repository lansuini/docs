var server_seed = "f039c143ffe965ff5d9ecc88ed5437dd3922bc4a51dd4103d4cb2dbba43559ed" 
var public_seed = "8770813203"
var game_no = "#1392081"

var CryptoJS = require('crypto-js')
var sha256 = require('crypto-js/sha256')
var Base64 = require('crypto-js/enc-base64')
var hash = sha256(server_seed + public_seed + game_no)
// console.log("sha256:", sha256(server_seed + public_seed + game_no))

// console.log("sha256 Base64:", Base64.stringity(sha256(server_seed + public_seed + game_no)))


console.log("hash1", hash.toString(CryptoJS.enc.Hex))
var hash2 = CryptoJS.HmacSHA256(server_seed + public_seed + game_no, "000000000000000000030587dd9ded1fcc5d603652da58deb670319bd2e09445")
console.log("hash2", hash2.toString(CryptoJS.enc.Hex))

var hash3 = CryptoJS.HmacSHA256(server_seed + public_seed + game_no, server_seed + public_seed + game_no)
console.log("hash3", hash3.toString(CryptoJS.enc.Hex))


var sha256 = CryptoJS.algo.SHA256.create();
sha256.update(server_seed);
sha256.update(public_seed);
sha256.update(game_no);
var hash4 = sha256.finalize();
console.log("hash4", hash4.toString(CryptoJS.enc.Hex))