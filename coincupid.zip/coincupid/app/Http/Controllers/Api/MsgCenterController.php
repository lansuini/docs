<?php
namespace App\Http\Controllers\Api;
class MsgCenterController extends ApiController
{
    public function getIMList()
    {

    }

    public function getFriendList()
    {

    }

    
}