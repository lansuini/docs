<?php

namespace App\Models\Manager\Analysis;

use App\Models\Manager\LoginLog as Model;

class OccupationCate extends Model
{
    protected $table = 'occupation_cate';

    protected $connection = 'Master';
}
