<?php
/**
 * 下拉选择.
 */

return [
    'accountType' => '账号类型',
    'Normal' => '正常',
    'Guest' => 'Guest',
    'Robot' => '机器人',
    'riskUserType' => '风控类型',
    'Control' => '锁定',
];