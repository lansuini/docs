<?php
/**
 * Created by PhpStorm.
 */

return [
    'PlayerName'=>'游戏名称',
    'Nickname'=>'昵称',
    'AccountType'=>'账号类型',
    'Client'=>'所属客户',
    'BannedTime'=>'禁用时间',
    'BannedType'=>'禁用类型',
    'LastLogonTime'=>'最后登录时间',
    'isRiskUser'=>'是否风控',
    'Created'=>'创建时间',
    'Action'=>'操作',
];