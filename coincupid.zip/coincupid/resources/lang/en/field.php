<?php
/**
 * Created by PhpStorm.
 */

return [
    'PlayerName'=>'PlayerName',
    'Nickname'=>'Nickname',
    'AccountType'=>'AccountType',
    'Client'=>'Client',
    'BannedTime'=>'BannedTime',
    'BannedType'=>'BannedType',
    'LastLogonTime'=>'LastLogonTime',
    'isRiskUser'=>'isRiskUser',
    'Created'=>'Created',
    'Action'=>'Action',
];