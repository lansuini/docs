<?php
/**
 * 下拉选择.
 */

return [
    'accountType' => 'accountType',
    'Normal' => 'Normal',
    'Guest' => 'Guest',
    'Robot' => 'Robot',
    'riskUserType' => 'riskUserType',
    'Control' => 'Control',
];