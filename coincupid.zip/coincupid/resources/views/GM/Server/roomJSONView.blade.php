<?php foreach ($forms as $k => $v) {?>
    <div class="form-group">
        <?=$v?>
    </div>
<?php } ?>

<div class="form-group">
    <input type="hidden" data-field="actionButton" name="actionButton" value="">
    <input type="hidden" data-field="actionField" name="actionField" value="">
</div>