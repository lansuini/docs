<?php

require '../repo/vendor/autoload.php';

use Workerman\Worker;
use Workerman\Lib\Timer;
use GuzzleHttp\Client;

$worker = new Worker();

$worker->count = 10;

$worker->onWorkerStart = function ($worker) {
    Timer::add(1, function () {
        $log = __DIR__ . '/request.log';

        $client = new Client();
        $res = $client->request('GET', 'https://www-api2.hwl8.com/v2/user/wallet/recharge/onlines', [
            'headers' => [
                'Authorization' => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiIsImp0aSI6InRva2VuIn0.eyJpc3MiOiJ0YzNnYS5jb20iLCJhdWQiOiJ0YzNnYS5jb20iLCJqdGkiOiJ0b2tlbiIsImlhdCI6MTU0MDIyMDY3NSwibmJmIjoxNTQwMjIwNzM1LCJleHAiOjE1NDI4MTI2NzUsInVpZCI6NTMsImxvZ2luSWQiOiI1YmNkZTcwMzYxOTdhIiwicGxHaWQiOjEsInRpbWUiOjE1NDAyMjA2NzUsInRyaWFsX3N0YXR1cyI6IiJ9.fb-fCcYRGh6yWDH4kJbOo4v6xcU1ylIm44ku3eNklMU',
            ],
        ]);

        file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . $res->getStatusCode() . "\n" . $res->getBody() . "\n\n", FILE_APPEND);
    });
};

Worker::runAll();