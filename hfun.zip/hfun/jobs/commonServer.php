<?php
require __DIR__ . '/../repo/vendor/autoload.php';

$settings = require __DIR__ . '/../config/settings.php';

$app = new \Slim\App($settings);

// Set up dependencies
require __DIR__ . '/src/dependencies.php';

// Register middleware
require __DIR__ . '/src/middleware.php';

$app->run();

$app->getContainer()->db->getConnection('default');

$alias = $app->getContainer()
             ->get('settings')['website']['alias'];

$alias = strtoupper($alias) . 'Server';

if (empty($alias)) {
    echo 'please input website alias';
    exit;
}

$logger = $app->getContainer()->logger;

\Workerman\Worker::$logFile = '/data/logs/php/commonServer.log';

$worker = new \Workerman\Worker();
$worker->count = 3;
$worker->name = $alias;

// 防多开配置
// if ($app->getContainer()->redis->get(\Logic\Define\CacheKey::$perfix['prizeServer'])) {
//     echo 'prizeServer服务已启动，如果已关闭, 请等待5秒再启动', PHP_EOL;
//     exit;
// }

$worker->onWorkerStart = function ($worker) {
    global $app, $logger;

    $proccId = 0;
    if ($worker->id === $proccId) {
        $interval = 10;
        \Workerman\Lib\Timer::add($interval, function () {

            Logic\Crontab\User::updateUserVip();
        });

    }

    //广告记录
    $proccId++;
    if ($worker->id === $proccId) {

        $exchange = 'ad_click';
        $queue = $exchange.'_1';

        $callback = function ($msg) use ($exchange, $queue, $logger) {
            try {
                $logger->info("【 $exchange, $queue 】".$msg->body);
                $params = json_decode($msg->body, true);
                print_r($params);
                DB::table('user_advert')->insert($params);

                $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
            }catch (\Exception $e){
//                print_r($params);
                $logger->error($msg->body);
            }

        };
        \Utils\MQServer::startServer($exchange, $queue, $callback);
    }


    //活跃统计
    $proccId++;
    if ($worker->id === $proccId) {

        $exchange = 'sum_active';
        $queue = $exchange;

        $callback = function ($msg) use ($app,$exchange, $queue, $logger) {
            try {
                $logger->info("【 $exchange, $queue 】".$msg->body);

                $params = json_decode($msg->body, true);
                $userLogic = new \Logic\Crontab\User($app->getContainer());
                $userLogic->updateUserActive($params);

                $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
            }catch (\Exception $e){
//                throw $e;
                $logger->error($msg->body);
            }

        };
        \Utils\MQServer::startServer($exchange, $queue, $callback);
    }
//    $proccId++;
//    if ($worker->id === $proccId) {
//        $interval = 8;
//        \Workerman\Lib\Timer::add($interval, function () {
//            \Logic\Movie\Upload::checkUploadMovies();
//        });
//
//    }
//    $proccId++;
//    // 消息发送
//    if ($worker->id === $proccId) {
//        $exchange = 'user_message';
//        $queue = $exchange . '_1';
//
//        $callback = function ($msg) use ($exchange, $queue, $logger) {
//            try {
//                $logger->info("【 $exchange, $queue 】" . $msg->body);
//                $params = json_decode($msg->body, true);
//                DB::table('user')
//                  ->selectRaw('id')
//                  ->whereIN($params['filed'], $params['inArray'])
//                  ->orderByDesc('id')
//                  ->chunk(2000, function ($users) use ($params) {
//                      $insertArr = [];
//                      foreach ($users as $user) {
//                          $message = [
//                              'uid'     => $user->id,
//                              'type'    => $params['type'],
//                              'm_id'    => $params['m_id'],
//                              'created' => time(),
//                              'updated' => time(),
//                          ];
//                          array_push($insertArr, $message);
//                      }
//                      DB::table('message_pub')
//                        ->insert($insertArr);
//                  });
//                $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
//            } catch (\Exception $e) {
//                $logger->error($msg->body);
//            }
//        };
//        \Utils\MQServer::startServer($exchange, $queue, $callback);
//    }




};
\Workerman\Worker::runAll();