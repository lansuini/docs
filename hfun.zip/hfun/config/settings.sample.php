<?php
!defined('RUNMODE') && define('RUNMODE', 'dev');  // dev、test、prod

return [
    'settings' => [
        'displayErrorDetails' => RUNMODE == 'prod' ? true : false, // set to false in production
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header

        // Renderer settings
        // 'renderer' => [
        //     'template_path' => __DIR__ . '/../templates/',
        // ],

        // Monolog settings
        'logger' => [
            'name' => 'tc-app',
            'path' => isset($_ENV['docker']) ? 'php://stdout' : __DIR__ . '/../logs/app.log',
            'level' => RUNMODE == 'prod' ?  \Monolog\Logger::ERROR : \Monolog\Logger::DEBUG,
            'type' => RUNMODE == 'dev' ? 'file' : 'mongodb', 
        ],

        // db
        'db' => [

            'default' => [
                'driver' => 'mysql',
                'host' => '10.200.124.16',
                'database' => 'core',
                'username' => 'root',
                'password' => 'tun6oc0j',
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ],

            'common' => [
                'driver' => 'mysql',
                'host' => '10.200.124.16',
                'database' => 'common',
                'username' => 'root',
                'password' => 'tun6oc0j',
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ],

            'data' => [
                'driver' => 'mysql',
                'host' => '10.200.124.16',
                'database' => 'data',
                'username' => 'root',
                'password' => 'tun6oc0j',
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ],
            'mart' => [
                'driver' => 'mysql',
                'host' => '10.200.124.16',
                'database' => 'mart',
                'username' => 'root',
                'password' => 'tun6oc0j',
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => ''
            ]
        ],

        // 平台mongodb
        'mongodb' => [
            'host' => '10.200.124.16',
            'port' => '27017',
            'user' => null,
            'password' => null,
        ],

        // rabbitmq
        'rabbitmq' => [
            'host' => '10.200.124.16',
            'port' => '5672',
            'user' => 'lottery',
            'password' => '85489e25c11dd98b7bbc74e8d63fccb9',
            'vhost' => '/',
        ],

        // redis
        'cache' => [
            'schema' => 'tcp',
            'host' => '10.200.124.16',
            'port' => 6379,
            'database' => 2,
            'password' => ''
        ],

        // 平台通用cache
        'cacheCommon' => [
            'schema' => 'tcp',
            'host' => '10.200.124.16',
            'port' => 6379,
            'database' => 1,
            'password' => ''
        ],

        // pusherio
        'pusherio' => [
            'app_id' => '657cbdb',
            'app_secret' => '7029df1c07a0c375657cbdb79923424c',
            'auth_url' => '/pusher/io/auth',
            'server_url' => ['http://pusherio.9001.ftdev.com', 'http://pusherio.9002.ftdev.com'], // 客户端负载分发
            'channel_prefix' => 'private-io-',
            'history_limit' => 10,
            'history_expire' => 86400,
        ],

        // app
        'app' => [
            'tid' => 1, // 平台分配厅主的id
            'app_secret' => 'cf28e0cede966e73ebd68a55acec1213ttlctest', // 不可逆，用以校验签名，app_secret 平台、厅主各存一份
            'tz_secret' => 'xahfggertdfgttlctest', // 不可逆，用以校验厅主本身的数据，长度20字节，签名后的数据写入数据库。一旦写入最好不要修改
            'app_key' => '231119adttlctest', // 双向加密密钥，长度16字节(字符可以是多字节)。一旦写入不可更改
            'mpi' => 'http://www.sayahao.com',
        ],

        // 微信凭证
        'weixinCredentials' =>  [
            [
                'type' => 1,
                'share_domain' => 'https://m.ddyifan.com',
                'share_url' => 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf39748e138764f57&redirect_uri={redirect_url}&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect',
                'app_id' => 'wxf39748e138764f57',
                'secret' => 'b6eebe1c3d576afd4f76afaa74041e00',
                'access_token_url' => 'https://api.weixin.qq.com/sns/oauth2/access_token?',
                'user_info_url' => 'https://api.weixin.qq.com/sns/userinfo?',
            ]
        ],

        // 开放平台微信凭证
        'weixinCredentialOpenplatform' => [
            'android' => [
                'app_id' => 'wx9cbde0d9885d6eef',
                'secret' => '8f2e52e4823e54d539e97ef3a41a1eec',
                'access_token_url' => 'https://api.weixin.qq.com/sns/oauth2/access_token?',
                'user_info_url' => 'https://api.weixin.qq.com/sns/userinfo?',
            ],

            'ios' => [
                'app_id' => 'wx9cbde0d9885d6eef',
                'secret' => '8f2e52e4823e54d539e97ef3a41a1eec',
                'access_token_url' => 'https://api.weixin.qq.com/sns/oauth2/access_token?',
                'user_info_url' => 'https://api.weixin.qq.com/sns/userinfo?',
            ]
        ],

        // 开彩网配置
        'apiplus' => ['url' => 'http://d.apiplus.net', 'token' => 'ta0d1c92300d2805ak'],

        // 彩票按配置
        'caipaokong' => ['url' => 'http://api.kaijiangtong.com/lottery/', 'uid' => '813226', 'token' => '05f5e3579fd8a1abc2f3a9b08ee04ad5a8eebff9'],
        
        // 上传配置
        'upload' => [
            'useDsn' => 'oss',

            'dsn' => [
                // 阿里云oss
                'oss' => [
                    'accessKeyId' => 'LTAIVTMYxSvcdPwB',
                    'accessKeySecret' => 'iQqA9kS7BXBcGVJMzseIdXakpmW5II',
                    'endpoint' => 'https://oss-cn-shenzhen.aliyuncs.com/',
                    'domain' => 'https://szfungame.oss-cn-shenzhen.aliyuncs.com', // 访问域名
                    'bucket' => 'szfungame', 
                    'dir' => 'upload',
                ],

                // 七牛上传
                'qiniu' => [
                    'accessKey' => "5mc4XjVjo8cS_aJsejpdODQhmDZbE9DFXPszaUCz",
                    'secretKey' => 'ua9wg-iS591CtCTOLwQgxd1_z1OOPDkOFYX4j-em',
                    'bucket' => 'tc-test', 
                    'domain' => 'https://res1.duoleke.net', // 访问域名
                    'dir' => 'upload',
                ],
            ]
        ],

        'jsonwebtoken' => [
            'public_key' => 'B6c5c11fe441acf6F71cab9c5debb6ee-=tctest',
            'uid_digital' => 116624, // 简单的伪装码key
            'expire' => 36000, //单位：秒
        ],

        // 网站配置
        'website' => [
            'name' => '唐朝游戏',  // 短信名称
            'registerTags' => 0,  // 注册用户默认tags
            'notInTags' => [4, 7], // 查询排除ID(试玩和测试)
            'payrequest' => 'https', // 支付回调协议头a
            'ipProtect' => true, // ip请求保护
            'ALog' => true, // 访问日志 
            'DBLog' => RUNMODE == 'prod' ? false : true, // 数据查询日志
            'alias' => 'tc', // 别名（saba使用）
            'thirdTranser' => ['open' => true, 'host' => 'http://127.0.0.1:9999'], // 第三方查询钱包转发查询
            'rakeBack' => true, // 返佣开关
            'agLogDir' => '/data/logs/3th/sayahao',
            // 短信配置
            'captcha' => [
                'loopTime' => 60,
                'useDsn' => 'ShouYi',
                'cacheTime' => 300, // 短信验证码缓存时间
                'reSendTime' => 60, // 重发时间
                'length' => 6, // 短信长度
                'range' => [1, 2, 3, 4, 5, 6, 7, 8, 9], // 验证码取值范围
                'templates' => [
                    0 =>  "【%s】你的验证码为：%s，请在5分钟内使用！",
                ],
                'dsn' => [
                    // 叮咚云
                    'DingDong' => [
                        'apikey' => 'fd918be74fa61ccd072272e64081656c',
                    ],
                    
                    // AWS
                    'AWS' => [
                        'credentials' => [
                            'key' => 'AKIAJ7TYHMXW3ZGQOIFA',
                            'secret' => 'qqOJxlzyorEE508AK7bv+zftWQBe2SLXdsZU+r5z',
                        ],
                        'region' => 'ap-southeast-1',//'us-east-1', // < your aws from SNS Topic region
                        'version' => 'latest'
                    ],

                    //广州首易
                    'ShouYi'=>[
                        'CorpID'=> '101392',
                        'LoginName'=>'zc',
                        'pwd'=>'Tf169852',
                        'wsdl'=>'http://sms.mobset.com/SDK2/Sms_Send.asp'
                    ],
                ],
            ],
        ],
    ],
];
