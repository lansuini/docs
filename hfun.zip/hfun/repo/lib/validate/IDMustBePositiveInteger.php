<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/4/8
 * Time: 13:58
 */
namespace lib\validate;

use lib\validate\BaseValidate;

class IDMustBePositiveInteger extends BaseValidate
{
    // 验证规则
    protected $rule = [
        'id' => 'require|isNotEmpty|isPositiveInteger',
    ];

    protected $message = [
        'id.isPositiveInteger' => 'id必须是正整数',
    ];

    protected $field = [
        'id'=>'id'

    ];

    protected $scene = [
        'default' => [
            'id',
        ],

    ];
}