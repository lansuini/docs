<?php
namespace lib\service\push;
require_once(dirname(__FILE__) . '/../IOSNotification.php');

class IOSGroupcast extends IOSNotification {
	function  __construct() {
		parent::__construct();
		$this->data["type"] = "groupcast";
		$this->data["filter"]  = NULL;
	}
}