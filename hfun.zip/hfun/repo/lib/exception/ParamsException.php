<?php
/**
 * author      : Gavin <liyn2007@qq.com>
 * createTime  : 2017/8/16 10:14
 * description : 通用参数错误校验类
 */

namespace lib\exception;

use lib\exception\BaseException;

class ParamsException extends BaseException
{

}