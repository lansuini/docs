<?php
/**
 *  任务接口模块
 * @author Taylor 2018-11-27
 */
namespace Logic\Movie;
use DB;
use Model\MovieTemp;
use Utils\Curl;
class Upload extends \Logic\Logic{


    public static function checkUploadMovies(){
        return;
        $pendingMovies = MovieTemp::where('status',2)->get()->toArray();
        foreach($pendingMovies as $pendingMovie) {
            try {
                $exists = DB::table('movie')->where('third_id', $pendingMovie['third_id'])->first();
                if ($exists) {
                    DB::table('movie_temp')->where('third_id', $pendingMovie['third_id'])->update(['status' => 1]);
                }

                $url = 'http://www-api.zyupload.com/result';
                $params['file_name'] = $pendingMovie['third_id'];
                $res = Curl::get($url . '?' . http_build_query($params));
                $result = json_decode($res, true);
                if ($result['state'] === 0) {
                    $data['url'] = $pendingMovie['url'];
                    $data['title'] = $pendingMovie['name'];
                    $data['third_id'] = $pendingMovie['third_id'];
                    $data['status'] = 3;
                    $data['size'] = $pendingMovie['size'];
                    $data['duration'] = $pendingMovie['duration'];
                    DB::table('movie_temp')->where('third_id', $pendingMovie['third_id'])->update(['status' => 1]);
                    DB::table('movie')->insert($data);
                    echo '电影上传成功！';
                } elseif ($result['state'] === 20) {
                    echo $pendingMovie['third_id'].'-'."电影正在上传中";
//                    return $this->lang->set(11004);
                } else {
                    echo '电影查询异常 : '.$pendingMovie['third_id'].'-'.$res;
//                    return $this->lang->set(11005, [$res]);
                }

            } catch (\Exception $e) {
                echo '系统错误 : '.$pendingMovie['third_id'].'-'.$e->getMessage();
//                return $this->lang->set(10001, $e->getMessage());
            }

        }
    }



}
