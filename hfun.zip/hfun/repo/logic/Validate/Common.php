<?php

namespace Logic\Validate;

use \lib\exception\BaseException;
/**
 * 验证码模块
 */
class Common extends \Logic\Logic {


    public function checkID($id){

        if (empty($id)) {
            $newResponse = $this->ci->response->withStatus(400);
            $newResponse = $newResponse->withJson([
                'state' => -1,
                'message' => 'id不能为空',
                'ts' => time(),
            ]);
            throw new BaseException($this->ci->request,$newResponse);
        }

        if (is_numeric($id) && is_int($id + 0) && ($id + 0) > 0) {
            return true;
        }

        $newResponse = $this->ci->response->withStatus(400);
        $newResponse = $newResponse->withJson([
            'state' => -1,
            'message' => 'id必须为正整数',
            'ts' => time(),
        ]);
        throw new BaseException($this->ci->request,$newResponse);
    }
}