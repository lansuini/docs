<?php

namespace Logic\Admin;

use Model\Admin\AdminUser;
use Utils\Client;
use Illuminate\Database\Capsule\Manager as Capsule;
use lib\exception\BaseException;
use DB;
/**
 * json web token
 * 保证web api验证信息不被篡改
 *
 * @auth *^-^*<dm>
 * @copyright XLZ CO.
 * @package
 * @date 2017/5/3 8:59
 */
class AdminToken extends \Logic\Logic{

    const KEY = 'this is secret use for jwt';

    const EXPIRE = 86400 * 7;

    protected $Db;

    protected $adminAuth;

    protected $playLoad = [
        'uid' => 0, // 0 匿名用户
        'rid' => 0, //role id, 0 默认权限
        'type' => 1, // 1 普通用户; 2 平台用户
        'nick' => '',
        'ip' => '0.0.0.0',
        'client_id' => '',
    ];

    public function __construct($ci)
    {
        parent::__construct($ci);
        $this->Db = new Capsule();
        $this->Db->setFetchMode(\PDO::FETCH_ASSOC);
        $this->amdinAuth = new AdminAuth($ci);
    }

    /**
     * 生成json web token(jwt)
     *
     * 由三部分组成：分别是处理过Header Payload Signature，各段之间通过点号(.)相连，形成：xxxxx.yyyyy.zzzzz
     * header，基本不变:
     * {
     *      "alg": "HS256",
     *      "typ": "JWT"
     * }
     *
     * Payload，形式：
     * {
     *      "iss": "lxz",
     *      "exp": "125444741",
     *      "usr": "app",
     *      "uuid": "8sdf7878"
     * }
     *
     * @param array  $userData
     * @param string $publicKey 用户公钥
     * @param int    $ext
     *
     * @return string
     */
    public function createToken(array $data = [], $publicKey = self::KEY, $ext = self::EXPIRE, $digital = '')
    {
        $user = DB::table('admin_user')->where('username', $data['username'])
            ->first(['id','status','salt','password','username','truename','nick','email','telephone','mobile','part','job','memo as comment','logintime']);
        if (empty($user)) {
            return $this->lang->set(10046);
        }
        $user = json_decode(json_encode($user), true);
        if($user['status'] !== 1){
            return $this->lang->set(10549);
        }
        if ($user['password'] != md5(md5($data['password']) . $user['salt'])) {
            return $this->lang->set(10046);
        }
        unset($user['salt']);
        unset($user['password']);
//        return  [
//            'uid' => self::fakeId(intval($user['id']), $digital),
//            'role' => self::fakeId(intval(0), $digital),
//            'nick' => $data['username'],
//            'type' => 1, //普通用户
//            'ip' => Client::getIp(),
//            'mac' => Client::ClientId(),
//            [
//                $publicKey,
//                $ext
//            ]
//        ];
//        $role = $this->Db->table('admin_user_role_relation')->where('uid',$user['id'])->value('rid');
        // 如果缺少role，则为0
//        $user['role'] = $role ?? 0;
        $user['role'] = 0;

        $userData = [
            'uid' => self::fakeId(intval($user['id']), $digital),
            'role' => self::fakeId(intval($user['role']), $digital),
            'nick' => $data['username'],
            'type' => 1, //普通用户
            'ip' => Client::getIp(),//'192.168.10.171'
            'mac' => Client::ClientId(),
        ];

//        print_r($userData);exit;

        // 1、生成header
        $header = ['alg' => "HS256", 'typ' => "JWT"];
        $header = base64_encode(json_encode($header));
        // 2、生成payload
        $payload = base64_encode(json_encode(array_merge(["iss" => "lxz", "exp" => time() + $ext], $userData)));
        // 3、生成Signature
        $signature = hash_hmac('sha256', $header.'.'.$payload, $publicKey, false);
        $token = $header.'.'.$payload.'.'.$signature;

//        $routes = $this->amdinAuth->getAuths(intval($user['role']));
        $routes = '';

//        $memberControls = $this->amdinAuth->getMemberControls(intval($user['role']));
        $memberControls = '';

        // fixme 踢下线需要cache
        $this->amdinAuth->saveAdminUser($user['id'], $userData, $ext);
        $this->amdinAuth->saveAdminWithToken($user['id'], $token, $ext);
        // save refresh token
        $rs['refresh_token'] = uniqid();
        $rs['expire'] = time() + $ext;

        $this->amdinAuth->saveRefreshToken($rs['refresh_token'], $token, $ext);

        DB::table('admin_user')->where('id',$user['id'])->update(['loginip'=>$userData['ip'],'logintime'=>date('Y-m-d H:i:s')]);

        $this->amdinAuth->updateUser($user['id'], null,
            ['logintime' => date('Y-m-d H:i:s'), 'updated' => date('Y-m-d H:i:s')]);

        // 4、返回结果
        return $this->lang->set(1,[],['token'=>$token,'list'=>$user,'route2' => $routes,
            'member_control' => $memberControls,'refresh_token'=>$rs['refresh_token'],'expire'=>$rs['expire']]);
    }

    /**
     * 用户名、密码匹配
     *
     * @param $user
     * @param $password
     * @return int -1 用户名或密码错误 -2 账号被停用 -3 用户名或密码错误
     */
    public function matchUser($user_id,$password)
    {
        $user = AdminUser::where('status', '1')->find($user_id)->toArray();

        if (is_array($user)) {

            if ($user['password'] != md5(md5($password) . $user['salt'])) {
                return $this->lang->set(10046);
            }
        }
        return $user;
    }

    /**
     * token校验
     * @return array
     * @throws BaseException
     * @throws \Interop\Container\Exception\ContainerException
     */
    public function verifyToken() {

        if (!$this->playLoad['rid'] || !$this->playLoad['uid']) {

            $config = $this->ci->get('settings')['jsonwebtoken'];
            $token = $this->getToken($config['public_key']);;

        }
        return $this->playLoad;
    }

    /**
     * 获取头部token信息
     * @param string $publicKey
     * @throws BaseException
     * @throws \Interop\Container\Exception\ContainerException
     */
    protected function getToken($publicKey = self::KEY)
    {
        $header = $this->request->getHeaderLine('Authorization');
        $config = $this->ci->get('settings')['jsonwebtoken'];
        // 判断header是否携带token信息
        if (!$header) {
            $newResponse = createRsponse($this->response,401,10041,'缺少验证信息！');
            throw new BaseException($this->request,$newResponse);
        }

        $token = substr($header, 7);
        if ($token && $data = $this->decode($token, $publicKey)) {
//                return $data;
            $uid = $this->originId($data['uid'], $config['uid_digital']);
            $this->amdinAuth->checkAdminuser($uid);
            $key = \Logic\Set\SetConfig::SET_GLOBAL;
            $cache = json_decode($this->redis->get($key),true);
            $login_check = true;

            $login_check = isset($cache['base']['Duplicate_LoginCheck']) ? $cache['base']['Duplicate_LoginCheck'] : $login_check;
            if ($login_check)
                $this->amdinAuth->checkAdminWithToken($uid, $token);

            $role = $this->originId($data['role'] ?? 0, $config['uid_digital']);
            $nick = $data['nick'];
            $this->playLoad = array_merge($this->playLoad, ['rid' => $role, 'uid' => $uid, 'nick' => $nick, 'ip' => Client::getIp()]);
            $GLOBALS['playLoad'] = $this->playLoad;

        }else{
            $newResponse = createRsponse($this->response,401,10041,'验证信息不合法！');
            throw new BaseException($this->request,$newResponse);
        }


    }


    /*
     * @param uid 用户id
    * 根据用户id删除token 删除管理需要踢该管理员下线小需求
    */
    public function deleteAdminWithToken($uid){
        return $this->amdinAuth->deleteAdminWithToken($uid);

    }



    /**
     * @param string $token
     * @param string $publicKey
     *
     * @return array|null
     * @see https://jwt.io/introduction/
     */
    protected function decode($token, $publicKey = self::KEY)
    {
        if (substr_count($token, '.') != 2) {
            return null;
        }
        list($header, $payload, $signature) = explode('.', $token, 3);

        $_header  = json_decode(base64_decode($header, true), true);
        $_payload = json_decode(base64_decode($payload, true), true);

        if (hash_hmac('sha256', $header.'.'.$payload, $publicKey, false) != $signature) {
            $newResponse = createRsponse($this->response,401,10041,'验证不通过！');
            throw new BaseException($this->request,$newResponse);
        }
        // 是否过期
        if ($_payload['exp'] <= time()) {
            $newResponse = createRsponse($this->response,401,10041,'登录超时！');
            throw new BaseException($this->request,$newResponse);
        }

        return $_payload ;
        return ['header' => $_header, 'payload' => $_payload];
    }

    /**
     * get user data
     *
     * @param string $publicKey
     * @return mixed|null
     */
    public function getPayload($publicKey = self::KEY)
    {
        $token = $this->getToken($publicKey);
        if (!$token) {
            return null;
        }

        return $token['payload'];
    }

    /**
     * 伪uid
     *
     * @param int $uid
     * @param int $digital
     * @return int
     */
    public static function fakeId(int $uid, int $digital)
    {
        return ~$digital - $uid;
    }

    /**
     * 原uid
     *
     * @param int $fakeId
     * @param int $digital
     * @return int
     */
    public function originId( $fakeId,  $digital)
    {
        return ~($fakeId + $digital);
    }
}
