<?php
/**
 * Created by PhpStorm.
 * User: tyleryang
 * Date: 2018/3/23
 * Time: 12:08
 */

namespace Logic\Set;

class SetConfig
{
    /**
     * 全局设置 tz
     */
    const SET_GLOBAL = 'system.config.global';
    /**
     * 站点设置
     */
    const SET_WEBSITE = 'system.config.website';
    /**
     * 用户注册设置
     */
    const SET_REGISTER_USER = 'system.config.reg.user';
    /**
     * 代理注册设置
     */
    const SET_REGISTER_AGENT = 'system.config.reg.agent';
    /**
     * 第三方客服
     */
    const SET_3TH_SERVICE = 'system.config.third.service';
    /**
     * 微信公众号安装
     */
    const SET_WECHAT_ACCOUNTS = 'system.config.wechat.accounts';
    /**
     * 厅主费用设置
     */
    const SET_TZ_COST = 'system.config.tz.cost';

    /**
     * 网站风格
     */
    const STYLE_MODULES = 'system.site.style';

    /**
     * 管理员会员权限控制
     */
    const MEMBER_CONTROLS = 'member.controls';

    /**
     * 彩种设置
     */
    const LOTTERY_CONF = 'lottery.conf';

    const DATA = [
        SetConfig::SET_GLOBAL => [
            'base' => [
                'maintaining '=>false,
                'advert'=>[1=>3,2=>3,3=>3,4=>3,5=>3,6=>3,7=>3,8=>3],
                'test_movie_domains'=>[
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157'
                ],
                'movie_domains'=>[
                    [
                        'host'=>'https://upload-api3.tgvplay.com',
                        'ip'=>'154.223.42.239',
                    ],
                    [
                        'host'=>'https://upload-api2.tgvplay.com',
                        'ip'=>'154.223.42.107',
                    ],
                    [
                        'host'=>'https://upload-api.tgvplay.com',
                        'ip'=>'154.223.42.224',
                    ],


                ],
            ],

        ],
        SetConfig::SET_WEBSITE => [
            'name' => '',
            'title' => '',
            'keywords' => '',
            'description' => '',
            'template' => '',
            'logo' => '',
            'message_bottom' => '',
        ],
        SetConfig::SET_3TH_SERVICE => [
            'code' => '<script></script>',
        ],

        SetConfig::SET_WECHAT_ACCOUNTS => [
            'mobil_appid' => '',
            'mobil_app_secret' => '',
            'appid' => '',
            'app_secret' => '',
            'token' => '',
            'encoding_aes_key' => '',
        ],

        SetConfig::SET_TZ_COST => [
            'game' => ''         // 游戏输赢分成设置  将各个游戏的组装成json字符串
        ],

        SetConfig::STYLE_MODULES => [
            'h5' => [
                ['id' => 1, 'key' => 'default', 'checked' => 0],
                ['id' => 2, 'key' => 'deepblue', 'checked' => 0],
                ['id' => 3, 'key' => 'gold', 'checked' => 0],
            ],
            'pc' => [
                ['id' => 4, 'key' => 'blacksky', 'checked' => 0],
                ['id' => 5, 'key' => 'purplestage', 'checked' => 0],
                ['id' => 6, 'key' => 'redclassics', 'checked' => 0],
                ['id' => 7, 'key' => 'shark', 'checked' => 0],
            ],
            'agent' => ['id' => 8, 'key' => 'default', 'checked' => 0],
            'admin' => ['id' => 9, 'key' => 'default', 'checked' => 0],
        ],

        SetConfig::MEMBER_CONTROLS => [
            // true 显示真实姓名， false 显示姓+*号
            'true_name' => false,
            // true 显示完整银行卡号，false 显示部份卡号
            'bank_card' => false,
            // true 显示完整的QQ、微信、skype等信息，false 显示部份
            'address_book' => false,
        ],

    ];
}
