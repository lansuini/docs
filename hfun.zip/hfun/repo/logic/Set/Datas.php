<?php

namespace Logic\Set;

/**
 * 获取一些全局的数据、常量
 *
 * @package Logic\Set
 */
class Datas extends \Logic\Logic
{

    public static $cache = [];

    /**
     * @return array|bool
     */
    public function memberControls() {
        return $this->get(SetConfig::MEMBER_CONTROLS);
    }

    /**
     * 获取游戏全局设置
     */
    public function getGameGlobalSet() {
        $global = $this->getGlobalSet();
        if (!$global || !isset($global['games']) || !$global['games']) {
            return [];
        }
        $liveList = $global['games'];
        // var_dump($liveList);exit;
        $newLiveList = [];
        foreach ($liveList as $k => $v) {
            if ($v['val']) {
                $newLiveList[$v['name']] = 1;
            }

        }
        return $newLiveList;
    }

    /**
     * 获取全局设置
     */
    public function getGlobalSet() {
        if (!($data = $this->get(SetConfig::SET_GLOBAL))) {
            return false;
        }
        return $data;
    }

    /**
     * 获取全局设置
     */
    public function getGlobal() {
        if (!($data = $this->get(SetConfig::SET_GLOBAL))) {
            return false;
        }

        if (!empty($data['games'])) {
            $gamesIds = array_values(array_column($data['games'], 'id'));
            $data['games'] = [];
            foreach (\Model\Partner::get() as $record) {
                if (in_array($record['id'], $gamesIds)) {
                    $data['games'][] = [
                        'id'   => $record['id'],
                        'name' => $record['name'],
                        'val'  => true,
                    ];
                }
            }
        }
        return $data;
    }


    /**
     * 第三方客服
     *
     * @return array|bool <br />
     * string code 客服代码
     */
    public function getService() {
        return $this->get(SetConfig::SET_3TH_SERVICE);
    }

    /**
     * 获取用户注册设置
     *
     * @param string $pf 平台， pc 或 h5
     *
     * @return array|bool
     * int id ID <br />
     * string item 项目 <br />
     * string name 名称 <br />
     * bool necessity 是否需要 <br />
     * bool visibility 是否显示 <br />
     */
    public function getUserRegister(string $pf = 'pc') {
        $pf = strtolower($pf);
        $key = SetConfig::SET_REGISTER_USER . ".$pf";

        return $this->get($key);
    }

    /**
     * @param $key <br />
     * Set::GLOBAL 全局设置 <br />
     * Set::SET_WEBSITE 站点设置<br />
     * Set::SET_REGISTER_USER 用户注册设置<br />
     * Set::SET_REGISTER_AGENT 代理注册设置<br />
     * Set::SET_3TH_SERVICE 第三方客服<br />
     *
     * @return bool|array
     */
    public function get($key) {
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        $data = $this->redis->get($key);

        if ($data) {
            $data = json_decode($data, true);
            self::$cache[$key] = $data;
            return $data;
        }

        if (!array_key_exists($key, SetConfig::DATA)) {
            return false;
        }

        $this->redis->set($key, json_encode(SetConfig::DATA[$key]));


        return SetConfig::DATA[$key];
    }

    /**
     * 复制值， 以原始数据为主， 不删除， 也不增加
     *
     * @param array $origin
     * @param array $data
     *
     * @return array
     */
    private function copyValue(array $origin, array $data) {
        $array = [];
        foreach ($origin as $key => $value) {
            if (is_array($value)) {
                $array[$key] = isset($data[$key]) ? $this->copyValue($value, $data[$key]) : $value;
            } else {
                $array[$key] = $data[$key] ?? $value;
            }
        }

        return $array;
    }

    /**
     *  唐朝启动后配置参数
     */
    public function getStartGlobal() {
        $_SERVER['REQUEST_SCHEME'] = isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : '';
        $_SERVER['HTTP_HOST'] = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';

        $pusherio = $this->ci->get('settings')['pusherio'];
        $data['code'] = '';  //第三方客服URL
        // $data['registbr_user'] = 1;  //用户注册是否要手机验证
        $data['withdraw_need_mobile'] = 1;  //提现是否需要手机验证
        $data['free_try_play'] = 1;  //免费试玩开关
        $data['down_url'] = '';  //APP下载url
        $data['app_name'] = '';
        $data['app_desc'] = '';

        $data['WeChat_login'] = false;
//        $data['world_cup'] = \Logic\Set\SetConfig::DATA[\Logic\Set\SetConfig::SET_GLOBAL]['base']['world_cup'];  //system.config.global

        $data['pusherio_server'] = is_array($pusherio['server_url']) ? current($pusherio['server_url']) : $pusherio['server_url'];  //pusherio socketio服务器地址
        $config = $this->get(SetConfig::SET_GLOBAL);
        $base = isset($config['base']) ? $config['base'] : [];

        if (!empty($this->get(SetConfig::SET_3TH_SERVICE)['code'])) {
            $data['code'] = $this->get(SetConfig::SET_3TH_SERVICE)['code'];
        }

        // if (!empty($this->get(SetConfig::SET_REGISTER_USER.'.all'))) {
        //     $data['registbr_user']=$this->get(SetConfig::SET_REGISTER_USER.'.all');
        // }

        $data['withdraw_need_mobile'] = (bool)(isset($base['withdraw_need_mobile']) ? $base['withdraw_need_mobile'] : $data['withdraw_need_mobile']);
        $data['WeChat_login'] = (bool)(isset($base['WeChat_login']) ? $base['WeChat_login'] : $data['WeChat_login']);
        $data['free_try_play'] = (bool)(isset($base['free_try_play']) ? $base['free_try_play'] : $data['free_try_play']);
        $data['down_url'] = isset($base['down_url']) ? $base['down_url'] : $data['down_url'];
        $data['app_name'] = isset($base['app_name']) ? $base['app_name'] : $data['app_name'];
        $data['app_desc'] = isset($base['app_desc']) ? $base['app_desc'] : $data['app_desc'];

//        $data['world_cup'] = isset($base['world_cup']) ? $base['world_cup'] : $data['world_cup'];
        if ($_SERVER['HTTP_HOST']) {
            $hostArr = explode('.', $_SERVER['HTTP_HOST']);
            $count = count($hostArr);
            $host = $hostArr[$count - 2] . '.' . $hostArr[$count - 1];
            $host = "m." . $host;
        } else {
            $host = '';
        }


        // 系统维护
//        $data['maintaining'] = isset($base['maintaining']) ? $base['maintaining'] : false;
        $data['maintaining'] = false;


        // 平台自动开关
        $data['unusual_period_auto'] = (bool)(isset($base['unusual_period_auto']) ? $base['unusual_period_auto'] : true);

        // 注册开关 1|2|3|4     1. 仅账号密码 2. 账号密码和账号密码手机  默认开3. 仅手机号密码4. 仅账号密码手机
        $data['register_type'] = (int)(isset($base['register_type']) ? $base['register_type'] : 2);


        return $data;
    }

    /**
     * 更改全局设置
     *
     * @param array $setting <br />
     * 参考 global方法的参数说明
     *
     * @return bool
     */
    public function updateGlobal(array $setting) {
        $conf = SetConfig::DATA[SetConfig::SET_GLOBAL]['base'];
        $origin = $this->get(SetConfig::SET_GLOBAL);
        $base = array_merge($conf, $origin['base']);
        $setting['base'] = $this->copyValue($base, $setting['base']);

        //$setting['games'] = $setting['games'];

        return $this->redis->set(SetConfig::SET_GLOBAL, json_encode($setting));
    }

    /**
     * @param string $key
     * @param array $setting
     *
     * @return bool
     */
    public function update(string $key, array $setting) {
        if (count($setting)) {
            $origin = $this->get($key);
            $new = $this->copyValue($origin, $setting);
            $new = json_encode($new);

            return $this->redis->set($key, $new);
        }

        return false;
    }


}