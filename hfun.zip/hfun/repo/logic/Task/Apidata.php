<?php
/**
 *  任务接口模块
 * @author Taylor 2018-11-27
 */
namespace Logic\Task;
use DB;

class Apidata extends \Logic\Logic{
    //获取用户id
    public function getUserId(){
        $udid = md5($_SERVER['HTTP_UDID']);
        $verify = $this->auth->verfiyToken();
        if ($verify->allowNext()) {
            $userId = $this->auth->getUserId();
            return $userId;
//            $userInfo = DB::table('user')
//                ->selectRaw('id,tel_code,mobile,name,invit_code,sex,viewable,downloadable,avatar,invit_num,level')
//                ->find($userId);
//            if(empty($userInfo->udid)){
//                DB::table('user')->where('id',$userId)->update(['udid'=>$udid]);
//            }
        }else{
            $userInfo = DB::table('user')
                ->where('udid', $udid)
                ->selectRaw('id')
                ->first();
            if(empty($userInfo)){
                return false;
            }else
                return $userInfo->id;
        }
    }

    //获取福利任务列表
    public function getTaskList(){
        $tasks = DB::table('movie_task')->where('task_kind', '=', 'welfare')->get();
        if(empty($tasks)){
           return null;
        }
        $tasks = json_decode(json_encode($tasks), true);
        $day = date('Y-m-d H:i:s');
        foreach($tasks as $task){
            if($task['status'] == 2) continue;
            if($task['is_long'] == 1 || ($task['s_time'] >= $day && $task['e_time'] <= $day)){//长期
                $list[] = ['task_name'=>$task['task_name'], 'task_desc'=>str_replace(['【GY】', '【HC】'], [$task['add_look_times'], $task['add_cache_times']], $task['task_desc']), 'add_look_times'=>$task['add_look_times'], 'add_cache_times'=>$task['add_cache_times']];
            }
        }
        return $list;
    }

    //获取福利的观影次数
    public function getTimes($u_id){
        if(empty($u_id)){
            return ['look_times'=>0, 'cache_times'=>0];
        }
        $task = DB::table('movie_user_log')->where('user_id', $u_id)->first(array(
            \DB::raw('SUM(look_times) as look_times'),
            \DB::raw('SUM(cache_times) as cache_times')
        ));
        //从缓存读取每日任务的临时次数
        $key = \Logic\Define\CacheKey::$perfix['level'].'_daily_'.$u_id.'_'.date('Ymd');
        $times = $this->redis->get($key);
        if(empty($times)){
            $times['look'] = 0;//观看次数
            $times['cache'] = 0;//缓存次数
        }else{
            $times = json_decode($times, true);
        }
        if(empty($task)){
            return ['look_times'=>$times['look'], 'cache_times'=>$times['cache']];
        }else{
            return ['look_times'=>$task->look_times + $times['look'], 'cache_times'=>$task->cache_times + $times['cache']];
        }
    }

    //每日任务
    public function dailyAddTimes(int $uid){
        $key = \Logic\Define\CacheKey::$perfix['level'].'_daily_'.$uid.'_'.date('Ymd');//每日任务是否完成
        $is_add = $this->redis->get($key);
        if(!empty($is_add)){//已完成任务
            return;
        }

        $task = DB::table('movie_task')->where('task_type', 'AD')->first();
        $date = date('Y-m-d H:i:s');
        if(empty($task) || $task->status == 2 ){//福利禁用或者不存在
            return;
        }
        if($task->is_long == 0 && $task->s_time > $date && $task->e_time < $date){//福利已过了有效期
            return;
        }
        if($task->expire_type == 1){//1 永久有效，2 当日有效
            DB::table('movie_user_log')->insert(['user_id' => $uid, 'log_type' => 'AD', 'look_times' => $task->add_look_times, 'cache_times'=>$task->add_cache_times, 'desc'=>$task->task_name." 观影次数+{$task->add_look_times}，缓存次数+{$task->add_cache_times}"]);
            $this->redis->setex($key, 24*3600, json_encode(['look'=>0, 'cache'=>0]));//24小时过期
        }else{
            $this->redis->setex($key, 24*3600, json_encode(['look'=>$task->add_look_times, 'cache'=>$task->add_cache_times]));//24小时过期
        }

    }

    //注册送福利
    public function registerAddTimes(int $u_id, string $invite_code){
        $this->taskAddTimes($u_id, 'ZC');//用户注册送福利
        $this->taskAddTimes($u_id, 'SJBD');//用户绑定手机号码
        if(!empty($invite_code)){
            $this->taskAddTimes($u_id, 'YQM');//填写邀请码
        }
    }

    //更新福利任务的观影次数
    public function taskAddTimes(int $uid, string $task_type){
        $task = DB::table('movie_task')->where('task_type', $task_type)->first();
        $date = date('Y-m-d H:i:s');
        if(empty($task) || $task->status == 2 ){//福利禁用或者不存在
            return;
        }
        if($task->is_long == 0 && $task->s_time > $date && $task->e_time < $date){//福利已过了有效期
            return;
        }

        $where = [['user_id', '=', $uid], ['log_type', '=', $task_type]];
        $log = DB::table('movie_user_log')->where($where)->first();
        if(empty($log)){
            DB::table('movie_user_log')->insert(['user_id' => $uid, 'log_type' => $task_type, 'look_times' => $task->add_look_times, 'cache_times'=>$task->add_cache_times, 'desc'=>$task->task_name." 观影次数+{$task->add_look_times}，缓存次数+{$task->add_cache_times}"]);
        }
    }


    /*
     * 获取任务观影次数
     * @param $type 1,已登录，2，未登录
     */
    public function getTaskTimes($u_id){
        if(empty($u_id)){
            return 0;
        }
        $verify = $this->auth->verfiyToken();

        $query = DB::table('movie_user_log')->where('user_id', $u_id);
        if (!$verify->allowNext()) {

           $query->where('log_type',['EWM']);

        }

        $task = $query->first(array(
            \DB::raw('SUM(look_times) as look_times'),
            \DB::raw('SUM(cache_times) as cache_times')
        ));
        //从缓存读取每日任务的临时次数
        $key = \Logic\Define\CacheKey::$perfix['level'].'_daily_'.$u_id.'_'.date('Ymd');
        $times = $this->redis->get($key);
        if(empty($times)){
            $times['look'] = 0;//观看次数
            $times['cache'] = 0;//缓存次数
        }else{
            $times = json_decode($times, true);
        }
        if(empty($task)){
            return ['look_times'=>$times['look'], 'cache_times'=>$times['cache']];
        }else{
            return ['look_times'=>$task->look_times + $times['look'], 'cache_times'=>$task->cache_times + $times['cache']];
        }
    }

}
