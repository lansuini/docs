<?php
/**
 *  任务接口模块
 * @author Taylor 2018-11-27
 */
namespace Logic\Crontab;
use DB;
class User extends \Logic\Logic{

    public static function updateUserVip(){

            $res = DB::table('cdkey')
                ->where('status',2)
                ->where('dlength','<>',0)
                ->where('end_date','<',date('Y-m-d H:i:s'))
                ->update(['status'=>3]);
            var_dump($res);
        }

    public function updateUserActive($params){
//        DB::enableQueryLog();
        try{

            DB::beginTransaction();

            $date = date('Y-m-d');
            $bitmap = 'user_active:'.$date;
            if($this->ci->redis->getBit($bitmap,$params['user_id'])){
                return ;
            }
            if($params['device_type'] == 'ios'){
                $type = 'ios_cnt';
            }else{
                $type = 'android_cnt';
            }

            $isexists = DB::table('rpt_user_active_day')->where('count_date',$date)->where('platform', $params['platform'])->first();
            if(!$isexists){
                $data = [
                    'count_date'=> $date,
                    'platform'=> $params['platform'],
                ];
                DB::table('rpt_user_active_day')->insert($data);
            }
            $res = DB::table('rpt_user_active_day')
                ->where('count_date',$date)
                ->where('platform', $params['platform'])
                ->increment('active_cnt',1,[$type=>\DB::raw("$type + 1")]);

            $isexists = DB::table('rpt_user_active_month')->where('count_date',date('Y-m'))->where('platform', $params['platform'])->first();
            if(!$isexists){
                $month_data = [
                    'count_date'=> date('Y-m'),
                    'platform'=> $params['platform'],
                ];
                DB::table('rpt_user_active_month')->insert($month_data);
            }
            $res = DB::table('rpt_user_active_month')
                ->where('count_date',date('Y-m'))
                ->where('platform', $params['platform'])
                ->increment('active_cnt',1,[$type=>\DB::raw("$type + 1")]);
//            print_r(DB::getQueryLog());
            if($res){
                $this->ci->redis->setBit($bitmap,$params['user_id'],1);
                echo '统计活跃成功！'.PHP_EOL;
            }else{
                echo '统计活跃失败！'.PHP_EOL;
//            \Utils\MQServer::send('sum_active',$params);
            }

            DB::commit();
        }catch (\Exception $e){
            DB::rollback();
//            throw $e;
//            $this->ci->logger->
        }

    }

    public function updateUserActiveBak($params)
    {

        try {

            DB::beginTransaction();

            $date = date('Y-m-d');
            $bitmap = 'user_active:' . $date;
            if ($this->ci->redis->getBit($bitmap, $params['user_id'])) {
                return;
            }
            if ($params['device_type'] == 'ios') {
                $type = 1;
            } else {
                $type = 2;
            }

            $isexists = DB::table('active_data')->where('type', $type)->where('date', $date)->where('platform', $params['platform'])->first();
            if (!$isexists) {
                $data = [
                    'count_date' => $date,
                    'type' => $type,
                    'platform' => $params['platform'],
                ];
                DB::table('active_data')->insert($data);
            }
            $res = DB::table('active_data')->where('type', $type)->where('date', $date)->where('platform', $params['platform'])->increment('num', 1);
            $isexists = DB::table('active_data_month')->where('type', $type)->where('date', date('Y-m'))->where('platform', $params['platform'])->first();
            if (!$isexists) {
                $month_data = [
                    'date' => date('Y-m'),
                    'type' => $type,
                    'platform' => $params['platform'],
                ];
                DB::table('active_data_month')->insert($month_data);
            }
            $res = DB::table('active_data_month')->where('type', $type)->where('date', date('Y-m'))->where('platform', $params['platform'])->increment('num', 1);
//            print_r(DB::getQueryLog());
            if ($res) {
                $this->ci->redis->setBit($bitmap, $params['user_id'], 1);
                echo '统计活跃成功！' . PHP_EOL;
            } else {
                echo '统计活跃失败！' . PHP_EOL;
//            \Utils\MQServer::send('sum_active',$params);
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            throw $e;
//            $this->ci->logger->
        }
    }






}
