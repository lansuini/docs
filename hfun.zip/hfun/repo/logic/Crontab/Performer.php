<?php
/**
 *  任务接口模块
 * @author Taylor 2018-11-27
 */
namespace Logic\Crontab;
use DB;
class Performer extends \Logic\Logic{

    public static function updatePerformerMovies(){

            $performers = DB::table('performer')->get()->toArray();

            foreach ($performers as $performer){
                try{
                    echo $performer->id;
                    $count = DB::table('performer_movie')->where('performer_id',$performer->id)->count();
                    echo $count;
                    DB::table('performer')->where('id',$performer->id)->update(['movies'=>$count]);
                    echo 'success';
                }catch (\Exception $e){
                    throw $e;
                    echo 'fail';
                }

            }
        }




}
