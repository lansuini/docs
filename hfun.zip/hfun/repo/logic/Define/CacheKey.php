<?php
/**
 * Created by PhpStorm.
 * User: tyleryang
 * Date: 2018/3/21
 * Time: 10:28
 */

namespace Logic\Define;
/**
 * Class CacheKey
 * 缓存key定义 前缀定义类
 * @package Logic\Define
 */
class CacheKey
{

    /**
     * key
     * @var array
     */
    public static $perfix = [

        // 密码错误校验前缀
        'pwdErrorLimit' => 'loginpwd_wrong_times_',

        // 全局配置
        'global' => 'system.config.global',

        // 注册
        'registerUser' => 'system.config.reg.user',

        // 第三方客服
        '3thService' => 'system.config.third.service',

        // 用户登录token
        'token' => 'token_',

        // 热门彩期
        'hotLottery' => 'curperiod_hot_all_',


        // 首页缓存
        'appHomePage' => 'app_home_page',

        // notice h5list
        'noticeH5list' => 'notice_h5_list',

        // banner
        'banner' => 'banner',


        // pusherio
        'pusherioHistory' => 'pusherio_history_',


        // 图形验证码前缀
        'authVCode' => 'auth_vcode:',

        // 短信通知码
        'captchaRefresh' => 'cache_refresh_',

        // 短信通知码
        'captchaText' => 'cache_text_',

        // 活动缓存
        'activeList' => 'activeList_',

        // ip流水防护
        'protectByIP' => 'protect_ip',

        // 用户流水防护
        'protectByUser' => 'protect_user',

        // userSafety
        'userSafety' => 'user_satety_',

        // socketiokey mess
        'socketioMessage' => 'socketio_message',


        // findpass
        'findPass' => 'find_pass_',

        // 用户在状在线最后时间
        'userOnlineLastTime' => 'user_online_last_time',

        //用户活跃时间zset
        'onlineUsers'   => 'online_users',

        // 用户禁用状态
        'userRejectLoginStatus' => 'user_reject_login_status',


        'sendMsgUserMobile' => 'sendMsg_%s_%s',  //1: +8615989289384, 2: sendMsgByAWS

        // 首页hot缓存
        'homePageHot' => 'home_page_hotv2',

        'KEY_ADMIN_USER' => 'admin_user_cache',


        //游客user_id缓存键
        'visitorUserId' => 'visitor_user_id',
        //已观影次数
        'todayViews'  => 'today_views',
        //hash 观影列表
        'todayViewMovies'  => 'today_view_movies',
        //hash 下载列表
        'todayDownMovies'  => 'today_down_movies',
        //层级
        'level'  => 'level',
        //advert
        'advert' => 'advert',
        //电影上传站点
        'movieDomains' => 'movie_domains',
        //homeColumn首页栏目
        'homeColumn'=>'home_column',
        //homeTopColumn首页推荐栏目
        'homeTopColumn'=>'home_top_column',
        //频道热门专题
        'channelHotColumn'=>'channel_hot_column',
        //频道热门专题
        'channelTopColumn'=>'channel_top_column',
        //频道热门演员
        'channelPerformerHot'=>'channel_performer_hot',
        //频道热门演员
        'channelTag'=>'channel_tag',
    ];

}