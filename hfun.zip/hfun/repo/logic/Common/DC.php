<?php
/**
 *  任务接口模块
 * @author Taylor 2018-11-27
 */
namespace Logic\Common;
use DB;
class DC extends \Logic\Logic{


    public static function record($action = '',$type = '',$user_id = '',$movie_id = ''){
        try{
            $action = ['view','download','collect','like','dislike'];

            switch($action){
                case 'view':

                    break;
                case 'download':

                    break;
                case 'collect':

                    break;
                case 'like':

                    break;
                case 'dislike':

                    break;
                default:

                    break;
            }

        }catch (\Exception $e){



        }
    }



}
