<?php
namespace Utils;
use Utils\Encrypt;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException ;
class Utils {

    /**
     * @return array
     */
    public static function NeedFilterKeywords() {
        return ['email', 'mobile', 'qq', 'weixin', 'skype', 'idcard', 'telephone', 'card'];
    }



    public static function gerIpRegion($ip = ''){

        global $app;
        if(empty($ip))
            return ;

        $logSetting = $app->getContainer()->get('settings')['log'];
        $log = $logSetting['path'] . 'request.log';
        $client = new Client();
        try{
            $result = $client->request('GET', 'http://ip.taobao.com/service/getIpInfo.php?ip='.$ip, [
                'timeout'  =>  3.14 ,
            ]);
            $region = '';
            if($result->getStatusCode() == 200){
                $res= (json_decode($result->getBody(),true));
                if($res['code'] === 0){
                    $region = $res['data']['region'];
                }
            }
            file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . $result->getStatusCode() . " ip:".$ip . "\n" . $result->getBody() . "\n\n", FILE_APPEND);

            return $region;
        }catch (\Exception $e){
            if($e instanceof ClientException){
                $response = $e->hasResponse() ? $e->getResponse() : '';
                file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . '请求异常：' . " ip:".$ip . "\n" . $e->getRequest() . '\n'.$response."\n\n", FILE_APPEND);
            }else{
                $app->getContainer()->logger->error('frontend', ['message'=>$e->getMessage()]);
//                throw $e;
            }
            return '';
        }

    }

    public static function gerIpRegion2($ip = ''){

        global $app;
        if(empty($ip))
            return ;

        $logSetting = $app->getContainer()->get('settings')['log'];
        $log = $logSetting['path'] . 'request.log';
        $client = new Client();
        try{
            $result = $client->request('GET', 'http://www.bejson.com/api/bejson/ipinfo.php?ip='.$ip, [
                'timeout'  =>  3.14 ,
            ]);
            $region = '';
            if($result->getStatusCode() == 200){
                $res= (json_decode($result->getBody(),true));
                if($res['code'] === 0){
                    $region = $res['data']['region'];
                }
            }
            file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . $result->getStatusCode() . " ip:".$ip . "\n" . $result->getBody() . "\n\n", FILE_APPEND);

            return $region;
        }catch (\Exception $e){
            if($e instanceof ClientException){
                $response = $e->hasResponse() ? $e->getResponse() : '';
                file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . '请求异常：' . " ip:".$ip . "\n" . $e->getRequest() . '\n'.$response."\n\n", FILE_APPEND);
            }else{
                $app->getContainer()->logger->error('frontend', ['message'=>$e->getMessage()]);
//                throw $e;
            }
            return '';
        }

    }

    /**
     * openssl 双向加密
     *
     * @return Encrypt|null
     */
    public static function Xmcrypt() {
        global $app;
        static $mt = null;
        if (is_null($mt)) {
            $key = $app->getContainer()->get('settings')['app']['app_key'];
            $mt  = new Encrypt($key);
        }

        return $mt;
    }

    /**
     * 加密
     *
     * @param string $data
     * @return string
     */
    public static function RSAEncrypt(string $data = null) {
        if (!strlen($data)) {
            return $data;
        }

        return self::Xmcrypt()->encrypt($data) ?? $data;
    }

    /**
     * 个人信息加、解密补丁
     *
     * @param array $data 多维数组
     * @param int   $handler Enc 加密 Dec 解密
     * @return array
     */
    public static function RSAPatch(array &$data = null, int $handler = Encrypt::DECRYPT) {
        if (!$data) {
            return $data;
        }
        foreach ($data as $key => &$datum) {
            $datum = is_object($datum) ? ((array) $datum) : $datum;
            if (is_array($datum)) {
                $datum = self::RSAPatch($datum, $handler);
            } else {
                if (in_array($key, self::NeedFilterKeywords(), true)) {
                    $datum = $handler == Encrypt::DECRYPT ? self::RSADecrypt($datum) : self::RSAEncrypt($datum);
                }
            }
        }

        return $data;
    }

    /**
     * 解密
     *
     * @param string $data
     * @return null|string
     */
    public static function RSADecrypt(string $data = null) {
        if (!strlen($data)) {
            return $data;
        }

        return self::Xmcrypt()->decrypt($data) ?? $data;
    }


    /**
     * 银行卡、提款、取款补丁
     * 处理表fund_deposit里面的银行卡信息(解密)
     * 数组：支持一维['pay_bank_info'=>,'receive_bank_info'=>]
     * 或二维数组[
     *  0=>['pay_bank_info'=>,'receive_bank_info'=>],
     *  1=>['pay_bank_info'=>,'receive_bank_info'=>]
     * ]
     *
     * @param \Data\Paged|\Row|\Rowset|array $result
     * @param int                            $handler
     * @return mixed
     */
    public static function DepositPatch(&$result, int $handler = Encrypt::DECRYPT) {
        if ($result instanceof \Data\Paged) {
            $data = $result->data();
        } elseif (is_array($result) || $result instanceof \Traversable) {
            $data = &$result;
        } else {
            return $result;
        }
        // 二维数组
        if (isset($data[0])) {
            foreach ($data as &$datum) {
                $datum = self::DepositPatch($datum, $handler);
            }
        } else {
            // 一维
            foreach ($data as $key => &$datum) {
                if (in_array($key, ['pay_bank_info', 'receive_bank_info'])) {
                    if (is_string($datum)) {
                        $datum = strlen($datum) ? json_decode($datum, true) : [];
                    }
                    if (is_array($datum)) {
                        $datum = json_encode(self::RSAPatch($datum, $handler), JSON_UNESCAPED_UNICODE);
                    }
                }
            }
        }

        if (is_object($result) && method_exists($result, 'setData')) {
            $result->setData($data);
        }

        return $result;
    }

    public static function exportExcel($file,$title,$data){
        header('Content-type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . $file.'.xls');
        $content = '';
        foreach ($title as $tval) {
            $content .= $tval . "\t";
        }
        $content .= "\n";
        if($data){
            foreach ($data as $val) {
                foreach ($val as $v){
                    $content .= $v . "\t";
                }
                $content .= "\n";
            }
        }
        echo mb_convert_encoding($content,"gb2312","UTF-8");
        exit;
    }

    /**
     * 随机字符串。
     * @param int $length 字符串长度。
     * @param string $chars 可选，字符表，默认为 a-zA-Z0-9 区分大小写的集合。
     * @return string 注意：返回的长度为 $length 和和字符表长度中的最小值。
     */
    public static function randStr(int $length = 16, string $chars = 'stOcdWpuFUVw9Eb4eYfgSZ0ykln3jTGa2xKB5zqrPTv7NDXCoMLRh8HIJiQA1m6') {
        //1.获取字符串的长度
        $len = strlen($chars)-1;

        //2.字符串截取开始位置
        $start=mt_rand(0,$len);

        //3.字符串截取长度
        $count=mt_rand(0,$len);

        //4.随机截取字符串，取其中的一部分字符串
        return substr($chars, $start, $length);

    }

    public static function decryptImg($url)
    {
        try{
            $img = file_get_contents($url);
            $options = OPENSSL_RAW_DATA;
            $key = '9536205862353e299dd4db1add091772';
            $cipher = 'AES-256-CBC';
            $iv = '0473bdcf22c5c816';
            $_encrypted = base64_decode($img);
            if (!$_encrypted) {
                return $img;
            }
            $decryptedImg = openssl_decrypt($_encrypted, $cipher, $key, $options, $iv);
            if (false === $decryptedImg) {
                //print_var(openssl_error_string());

                return $img;
            }
            return $decryptedImg;
        }catch (\Exception $e){
            throw $e;
            return $img;
        }

    }
}