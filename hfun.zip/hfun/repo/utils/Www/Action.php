<?php
namespace Utils\Www;

use Slim\Exception\SlimException;

class Action {

    protected $ci;

    /**
     * 前置操作方法列表
     * @var array $beforeActionList
     * @access protected
     */
    protected $beforeActionList = [];

    protected $ipProtect = true;

    protected $maintaining = true;

//     public function __construct($ci)
//     {
//         $this->ci = $ci;
//         if ($this->beforeActionList) {
//             foreach ($this->beforeActionList as $method ) {
//
//                 call_user_func([$this, $method]);
//
//             }
//         }
//     }

    public function init($ci) {

        $this->ci = $ci;

        // 系统维护性开关
        if (in_array($this->request->getMethod(), ['POST', 'PUT', 'PATCH', "DELETE"]) && ((new \Logic\Set\Datas($this->ci))->getStartGlobal())['maintaining'] && $this->maintaining) {
            return $this->lang->set(5);
        }

        // ip 请求流量保护
        if (isset($website['ipProtect']) && $website['ipProtect'] && $this->ipProtect) {
            $res = \Utils\Client::getApiProtectByIP();
            if (!$res->allowNext()) {
                return $res;
            }
        }

        if ($this->beforeActionList) {
            foreach ($this->beforeActionList as $method) {
                call_user_func([$this, $method]);
            }
        }
    }

    /**
     * 校验token
     * @throws BaseException
     */
    public function verifyToken(){


        $verify = $this->auth->verfiyToken();

        if (!$verify->allowNext()) {
            $newResponse = createRsponse($this->response,401,162,'登录已过期，请重新登录！');
            throw new SlimException($this->request,$newResponse);
        }


    }

    public function establish(){
        if(!isset($_SERVER['HTTP_UDID']) && empty($_SERVER['HTTP_UDID'])){
            $newResponse = createRsponse($this->response,401,401,'建立会话失败！');
            throw new SlimException($this->request,$newResponse);
        }
//        $udid = $_SERVER['HTTP_UDID'];
//        $key = 'udid_uid';
//        $res = $this->redis->hexists($key,$udid);
//        if(!$res){
//            $this->redis->hset($key,$udid,0);
//        }

    }


    public function __get($field) {
        if (!isset($this->{$field})) {
            return $this->ci->{$field};
        } else {
            return $this->{$field};
        }
    }

}
