<?php
/**
 * Created by PhpStorm.
 * User: tyleryang
 * Date: 2018/3/21
 * Time: 15:18
 */

namespace Utils;

class Client {

    /**
     * 取客户端IP
     * @return [type] [description]
     */
    public static function getIp() {

//        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
//            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
//        } else if (isset($_SERVER['HTTP_CLIENT_IP'])) {
//            $ip = $_SERVER['HTTP_CLIENT_IP'];
//        } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
//            $ip = $_SERVER['HTTP_X_FORWARDED'];
//        } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
//            $ip = $_SERVER['HTTP_FORWARDED_FOR'];
//        } else if (isset($_SERVER['HTTP_FORWARDED'])) {
//            $ip = $_SERVER['HTTP_FORWARDED'];
//        } else if (isset($_SERVER['REMOTE_ADDR'])) {
//            $ip = $_SERVER['REMOTE_ADDR'];
//        }
        if(!empty($_SERVER["HTTP_CLIENT_IP"]))
        {
            $ip = $_SERVER["HTTP_CLIENT_IP"];
        }
        else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
        {
            $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        }
        else if(!empty($_SERVER["REMOTE_ADDR"]))
        {
            $ip = $_SERVER["REMOTE_ADDR"];
        }else{
            $ip = '';
        }

        preg_match("/[\d\.]{7,15}/", $ip, $cips);
        $cip = isset($cips[0]) ? $cips[0] : '0.0.0.0';
        unset($cips);

        return $cip;

        if (empty($ip)) {
            return '0.0.0.0';
        } else {
            return (explode(',', $ip))[0];
        }

    }

    /**
     * 客户端唯一标识
     *
     * 并不严格
     *
     * @param string $mac
     * @return string|bool
     */
    public static function ClientId($mac = '') {
        if (!is_string($mac)) {
            return false;
        }
        if (empty($mac)) {
            //$remoteIp = self::getClientIp();
            $agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

            return sha1(join('.', array($agent)));
        } else {
            return sha1($mac);
        }
    }

    public static function isSsl() {  
        if(isset($_SERVER['HTTPS']) && ('1' == $_SERVER['HTTPS'] || 'on' == strtolower($_SERVER['HTTPS']))){  
            return true;  
        }elseif(isset($_SERVER['SERVER_PORT']) && ('443' == $_SERVER['SERVER_PORT'] )) {  
            return true;  
        }  
        return false;  
    }

    /**
     * 基于ip流水防护
     */
    public static function getApiProtectByIP($tags = '', $second = 3, $reqNum = 30, $methods = ['PUT', 'POST', 'PATCH', 'DELETE']) {
        global $app;
        $ci = $app->getContainer();
        $config = $ci->get('settings')['website'];
        if(isset($config['antiBrush']) && $config['antiBrush'] === false )
            return true;
        $key = \Logic\Define\CacheKey::$perfix['protectByIP'].'_'.$tags.'_'.self::getIp();
        if (in_array($ci->request->getMethod(), $methods) && $ci->redis->incr($key) > $reqNum) {
            return $ci->lang->set(14);
        }
        $ci->redis->expire($key, $second);
        return $ci->lang->set(0);
    }

    /**
     * 基于用户级流水防护
     */
    public static function getApiProtectByUser($userId, $tags = '', $second = 3, $reqNum = 10, $methods = ['PUT', 'POST', 'PATCH', 'DELETE']) {
        global $app;
        $ci = $app->getContainer();
        $key = \Logic\Define\CacheKey::$perfix['protectByUser'].'_'.$tags.'_'.$userId;
        if (in_array($ci->request->getMethod(), $methods) && $ci->redis->incr($key) > $reqNum) {
            return $ci->lang->set(15);
        }
        $ci->redis->expire($key, $second);
        return $ci->lang->set(0);
    }
}