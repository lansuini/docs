<?php
/**
 * Created by PhpStorm.
 * User: tyleryang
 * Date: 2018/3/22
 * Time: 12:22
 */

namespace Model;

class AdminUser extends \Illuminate\Database\Eloquent\Model {

    protected $table = 'admin_user';

    public function getTruenameAttribute($value) {
        return empty($value) ? 'unknow' : $value;
    }

    public function getNickAttribute($value) {
        return empty($value) ? 'anonymity' : $value;
    }

}