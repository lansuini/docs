<?php

namespace Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MovieTemp extends \Illuminate\Database\Eloquent\Model {

    use SoftDeletes;
    /**
     * 需要被转换成日期的属性。
     *
     * @var array
     */

    protected $table = 'movie_temp';


    public $timestamps = false;

    /**
     * 需要被转换成日期的属性。
     *
     * @var array
     */
//    public static function boot() {
//
//        parent::boot();
//
//        static::creating(function ($obj) {
//            $ip = \Utils\Client::getIp();
//            $obj->ip = \DB::raw("inet6_aton('$ip')");
//            $obj->salt = self::getGenerateChar(6);
//            $obj->password = self::getPasword($obj->password, $obj->salt);
//        });

        // static::updating(function ($obj) {
        //     $obj->salt = self::getGenerateChar(6);
        //     $obj->password = md5(md5($obj->password) . $obj->salt);

        // });

        // static::observe(new \Model\Observer\UserObserver);
//    }



}

