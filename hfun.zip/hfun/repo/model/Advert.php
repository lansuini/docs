<?php

namespace Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Advert extends \Illuminate\Database\Eloquent\Model {

    use SoftDeletes;
    /**
     * 需要被转换成日期的属性。
     *
     * @var array
     */

    protected $table = 'advert';


    public $timestamps = false;

    /**
     * 需要被转换成日期的属性。
     *
     * @var array
     */
//    public static function boot() {
//
//        parent::boot();
//
//        static::creating(function ($obj) {
//            $ip = \Utils\Client::getIp();
//            $obj->ip = \DB::raw("inet6_aton('$ip')");
//            $obj->salt = self::getGenerateChar(6);
//            $obj->password = self::getPasword($obj->password, $obj->salt);
//        });

        // static::updating(function ($obj) {
        //     $obj->salt = self::getGenerateChar(6);
        //     $obj->password = md5(md5($obj->password) . $obj->salt);

        // });

        // static::observe(new \Model\Observer\UserObserver);
//    }

    /**
     *
     * @param
     *            生成随机字符串
     *
     * @return string|unknown
     */
    public static function getGenerateChar($length = 6, $chars = null) {
        // 密码字符集，可任意添加你需要的字符
        $chars = $chars ?? "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_ []{}<>~`+=,.;:?|";
        $password = "";
        for ($i = 0; $i < $length; $i++) {
            $password .= $chars[mt_rand(0, strlen($chars) - 1)];
        }

        return $password;
    }


}

