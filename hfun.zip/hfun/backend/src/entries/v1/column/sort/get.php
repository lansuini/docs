<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [
                'sort_type'=>'require|in:1,2,3'
            ],
            [],
            ['sort_type'=>'推荐类型']
        ))->paramsCheck('',$this->request,$this->response);


        $params = $this->request->getParams();

        $columns = DB::table('column_sort')->where('sort_type',$params['sort_type'])->orderBy('sort')->get()->toArray();

        return $this->lang->set(0,[],$columns);
    }
};
