<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Updated By: Jacky.Zhuo <zhuojiejie@funtsui.com>
 * Date: 2018/6/7
 * Time: 16:18
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken',
        'authorize',
    ];

    public function run()
    {
        //    id，state，sort
//            $upData = [
//                ['id'=>37,'type'=>1,'sort'=>1],
//                ['id'=>38,'type'=>1,'sort'=>2],
//                ['id'=>36,'type'=>1,'sort'=>3],
//            ];
        (new BaseValidate(
            [
                'sort_type' => 'require|in:1,2,3',
                'data' => 'require|array',
            ],
            [],
            []
        ))->paramsCheck('', $this->request, $this->response);
        $params = $this->request->getParams();

        try {
            DB::beginTransaction();

            DB::table('column_sort')->where('sort_type', $params['sort_type'])->delete();
            DB::table('column_sort')->insert($params['data']);

            DB::commit();
            return $this->lang->set(0);
        } catch (\Exception $e) {
            DB::rollback();
//            throw $e;
            return $this->lang->set(-2);
        }
    }
};