<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run()
    {
        (new BaseValidate(
            [
                'name'=>'require|max:250|unique:column,name',
                'des'=>'requireIf:type,2',
                'icon'=>'require|url',
                'cover'=>'requireIf:type,2|url',
                'type'=>'require|in:1,2',
//                'istop'=>'require|in:1,2',
//                'hot'=>'require|between:0,99',
                'sort'=>'requireIf:type,1|between:0,99',
                'display'=>'require|in:1,2',
//                'tag'=>'require|array',
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();
        $cover = $this->request->getParam('cover','');
        $des = $this->request->getParam('des','');
        $sort = $this->request->getParam('sort',99);
//        $tags = array_filter($params['tag']);
        $data = [];
        $data['name'] = $params['name'];
        $data['des'] = $des;
        $data['icon'] = $params['icon'];
        $data['cover'] = $cover;
        $data['type'] = $params['type'];
//        $data['istop'] = $params['istop'];
//        $data['hot'] = $params['hot'];
        $data['sort'] = $sort;
        $data['display'] = $params['display'];
//        $data['tag'] = implode(',',$tags);
//        try{
//            DB::beginTransaction();
//
//            $columnId = DB::table('column')->insertGetId($data);
//
//
//            if(!empty($tags)){
//                $tagData = [];
//                foreach ($tags as $tag){
//                    $tagInfo = DB::table('tag')->find($tag);
//                    if(!$tagInfo)
//                        continue;
//                    array_push($tagData,['column_id'=>$columnId,'tag_id'=>$tag]);
//
//                }
//                DB::table('column_tag')->insert($tagData);
//            }
//
//
//            DB::commit();
////            print_r(DB::getQueryLog());
//        }catch (\Exception $e){
////            print_r($performerData);
//            DB::rollback();
//            throw $e;
//            return $this->lang->set(-2);
//        }

        $res = DB::table('column')->insertGetId($data);
        if(!$res)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};