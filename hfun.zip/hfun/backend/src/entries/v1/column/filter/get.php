<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [
                'column_type'=>'require|in:1,2',
                'sort_type'=>'require|in:1,2,3'
            ],
            [],
            ['column_type'=>'栏目类型','sort_type'=>'推荐类型']
        ))->paramsCheck('',$this->request,$this->response);


        $params = $this->request->getParams();

        $query = DB::table('column as c')
            ->join('column_sort as cs',function($join) use ($params){
                $join->on('c.id','=','cs.id')
                    ->where('cs.sort_type','=',$params['sort_type']);
            }, null,null,'left')
            ->where('c.type','=',$params['column_type'])
            ->where('c.display','=',1)
            ->where('cs.id',null)
            ->select(['c.id','c.name','c.type','c.sort']);

        $columns = $query->orderByDesc('c.created')->get()->toArray();
        return $this->lang->set(0,[],$columns);
    }
};
