<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);

        $column = DB::table('column')->find($id);
        if(!$column)
            return $this->lang->set(61);

        try{
            DB::beginTransaction();

            DB::table('column')->where('id',$id)->delete();
            DB::table('column_tag')->where('column_id',$id)->delete();

            DB::commit();
        }catch (\Exception $e){
            DB::rollback();
            return $this->lang->set(-2);
        }

        return $this->lang->set(0);
    }
};