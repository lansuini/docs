<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);
        (new BaseValidate(
            [
                'name'=>'require|max:250|unique:column,name',
                'des'=>'requireIf:type,2',
                'icon'=>'require|url',
                'cover'=>'requireIf:type,2|url',
                'type'=>'require|in:1,2',
//                'istop'=>'require|in:1,2',
//                'hot'=>'require|between:0,99',
                'sort'=>'requireIf:type,1|between:0,99',
                'display'=>'require|in:1,2',
//                'tag'=>'require|array',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $column = DB::table('column')->find($id);
        if(!$column)
            return $this->lang->set(61);
        $params = $this->request->getParams();
        $cover = $this->request->getParam('cover','');
        $des = $this->request->getParam('des','');
        $sort = $this->request->getParam('sort',99);
//        $tags = array_filter($params['tag']);
        $data = [];
        if($column->name != $params['name']){
            $data['name'] = $params['name'];
            $res = DB::table('column_sort')->where('id',$id)->update(['name'=>$params['name']]);
        }
        $data['des'] = $des;
        $data['icon'] = $params['icon'];
        $data['cover'] = $cover;
        $data['type'] = $params['type'];
//        $data['istop'] = $params['istop'];
//        $data['hot'] = $params['hot'];
        $data['sort'] = $sort;
        $data['display'] = $params['display'];
//        $data['tag'] = implode(',',$tags);
//
        $res = DB::table('column')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};