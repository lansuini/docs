<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [
                'column_id'=>'require|number',
                'movie_ids'=>'array',
            ],
            [],
            ['column_id'=>'栏目','movie_id'=>'电影']
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();
        $data = [];
        foreach ($params['movie_ids'] as $movie_id){
            $movie = DB::table('column_movie')
                ->where('column_id',$params['column_id'])
                ->where('movie_id',$movie_id)
                ->first();
            if($movie){
                continue;
            }
            $movie = ['column_id'=>$params['column_id'],'movie_id'=>$movie_id];

            array_push($data,$movie);

        }
        if($data){
            $res = DB::table('column_movie')->insert($data);
            if(!$res)
                return $this->lang->set(-2);
            return $this->lang->set(0);
        }else{
            return $this->lang->set(0);
        }

    }
};
