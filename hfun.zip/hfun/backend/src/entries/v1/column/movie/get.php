<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = '')
    {
        $this->checkID($id);
        $params = $this->request->getParams();
        $query = DB::table('column_movie as cm')
            ->leftJoin('movie as m','cm.movie_id','=','m.id')
            ->where('cm.column_id',$id)
            ->select(['m.id','m.title','m.cover','cm.created']);

        $attributes['total'] = $query->count();
        $perfomers = $query->forPage($params['page'],$params['page_size'])->orderByDesc('cm.created')->get()->toArray();

        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        return $this->lang->set(0,[],$perfomers,$attributes);
    }
};
