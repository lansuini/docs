<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

//`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
//`status` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0',
//`display` TINYINT(3) UNSIGNED NOT NULL DEFAULT '1' COMMENT '1,展示，2隐藏',
//`title` VARCHAR(255) NULL DEFAULT NULL COMMENT '标题',
//`url` VARCHAR(500) NULL DEFAULT NULL COMMENT '影片地址',
//`des` TEXT NULL COMMENT '描述',
//`cover` VARCHAR(500) NULL DEFAULT NULL COMMENT '封面',
//`region` VARCHAR(250) NULL DEFAULT NULL COMMENT '制片地区',
//`views` BIGINT(20) NOT NULL DEFAULT '0' COMMENT '播放次数',
//`collection` BIGINT(20) NOT NULL DEFAULT '0' COMMENT '收藏',
//`download` BIGINT(20) NOT NULL DEFAULT '0' COMMENT '下载量',
//`like` BIGINT(20) NOT NULL DEFAULT '0' COMMENT '顶',
//`dislike` BIGINT(20) NOT NULL DEFAULT '0' COMMENT '踩',
//`sort` TINYINT(4) NOT NULL DEFAULT '0',
//`created` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
//`updated` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    public function run()
    {
        (new BaseValidate(
            [
                'title'=>'require|max:250',
                'des'=>'require',
                'cover'=>'require|url',
                'cover2'=>'require|url',
                'url'=>'require|url',
                'region'=>'require|integer',
                'sort'=>'between:0,99',
//                'display'=>'require|in:1,2',
                'status'=>'require|in:1,2,3',
                'performer'=>'array',
                'tag'=>'array',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();
        $performers = $this->request->getParam('performer',[]);
        $tags = $this->request->getParam('tag',[]);
        $sort = $this->request->getParam('sort',99);

        $performers = array_filter($performers);
        $tags = array_filter($tags);
        $data = [];
        $data['title'] = $params['title'];
        $data['des'] = $params['des'];
        $data['cover'] = $params['cover'];
        $data['cover2'] = $params['cover2'];
        $data['url'] = $params['url'];
        $data['region'] = $params['region'];
        $data['sort'] = $sort;
        $data['status'] = $params['status'];
        $data['performer'] = implode(',',$performers);
        $data['tag'] = implode(',',$tags);
        try{
            DB::beginTransaction();

            $movieId = DB::table('movie')->insertGetId($data);
            if(!empty($performers)){
                $performerData = [];
                foreach ($performers as $performer){
                    $performerInfo = DB::table('performer')->find($performer);
                    if(!$performerInfo)
                        continue;
                    array_push($performerData,['movie_id'=>$movieId,'performer_id'=>$performer]);

                }
                DB::table('performer_movie')->insert($performerData);
            }

            if(!empty($tags)){
                $tagData = [];
                foreach ($tags as $tag){
                    $tagInfo = DB::table('tag')->find($tag);
                    if(!$tagInfo)
                        continue;
                    array_push($tagData,['movie_id'=>$movieId,'tag_id'=>$tag]);

                }
                DB::table('movie_tag')->insert($tagData);
            }


            DB::commit();
//            print_r(DB::getQueryLog());
        }catch (\Exception $e){
//            print_r($performerData);
            DB::rollback();
            throw $e;
            return $this->lang->set(-2);
        }

        return $this->lang->set(0);
    }
};