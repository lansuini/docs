<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();

        $query = DB::table('region')
            ->forPage($params['page'],$params['page_size'])
            ->selectRaw('id,name,created');

        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $regions = $query->get()->toArray();

        return $this->lang->set(0,[],$regions,$attributes);
    }
};
