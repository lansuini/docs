<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];

    public function run($id = '')
    {
        $this->checkID($id);

        $region = DB::table('region')->find($id);
        if(!$region)
            return $this->lang->set(87);

        $movies = DB::table('movie')->where('region',$id)->first();

        if($movies)
            return $this->lang->set(88);

        $res = DB::table('region')->where('id',$id)->delete();

        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};