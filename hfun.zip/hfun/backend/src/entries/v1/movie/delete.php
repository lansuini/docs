<?php

use Logic\Admin\BaseController;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id='')
    {

        $this->checkID($id);
        $movie = DB::table('movie')->where('display',1)->find($id);
        if(!$movie)
            return $this->lang->set(10015);

        try{
            DB::beginTransaction();

            DB::table('movie')->where('id',$id)->update(['display'=>2]);
            DB::table('column_movie')->where('movie_id',$id)->delete();
            DB::table('movie_tag')->where('movie_id',$id)->update(['display'=>2]);

            DB::commit();
            return $this->lang->set(0);
        }catch (\Exception $e){
            DB::rollback();
            return $this->lang->set(-2);
        }

        return $this->lang->set(0);

    }
};
