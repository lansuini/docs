<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {

        (new BaseValidate([
            'tag'=>'number'
        ]))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getQueryParams();
        $query = DB::table('movie')
            ->leftJoin('region','movie.region','=','region.id')
            ->where('movie.display',1)
            ->selectRaw('t_movie.id,status,title,des,cover,region,t_region.name as region_name,cover,cover2,views,collection,download,size,duration,sort,url,t_movie.created')
            ;

        $query = isset($params['title']) && !empty($params['title']) ? $query->where('movie.title','like',"%".$params['title']."%") : $query;
        $query = isset($params['created_start']) && !empty($params['created_start']) ? $query->where('movie.created','>=',$params['created_start']) : $query;
        $query = isset($params['created_end']) && !empty($params['created_end']) ? $query->where('movie.created','<=',$params['created_end']) : $query;
//        $query = isset($params['status']) && !empty($params['status']) ? $query->where('movie.status','=',$params['status']) : $query;

        if(isset($params['status']) && $params['status'] == 3){
            $query = $query->where('movie.status',3);
        }elseif(isset($params['status']) && !empty($params['status'])){

            $query = $query->where('movie.status','=',$params['status']);
        }else{
            $query->where('movie.status','<>',3);
        }

        $query = isset($params['tag']) && !empty($params['tag']) ? $query->whereRaw("find_in_set({$params['tag']},tag)") : $query;
        $countQuery = clone $query;
        $attributes['total'] = $countQuery->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $movies = $query->forPage($params['page'],$params['page_size'])->orderByDesc('movie.created')->get()->toArray();
        foreach ($movies as $movie){
            $performers = DB::table('performer_movie as pm')
                ->leftJoin('performer','pm.performer_id','=','performer.id')
                ->where('pm.movie_id',$movie->id)
                ->selectRaw('t_performer.id,t_performer.name')
                ->get()->toArray();
            $movie->performers = empty($performers) ? [] : $performers ;

            $tags = DB::table('movie_tag as mt')
                ->leftJoin('tag','mt.tag_id','=','tag.id')
                ->where('mt.movie_id',$movie->id)
                ->selectRaw('t_tag.id,t_tag.name')
                ->get()->toArray();
            $movie->tags = empty($tags) ? [] : $tags ;
        }
        return $this->lang->set(0,[],$movies,$attributes);
    }
};
