<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();

        $query = DB::table('performer')

            ->selectRaw('id,sex,name,cup,bwh,height,des,avatar,sort,created');

        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $regions = $query->forPage($params['page'],$params['page_size'])->get()->toArray();

        return $this->lang->set(0,[],$regions,$attributes);
    }
};
