<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {

        (new BaseValidate(
            [
                'order'=>'in:views,movies'
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();

        $query = DB::table('performer as p')
            ->leftJoin('performer_sort as ps','p.id','=','ps.id')
            ->where('ps.id',null)
            ->select(['p.id','p.name','p.sort']);

        $query = isset($params['name']) && !empty($params['name']) ? $query->where('p.name','like',$params['name']) : $query;

        $query = isset($params['order']) && !empty($params['order']) ? $query->orderByDesc('p.'.$params['order']) : $query;

        $perfomers = $query->orderByDesc('p.created')->get()->toArray();

//        $attributes['total'] = $query->count();
//        $attributes['page'] = $params['page'];
//        $attributes['page_size'] = $params['page_size'];
//        return $this->lang->set(0,[],$perfomers,$attributes);
        return (array)$perfomers;
    }
};
