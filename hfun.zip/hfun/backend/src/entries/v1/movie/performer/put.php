<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run($id='')
    {
        $this->checkID($id);
        $performer = DB::table('performer')->find($id);
        if(!$performer)
            return $this->lang->set(87);
        (new BaseValidate(
            [
                'name'=>'require|max:50|unique:performer,name^id',
                'sex'=>'require|in:1,2',
                'cup'=>'require',
                'bwh'=>'require',
                'height'=>'require|number',
                'sort'=>'require|between:0,99',
                'des'=>'require|max:500',
                'avatar'=>'require|max:500',

            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();

        $data = [];
        $data['name'] = $params['name'];
        $data['sex'] = $params['sex'];
        $data['cup'] = $params['cup'];
        $data['bwh'] = $params['bwh'];
        $data['height'] = $params['height'];
        $data['des'] = $params['des'];
        $data['sort'] = $params['sort'];
        $data['avatar'] = $params['avatar'];

        $res = DB::table('performer')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};