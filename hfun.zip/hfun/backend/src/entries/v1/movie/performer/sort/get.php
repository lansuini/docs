<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {


        $perfomers = DB::table('performer_sort')
            ->selectRaw('id,name,sort')
            ->orderBy('sort')
            ->get()
            ->toArray();

        return (array)$perfomers;
    }
};
