<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;

use OSS\OssClient;
use OSS\Core\OssException;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run()
    {
        $params = $this->request->getParams();
//        print_r($params);exit;
        $callback_id = DB::table('movie_callback_log')->insertGetId(['params'=>json_encode($params)]);
        (new BaseValidate(
            [
//                'id'=>'require',
                'name'=>'require',
//                'url'=>'require',

            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();



        $data = [];
        $data['third_id'] = $params['name'];
        $tempMovie = DB::table('movie_temp')->where('third_id',$params['name'])->first();
        if(!$tempMovie){
            DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>'没有此电影']);
            die('没有此电影');
        }
        if($tempMovie->status == 1){
            DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>'电影已存在']);
            die('电影已存在');
        }
        $data['url'] = $tempMovie->url;
        $data['title'] = $tempMovie->name;
        $data['size'] = $tempMovie->size;
        $data['duration'] = $tempMovie->duration;
        $data['status'] = 3;
        try{
            DB::beginTransaction();

            DB::table('movie')->insert($data);
            DB::table('movie_temp')->where('third_id',$params['name'])->update(['status'=>1]);
            DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>'上传成功']);

            DB::commit();

            $this->chooseDomain();
            die('success');
            echo 'success';
        }catch (\Exception $e){

            DB::rollback();
//            throw $e;
            DB::table('movie_temp')->where('third_id',$params['name'])->update(['memo'=>'回调失败','status'=>3]);
            DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>'操作失败']);
            die('fail');
            return $this->lang->set(-2);
        }
        die('success');
        return $this->lang->set(0);
    }

    //给服务器正在上传的数量减一
    public function chooseDomain(){
        $ip = \Utils\Client::getIp();
        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];
        //测试地址
        if (RUNMODE == 'dev') {

            $test_movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['test_movie_domains'];
            $movie_domains = [
                [
                    'host'=>$test_movie_domains['host'],
                    'ip'=>$test_movie_domains['ip'],
                ],
                [
                    'host'=>$test_movie_domains['host'],
                    'ip'=>$test_movie_domains['ip'],
                ],
                [
                    'host'=>$test_movie_domains['host'],
                    'ip'=>$test_movie_domains['ip'],
                ]
            ];
        }
        foreach ($movie_domains as $k=>$movie_domain){
            if($ip==$movie_domain['ip']){
                $this->redis->hincrby(Logic\Define\CacheKey::$perfix['movieDomains'],$k,-1);
            }
        }
    }


};