<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;

use OSS\OssClient;
use OSS\Core\OssException;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run()
    {
        $params = $this->request->getParams();
//        print_r($params);exit;
        $callback_id = DB::table('movie_callback_log')->insertGetId(['params'=>json_encode($params)]);
        (new BaseValidate(
            [
//                'id'=>'require',
                'name'=>'require',
                'url'=>'require',

            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();

        $directory = $this->ci->get('settings')['upload_directory'];

        $data = [];
//        $data['third_id'] = $params['id'];
        $data['name'] = $params['name'];
        $data['url'] = $params['url'];
        $data['status'] = 3;

        $file = $directory.'/'.$params['name'].'.m3u8';

        try{
            $myfile = fopen($file, "w+");
            fwrite($myfile, $params['content']);
            fclose($myfile);
            $fileName = $this->getUploadName($file);

            $settings = $this->ci->get('settings')['upload'];
            $res = [];
            $temp = [
                'error'=>true,
                'error_msg'=>'未知原因',
                'url'=>'',
            ];
            foreach ($settings['dsn'] as $obj => $config) {

                $temp = $this->$obj($config, $file, $fileName);
//                var_dump($temp);

                if(empty($temp['error'])){
                    array_push($res,$temp);
//                    $res = $temp;
                }
            }
            if(!empty($res)){
                $data['url'] = $res[0]['url'];
                $data['location'] = $file;
                $res = DB::table('movie')->insert($data);
                DB::table('movie_temp')->where('third_id',$params['id'])->update(['location'=>$file,'url'=>$data['url'],'status'=>1]);
                DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>'上传成功','status'=>1]);
                return $this->lang->set(0);
            }else{
                //上传文件失败
                DB::table('movie_temp')->where('third_id',$params['id'])->update(['location'=>$file,'status'=>3]);
                DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>$temp['error_msg'],'status'=>3]);
                return $this->lang->set(-2);

            }

            return $this->lang->set(0);
        }catch(\Exception $e){
            DB::table('movie_callback_log')->where('id',$callback_id)->update(['response'=>'执行程序失败','status'=>3]);
            throw $e;
            return $this->lang->set(-2);
        }


        return $this->lang->set(0);
    }

    /**
     * 七牛上传
     * @param  [type] $config [description]
     * @param  [type] $file   [description]
     * @return [type]         [description]
     */
    protected function qiniu($config, $file, $fileName) {
        // 构建鉴权对象
        $auth = new Auth($config['accessKey'], $config['secretKey']);
        // 生成上传 Token
        $token = $auth->uploadToken($config['bucket']);
        $key = $config['dir'].'/'.$fileName;
        // 初始化 UploadManager 对象并进行文件的上传。
        $uploadMgr = new UploadManager();
        // 调用 UploadManager 的 putFile 方法进行文件的上传。
        list($ret, $err) = $uploadMgr->putFile($token, $key, $file);
        if ($err !== null) {
            return [
                'error'=>true,
                'error_msg'=>'qiniu:'.print_r($err, true),
                'url'=>'',
            ];
//            return $this->lang->set(15, [], [], ['error' => 'qiniu:'.print_r($err, true)]);
        } else {
            return [
                'error'=>false,
                'error_msg'=>'',
                'url'=>$config['domain'].'/'.$key,
            ];
        }
    }

    /**
     * 阿里云OSS上传
     * @param  [type] $config [description]
     * @return [type]         [description]
     */
    protected function oss($config, $file, $fileName) {
        try {
            $ossClient = new OssClient($config['accessKeyId'], $config['accessKeySecret'], $config['endpoint']);
        } catch (OssException $e) {
            return $this->lang->set(15, [], [], ['error' => 'oss":'.$e->getMessage()]);
        }

        try {
            $object = $config['dir'].'/'.$fileName;
            $content = file_get_contents($file);
            $ossClient->putObject($config['bucket'], $object, $content);
            return [
                'error'=>false,
                'error_msg'=>'',
                'url'=>$config['domain'].'/'.$object,
            ];
        } catch (OssException $e) {
            return [
                'error'=>true,
                'error_msg'=>'oss":'.$e->getMessage(),
                'url'=>'',
            ];
        }
    }

    /**
     * 取得上传后文件名称
     * @param  [type] $fileName [description]
     * @return [type]           [description]
     */
    protected function getUploadName($file) {
        $temp = explode('.', $file);
        $fileExt = strtolower(end($temp));
        return md5(time().mt_rand(0, 999999)).'.'.$fileExt;
    }

    /**
     * 移除临时文件
     * @param  [type] $file [description]
     * @return [type]       [description]
     */
    protected function remove($file) {
        @unlink($file['tmp_name']);
    }
};