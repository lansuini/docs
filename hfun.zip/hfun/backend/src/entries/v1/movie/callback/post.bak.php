<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run()
    {
        $params = $this->request->getParams();
        DB::table('movie_callback_log')->insert(['params'=>json_encode($params)]);
        (new BaseValidate(
            [
                'id'=>'require',
                'name'=>'require',
                'content'=>'require',

            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();

        $directory = $this->ci->get('settings')['upload_directory'];

        $data = [];
        $data['third_id'] = $params['id'];
        $data['name'] = $params['name'];
        $data['status'] = 3;

        $file = $directory.'/'.$params['name'].'.m3u8';

        try{
            $myfile = fopen($file, "w+");
            fwrite($myfile, $params['content']);
            fclose($myfile);
            $data['url'] = $file;
            $res = DB::table('movie')->insert($data);
        }catch(\Exception $e){

//            throw $e;
            return $this->lang->set(-2);
        }

        if(!$res)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};