<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Http\UploadedFile;
use \Psr\Http\Message\UploadedFileInterface;
return new class() extends BaseController
{

    public $options = OPENSSL_RAW_DATA;
    public $key = '9536205862353e299dd4db1add091772';
    public $cipher = 'AES-256-CBC';
    public $iv = '0473bdcf22c5c816';
    public function run(){

        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $cacheKey = Logic\Define\CacheKey::$perfix['movieDomains'];
        $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];

        //测试地址
        if (RUNMODE == 'dev') {

            $movie_domains = [
                [
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157',
                ],
                [
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157',
                ],
                [
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157',
                ]
            ];
        }

        if(!$this->redis->exists($cacheKey)){
//            $this->redis->del($cacheKey);
            foreach ($movie_domains as $k=>$movie_domain){
                $this->redis->hset($cacheKey,$k,0);
            }
        }
        $data = $this->redis->hgetall($cacheKey);
//        print_r($data);
        $minvalue = min($data);
        $minkey = array_search($minvalue,$data);
//        print_r($movie_domains[$minkey]);
//        $this->redis->hincrby($cacheKey,$minkey,1);

        return $this->lang->set(0,[],['domain' => $movie_domains[$minkey]['host']]);
//        $data = $this->redis->hgetall($cacheKey);
//        print_r($data);

    }


};