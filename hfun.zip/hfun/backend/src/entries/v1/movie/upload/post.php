<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run()
    {

        (new BaseValidate(
            [
                'id'=>'require|unique:movie_temp,third_id',
                'size'=>'require',
                'url'=>'require|url',
                'duration'=>'require',
                'name'=>'require|max:250',
                'domain'=>'require|max:250',

            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();

        $data = [];
        $data['third_id'] = $params['id'];
        $data['name'] = $params['name'];
        $data['url'] = $params['url'];
        $data['size'] = $params['size'];
        $data['duration'] = $params['duration'];
        $data['upload_host'] = $params['domain'];

        $res = DB::table('movie_temp')->insert($data);
        if(!$res)
            return $this->lang->set(-2);

        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $cacheKey = Logic\Define\CacheKey::$perfix['movieDomains'];
        $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];

        //测试地址
        if (RUNMODE == 'dev') {

            $movie_domains = [
                [
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157',
                ],
                [
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157',
                ],
                [
                    'host'=>'https://www-api.zyupload.com',
                    'ip'=>'23.98.36.157',
                ]
            ];
        }
        if(!$this->redis->exists($cacheKey)){
            foreach ($movie_domains as $k=>$movie_domain){
                $this->redis->hset($cacheKey,$k,0);
            }
        }

        foreach ($movie_domains as $key => $movie_domain){
            if($params['domain'] == $movie_domain['host']){

                $this->redis->hincrby($cacheKey,$key,1);
            }

        }

        return $this->lang->set(0);
    }
};