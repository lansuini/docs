<?php

use Logic\Admin\BaseController;
use Model\MovieTemp;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id='')
    {

        $this->checkID($id);
        $movie = MovieTemp::find($id);
        if(!$movie)
            return $this->lang->set(10015);

        $res = MovieTemp::where('id',$id)->delete();
        if(!$res)
            return $this->lang->set(-2);
        return $this->lang->set(0);

    }
};
