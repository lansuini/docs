<?php

use Logic\Admin\BaseController;
use Model\MovieTemp;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [

                'third_id'=>'require|max:250',

            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $tempMovie = DB::table('movie_temp')->where('third_id',$params['third_id'])->first();
        if(!$tempMovie){
            return $this->lang->set(11002);
        }
        if($tempMovie->status == 1){
            return $this->lang->set(11003);
        }

        try{
            $exists = DB::table('movie')->where('third_name',$params['third_id'])->first();
            if($exists){
                DB::table('movie_temp')->where('third_id',$params['third_id'])->update(['status'=>1]);
            }
            $url = $tempMovie->upload_host . '/result';
//            $uploadMovieSetting = $this->ci->get('settings')['movie_upload'];
//            $url = isset($uploadMovieSetting['third_query_url']) ? $uploadMovieSetting['third_query_url'] : $url;
            $queryParams['file_name'] = $params['third_id'];
            $res = Utils\Curl::get($url . '?' . http_build_query($queryParams));
            $result = json_decode($res,true);
            if($result['state'] === 0){
                $key = \Logic\Set\SetConfig::SET_GLOBAL;
                $cacheKey = Logic\Define\CacheKey::$perfix['movieDomains'];
                $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];
                //测试地址
                if (RUNMODE == 'dev') {
                    $test_movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['test_movie_domains'];
                    $movie_domains = [
                        [
                            'host'=>$test_movie_domains['host'],
                            'ip'=>$test_movie_domains['ip'],
                        ],
                        [
                            'host'=>$test_movie_domains['host'],
                            'ip'=>$test_movie_domains['ip'],
                        ],
                        [
                            'host'=>$test_movie_domains['host'],
                            'ip'=>$test_movie_domains['ip'],
                        ]
                    ];
                }

                foreach ($movie_domains as $k=>$movie_domain){
                    if($url == $movie_domain['host']){
                        $this->redis->hincrby($cacheKey,$k,-1);
                    }
                }

                $data['url'] = $tempMovie->url;
                $data['title'] = $tempMovie->name;
                $data['third_id'] = $params['third_id'];
                $data['status'] = 3;
                $data['size'] = $tempMovie->size;
                $data['duration'] = $tempMovie->duration;
                DB::table('movie_temp')->where('third_id',$params['third_id'])->update(['status'=>1]);
                DB::table('movie')->insert($data);
            }elseif($result['state'] === 20){
                return $this->lang->set(11004);
            }else{
                return $this->lang->set(11005, [$res]);
            }

        }catch (\Exception $e){

            return $this->lang->set(10001, $e->getMessage());
        }


    }
};
