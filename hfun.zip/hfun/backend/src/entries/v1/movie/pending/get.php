<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();

        $query = DB::table('movie')
            ->where('status',3)
            ->leftJoin('region','moive.region','=','region.id')
            ->forPage($params['page'],$params['page_size'])
            ->selectRaw('id,title,url,des,cover,cover2,region,region.name as region_name');

        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $levels = $query->get()->toArray();

        return $this->lang->set(0,[],$levels,$attributes);
    }
};
