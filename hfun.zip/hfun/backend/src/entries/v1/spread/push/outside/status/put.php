<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
//use lib\service\Allies;
use lib\service\push\Umeng;
return new class() extends BaseController
{
    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = '')
    {

        $this->checkID($id);
        $push = DB::table('push_outside')->where('status', 1)->where('id',$id)->lockForUpdate()->first();
        if (!$push)
            return $this->lang->set(10015);
        $pv = DB::table('advert_group')->find($push->pv);

        $push_setting = $this->ci->get('settings')['push'][$pv->channel];
        // Set your appkey and master secret here
        switch ($push->platform) {

            case 1:

                try{
                    $options['app_key'] = $push_setting['android']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['android']['app_master_secret']; //友盟MasterSecret
                    $this->sendCast('Android',$push,$options);

                    $options['app_key'] = $push_setting['ios']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['ios']['app_master_secret']; //友盟MasterSecret
                    $this->sendCast('IOS',$push,$options);
                    DB::table('push_outside')->where('id',$id)->update(['status'=>2,'push_time'=>date('Y-m-d H:i:s')]);
                }catch (\Exception $e){
                    return $this->lang->set(10013, [$e->getMessage()]);
                }
                break;
            case 2:

                try{

                    $options['app_key'] = $push_setting['ios']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['ios']['app_master_secret']; //友盟MasterSecret
                    $this->sendCast('IOS',$push,$options);

                    DB::table('push_outside')->where('id',$id)->update(['status'=>2,'push_time'=>date('Y-m-d H:i:s')]);
                }catch (\Exception $e){
                    return $this->lang->set(10013, [$e->getMessage()]);
                }
                break;
            case 3:
                try{

                    $options['app_key'] = $push_setting['android']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['android']['app_master_secret']; //友盟MasterSecret
                    $this->sendCast('Android',$push,$options);
                    DB::table('push_outside')->where('id',$id)->update(['status'=>2,'push_time'=>date('Y-m-d H:i:s')]);

                }catch (\Exception $e){
                    return $this->lang->set(10013, [$e->getMessage()]);
                }
                break;
            default:
                try{
                    $options['app_key'] = $push_setting['android']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['android']['app_master_secret']; //友盟MasterSecret
                    $this->sendCast('Android',$push,$options);
//                    $android_push = new Umeng($options['app_key'], $options['appMasterSecret']);
//                    $android_push->sendAndroidBroadcast($push);

                    $options['app_key'] = $push_setting['ios']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['ios']['app_master_secret']; //友盟MasterSecret
                    $this->sendCast('IOS',$push,$options);
//                    $ios_push = new Umeng($options['app_key'], $options['appMasterSecret']);
//                    $ios_push->sendIOSBroadcast($push);
                    DB::table('push_outside')->where('id',$id)->update(['status'=>2,'push_time'=>date('Y-m-d H:i:s')]);
                }catch (\Exception $e){
                    return $this->lang->set(10013, [$e->getMessage()]);
                }
                break;

        }

        return $this->lang->set(0);

    }

    public function sendCast($platform,$push,$options){


        $umeng = new Umeng($options['app_key'], $options['appMasterSecret']);
        if($push->send_type == 1){

            if($push->send_obj == 1){
                $fund = 'send'.$platform.'Broadcast';
                $umeng->$fund($push);
            }
        }else{
            $fund = 'send'.$platform.'Groupcast';
            $umeng->$fund($push);
        }


    }

};