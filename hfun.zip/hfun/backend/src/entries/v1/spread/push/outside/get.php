<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{
    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        $send_type1 = [1=>'全部',2=>'注册用户',3=>'游客'];

        $params = $this->request->getParams();

        $query = DB::table('push_outside as ps')
            ->leftJoin('advert_group as g','ps.pv' ,'=','g.id')
            ->leftJoin('admin_user as au','ps.creator','=','au.id');

        $attributes['total'] = $query->count();

        $pushs = $query->forPage($params['page'],$params['page_size'])
            ->orderByDesc('ps.created')
            ->get(['ps.id','ps.batch_num','ps.status','ps.platform','ps.pv','g.channel as pv_name','au.username as creaetor','ps.send_type','ps.send_obj','ps.link_type','ps.link','ps.link_name','ps.created','ps.push_time','ps.content'])
            ->toArray();


        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];

        foreach ($pushs as $push){

            $push->send_type_name = $push->send_type == 1 ? '用户类型' : '用户层级';

            $push->send_obj_name =  $push->send_type == 1 ?  $send_type1[$push->send_obj] : 'lv'.($push->send_obj - 1);
        }

        return $this->lang->set(0,[],$pushs,$attributes);

    }


};