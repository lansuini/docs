<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{
    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = '')
    {

        $this->checkID($id);
        $push = DB::table('push_outside')->where('status','<>',2)->find($id);
        if(!$push){
            return $this->lang->set(10015);
        }


        $res = DB::table('push_outside')->where('id',$id)->delete();
        if(!$res)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }


};