<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{
    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = '')
    {

        $this->checkID($id);
        (new BaseValidate(
            [
                'platform' => 'require|in:1,2,3',
                'pv' => 'require',
                'link_type' => 'require|in:1,2,3,4,5,6,7',//1，首页，2，频道，3，发现，4，我的，5，专题，6，栏目，7，电影
                'link' => 'requireIf:link_type,5,6,7',
                'send_type' => 'require|in:1,2',
                'send_obj' => 'require|number',
                'content' => 'require|max:100',
            ],
            [],
            ['platform' => '手机系统', 'pv' => '包平台', 'link_type' => '跳转类型', 'link' => '跳转位置', 'send_type' => '发送类型', 'send_obj' => '发送对象', 'content' => '发送内容']
        ))->paramsCheck('', $this->request, $this->response);

        $params = $this->request->getParams();

        $data['batch_num'] = date('YmdHi');
        $data['platform'] = $params['platform'];
        $data['pv'] = $params['pv'];
        $data['link_type'] = $params['link_type'];
        $data['link'] = $params['link'];
        $data['link_name'] = $params['link_name'];
        $data['send_type'] = $params['send_type'];
        $data['send_obj'] = $params['send_obj'];
        $data['content'] = $params['content'];

        $res = DB::table('push_outside')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }


};