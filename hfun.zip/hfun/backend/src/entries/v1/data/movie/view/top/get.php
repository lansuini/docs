<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '影片播放每日top10';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){


        $subQuery = DB::table('user_view')
            ->selectRaw('count(movie_id) as num,movie_id')
            ->where('created','>',date('Y-m-d'))
            ->groupBy('movie_id')
            ->orderByDesc('num')
            ->limit(10);

        $top_movies = DB::table( DB::raw("({$subQuery
            
            ->toSql()}) as t_v"))
            ->mergeBindings($subQuery)
            ->leftJoin('movie as m','v.movie_id','=','m.id')
            ->select(['id','title','num'])
            ->get()->toArray()
        ;

        return (array)$top_movies;

    }
};