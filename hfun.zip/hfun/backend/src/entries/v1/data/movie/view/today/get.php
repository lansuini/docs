<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '今日影片播放次数';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){


        $count = DB::table('user_view')->where('created','>',date('Y-m-d'))->count();

        return $this->lang->set(0,[],['count'=>$count]);

    }
};