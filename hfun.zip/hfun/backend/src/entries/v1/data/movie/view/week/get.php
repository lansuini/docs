<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '7日观影数量';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        $time_end = date('Y-m-d');
        $time_start = date('Y-m-d',strtotime('-6 day'));

        $res = DB::table('rpt_viewing_day')
            ->where('count_date','>=',$time_start)
            ->where('count_date','<=',$time_end)
            ->selectRaw('count_date as date,sum(viewing_cnt) as count')
            ->groupBy('count_date')
            ->orderBy('count_date')
            ->get()->toArray();

        return (array)$res;
    }
};