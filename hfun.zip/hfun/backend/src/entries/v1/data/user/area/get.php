<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '会员地区分布';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        $res = DB::table('user_area')->orderBy('num')->get(['province as name','num as value'])->toArray();

        return (array)$res;

    }
};