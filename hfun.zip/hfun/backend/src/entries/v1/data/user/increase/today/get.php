<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '今日新增用户';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        $time_start = date('Y-m-d');
        $time_end = date('Y-m-d').' 23:59:59';

        $count = DB::table('user')->where('created','>=',$time_start)->where('created','<=',$time_end)->count();

        return $this->lang->set(0,[],['count'=>$count]);
    }
};