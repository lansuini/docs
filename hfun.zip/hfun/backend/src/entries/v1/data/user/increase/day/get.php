<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '新增用户';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        (new \lib\validate\BaseValidate(
            [
                'type'=>'require|in:1,2'
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $time_start = $this->request->getParam('time_start',date('Y-m-d'));
        $time_end = $this->request->getParam('time_end',date('Y-m-d').' 23:59:59');

        $params = $this->request->getParams();
        if($params['type'] == 1){

            $table = 'rpt_user_day';

        }else{

            $table = 'rpt_user_day';
        }
        $query = DB::table("$table")
            ->where('count_date','>=',$time_start)
            ->where('count_date','<=',$time_end);

        $query = isset($params['platform']) ? $query->where('platform',$params['platform']) : $query ;

        $result = $query
            ->selectRaw('count_date as date,new_register_cnt,cumula_register_cnt,android_new_register_cnt,android_cumula_register_cnt,ios_new_register_cnt,ios_cumula_register_cnt')
            ->get()->toArray();

        return $this->lang->set(0,[],$result);
    }
};