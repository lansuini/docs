<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '7天新增用户';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        $time_start = $this->request->getParam('time_start',date('Y-m-d',strtotime('-7 day')));
        $time_end = $this->request->getParam('time_end',date('Y-m-d').' 23:59:59');

        $ios_users = DB::table('user')
            ->where('created','>=',$time_start)
            ->where('created','<=',$time_end)
            ->where('device_type','ios')
            ->count();
        $android_users = DB::table('user')
            ->where('created','>=',$time_start)
            ->where('created','<=',$time_end)
            ->where('device_type','android')
            ->count();
        return $this->lang->set(0,[],['ios'=>$ios_users,'android'=>$android_users]);
    }
};