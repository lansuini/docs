<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;
return new class() extends BaseController
{
    const TITLE = '今日新增用户';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        $now = time();
        $count = $this->redis->zcount(\Logic\Define\CacheKey::$perfix['onlineUsers'],$now - 600,$now);

        return $this->lang->set(0,[],['count'=>$count]);
    }
};