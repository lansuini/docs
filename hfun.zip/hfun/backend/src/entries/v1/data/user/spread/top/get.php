<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{
    const TITLE = '用户推广每日top10';

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){



        $subQuery = DB::table('user')
            ->where('created','>',date('Y-m-d'))
            ->where('pid','<>','')
            ->selectRaw('pid,count(id) as num')
            ->groupBy('pid')
            ->orderByDesc('num')
            ->limit(10);

        $top_users = DB::table( DB::raw("({$subQuery
            
            ->toSql()}) as t_v"))
            ->mergeBindings($subQuery)
            ->leftJoin('user as u','v.pid','=','u.id')
            ->select(['id','name','num'])
            ->get()->toArray()
        ;

        return (array)$top_users;

    }
};