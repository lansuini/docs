<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Http\UploadedFile;
use \Psr\Http\Message\UploadedFileInterface;
use Grafika\Grafika;
use lib\service\Allies;
return new class() extends BaseController
{

    public function run(){





        echo 421;exit;
        $this->test();exit;


//        $directory = $this->ci->get('settings')['upload_directory'];
//        $file = 'D:\myserver\root\hfun\config/uploads/avatar.png';
//        print_r($this->upload_im_img($file,'png'));exit;
//        $file1 = 'D:\myserver\root\hfun\config/uploads/avatar';
//        $file2 = 'D:\myserver\root\hfun\config/uploads/yanying.jpg';
//        $file3 = 'D:\myserver\root\hfun\config/uploads/yanying2.jpg';
//        echo md5_file($file);
//        echo "<pre/>";
//        echo md5_file($file1);
//        exit;
//        $editor = Grafika::createEditor();
//        $editor->open($image , $file2); // 打开yanying.jpg并且存放到$image1
//
//        $filter = Grafika::createFilter('Sharpen',50);
//        $editor->apply( $image, $filter );
//        $editor->save($image,$directory.'/yanying3.jpg');
//        exit;
//
//        $filter = Grafika::createFilter('Pixelate',10);
//        $editor->apply( $image, $filter );
//        $editor->save($image,$directory.'333/yanying-Pixelate-10.jpg');
//        exit;
//
//        $editor->resizeFit($image1 , 200 , 200);
//        $editor->save($image1 , $directory.'/yanying1.jpg');
//
//        $editor->open($image2 , $file); // 打开yanying.jpg并且存放到$image2
//        $editor->resizeFit($image2 , 200 , 200);
//        $editor->save($image2 , 'yanying2.jpg');
//
//
//        exit;
        $directory = $this->ci->get('settings')['upload_directory'];

        $uploadedFiles = $this->request->getUploadedFiles();
        if(!isset($uploadedFiles['file']) && empty($uploadedFiles['file'])){
            return $this->lang->set(10100);
        }

        $uploadedFile = $uploadedFiles['file'];
        $allowedExts = array("m3u8");

        if ($uploadedFile->getError() === UPLOAD_ERR_OK) {

            $temp = explode(".", $uploadedFile->getClientFilename());
            $extension = end($temp);     // 获取文件后缀名
//            if(!in_array($extension,$allowedExts)){
//                return $this->lang->set(10102);
//            }
            $filename = $this->moveUploadedFile($directory, $uploadedFile);
            $data['filename'] = $filename;
//            return $data;
            $this->response->write('uploaded ' . $filename . '<br/>');
        }else{
            return $this->lang->set(10101,[$uploadedFile->getError()]);
        }

//        foreach ($uploadedFiles['example1'] as $uploadedFile) {
//            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
//                $filename = $this->moveUploadedFile($directory, $uploadedFile);
//                $this->response->write('uploaded ' . $filename . '<br/>');
//            }
//        }


//        // handle multiple inputs with the same key
//        foreach ($uploadedFiles['example2'] as $uploadedFile) {
//            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
//                $filename = moveUploadedFile($directory, $uploadedFile);
//                $this->response->write('uploaded ' . $filename . '<br/>');
//            }
//        }
//
//        // handle single input with multiple file uploads
//        foreach ($uploadedFiles['example3'] as $uploadedFile) {
//            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
//                $filename = $this->moveUploadedFile($directory, $uploadedFile);
//                $this->response->write('uploaded ' . $filename . '<br/>');
//            }
//        }

        }

        public function test(){


        //使用类
        $options['app_key'] = '5c10738cb465f5c7a1000663'; //友盟key;
        $options['appMasterSecret'] = 'g35mdplz1c0ntuspl5deaj4sroavssoe'; //友盟MasterSecret

        $this->umeng = new Allies($options);

        $info['ticker'] = '';
        $info['prod_id'] ='';
        $info['title'] ='hulala'; //广播通知不能为空补填
        $info['type'] = 4;  //附加字段类型1 跳转消息详情
        $info['text'] = '提醒'; //
        $info['production_mode'] = 'false';

//        $value=$this->umeng->Android_Device_Push($info, $token);  //单播传入数据和用户token

//        $value = $this->umeng->Android_Broadcast($info);  //广播直接传入数据
        $value = $this->umeng->Ios_Broadcast($info);  //广播直接传入数据
        var_dump($value);exit;

        }

        /**
         * Moves the uploaded file to the upload directory and assigns it a unique name
         * to avoid overwriting an existing uploaded file.
         *
         * @param string $directory directory to which the file is moved
         * @param UploadedFile $uploaded file uploaded file to move
         * @return string filename of moved file
         */
        public function moveUploadedFile($directory, UploadedFile $uploadedFile)
        {
            $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
            $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
            $filename = sprintf('%s.%0.8s', $basename, $extension);
//            $filename = $uploadedFile->getClientFilename();

            $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);

            return $filename;
        }

    /**
     * 图片上传
     * @author Dong
     * @date   2018-04-08
     * @param  [type]     $url  文件路径
     * @param  [type]     $type 文件类型
     */
    function upload_im_img($url,$type)
    {
        // 二进制文件上传
        $file = file_get_contents($url);
        $filename = 'Filedata';//上传到$_FILES数组中的 key
        $name = uniqid('', true) . '.' . $type;//文件名
        $type = 'image/jpeg';//文件类型

        $key = "$filename\"; filename=\"$name\r\nContent-Type: $type\r\n";
        $fields[$key] = $file;
        //将图片上传到七牛返回图片路径
        $ch = curl_init();
        $url = 'https://res2.icriw.com';
//        curl_setopt($ch, CURLOPT_SAFE_UPLOAD, false);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $filename = curl_exec($ch);
        //$filename = substr($filename,3);//进行截取
        return $name;
    }
};