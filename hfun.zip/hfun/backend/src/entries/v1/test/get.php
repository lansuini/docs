<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use Slim\Http\UploadedFile;
use \Psr\Http\Message\UploadedFileInterface;
use Psr\Http\Message\ServerRequestInterface;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ClientException ;
return new class() extends BaseController
{

    public function run($day = 1){

//        echo md5('04251669-C3D6-48F3-9D05-5EB27754B362');exit;
        $date = date('Y-m-d',strtotime("-$day day"));
        $bitmap = 'user_active:'.$date;
        echo $this->redis->bitcount($bitmap);exit;

        $ip = $_SERVER['REMOTE_ADDR'];
        $ip = '47.52.61.245';
        $logSetting = $this->ci->get('settings')['log'];
        $log = $logSetting['path'] . 'request.log';
        $client = new Client();
        try{
            $result = $client->request('GET', 'http://ip.taobao.com/service/getIpInfo.php?ip='.$ip, [
                'timeout'  =>  3.14 ,
            ]);
            $region = '';
            if($result->getStatusCode() == 200){
                $res= (json_decode($result->getBody(),true));
                if($res['code'] === 0){
                    $region = $res['data']['region'];
                }
            }
            file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . $result->getStatusCode() . " ip:".$ip . "\n" . $result->getBody() . "\n\n", FILE_APPEND);

            return $region;
        }catch (\Exception $e){
            if($e instanceof ClientException){
                $response = $e->hasResponse() ? $e->getResponse() : '';
                file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . '请求异常：' . " ip:".$ip . "\n" . $e->getRequest() . '\n'.$response."\n\n", FILE_APPEND);
            }else{
                $this->logger->error('frontend', $e->getMessage());
//                throw $e;
            }
            return '';
        }


exit;
        print_r($res);exit;



        exit;


        echo md5('530AA0E6-BB2C-43F6-A450-1907A36C3FDC');
//        $userLogic = new \Logic\Crontab\User($this->ci);
//
//        $userLogic->updateUserActive(['user_id'=>1,'device_type'=>'ios']);
        exit;


        $movies = DB::table('movie1')->where('id','<=',454)->where('id','>=',405)->selectRaw('title,cover,cover2,performer,tag,url,tmp_views,rating')->get()->toArray();
        $datas = [];
        foreach ($movies as $k => $movie) {
            try{
                if($movie->performer){
                    $performers = explode(',', $movie->performer);
                    $performers = array_filter($performers);
                    $performer_ids = [];
                    foreach ($performers as $performer) {

                        $performer_info = DB::table('performer')->where('name', $performer)->first();
                        if (!$performer_info) {
                            $performer_id = DB::table('performer')->insertGetId(['name' => $performer]);
                        } else {
                            $performer_id = $performer_info->id;
                        }
                        if( !in_array($performer_id,$performer_ids)){
                            array_push($performer_ids, $performer_id);
                        }
                    }

                    $movie->performer = implode(',', $performer_ids);
                }

                if($movie->tag){
                    $tags = explode(',', $movie->tag);
                    $tags = array_filter($tags);
                    $tag_ids = [];
                    foreach ($tags as $tag) {
                        $tag_info = DB::table('tag')->where('name', $tag)->first();
                        if (!$tag_info) {
                            $tag_id = DB::table('tag')->insertGetId(['name' => $tag]);
                        } else {
                            $tag_id = $tag_info->id;
                        }
                        if(!in_array($tag_id,$tag_ids)){
                            array_push($tag_ids, $tag_id);
                        }
                    }

                    $movie->tag = implode(',', $tag_ids);
                }

                array_push($datas,(array)$movie);
            }catch (\Exception $e){
                print_r($movie);
            }

//            break;
        }
        DB::table('movie')->insert($datas);
        exit;

        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $cacheKey = Logic\Define\CacheKey::$perfix['movieDomains'];

        $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];
        print_r($movie_domains);exit;

        $collection = $this->mongodb->selectCollection('startup_log');
        $query = [];

        $options = [];

// 读取一条数据
        $data = $collection->find($query, $options);
        foreach ($data as $one){
            var_dump($one);
        }
        exit;

        $manager = new MongoDB\Driver\Manager("mongodb://23.98.36.157:27017");
        $collection = new MongoDB\Collection($manager, "local",'startup_log');
        // 插入一条数据
//        $data = array('user_id' => 2, 'movie_id' => 1, 'type' => 1,'created'=>time());
//        $collection->insertOne($data);
        // 修改一条数据
//        $collection->updateOne(array('user_id' => 1,'movie_id'=>2), array('$set' => array('user_id' => 1,'movie_id'=>2)));

        $query = [];

        $options = [];

// 读取一条数据
        $data = $collection->find($query, $options);
        foreach ($data as $one){
            var_dump($one);
        }
        exit;
        print_r($data);exit;

        $client = new \MongoDB\Client("mongodb://127.0.0.1:21707}");
        $db = $client->selectDatabase('local');

        $collection = $this->mongodb->selectCollection('movie_rating');
//        print_r($collection);exit;
        $data = $collection->find();
        print_r($data);exit;
        $query = [];

        $options = [];

        $cursor = $collection->find($query, $options);
        foreach ($cursor as $document) {
            echo $document['_id'] . "\n";
        }
        print_r($cursor);exit;

        \Logic\Movie\Upload::checkUploadMovies();exit;

        $host = 'https://gcc.hg-vdplay.com/img';

        $data = '{"code":0,"count":199,"data":[{"id":15636,"nameCn":"横山美雪","nameEn":"Miyuki Yokoyama","nameJpn":"横山美雪","photoUrl":"/nvyou_img/yokoyama_miyuki2.jpg"},{"id":19367,"nameCn":"冲田杏梨","nameEn":"","nameJpn":"沖田杏梨","photoUrl":"/nvyou_img/okita_anri.jpg"},{"id":24500,"nameCn":"长泽梓","nameEn":"","nameJpn":"长泽梓","photoUrl":"/52/abffd214c281ac0caadfdf8ea02d75a9.jpg"},{"id":4098,"nameCn":"希志爱野","nameEn":"Aino Kishi","nameJpn":"希志あいの","photoUrl":"/nvyou_img/kisi_aino.jpg"},{"id":27949,"nameCn":"石原莉奈","nameEn":"Rina Ishihara","nameJpn":"石原莉奈","photoUrl":"/nvyou_img/isihara_rina.jpg"},{"id":9197,"nameCn":"辻本杏","nameEn":"An Tsujimoto","nameJpn":"辻本杏","photoUrl":"/nvyou_img/tuzimoto_an.jpg"},{"id":24406,"nameCn":"小川阿佐美","nameEn":"Ogawa Asami","nameJpn":"小川あさ美","photoUrl":"/nvyou_img/ogawa_asami2.jpg"},{"id":10824,"nameCn":"雪菜","nameEn":"","nameJpn":"雪菜","photoUrl":"/nvyou_img/yukina.jpg"},{"id":7852,"nameCn":"柚月向日葵","nameEn":"","nameJpn":"柚月ひまわり","photoUrl":"/nvyou_img/yuzuki_himawari.jpg"},{"id":13146,"nameCn":"成濑心美","nameEn":"Cocomi Naruse","nameJpn":"成瀬心美","photoUrl":"/nvyou_img/naruse_kokomi.jpg"},{"id":5019,"nameCn":"星野娜美","nameEn":"Hoshino Nami","nameJpn":"星野ナミ","photoUrl":"/nvyou_img/hosino_nami.jpg"},{"id":5341,"nameCn":"星美梨香","nameEn":"Hoshimi Rika","nameJpn":"星美りか","photoUrl":"/nvyou_img/hosimi_rika.jpg"},{"id":19337,"nameCn":"奥田咲","nameEn":"Saki Okuda","nameJpn":"奥田咲","photoUrl":"/nvyou_img/okuda_saki.jpg"},{"id":13092,"nameCn":"大槻响","nameEn":"Hibiki Otsuki","nameJpn":"大槻ひびき","photoUrl":"/nvyou_img/ootuki_hibiki.jpg"},{"id":14754,"nameCn":"羽月希","nameEn":"","nameJpn":"羽月希","photoUrl":"/nvyou_img/haduki_nozomi.jpg"}],"enumCode":"SUCCESS","msg":"15","pageCount":14,"pageNo":2,"pageSize":15,"success":true}';

        $data = json_decode($data,true);

        $performers = [];
        foreach($data['data'] as $performer){
            $one = [
                'name'=>$performer['nameCn'],
                'name_en'=>$performer['nameEn'],
                'name_jpn'=>$performer['nameJpn'],
                'avatar'=>$host.$performer['photoUrl']
            ];
            array_push($performers,$one);
        }
        DB::table('performer')->insert($performers);
        exit;

        echo 666;
        $this->redis->setex('test',600,32123);
        echo $this->redis->get('test');
        $res = DB::table('column')->get()->toArray();
        print_r($res);exit;
        
        $directory = $this->ci->get('settings')['upload_directory'];

        $uploadedFiles = $this->request->getUploadedFiles();
        if(!isset($uploadedFiles['file']) && empty($uploadedFiles['file'])){
            return $this->lang->set(10100);
        }

        $uploadedFile = $uploadedFiles['file'];
        $allowedExts = array("m3u8");

        if ($uploadedFile->getError() === UPLOAD_ERR_OK) {

            $temp = explode(".", $uploadedFile->getClientFilename());
            $extension = end($temp);     // 获取文件后缀名
//            if(!in_array($extension,$allowedExts)){
//                return $this->lang->set(10102);
//            }
            $filename = $this->moveUploadedFile($directory, $uploadedFile);
            $data['filename'] = $filename;
            return $data;
            $this->response->write('uploaded ' . $filename . '<br/>');
        }else{
            return $this->lang->set(10101,[$uploadedFile->getError()]);
        }

//        foreach ($uploadedFiles['example1'] as $uploadedFile) {
//            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
//                $filename = $this->moveUploadedFile($directory, $uploadedFile);
//                $this->response->write('uploaded ' . $filename . '<br/>');
//            }
//        }


//        // handle multiple inputs with the same key
//        foreach ($uploadedFiles['example2'] as $uploadedFile) {
//            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
//                $filename = moveUploadedFile($directory, $uploadedFile);
//                $this->response->write('uploaded ' . $filename . '<br/>');
//            }
//        }
//
//        // handle single input with multiple file uploads
//        foreach ($uploadedFiles['example3'] as $uploadedFile) {
//            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
//                $filename = $this->moveUploadedFile($directory, $uploadedFile);
//                $this->response->write('uploaded ' . $filename . '<br/>');
//            }
//        }

        }

        /**
         * Moves the uploaded file to the upload directory and assigns it a unique name
         * to avoid overwriting an existing uploaded file.
         *
         * @param string $directory directory to which the file is moved
         * @param UploadedFile $uploaded file uploaded file to move
         * @return string filename of moved file
         */
        public function moveUploadedFile($directory, UploadedFile $uploadedFile)
        {
//            $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
//            $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
//            $filename = sprintf('%s.%0.8s', $basename, $extension);
            $filename = $uploadedFile->getClientFilename();

            $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);

            return $filename;
        }
};