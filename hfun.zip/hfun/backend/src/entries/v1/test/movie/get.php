<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];

    public function run()
    {
//        $params = $this->request->getParams();
        $this->test2();exit;
        $movies = DB::table('movie1')->where('id','<',454)->where('id','>=',405)->selectRaw('title,cover,cover2,performer,tag,url,tmp_views,rating')->get()->toArray();
        $datas = [];
        foreach ($movies as $k => $movie) {
            try{
                if($movie->performer){
                    $performers = explode(',', $movie->performer);
                    $performers = array_filter($performers);
                    $performer_ids = [];
                    foreach ($performers as $performer) {

                        $performer_info = DB::table('performer')->where('name', $performer)->first();
                        if (!$performer_info) {
                            $performer_id = DB::table('performer')->insertGetId(['name' => $performer]);
                        } else {
                            $performer_id = $performer_info->id;
                        }
                        if( !in_array($performer_id,$performer_ids)){
                            array_push($performer_ids, $performer_id);
                        }

                    }

                    $movie->performer = implode(',', $performer_ids);
                }

                if($movie->tag){
                    $tags = explode(',', $movie->tag);
                    $tags = array_filter($tags);
                    $tag_ids = [];
                    foreach ($tags as $tag) {
                        $tag_info = DB::table('tag')->where('name', $tag)->first();
                        if (!$tag_info) {
                            $tag_id = DB::table('tag')->insertGetId(['name' => $tag]);
                        } else {
                            $tag_id = $tag_info->id;
                        }
                        if(!in_array($tag_id,$tag_ids)){
                            array_push($tag_ids, $tag_id);
                        }

                    }

                    $movie->tag = implode(',', $tag_ids);
                }

                array_push($datas,(array)$movie);
//                DB::table('movie')->insert((array)$movie);
            }catch (\Exception $e){
                print_r($movie);
            }

//            break;
        }
        DB::table('movie')->insert($datas);
        exit;
    }


    public function test2(){
        $movies = DB::table('movie')->where('id','<=',657)->where('id','>=',611)->selectRaw('id,title,cover,cover2,performer,tag,url,tmp_views,rating')->get()->toArray();
        foreach ($movies as $k => $movie) {
            try{
                if($movie->performer){
                    $performers = explode(',', $movie->performer);

                    $performerData = [];
                    foreach ($performers as $performer) {

                        array_push($performerData, ['movie_id' => $movie->id, 'performer_id' => $performer]);

                    }
                    DB::table('performer_movie')->insert($performerData);

                }

                if($movie->tag){
                    $tags = explode(',', $movie->tag);
                    $tagData = [];
                    foreach ($tags as $tag) {
                        array_push($tagData,['movie_id'=>$movie->id,'tag_id'=>$tag]);
                    }

                    DB::table('movie_tag')->insert($tagData);
                }


            }catch (\Exception $e){
                print_r($movie);
            }

        }
        exit;
    }
};
