<?php
// 引入鉴权类
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;

use OSS\OssClient;
use OSS\Core\OssException;

use Utils\Www\Action;
return new class extends Action {
    const TITLE = "文档编写中";
    const HINT = "开发的技术提示信息";
    const DESCRIPTION = "文档编写中";
    const TYPE = "text/json";


    public function run() {


        $region = \Utils\Utils::gerIpRegion2('2409:8938:7410:1aec:b5ac:7a1d:2df7:a708');
        print_r($region);exit;
        $res=[
            'Message'=>'成功',
            'Code'=>1,
            'Success'=>true
        ];
        echo json_encode($res);exit;

        echo  uniqid(); exit;

        DB::table('user')
            ->selectRaw('id,inet_ntoa(last_login_ip) as ip')
//            ->where('region', '')
            ->where('last_login_ip','<>','')
            ->orderBy('id')
            ->chunk(100, function ($users) {

                $insertArr = [];
//                print_r($users);
                foreach ($users as $user) {
                    $region = \Utils\Utils::gerIpRegion2($user->ip);
                    $message = [
                        'id'     => $user->id,
                        'region' => $region,
                    ];
                    array_push($insertArr, $message);
                }
//                print_r($insertArr);
                $this->updateBatch($insertArr);
            });
//        exit;

        $res = DB::table('user')
            ->selectRaw('id,inet_ntoa(last_login_ip) as ip')
//            ->where('region', '')
            ->where('last_login_ip','<>','')
            ->orderByDesc('id')
            ->limit(200)
            ->get()
            ->toArray();
        foreach ($res as $re){
            $region =  \Utils\Utils::gerIpRegion2($re->ip);
            echo $re->id;echo $region;
            if($region){
                DB::table('user')->where('id',$re->id)->update(['region'=>$region]);
            }
        }
        print_r($res);
        exit;
        $res = DB::table('user')
            ->selectRaw('id,inet_ntoa(register_ip) as ip')
            ->where('region', '')
            ->where('register_ip','<>','')
            ->orderByDesc('id')
            ->limit(200)
            ->get()
            ->toArray();
        foreach ($res as $re){
            $region =  \Utils\Utils::gerIpRegion($re->ip);
            if($region){
                DB::table('user')->where('id',$re->id)->update(['region'=>$region]);
            }
        }
//        print_r($res);
        exit;


        $file = 'D:\myserver\root\hfun\config/uploads/4140752074390717.m3u8';

        $fileName = $this->getUploadName($file);

        $settings = $this->ci->get('settings')['upload'];
        $res = [];
        foreach ($settings['dsn'] as $obj => $config) {

            $temp = $this->$obj($config, $file, $fileName);
            var_dump($temp);

            if(empty($temp['error'])){
                array_push($res,$temp);
//                    $res = $temp;
            }
        }

        return empty($res) ? $this->lang->set(10015) : $res;
    }

    //批量更新
    public function updateBatch($multipleData = [])
    {
        try {
            if (empty($multipleData)) {
                throw new \Exception("数据不能为空");
            }
//            $tableName = DB::getTablePrefix() . $this->getTable(); // 表名
            $tableName = 't_user'; // 表名
            $firstRow = current($multipleData);

            $updateColumn = array_keys($firstRow);
            // 默认以id为条件更新，如果没有ID则以第一个字段为条件
            $referenceColumn = isset($firstRow['id']) ? 'id' : current($updateColumn);
            unset($updateColumn[0]);
            // 拼接sql语句
            $updateSql = "UPDATE " . $tableName . " SET ";
            $sets = [];
            $bindings = [];
            foreach ($updateColumn as $uColumn) {
                $setSql = "`" . $uColumn . "` = CASE ";
                foreach ($multipleData as $data) {
                    $setSql .= "WHEN `" . $referenceColumn . "` = ? THEN ? ";
                    $bindings[] = $data[$referenceColumn];
                    $bindings[] = $data[$uColumn];
                }
                $setSql .= "ELSE `" . $uColumn . "` END ";
                $sets[] = $setSql;
            }
            $updateSql .= implode(', ', $sets);
            $whereIn = collect($multipleData)->pluck($referenceColumn)->values()->all();
            $bindings = array_merge($bindings, $whereIn);
            $whereIn = rtrim(str_repeat('?,', count($whereIn)), ',');
            $updateSql = rtrim($updateSql, ", ") . " WHERE `" . $referenceColumn . "` IN (" . $whereIn . ")";
            // 传入预处理sql语句和对应绑定数据
            return DB::update($updateSql, $bindings);
        } catch (\Exception $e) {
            throw $e;
            return false;
        }
    }
    /**
     * 七牛上传
     * @param  [type] $config [description]
     * @param  [type] $file   [description]
     * @return [type]         [description]
     */
    protected function qiniu($config, $file, $fileName) {
        // 构建鉴权对象
        $auth = new Auth($config['accessKey'], $config['secretKey']);
        // 生成上传 Token
        $token = $auth->uploadToken($config['bucket']);
        $key = $config['dir'].'/'.$fileName;
        // 初始化 UploadManager 对象并进行文件的上传。
        $uploadMgr = new UploadManager();
        // 调用 UploadManager 的 putFile 方法进行文件的上传。
        list($ret, $err) = $uploadMgr->putFile($token, $key, $file);
        if ($err !== null) {
            return [
                'error'=>true,
                'error_msg'=>'qiniu:'.print_r($err, true),
                'url'=>'',
            ];
//            return $this->lang->set(15, [], [], ['error' => 'qiniu:'.print_r($err, true)]);
        } else {
            return [
                'error'=>false,
                'error_msg'=>'',
                'url'=>$config['domain'].'/'.$key,
            ];
        }
    }

    /**
     * 阿里云OSS上传
     * @param  [type] $config [description]
     * @return [type]         [description]
     */
    protected function oss($config, $file, $fileName) {
        try {
            $ossClient = new OssClient($config['accessKeyId'], $config['accessKeySecret'], $config['endpoint']);
        } catch (OssException $e) {
            return $this->lang->set(15, [], [], ['error' => 'oss":'.$e->getMessage()]);
        }

        try {
            $object = $config['dir'].'/'.$fileName;
            $content = file_get_contents($file);
            $ossClient->putObject($config['bucket'], $object, $content);
            return [
                'error'=>false,
                'error_msg'=>'',
                'url'=>$config['domain'].'/'.$object,
            ];
        } catch (OssException $e) {
            return [
                'error'=>true,
                'error_msg'=>'oss":'.$e->getMessage(),
                'url'=>'',
            ];
        }
    }

    /**
     * 取得上传后文件名称
     * @param  [type] $fileName [description]
     * @return [type]           [description]
     */
    protected function getUploadName($file) {
        $temp = explode('.', $file);
        $fileExt = strtolower(end($temp));
        return md5(time().mt_rand(0, 999999)).'.'.$fileExt;
    }

    /**
     * 移除临时文件
     * @param  [type] $file [description]
     * @return [type]       [description]
     */
    protected function remove($file) {
        @unlink($file['tmp_name']);
    }
};
