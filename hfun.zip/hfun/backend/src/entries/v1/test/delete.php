<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Http\UploadedFile;
use \Psr\Http\Message\UploadedFileInterface;
return new class() extends BaseController
{

/etc/php.d/bz2.ini,
/etc/php.d/calendar.ini,
/etc/php.d/ctype.ini,
/etc/php.d/curl.ini,
/etc/php.d/dom.ini,
/etc/php.d/exif.ini,
/etc/php.d/fileinfo.ini,
/etc/php.d/ftp.ini,
/etc/php.d/gd.ini,
/etc/php.d/gettext.ini,
/etc/php.d/gmp.ini,
/etc/php.d/iconv.ini,
/etc/php.d/igbinary.ini,
/etc/php.d/json.ini,
/etc/php.d/mbstring.ini,
/etc/php.d/mcrypt.ini,
/etc/php.d/mongodb.ini,
/etc/php.d/pdo.ini,
/etc/php.d/pdo_sqlite.ini,
/etc/php.d/phar.ini,
/etc/php.d/phpest.ini,
/etc/php.d/posix.ini,
/etc/php.d/redis.ini,
/etc/php.d/shmop.ini,
/etc/php.d/simplexml.ini,
/etc/php.d/sockets.ini,
/etc/php.d/sqlite3.ini,
/etc/php.d/sysvmsg.ini,
/etc/php.d/sysvsem.ini,
/etc/php.d/sysvshm.ini,


    public $options = OPENSSL_RAW_DATA;
    public $key = '9536205862353e299dd4db1add091772';
    public $cipher = 'AES-256-CBC';
    public $iv = '0473bdcf22c5c816';
    public function run(){

        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $cacheKey = Logic\Define\CacheKey::$perfix['movieDomains'];
        $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];

        if (RUNMODE == 'dev') {

            $movie_domains = [
                [
                    'http://www-api.zyupload.com',
                    '23.98.36.157',
                ],
                [
                    'http://www-api.zyupload.com',
                    '23.98.36.157',
                ],
                [
                    'http://www-api.zyupload.com',
                    '23.98.36.157',
                ]
            ];
        }

        if(!$this->redis->exists($cacheKey)){
//            $this->redis->del($cacheKey);
            foreach ($movie_domains as $k=>$movie_domain){
                $this->redis->hset($cacheKey,$k,0);
            }
        }
        $data = $this->redis->hgetall($cacheKey);
        print_r($data);
        $minvalue = min($data);
        $minkey = array_search($minvalue,$data);
//        print_r($data);
//        array_multisort($data);
//        print_r($data);
//        $minkey = key($data);
        echo "<pre/>";
//        var_dump($minkey);

        print_r($movie_domains[$minkey]);
        echo "<pre/>";
        $this->redis->hincrby($cacheKey,$minkey,1);
        $data = $this->redis->hgetall($cacheKey);
        print_r($data);
        exit;
        $key = Logic\Set\SetConfig::DATA['base'];


        $directory = $this->ci->get('settings')['upload_directory'];
        $encryptImg = [
            'secret_key' => '9536205862353e299dd4db1add091772',   //32位字节
            'iv' => '0473bdcf22c5c816',                 //长度必须16字节
            'method' => 'AES-256-CBC',
        ];

        $aes= $this->ci->get('settings')['encryptImg'];
        $aes= $encryptImg['iv'];
//        echo strrev($aes)
        $file = file_get_contents('http://phpplay.tepigou.com/img/img_RD57l7tu38LFNmT1.jpg');
        echo base64_encode(Utils\Utils::decryptImg($file));exit;



        header("Content-Type: image/jpeg;text/html; charset=utf-8");
        print_r($this->decrypt($file));exit;
        echo $file;exit;
//        print_r($file);exit;
//        $en = new \Utils\Encrypt($aes);
        file_put_contents($directory.'/test.jpg',$this->decrypt($file));
        echo 666;
//        print_r(base64_encode($this->decrypt($file)));exit;
    }

    public function decrypt($encrypted)
    {
        $_encrypted = base64_decode($encrypted);
        if (!$_encrypted) {
            return $encrypted;
        }
        $decrypted = openssl_decrypt($_encrypted, $this->cipher, $this->key, $this->options, $this->iv);
        if (false === $decrypted) {
            //print_var(openssl_error_string());

            return $encrypted;
        }
        return $decrypted;
    }
};