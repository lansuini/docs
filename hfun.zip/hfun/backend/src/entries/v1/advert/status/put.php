<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);
        (new BaseValidate(
            [

                'status'=>'require|in:1,2',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $advert = DB::table('advert')->find($id);
        if(!$advert)
            return $this->lang->set(61);
        $params = $this->request->getParams();
        $data = [];
        $data['status'] = $params['status'];
        if($params['status'] == 1){
            if(in_array($advert->position,[2,3])){
                try{
                    DB::beginTransaction();
                    DB::table('advert')->where('position',$advert->position)->update(['status'=>2]);
                    $res = DB::table('advert')->where('id',$id)->update($data);
                    DB::commit();
                    return $this->lang->set(0);
                }catch (\Exception $e){
                    DB::rollback();
                    return $this->lang->set(-2);
                }
            }else{
                $res = DB::table('advert')->where('id',$id)->update($data);
            }

        }else{
            $res = DB::table('advert')->where('id',$id)->update($data);
        }

        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};