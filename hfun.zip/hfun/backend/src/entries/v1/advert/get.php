<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [
                'sort'=>'in:desc,asc'
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $query = DB::table('advert as a')
            ->leftJoin('advert_group as g','a.group_id','=','g.id')
            ->select(['a.id','a.group_id','g.name as group_name','a.title','a.image','a.position','a.link','a.type','a.link_type','a.apk','a.ipa','a.times','a.sort','a.status','a.created']);

        $query = isset($params['type']) && !empty($params['type']) ? $query->where('type',$params['type']) : $query;
        $query = isset($params['group_id']) && !empty($params['group_id']) ? $query->where('group_id',$params['group_id']) : $query;
        $query = isset($params['position']) && !empty($params['position']) ? $query->where('position',$params['position']) : $query;


        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $query = $query->forPage($params['page'],$params['page_size']);
        $query = isset($params['sort']) && !empty($params['sort']) ? $query->orderBy('sort',$params['sort']) : $query;
        $adverts = $query->get()->toArray();

        foreach ($adverts as $advert){
            if($advert->link_type != 1){
                $link_column = DB::table('column')->find($advert->link);
                if($link_column)
                    $advert->link_column = $link_column->name;
            }else{
                $advert->link_column = $advert->link;
            }

        }

        return $this->lang->set(0,[],$adverts,$attributes);
    }
};
