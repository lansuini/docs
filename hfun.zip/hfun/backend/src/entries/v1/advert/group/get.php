<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
//        (new BaseValidate(
//            [
//                'sort'=>'in:desc,asc'
//            ]
//        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $query = DB::table('advert_group')

            ->selectRaw('id,name,channel,created');


        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $query = $query->forPage($params['page'],$params['page_size']);
        $adverts = $query->get()->toArray();

        return $this->lang->set(0,[],$adverts,$attributes);
    }
};
