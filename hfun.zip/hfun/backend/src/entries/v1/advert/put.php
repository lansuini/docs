<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {

        $this->checkID($id);
        (new BaseValidate(
            [
                'group_id'=>'require|number',
                'title'=>'require|max:250',
                'image'=>'require|url',
                'link'=>'requireIf:1,2,3',
                'ipa'=>'requireIf:link_type,4',//ios
                'apk'=>'requireIf:link_type,4',//安卓
                'status'=>'require|in:1,2',
                'position'=>'require|between:1,9',
//                'type'=>'require|in:1,2',
                'link_type'=>'require|in:1,2,3,4',
                'times'=>'requireIf:position,2,3|between:0,120',
                'sort'=>'require|between:0,99',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();
        $times = $this->request->getParam('times',3);
        $ipa = $this->request->getParam('ipa','');
        $apk = $this->request->getParam('apk','');
        $link = $this->request->getParam('link','');
        $data = [];
        $data['group_id'] = $params['group_id'];
        $data['title'] = $params['title'];
        $data['image'] = $params['image'];
        $data['status'] = $params['status'];
        $data['link'] = $link;
        $data['position'] = $params['position'];
        $data['link_type'] = $params['link_type'];
        $data['sort'] = $params['sort'];
        $data['times'] = $times;
        $data['ipa'] = $ipa;
        $data['apk'] = $apk;

        $res = DB::table('advert')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};