<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;

return new class() extends BaseController
{
    const TITLE       = '修改管理员状态';

    //前置方法
    protected $beforeActionList = [
        'verifyToken', 'authorize',
    ];

    public function run($id = '')
    {
        $this->checkID($id);
        (new BaseValidate([
            'status'=> 'require|in:0,1',

        ],
            [],
            ['status'=>'状态']
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $data['status'] = $params['status'];

        $res = DB::table('admin_user')->where('id',$id)->update($data);

        if($res === false)
            return $this->lang->set(-2);

        if($params['status'] == 0) (new Logic\Admin\AdminAuth($this->ci))->deleteAdminWithToken($id);

        return $this->lang->set(0);

    }
};
