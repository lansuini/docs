<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;

return new class() extends BaseController
{
    const TITLE       = '新增管理员';

    //前置方法
    protected $beforeActionList = [
        'verifyToken', 'authorize',
    ];

    public function run()
    {
        (new BaseValidate([
            'username'=> 'require|alphaNum|unique:admin_user,username',
            'password'=> 'require|length:6,12',
            'truename'=> 'require',
            'part'=> 'require',
            'job'=> 'require',
        ],
            [],
            ['username'=>'管理员名称','password'=>'密码','truename'=>'真实姓名','part'=> '部门', 'job'=> '职位']
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $data['username'] = $params['username'];
        list($password, $salt) = $this->makePW($params['password']);
        $data['password'] = $password;
        $data['salt'] = $salt;
        $data['truename'] = $params['truename'];
        $data['part'] = $params['part'];
        $data['job'] = $params['job'];

        $res = DB::table('admin_user')->insertGetId($data);
        if(!$res)
            return $this->lang->set(-2);
        return $this->lang->set(0);

    }
};
