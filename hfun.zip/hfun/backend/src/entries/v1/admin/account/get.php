<?php

use Model\AdminUser;
use Logic\Admin\BaseController;

return new class() extends BaseController {
    const TITLE = '管理员列表';

    //前置方法
    protected $beforeActionList = [
        'verifyToken', 'authorize',
    ];

    public function run() {

        $params = $this->request->getParams();

        $query = AdminUser::selectRaw('id,username,truename,status,part,job,loginip,logintime,created');

        $query = isset($params['username']) && !empty($params['username']) ? $query->where('username','like','%'.$params['username'].'%') : $query;

        $total = $query->count();
        $admins = $query->forPage($params['page'],$params['page_size'])->orderBydesc('created')->get()->toArray();

        $attributes['total'] = $total;
        $attributes['number'] = $params['page'];
        $attributes['size'] = $params['page_size'];

        return $this->lang->set(0, [], $admins, $attributes);
    }

};
