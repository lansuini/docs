<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;

return new class() extends BaseController
{
    const TITLE       = '删除管理员';

    //前置方法
    protected $beforeActionList = [
        'verifyToken', 'authorize',
    ];

    public function run($id = '')
    {
        $this->checkID($id);

        $res = DB::table('admin_user')->where('id',$id)->delete();

        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);

    }
};
