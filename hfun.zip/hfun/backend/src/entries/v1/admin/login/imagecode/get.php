<?php
/**
 * 后台登录获取验证码
 * @author Taylor 2018-11-27
 */

use Logic\Admin\BaseController;

return new class extends BaseController{

    public $beforeActionList = [];

    public function run(){
        return (new \Logic\Captcha\Captcha($this->ci))->getImageCode();
    }
};
