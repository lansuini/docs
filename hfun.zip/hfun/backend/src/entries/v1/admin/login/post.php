<?php
/**
 * 登录接口
 * @author Taylor 2018-11-27
 */

use Utils\Admin\Action;
use Utils\GeoIP;
use Logic\Admin\AdminToken;
use Respect\Validation\Validator as v;
use Logic\Set\SetConfig;
use Utils\Utils;

return new class extends Action {

    public function run() {
//        $key = \Logic\Set\SetConfig::SET_GLOBAL;
//        $settings = (new \Logic\Set\Datas($this->ci))->getGlobalSet();
//
//        //ip白名单登录限制
//        $ip_limit_whitelist = isset($settings['base']['ip_limit_whitelist']) ? $settings['base']['ip_limit_whitelist'] : SetConfig::DATA[SetConfig::SET_GLOBAL]['base']['ip_limit_whitelist'];
//        if ($ip_limit_whitelist) {
//            $ipExist = (new \Model\IpLimit())->where('ip', Utils::RSAEncrypt(\Utils\Client::getIp()))
//                ->count();
//
//            if ($ipExist <= 0) {
//                return $this->lang->set(10614);
//            }
//        }
//
//        $ip_limit_china = isset($settings['base']['IP_limit']) ? $settings['base']['IP_limit'] : SetConfig::DATA[$key]['base']['IP_limit'];
//        if ($ip_limit_china) {
//            $geoipObject = new GeoIP();
//            $gi = $geoipObject->geoip_open(false, GEOIP_STANDARD);
//            $country_code = $geoipObject->geoip_country_code_by_addr($gi, \Utils\Client::getIp());
//            $country_name = $geoipObject->geoip_country_name_by_addr($gi, \Utils\Client::getIp());
//            $geoipObject->geoip_close($gi);
//
//            if ($country_code == 'CN' || $country_name == 'China') {
//                return $this->lang->set(10044);
//            }
//        }

        $validation = $this->validator->validate($this->request, [
//            'token'    => v::noWhitespace()
//                ->length(32, 32)
//                ->setName('验证码'),
            'code'     => v::noWhitespace()
                ->length(4, 6)
                ->setName('验证码'),
            'username' => v::noWhitespace()
                ->length(4, 16)
                ->setName('用户名'),
            'password' => v::noWhitespace()
                ->length(6, 32)
                ->setName('密码'),
        ]);

        if (!$validation->isValid()) {
            return $validation;
        }

        $params = $this->request->getParsedBody();

        $val = (new \Logic\Captcha\Captcha($this->ci))->validateImageCode($params['token'], $params['code']);
        if (!$val) {
            return $this->lang->set(10045);
        }

        $jwt = new AdminToken($this->ci);
        $jwtconfig = $this->ci->get('settings')['jsonwebtoken'];
        $digital = intval($jwtconfig['uid_digital']);
        $token = $jwt->createToken($params, $jwtconfig['public_key'], 86400 * 7, $digital);
        return $token;
    }
};
