<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);
        $attr = DB::table('tag_attr')->find($id);
        if(!$attr)
            return $this->lang->set(87);

        (new BaseValidate(
            [
                'name'=>'require|max:50|unique:tag_attr,name^id',

            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();
        $data = [];
        $data['name'] = $params['name'];


        $res = DB::table('tag_attr')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};