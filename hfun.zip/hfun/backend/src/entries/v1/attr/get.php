<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();

        $query = DB::table('tag_attr')
            ->forPage($params['page'],$params['page_size'])
            ->selectRaw('id,name,created');

        $query = isset($params['name']) && !empty($params['name']) ? $query->where('name',$params['name']) : $query;


        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $attrs = $query->get()->toArray();
        $counts = DB::table('tag')->selectRaw("attr_id,count(id) as tags")->groupBy('attr_id')->pluck('tags','attr_id')->toArray();
        foreach ($attrs as $attr){
            if(isset($counts[$attr->id])){
                $attr->tags = $counts[$attr->id];
            }else{
                $attr->tags = 0;
            }

        }
        return $this->lang->set(0,[],$attrs,$attributes);
    }
};
