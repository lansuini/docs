<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run()
    {
        (new BaseValidate(
            [
                'name'=>'require|max:50|unique:tag_attr,name',

            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();
        $data = [];
        $data['name'] = $params['name'];

        $res = DB::table('tag_attr')->insert($data);
        if(!$res)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};