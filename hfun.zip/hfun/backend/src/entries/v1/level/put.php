<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);

        (new BaseValidate(
            [
                'name'=>'require|max:250|unique:user,name',
                'invit_num'=>'require|integer',
                'viewable'=>'require|integer',
                'downloadable'=>'require|integer',
//                'des'=>'require|max:250',
                'icon'=>'require|url|max:500',
                'icon_name'=>'require|max:50',
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();
        $level = DB::table('level')->find($id);
        if(!$level)
            return $this->lang->set(19);

        if($level->level != 1){
            $downlevel = $level->level-1;
            $downlevel = DB::table("level")->where('level',$downlevel)->first();
            if($params['invit_num'] <= $downlevel->invit_num)
                return $this->lang->set(57);
            $max = DB::table("level")->orderBy("id",'desc')->first();
            if($id != $max->id){
                $uplevel = $level->level+1;
                $uplevel = DB::table("level")->where('level',$uplevel)->first();;
                if($params['invit_num'] >= $uplevel->invit_num)
                    return $this->lang->set(10410);
            }
        }

        $data = [];
        $data['name'] = $params['name'];
        $data['icon'] = $params['icon'];
        $data['icon_name'] = $params['icon_name'];
        $data['invit_num'] = $params['invit_num'];
        $data['viewable'] = $params['viewable'];
        $data['downloadable'] = $params['downloadable'];
//        $data['des'] = $params['des'];

        $res = DB::table('level')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);
        $levels = DB::table('level')->get(['id','icon','icon_name','level','invit_num','viewable','downloadable','des','name'])->toArray();
        $this->redis->setex(\Logic\Define\CacheKey::$perfix['level'],60,json_encode($levels));
        return $this->lang->set(0);
    }
};