<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();

        $query = DB::table('level')
            ->forPage($params['page'],$params['page_size'])
            ->selectRaw('id,invit_num,viewable,downloadable,icon,icon_name,name,total');

        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $level_count = DB::table('user')->selectRaw("level,count('id') as total")->groupBy('level')->pluck('total','level')->toArray();
        $levels = $query->get()->toArray();
        foreach ($levels as &$level){
            $level->total = isset($level_count[$level->id]) ? $level_count[$level->id] : 0;
        }

        return $this->lang->set(0,[],$levels,$attributes);
    }
};
