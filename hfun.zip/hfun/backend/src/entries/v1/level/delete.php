<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);
        if($id == 1)
            return $this->lang->set(26);

        $level = DB::table('level')->find($id);
        if(!$level)
            return $this->lang->set(19);

        $maxLevel = DB::table('level')->max('level');
        if($level->level != $maxLevel)
            return $this->lang->set(10409);

        $res = DB::table('level')->where('id',$id)->delete();
        if(!$res)
            return $this->lang->set(-2);
        $levels = DB::table('level')->get(['id','icon','icon_name','level','invit_num','viewable','downloadable','des','name'])->toArray();
        $this->redis->setex(\Logic\Define\CacheKey::$perfix['level'],60,json_encode($levels));
        return $this->lang->set(0);
    }
};