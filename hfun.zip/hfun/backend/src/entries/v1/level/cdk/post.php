<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/10
 * Time: 18:30
 */
use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{
    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){

        (new BaseValidate(
            [
                'nums'=>'require|number',
                'dlength'=>'require|in:0,1,3,7,30,90,180,365',
                'partner'=>'require',
            ],
            [],
            ['nums'=>'数量','dlength'=>'有效时长','partner'=>'推广伙伴']
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();
        if(is_numeric($params['partner'])){

            $partner = DB::table('spread_partner')->where('id',$params['partner'])->first();
            if(!$partner){
                return $this->lang->set(10015);
            }
        }else{
            $partnerId = DB::table('spread_partner')->insertGetId(['name'=>$params['partner']]);
            $params['partner'] = $partnerId;
        }



        $data = generateCode($params);
        if(!empty($data)){
            DB::table('cdkey')->insert($data);
        }

        return $this->lang->set(0);
    }

};