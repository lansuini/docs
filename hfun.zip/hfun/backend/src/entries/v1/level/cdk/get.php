<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {

        (new BaseValidate([
            'status'=>'in:1,2,3',
            'user_name'=>'max:50',
            'dlength' => 'number',
        ]))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getQueryParams();
        $query = DB::table('cdkey as c')
            ->leftJoin('spread_partner as sp','c.partner','=','sp.id')
            ->leftJoin('user as u','u.id','=','c.user_id')
            ->select(['c.id','code','c.status','c.partner','sp.name as partner_name','origin','user_id','u.account as user_name','dlength','act_date','end_date','c.created'])
            ;

        $query = isset($params['code']) && !empty($params['code']) ? $query->where('c.code',$params['code']) : $query;
        $query = isset($params['dlength']) ? $query->where('c.dlength',$params['dlength']) : $query;
        $query = isset($params['status']) && !empty($params['status']) ? $query->where('c.status',$params['status']) : $query;
        $query = isset($params['origin']) && !empty($params['origin']) ? $query->where('c.origin',$params['origin']) : $query;
        $query = isset($params['user_name']) && !empty($params['user_name']) ? $query->where('u.name','=',$params['user_name']) : $query;
        $query = isset($params['partner']) && !empty($params['partner']) ? $query->where('c.partner','=',$params['partner']) : $query;
        $query = isset($params['created_start']) && !empty($params['created_start']) ? $query->where('c.created','>=',$params['created_start']) : $query;
        $query = isset($params['created_end']) && !empty($params['created_end']) ? $query->where('c.created','<=',$params['created_end']) : $query;


        $countQuery = clone $query;
        $attributes['total'] = $countQuery->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];

        $cdks = $query->forPage($params['page'],$params['page_size'])->orderByDesc('c.created')->get()->toArray();

        return $this->lang->set(0,[],$cdks,$attributes);
    }
};
