<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [
                'name'=>'require',
                'icon'=>'require|url',
                'icon_name'=>'require|max:50',
                'invit_num'=>'require|integer',
//                'des'=>'require|max:250',
                'viewable'=>'require|integer',
                'downloadable'=>'require|integer',
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();
        $maxLevel = DB::table('level')->orderByDesc('level')->first();
        if($params['invit_num'] <= $maxLevel->invit_num)
            return $this->lang->set(57);

        $data = [];
        $data['name'] = $params['name'];
//        $data['des'] = $params['des'];
        $data['level'] = $maxLevel->level + 1;
        $data['icon'] = $params['icon'];
        $data['icon_name'] = $params['icon_name'];
        $data['invit_num'] = $params['invit_num'];
        $data['viewable'] = $params['viewable'];
        $data['downloadable'] = $params['downloadable'];
        $res = DB::table('level')->insert($data);

        if(!$res)
            return $this->lang->set(-2);
        $levels = DB::table('level')->get(['id','icon','icon_name','level','invit_num','viewable','downloadable','des','name'])->toArray();
        $this->redis->setex(\Logic\Define\CacheKey::$perfix['level'],60,json_encode($levels));
        return $this->lang->set(0);

    }
};