<?php
/**
 * 公告内容列表
 * @author Taylor 2018-11-25
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){
//        $params = $this->request->getParams();
        $page = $this->request->getParam('page', 1);//页数
        $page_size = $this->request->getParam('page_size',20);//每页记录数
        $query = DB::table('notice')->orderBy('status', 'asc')->orderBy('id', 'desc');

        $attributes['total'] = $query->count();
        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;
        $users = $query->forPage($page, $page_size)->get()->toArray();

        return $this->lang->set(0, [], $users, $attributes);
    }
};
