<?php
/**
 * 公告内容新增
 * @author Taylor 2018-11-25
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){
        $v = [
            'title' => 'require',
            'content' => 'require',
            'receiver' => 'in:ALL,GUEST,REG',
            's_time' => 'require',
            'e_time' => 'require',
        ];
        $validate = new \lib\validate\BaseValidate($v);
        $validate->paramsCheck('', $this->request, $this->response);
        $data = $this->request->getParams();

        if(empty($data['s_time']) || empty($data['e_time'])){
            return $this->lang->set(886, ['开始时间或结束时间不能都为空']);
        }
        if($data['s_time'] > $data['e_time']){
            return $this->lang->set(886, ['开始时间不能大于结束时间']);
        }

        $res = DB::table('notice')->insert($data);
        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};
