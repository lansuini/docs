<?php
/**
 * 福利任务编辑
 * @author Taylor 2018-11-24
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id){
        $this->checkID($id);
        $notice = DB::table('notice')->find($id);
        if(!$notice)
            return $this->lang->set(886, ['公告不存在']);

        DB::beginTransaction();
        try{
            $status = $notice->status == 1 ? 2 : 1;//启用变禁用，禁用变启用
            if($status == 1){//状态启用时，其他的禁用
                DB::table('notice')->where('id', '<>', $id)->update(['status'=>'2']);//其他的禁用
            }
            DB::table('notice')->where('id', $id)->update(['status'=>$status]);
            DB::commit();
        }catch (\Exception $e){
            DB::rollback();
        }

        return $this->lang->set(0);
    }
};
