<?php
/**
 * 福利任务编辑
 * @author Taylor 2018-11-24
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){
        $v = [
            'id' => 'require',
            'title' => 'require',
            'content' => 'require',
            'receiver' => 'in:ALL,GUEST,REG',
            'status' => 'in:1,2',
            's_time' => 'require',
            'e_time' => 'require'
        ];
        $validate = new \lib\validate\BaseValidate($v);
        $validate->paramsCheck('', $this->request, $this->response);
        $data = $this->request->getParams();
        $notice = DB::table('notice')->find($data['id']);
        if(!$notice)
            return $this->lang->set(886, ['公告不存在']);

        $n_data['title'] = $data['title'];
        $n_data['content'] = $data['content'];
        $n_data['receiver'] = $data['receiver'];
        $n_data['status'] = $data['status'];
        $n_data['s_time'] = $data['s_time'];
        $n_data['e_time'] = $data['e_time'];

        if(empty($data['s_time']) || empty($data['e_time'])){
            return $this->lang->set(886, ['开始时间或结束时间不能都为空']);
        }
        if($data['s_time'] > $data['e_time']){
            return $this->lang->set(886, ['开始时间不能大于结束时间']);
        }
        $n_data['status'] = $data['status'];

        DB::beginTransaction();
        try{
            if($data['status'] == 1){//状态启用时，其他的禁用
                DB::table('notice')->where('id', '<>', $data['id'])->update(['status'=>'2']);//其他的禁用
            }
            DB::table('notice')->where('id', $data['id'])->update($n_data);
            DB::commit();
        }catch (\Exception $e){
            DB::rollback();
        }

        return $this->lang->set(0);
    }
};
