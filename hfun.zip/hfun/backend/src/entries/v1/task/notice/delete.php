<?php
/**
 * 公告删除
 * Taylor 2018-11-25
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = '')
    {
        $this->checkID($id);

        $notice = DB::table('notice')->find($id);
        if(!$notice)
            return $this->lang->set(886, ['公告不存在']);

        $res = DB::table('notice')->where('id',$id)->delete();
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};