<?php
/**
 * 每日任务
 * @author Taylor 2018-11-24
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){
//        $params = $this->request->getParams();
        $page = $this->request->getParam('page', 1);//页数
        $page_size = $this->request->getParam('page_size',20);//每页记录数
        $query = DB::table('movie_task')->where('task_kind', 'daily')->selectRaw('id,task_name,task_desc,task_type,add_look_times,add_cache_times,expire_type,is_long,s_time,e_time,status,sorted,created,updated');

//        $query = isset($params['account']) && !empty($params['account']) ? $query->where('account',$params['account']) : $query;
//        $query = isset($params['sex']) && !empty($params['sex']) ? $query->where('sex',$params['sex']) : $query;
        $attributes['total'] = $query->count();
        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;
        $users = $query->forPage($page, $page_size)->get()->toArray();

        return $this->lang->set(0, [], $users, $attributes);
    }
};
