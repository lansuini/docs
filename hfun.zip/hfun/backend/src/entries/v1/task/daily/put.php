<?php
/**
 * 福利任务编辑
 * @author Taylor 2018-11-24
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run(){
        $v = [
            'id' => 'require',
            'task_name' => 'require',
            'task_desc' => 'require',
            'add_look_times' => 'require',
            'add_cache_times' => 'require',
            'is_long' => 'in:1,0',
            'expire_type' => 'in:1,2',
            'status' => 'in:1,2',
            'sorted' => 'require',
        ];
        $validate = new \lib\validate\BaseValidate($v);
        $validate->paramsCheck('', $this->request, $this->response);
        $data = $this->request->getParams();
        $task = DB::table('movie_task')->find($data['id']);
        if(!$task)
            return $this->lang->set(886, ['每日任务不存在']);

        $task_data['task_name'] = $data['task_name'];
        $task_data['task_desc'] = $data['task_desc'];
        $task_data['add_look_times'] = $data['add_look_times'];
        $task_data['add_cache_times'] = $data['add_cache_times'];
        $task_data['s_time'] = $data['s_time'];
        $task_data['e_time'] = $data['e_time'];
        $task_data['expire_type'] = $data['expire_type'];//1 永久有效，2 当日有效，每日任务才有这个
        $task_data['is_long'] = $data['is_long'];
        if($task_data['is_long'] == 1){//启用时间为永久
            $task_data['s_time'] = null;
            $task_data['e_time'] = null;
        }else{
            if(empty($task_data['s_time']) && empty($task_data['e_time'])){
                return $this->lang->set(886, ['开始时间和结束时间不能都为空']);
            }
            if(empty($task_data['s_time']) && empty($task_data['e_time']) && $task_data['s_time'] > $task_data['e_time']){
                return $this->lang->set(886, ['开始时间不能大于结束时间']);
            }
        }
        $task_data['status'] = $data['status'];
        $task_data['sorted'] = $data['sorted'];

        $res = DB::table('movie_task')->where('id', $data['id'])->where('task_kind', 'daily')->update($task_data);
        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};
