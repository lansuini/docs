<?php
/**
 * 视频推广编辑
 * @author Taylor 2018-11-26
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{
    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = ''){

        $this->checkID($id,'渠道');
        $v = [
            'spread_url' => 'require',
            'spread_content' => 'require'
        ];
        $validate = new \lib\validate\BaseValidate($v);
        $validate->paramsCheck('', $this->request, $this->response);

        $data = $this->request->getParams();
        if(!filter_var($data['spread_url'], FILTER_VALIDATE_URL)){
            return $this->lang->set(886, ['链接不合法']);
        }
        $conf = DB::table('platform')->find($id);
        if(!$conf)
            return $this->lang->set(886, ['视频推广信息不存在']);

        $task_data['spread_url'] = $data['spread_url'];
        $task_data['spread_content'] = $data['spread_content'];

        $res = DB::table('platform')->where('id', $data['id'])->update($task_data);
        if($res === false)
            return $this->lang->set(-2);

        return $this->lang->set(0);
    }
};
