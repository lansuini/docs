<?php
/**
 * 视频推广信息获取
 * @author Taylor 2018-11-26
 */
use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = ''){

        $this->checkID($id,'渠道');

        $config = DB::table('platform')->where('id',$id)->first();

        if(empty($config)){
            return $this->lang->set(886, ['推广信息不存在']);
        }

        return $this->lang->set(0, [], $config);
    }
};
