<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();
        $query = DB::table('user')->selectRaw('id,account,name,mobile,sex,level,invit_num,viewable,downloadable,status,region,created,inet_ntoa(last_login_ip) as ip,last_login_time,pv');

        $query = isset($params['account']) && !empty($params['account']) ? $query->where('account',$params['account']) : $query;
        $query = isset($params['name']) && !empty($params['name']) ? $query->where('name',$params['name']) : $query;
        $query = isset($params['sex']) && !empty($params['sex']) ? $query->where('sex',$params['sex']) : $query;
        $query = isset($params['level']) && !empty($params['level']) ? $query->where('level',$params['level']) : $query;
        $query = isset($params['mobile']) && !empty($params['mobile']) ? $query->where('mobile',$params['mobile']) : $query;
        $query = isset($params['status']) && !empty($params['status']) ? $query->where('status',$params['status']) : $query;
        $query = isset($params['channel']) && !empty($params['channel']) ? $query->where('pv',$params['channel']) : $query;
        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $users = $query->forPage($params['page'],$params['page_size'])->orderByDesc('created')->get()->toArray();
        $channel = DB::table('platform')->pluck('name','channel')->toArray();
        $api_logic = new \Logic\Task\Apidata($this->ci);
        foreach ($users as $user){

            $user->channel = $channel[$user->pv];
            $times = $api_logic->getTimes($user->id);//福利任务对应的观影次数和缓存次数
            $user->viewable = $user->viewable + $times['look_times'];
            $user->downloadable = $user->downloadable + $times['cache_times'];
        }

        return $this->lang->set(0,[],$users,$attributes);
    }
};
