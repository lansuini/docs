<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/7
 * Time: 15:52
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {

        $this->checkID($id);

        (new BaseValidate(
            [
                'download'=>'require|number'
            ],
            [],
            [
                'download'=>'下载次数'
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $download = $this->request->getParsedBodyParam('download');
        $res = DB::table('user')->where('id',$id)->update(['downloadable'=>$download]);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};