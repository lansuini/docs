<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];
    public function run($id = '') {

        $this->checkID($id);

        $userInfo = DB::table('user')->selectRaw('id,account,mobile,name,invit_code,sex,viewable,downloadable,invit_num,level')->find($id);
//        $userData = DB::table('user_data')->selectRaw('collection,download,views')->where('user_id',$id)->first();
//        $levels = $this->redis->get(\Logic\Define\CacheKey::$perfix['level']);
//        if(empty($levels))
//        {
//            $levels = DB::table('level')->get(['id','invit_num','viewable','downloadable','des','name'])->toArray();
//            $this->redis->setex(\Logic\Define\CacheKey::$perfix['level'],60,json_encode($levels));
//        }else{
//            $levels = json_decode($levels,true);
//        }
//        $userInfo->levels = $levels;
//        foreach ($levels as $level){
//            $level = (array)$level;
//            if($userInfo->invit_num <= $level['invit_num']){
//                if($userInfo->level == $level['id']){
//                    $userInfo->level_name = $level['name'];
//                    array_shift($levels);
//
//                    break;
//                }elseif($userInfo->level <$level['id']){
//                    DB::table('user')->where('id',$id)->update([
//                        'level'=>$level['id'],
//                        'viewable'=>DB::Raw(" viewable +{$level['viewable']}"),
//                        'downloadable'=>DB::Raw(" downloadable +{$level['downloadable']}"),
//                    ]);
//                    $userInfo->level = $level['id'];
//                    $userInfo->level_name = $level['name'];
//                    $userInfo->viewable = $userInfo->viewable + $level['viewable'];
//                    $userInfo->downloadable = $userInfo->downloadable + $level['downloadable'];
//                    array_shift($levels);
//
//                    break;
//                }
//
//            }
//            continue;
//        }
//        $nextLevel = array_shift($levels);
//        $userInfo->next_level_left = $nextLevel['invit_num'] - $userInfo->invit_num;
        $api_logic = new \Logic\Task\Apidata($this->ci);
        $times = $api_logic->getTimes($userInfo->id);//福利任务对应的观影次数和缓存次数
        $userInfo->viewable = $userInfo->viewable + $times['look_times'];
        $userInfo->downloadable = $userInfo->downloadable + $times['cache_times'];
        $todayViews = $this->redis->hget(\Logic\Define\CacheKey::$perfix['todayViews'],$id);
        $userInfo->todayViews = (int)$todayViews;
        $userInfo->views = DB::table('user_view')->where('user_id',$id)->count();
        return (array)$userInfo;

    }
};