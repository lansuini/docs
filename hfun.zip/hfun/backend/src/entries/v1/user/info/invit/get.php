<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/12/19
 * Time: 14:02
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run($id = ''){

        $this->checkID($id);
        $params = $this->request->getParams();

        $userInfo = DB::table('user')->selectRaw('id,pv,account,name,invit_code,downloadable,invit_num,invit_code')->find($id);
        if(!$userInfo){
            return $this->lang->set(10015);
        }
        $userInfo->spread_url = DB::table('platform')->where('channel',$userInfo->pv)->value('spread_url');
        $userInfo->spread_url = $userInfo->spread_url.'?invit_code='.$userInfo->invit_code;

        $query = DB::table('user')->where('pid',$id)->selectRaw('account,name,created');

        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];

        $userInfo->invit_users = $query->forPage($params['page'],$params['page_size'])->orderByDesc('created')->get()->toArray();

        return $this->lang->set(0,[],$userInfo,$attributes);
    }
};