<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);

        $tag = DB::table('tag')->find($id);
        if(!$tag)
            return $this->lang->set(10015);

        try{
            DB::beginTransaction();

            DB::table('movie_tag')->where('tag_id',$id)->delete();
            DB::table('column_tag')->where('tag_id',$id)->delete();

            DB::table('tag')->where('id',$id)->delete();

            DB::commit();
            return $this->lang->set(0);
        }catch (\Exception $e){
            DB::rollback();
            return $this->lang->set(-2);
        }

        return $this->lang->set(0);
    }
};