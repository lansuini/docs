<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 15:41
 */

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];


    public function run($id = '')
    {
        $this->checkID($id);
        $tag = DB::table('tag')->find($id);
        if(!$tag)
            return $this->lang->set(87);

        (new BaseValidate(
            [
                'name'=>'require|max:250|unique:tag,name^id',
                'attr_id'=>'require|number',
//                'cover'=>'require|url',
//                'sort'=>'require|between:0,99',
//                'display'=>'require|in:1,2',
//                'hot'=>'require|between:0,99',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();
        $data = [];
        $data['name'] = $params['name'];
        $data['attr_id'] = $params['attr_id'];
//        $data['cover'] = $params['cover'];
//        $data['sort'] = $params['sort'];
//        $data['display'] = $params['display'];
//        $data['hot'] = $params['hot'];

        $res = DB::table('tag')->where('id',$id)->update($data);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};