<?php

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
        'verifyToken','authorize'
    ];

    public function run()
    {
        $params = $this->request->getParams();

        $query = DB::table('tag as t')
            ->leftJoin('tag_attr as a','t.attr_id','=','a.id')
            ->select(['t.id','t.name','t.attr_id','a.name as attr_name','t.cover','t.times','t.sort','t.hot','t.display','t.created'])
            ->forPage($params['page'],$params['page_size'])
            ;

        $query = isset($params['name']) && !empty($params['name']) ? $query->where('t.name','like','%'.$params['name'].'%') : $query;

        $attributes['total'] = $query->count();
        $attributes['page'] = $params['page'];
        $attributes['page_size'] = $params['page_size'];
        $tags = $query->orderBy('t.created')->get()->toArray();
        foreach($tags as $tag){
            $tag->times = DB::table('movie_tag')->where('tag_id',$tag->id)->count('tag_id');
        }
        return $this->lang->set(0,[],$tags,$attributes);
    }
};
