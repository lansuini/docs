<?php

use Logic\Admin\BaseController;
use lib\validate\BaseValidate;
return new class() extends BaseController
{

    //前置方法
    protected $beforeActionList = [
//        'verifyToken','authorize'
    ];

    public function run()
    {
        (new BaseValidate(
            [
                'url'=>'require|url'
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $title = $this->request->getParam('title','');
        $performer = $this->request->getParam('performer','');
        $des = $this->request->getParam('des','');
        $tag = $this->request->getParam('tag','');
        $cover = $this->request->getParam('cover','');
        $cover2 = $this->request->getParam('vertical_conver','');
        $url = $this->request->getParam('url','');
        $size = $this->request->getParam('size','');
        $duration = $this->request->getParam('duration','');

        $data['status'] = 3;
        $data['title'] = $title;
        $data['performer'] = $performer;
        $data['des'] = $des;
        $data['tag'] = $tag;
        $data['cover'] = $cover;
        $data['cover2'] = $cover2;
        $data['url'] = $url;
        $data['size'] = $size;
        $data['duration'] = $duration;
        $data['tmp_views'] = rand(100000,200000);
        $data['rating'] = rand(79,95)/10;

        DB::table('movie1')->insert($data);
    }
};
