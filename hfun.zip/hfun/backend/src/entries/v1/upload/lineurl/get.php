<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/11/9
 * Time: 14:26
 */

use Logic\Admin\BaseController;

return new class() extends BaseController
{

    public function run()
    {
//        return 'http://www-api.tgupload.com';
//        if($_SERVER['REMOTE_ADDR'] == '192.168.51.75'){
//            return 'http://www-api.tgupload.com';
//        }
        $key = \Logic\Set\SetConfig::SET_GLOBAL;
        $cacheKey = Logic\Define\CacheKey::$perfix['movieDomains'];

        $movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['movie_domains'];

        //测试地址
        if (RUNMODE == 'dev') {
            $test_movie_domains = Logic\Set\SetConfig::DATA[$key]['base']['test_movie_domains'];
            $movie_domains = [
                [
                    'host'=>$test_movie_domains['host'],
                    'ip'=>$test_movie_domains['ip'],
                ],
                [
                    'host'=>$test_movie_domains['host'],
                    'ip'=>$test_movie_domains['ip'],
                ],
                [
                    'host'=>$test_movie_domains['host'],
                    'ip'=>$test_movie_domains['ip'],
                ]
            ];
        }

        if(!$this->redis->exists($cacheKey)){
            foreach ($movie_domains as $k=>$movie_domain){
                $this->redis->hset($cacheKey,$k,0);
            }
        }
        $data = $this->redis->hgetall($cacheKey);
//        print_r($data);
        $minvalue = min($data);
        $minkey = array_search($minvalue,$data);
//        echo "<pre/>";

//        print_r($movie_domains[$minkey]);
//        echo "<pre/>";
//        $this->redis->hincrby($cacheKey,$minkey,1);
//        $data = $this->redis->hgetall($cacheKey);
//        print_r($data);
//        exit;
        return $movie_domains[$minkey]['host'];
    }
};