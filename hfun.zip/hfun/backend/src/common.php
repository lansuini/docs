<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/4/8
 * Time: 13:41
 */

function createRsponse($response, $status = 200, $state = 0, $message = 'ok', $data = null, $attributes = null) {

    return $response
        // ->withHeader('Access-Control-Allow-Origin', '*')
        // ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        // ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
        ->withStatus($status)
        ->withJson([
            'data'       => $data,
            'attributes' => $attributes,
            'state'      => $state,
            'message'    => $message,
            'ts'         => time(),
        ]);
}

/**
 * 判断值是否是大于0的正整数
 *
 * @param $value
 *
 * @return bool
 */
function isPositiveInteger($value) {
    if (is_numeric($value) && is_int($value + 0) && ($value + 0) > 0) {
        return true;
    } else {
        return false;
    }
}


/**
 * 使用正则验证数据
 *
 * @access public
 *
 * @param string $value
 *            要验证的数据
 * @param string $rule
 *            验证规则
 *
 * @return boolean
 */
function regex($value, $rule) {

    $validate = [
        'require'      => '/\S+/',
        'email'        => '/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/',
        'mobile'       => '/^((13[0-9]{1})|(14[5,7,8,9]{1})|(15[0-35-9]{1})|(166)|(17[0234678]{1})|(18[0-9]{1})|(19[89]{1}))\d{8}$/',
        'phone'        => '/^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/',
        'url'          => '/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(:\d+)?(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/',
        'currency'     => '/^\d+(\.\d+)?$/',
        'number'       => '/^\d+$/',
        'zip'          => '/^\d{6}$/',
        'integer'      => '/^[-\+]?\d+$/',
        'double'       => '/^[-\+]?\d+(\.\d+)?$/',
        'english'      => '/^[A-Za-z]+$/',
        'bankcard'     => '/^\d{14,19}$/',
        'safepassword' => '/^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}$/',
        'chinese'      => '/^[\x{4e00}-\x{9fa5}]+$/u',
        'oddsid'       => '/^([+]?\d+)|\*$/',//验证赔率设置id
        'qq'           => '/^[1-9]\\d{4,14}/',//验证qq格式
    ];
    // 检查是否有内置的正则表达式
    if (isset ($validate [strtolower($rule)])) {
        $rule = $validate [strtolower($rule)];
    }

    return 1 === preg_match($rule, $value);
}

function is_json($string) {
    json_decode($string);
    return (json_last_error() == JSON_ERROR_NONE);
}

/**
 * 生成永远唯一的激活码
 * @return string
 */
function create_guid($namespace = null) {
    static $guid = '';
    $uid = uniqid ( "", true );

    $data = $namespace;
    $data .= $_SERVER ['REQUEST_TIME'];     // 请求那一刻的时间戳
    $data .= $_SERVER ['HTTP_USER_AGENT'];  // 获取访问者在用什么操作系统
    $data .= $_SERVER ['SERVER_ADDR'];      // 服务器IP
    $data .= $_SERVER ['SERVER_PORT'];      // 端口号
    $data .= $_SERVER ['REMOTE_ADDR'];      // 远程IP
    $data .= $_SERVER ['REMOTE_PORT'];      // 端口信息

    $hash = strtoupper ( hash ( 'ripemd128', $uid . $guid . md5 ( $data ) ) );
    $guid = '{' . substr ( $hash, 0, 8 ) . '-' . substr ( $hash, 8, 4 ) . '-' . substr ( $hash, 12, 4 ) . '-' . substr ( $hash, 16, 4 ) . '-' . substr ( $hash, 20, 12 ) . '}';

    return $guid;
}

/**
 * 生成vip激活码
 * @param int $nums             生成多少个优惠码
 * @param array $exist_array     排除指定数组中的优惠码
 * @param int $code_length         生成优惠码的长度
 * @param int $prefix              生成指定前缀
 * @return array                 返回优惠码数组
 */
function generateCode( $data = [],$exist_array = [],$code_length = 12,$prefix = '' )
{

    $characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnpqrstuvwxyz";
    $promotion_codes = array();//这个数组用来接收生成的优惠码

    for ($j = 0; $j < $data['nums']; $j++) {

        $code = '';

        for ($i = 0; $i < $code_length; $i++) {

            $code .= $characters[mt_rand(0, strlen($characters) - 1)];

        }

        //如果生成的4位随机数不再我们定义的$promotion_codes数组里面
        if (!in_array($code, $promotion_codes)) {

            if (is_array($exist_array)) {

                if (!in_array($code, $exist_array)) {//排除已经使用的优惠码

                    $promotion_codes[$j]['code'] = $prefix . $code;//将优惠码赋值给数组
                    $promotion_codes[$j]['partner'] = $data['partner'];//将优惠码赋值给数组
                    $promotion_codes[$j]['dlength'] = $data['dlength'];//将优惠码赋值给数组

                } else {

                    $j--;

                }

            } else {

                $promotion_codes[$j]['code'] = $prefix . $code;//将优惠码赋值给数组
                $promotion_codes[$j]['partner'] = $data['partner'];//将优惠码赋值给数组
                $promotion_codes[$j]['dlength'] = $data['dlength'];//将优惠码赋值给数组

            }

        } else {
            $j--;
        }
    }
//    print_r($promotion_codes);exit;
    return $promotion_codes;

}

/**
 * 生成vip激活码
 * @param int $nums             生成多少个优惠码
 * @param array $exist_array     排除指定数组中的优惠码
 * @param int $code_length         生成优惠码的长度
 * @param int $prefix              生成指定前缀
 * @return array                 返回优惠码数组
 */
function generateCodeBak( $nums = 1,$exist_array = [],$code_length = 12,$prefix = '' )
{

    $characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnpqrstuvwxyz";
    $promotion_codes = array();//这个数组用来接收生成的优惠码

    for ($j = 0; $j < $nums; $j++) {

        $code = '';

        for ($i = 0; $i < $code_length; $i++) {

            $code .= $characters[mt_rand(0, strlen($characters) - 1)];

        }

        //如果生成的4位随机数不再我们定义的$promotion_codes数组里面
        if (!in_array($code, $promotion_codes)) {

            if (is_array($exist_array)) {

                if (!in_array($code, $exist_array)) {//排除已经使用的优惠码

                    $promotion_codes[$j] = $prefix . $code; //将生成的新优惠码赋值给promotion_codes数组

                } else {

                    $j--;

                }

            } else {

                $promotion_codes[$j] = $prefix . $code;//将优惠码赋值给数组

            }

        } else {
            $j--;
        }
    }

    return $promotion_codes;

}