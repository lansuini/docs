<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/7
 * Time: 15:52
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action
{


    public function run()
    {

        $verify = $this->auth->verfiyToken();
        if (!$verify->allowNext()) {
            return $verify;
        }

        $userId = $this->auth->getUserId();

        (new BaseValidate(
            [
                'name'=>'require|max:50'
            ],
            [],
            [
                'name'=>'用户名'
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $name = $this->request->getParsedBodyParam('name');
        $res = DB::table('user')->where('id',$userId)->update(['name'=>$name]);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};