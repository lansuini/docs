<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/7
 * Time: 15:52
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action
{


    public function run()
    {

        $verify = $this->auth->verfiyToken();
        if (!$verify->allowNext()) {
            return $verify;
        }

        $userId = $this->auth->getUserId();

        (new BaseValidate(
            [
                'sex'=>'require|in:1,2'
            ],
            [],
            [
                'sex'=>'性别'
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $sex = $this->request->getParsedBodyParam('sex');
        $res = DB::table('user')->where('id',$userId)->update(['sex'=>$sex]);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};