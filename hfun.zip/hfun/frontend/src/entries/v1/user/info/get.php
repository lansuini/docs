<?php
use Utils\Www\Action;

return new class extends Action {
    //前置方法
    protected $beforeActionList = [
        'establish'

    ];

    public function run() {

        $pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : 'mango';
        $udid = md5($_SERVER['HTTP_UDID']);
//        $udid = 'f7539091ec06afe8dd2b83be8264989b';
        $verify = $this->auth->verfiyToken();
        if ($verify->allowNext()) {
            $userId = $this->auth->getUserId();
            $userInfo = DB::table('user')
                ->selectRaw('id,tel_code,mobile,name,invit_code,sex,viewable,downloadable,avatar,invit_num,level,vip,vip_exp,device_type')
                ->find($userId);
            $cdk = DB::table('cdkey')->where('user_id',$userId)->where('status',2)->where('is_new',1)->first();
            if(!$cdk){
                $userInfo->vip = 0;
                $userInfo->vip_exp = '';
            }else{
                if(empty($cdk->dlength)){
                    $userInfo->vip = 2;
                    $userInfo->vip_exp = '';
                }else{
                    $userInfo->vip = 1;
                    $userInfo->vip_exp = $cdk->end_date;
                }
            }
            
        }else{
            $userInfo = DB::table('user')
                ->where('udid',$udid)
                ->selectRaw('id,tel_code,mobile,name,invit_code,sex,viewable,downloadable,avatar,invit_num,level,vip,vip_exp,device_type')
                ->first();
            if(!$userInfo){
                $level = DB::table('level')->where('level',1)->first();
                $code = random(8);
                $userData = [
                    'udid'=>$udid,
                    'name'=>18125644 .$code,
                    'invit_code'=>$code,
                    'viewable'=>$level->viewable,
                    'downloadable'=>$level->downloadable,
                    'device_type'=>get_device_type(),
                    'register_ip' => DB::getIPv6(),
                    'pv'=>$pv,
                    'last_login_ip'   => DB::getIPv6(),
                    'region' => \Utils\Utils::gerIpRegion2(\Utils\Client::getIp()),
                ];
                try{
                    DB::beginTransaction();

                    $userId = DB::table('user')->insertGetId($userData);
                    DB::table('user_info')->insert(['user_id'=>$userId]);
                    DB::table('user_data')->insert(['user_id'=>$userId]);

                    DB::commit();
                }catch (\Exception $e){

                    DB::rollback();
                    throw $e;
                    return $verify;
                }
                $userInfo = DB::table('user')
                    ->where('udid',$udid)
                    ->selectRaw('id,tel_code,mobile,name,invit_code,sex,viewable,downloadable,avatar,invit_num,level,vip,vip_exp,device_type')
                    ->first();
            }

            $userInfo->vip = 0;
            $userInfo->vip_exp = '';

        }

        if(!$userInfo){
            return $this->lang->set(-2);
        }
        $updata = [];
        $device_type = get_device_type();
        if($userInfo->device_type != $device_type){
            $updata['device_type'] = $device_type;
        }
        if(empty($userInfo->region)){
            $updata['region'] = \Utils\Utils::gerIpRegion2(\Utils\Client::getIp());
        }
        if($updata){
            DB::table('user')->where('udid',$udid)->update($updata);

        }

        //活跃统计
        $date = date('Y-m-d');
        $bitmap = 'user_active:'.$date;
        if(!$this->redis->getBit($bitmap,$userInfo->id)){
            \Utils\MQServer::send('sum_active', [
                'user_id'   => $userInfo->id,
                'device_type' => $device_type,
                'platform'=>$pv
            ]);
        }

        $levels = $this->redis->get(\Logic\Define\CacheKey::$perfix['level']);
        if(empty($levels))
        {
            $levels = DB::table('level')->orderBy('level')->get(['id','icon','icon_name','invit_num','level','viewable','downloadable','des','name'])->toArray();
            $this->redis->setex(\Logic\Define\CacheKey::$perfix['level'],60,json_encode($levels));
        }else{
            $levels = json_decode($levels,true);
        }
        $userInfo->levels = $levels;
        $defaultLevel = (array)$levels[0];
        $viewable = $defaultLevel['viewable'];
        $downloadable = $defaultLevel['downloadable'];
        $currentLevel =  $defaultLevel ;
        foreach ($levels as $level){

            $level = (array)$level;
            if($level['level'] == 1)
                continue;
            if($userInfo->invit_num >= $level['invit_num']){
                $viewable += $level['viewable'];
                $downloadable += $level['downloadable'];
                $currentLevel = $level;
            }else{
                $userInfo->next_level = $level;
                break;
            }

        }
//        print_r($currentLevel);exit;

        if($viewable != $userInfo->viewable || $downloadable != $userInfo->downloadable || $currentLevel['level'] != $userInfo->level){
            DB::table('user')->where('id',$userInfo->id)->update([
                        'level'=>$currentLevel['level'],
                        'viewable'=>$viewable,
                        'downloadable'=>$downloadable,
                    ]);
        }
        $userInfo->level = $currentLevel;
        $userInfo->viewable = $viewable;
        $userInfo->downloadable = $downloadable;
        $userInfo->data = [
            'collection'=>0,
            'download'=>0,
            'views'=>0
        ];
        $api_logic = new \Logic\Task\Apidata($this->ci);
        $userInfo->tasks = [];
        $userInfo->tasks = $api_logic->getTaskList();//福利任务列表
        if($verify->allowNext()){
            $userData = DB::table('user_data')->selectRaw('collection,download,views')->where('user_id',$userInfo->id)->first();
            $userInfo->data = $userData;
            $times = $api_logic->getTaskTimes($userInfo->id);//福利任务对应的观影次数和缓存次数
            $userInfo->viewable = $userInfo->viewable + $times['look_times'];
            $userInfo->downloadable = $userInfo->downloadable + $times['cache_times'];
        }
        //Add by Taylor 2018-11-27
//        $userInfo->next_level = (array)array_shift($levels);
        if(isset($userInfo->next_level) && $userInfo->next_level){
            $userInfo->next_level_left = $userInfo->next_level['invit_num'] - $userInfo->invit_num;
            $userInfo->next_level_left = $userInfo->next_level_left < 0 ? 0 : $userInfo->next_level_left;
        }else{
            $userInfo->next_level_left = 0;
        }
        unset($userInfo->id);
        $todayViews = $this->redis->hlen(\Logic\Define\CacheKey::$perfix['todayViewMovies'].':'.$udid);
        $userInfo->todayViews = (int)$todayViews > $userInfo->viewable ? $userInfo->viewable: (int)$todayViews;
        return (array)$userInfo;

    }
};