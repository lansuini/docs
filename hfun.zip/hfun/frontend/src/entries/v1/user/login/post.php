<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/1
 * Time: 9:57
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;

return new class extends Action {
    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run() {

        (new BaseValidate(
            [
//                'type'=>'require|in:1,2,3',
                'key' =>'require',
                'pass' =>'require',
            ],
            [],
            [
                'key' =>'账号',
                'pass' =>'密码',
            ]))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParsedBody();

        $user = DB::table('user')->where('mobile',$params['key'])->first();
        if(empty($user))
//            print_r(DB::getQueryLog());
            return $this->lang->set(51);
        if($user->status == 2)
            return $this->lang->set(54);


        if(!password_verify($params['pass'],$user->password)){
            return $this->lang->set(129);
        }
        $res = $this->auth->baseLogin((array)$user);

//        $userId = $this->auth->getUserId();
//        $udid = md5($_SERVER['HTTP_UDID']);
//        $udid_uid = 'udid_uid';
//        $last_uid = $this->redis->hget($udid_uid,$udid);
//        $uid_udid = 'uid_udid';
//        $last_udid = $this->redis->hget($uid_udid,$udid);
//        if(!$last_uid && !$last_udid ){
//            //如果缓存两个都为0，就设置
//            $this->redis->hset($udid_uid,$udid,$userId);
//            $this->redis->hset($uid_udid,$userId,$udid);
//        }
//        if(!$last_uid && $last_udid ){
//            //更换了设备，查出以前的udid
//            $hkey = \Logic\Define\CacheKey::$perfix['todayViewMovies'];
//
//            if($this->redis->hexists($hkey.'_'.$last_udid)){
//                $this->redis->hmset($hkey.'_'.$last_udid,$hkey.'_'.$udid);
//            }
//
//        }

        return $res;

    }
};