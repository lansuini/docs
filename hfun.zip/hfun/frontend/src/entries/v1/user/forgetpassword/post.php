<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/1
 * Time: 9:57
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;

return new class extends Action {

    public function run() {

        (new BaseValidate(
            [
//                'type'=>'require|in:1,2,3',
                'telphone_code'=>'require',
                'telphone'=>'require|length:11|number',
                'txt_code' =>'require|number|length:6',
                'password'=>'require|length:6,20'
            ],
            [],
            [
                'telphone_code'=>'手机区号',
                'telphone' =>'手机号',
                'txt_code' =>'验证码',
                'password' =>'新密码',
            ]))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();
        $user = DB::table('user')->where('mobile',$params['telphone'])->first();
        if(empty($user))
            return $this->lang->set(51);
        $val = (new \Logic\Captcha\Captcha($this->ci))->validateTextCode($params['telphone_code'].$params['telphone'],$params['txt_code']);
        if (!$val) {
            return $this->lang->set(10045);
        }

        $res = DB::table('user')->where('id',$user->id)->update(['password'=>password_hash($params['password'],PASSWORD_DEFAULT)]);
        if($res === false)
            return $this->lang->set(-2);
        return $this->lang->set(0);
    }
};