<?php
use Utils\Www\Action;
use lib\validate\BaseValidate;
/**
 * 推广列表
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run() {

        $page = $this->request->getParam('page',1);
        $page_size = $this->request->getParam('page_size',15);

        $udid = md5($_SERVER['HTTP_UDID']);
        $verify = $this->auth->verfiyToken();
        if ($verify->allowNext()) {
            $userId = $this->auth->getUserId();
            $user_info = DB::table('user')->find($userId);

        }else{
            $user_info = DB::table('user')->where('udid',$udid)->first();

        }

        if(!$user_info)
            return [];
        $query = DB::table('user')
            ->selectRaw('name,mobile,created')
            ->where('pid',$user_info->id);

        $total = $query->count();
        if(!$total)
            return [];
        $user = $query->forPage($page,$page_size)->orderByDesc('created')->get()->toArray();
//        print_r(DB::getQueryLog());exit;
        $attributes['total'] = $total;
        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;
        return $this->lang->set(0,[],$user,$attributes);

    }
};