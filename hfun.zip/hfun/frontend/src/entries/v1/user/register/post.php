<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/10/31
 * Time: 16:58
 */
use Utils\Www\Action;
use lib\validate\BaseValidate;
use lib\exception\BaseException;
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];

    public $pv = 'mango';

    public function run() {

        $udid = md5($_SERVER['HTTP_UDID']);
        $this->pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : 'mango';

        (new BaseValidate(
            [
                'invit_code'=>'max:8',
                'txt_code'=>'require|number',
                'telphone_code'=>'require',
                'telphone'=>'require|length:11|number|unique:user,mobile',
                'password'=>'require|length:6,15',
            ],
            [],
            [
                'invit_code'=>'邀请码',
                'txt_code'=>'验证码',
                'telphone_code'=>'手机区号',
                'telphone'=>'手机号',
                'password'=>'密码',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $mobile = $this->request->getParam('telphone');
        $telphoneCode = $this->request->getParam('telphone_code','+86');
        $invitCode = $this->request->getParam('invit_code','');
        $txtCode = $this->request->getParam('txt_code','');
        $password = $this->request->getParam('password');


        $val = (new \Logic\Captcha\Captcha($this->ci))->validateTextCode($telphoneCode.$mobile,$txtCode);
        if (!$val) {
            return $this->lang->set(10045);
        }

        $userInfo = DB::table('user')->where('udid',$udid)->first();

        if(empty($userInfo)){
            //游客信息为空
            $userId = $this->registerByEmptyUser($mobile,$telphoneCode,$password,$invitCode,$udid);

        } elseif($userInfo && $userInfo->password){
            //游客信息不为空且已经绑定手机则新建
            $userId = $this->registerByEmptyUdid($mobile,$telphoneCode,$password,$invitCode);
        }else{
            //游客信息不为空但未绑定手机则绑定手机
            $userId = $this->registerByMobile($mobile,$telphoneCode,$password,$invitCode,$udid);
        }


        $user = DB::table('user')->find($userId);
        (new \Logic\Task\Apidata($this->ci))->registerAddTimes($userId, $invitCode);//Add by Taylor 2018-11-27
        $res = $this->auth->baseLogin((array)$user);
        return $res;

    }

    private function registerByEmptyUdid($mobile,$telphoneCode,$password,$invitCode = ''){

        $code = random(8);
        $userData = [
            'account'=>$mobile,
            'name' => 18125644 . $code,
            'invit_code' => $code,
            'mobile'=>$mobile,
            'tel_code'=>$telphoneCode,
            'password'=>password_hash($password,PASSWORD_DEFAULT),
            'device_type'=>get_device_type(),
            'register_ip' => DB::getIPv6(),
            'pv' => $this->pv,
            'last_login_ip'   => DB::getIPv6(),
            'region' => \Utils\Utils::gerIpRegion2(\Utils\Client::getIp()),
        ];
        try{
            DB::beginTransaction();
            if($invitCode){
                $upUser = DB::table('user')->where('invit_code',$invitCode)->first();
                if($upUser){
                    DB::table('user')->where('invit_code',$invitCode)->increment('invit_num',1);
                    $userData['pid'] = $upUser->id;
                }
            }
            $userId = DB::table('user')->insertGetId($userData);
            DB::table('user_info')->insert(['user_id'=>$userId]);
            DB::table('user_data')->insert(['user_id'=>$userId]);
            DB::commit();
            return $userId;
        }catch (\Exception $e){

            DB::rollback();
            $newResponse = $this->response->withStatus(400);
            $newResponse = $newResponse->withJson([
                'state' => -2,
                'message' => '注册失败！',
                'ts' => time(),
            ]);
            throw new BaseException($this->request, $newResponse);
        }


    }

    private function registerByEmptyUser($mobile,$telphoneCode,$password,$invitCode = '',$udid){

        $level = DB::table('level')->where('level', 1)->first();
        $code = random(8);
        $userData = [
            'udid' => $udid,
            'name' => 18125644 . $code,
            'invit_code' => $code,
            'viewable' => $level->viewable,
            'downloadable' => $level->downloadable,
            'device_type' => get_device_type(),
            'account'=>$mobile,
            'mobile'=>$mobile,
            'tel_code'=>$telphoneCode,
            'password'=>password_hash($password,PASSWORD_DEFAULT),
            'register_ip' => DB::getIPv6(),
            'pv' => $this->pv,
            'last_login_ip'   => DB::getIPv6(),
            'region' => \Utils\Utils::gerIpRegion2(\Utils\Client::getIp()),
        ];
        try {
            DB::beginTransaction();

            if($invitCode){
                $upUser = DB::table('user')->where('invit_code',$invitCode)->first();
                if($upUser){
                    DB::table('user')->where('invit_code',$invitCode)->increment('invit_num',1);
                    $userData['pid'] = $upUser->id;
                }
            }
            $userId = DB::table('user')->insertGetId($userData);
            DB::table('user_info')->insert(['user_id'=>$userId]);
            DB::table('user_data')->insert(['user_id'=>$userId]);

            DB::commit();
            return $userId;
        } catch (\Exception $e) {

            DB::rollback();
            $newResponse = $this->response->withStatus(400);
            $newResponse = $newResponse->withJson([
                'state' => -2,
                'message' => '注册失败！',
                'ts' => time(),
            ]);
            throw new BaseException($this->request, $newResponse);
        }


    }

    private function registerByMobile($mobile,$telphoneCode,$password,$invitCode = '',$udid){

        $userData = [
            'account' => $mobile,
            'mobile' => $mobile,
            'tel_code' => $telphoneCode,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'device_type' => get_device_type(),
            'register_ip' => DB::getIPv6(),
            'pv' => $this->pv,
            'last_login_ip'   => DB::getIPv6(),
            ];
        try {
            DB::beginTransaction();

            $userInfo = DB::table('user')->where('udid', $udid)->first();

            if (!empty($invitCode) && empty($userInfo->pid)) {

                $upUser = DB::table('user')->where('invit_code', $invitCode)->first();
                if ($upUser) {
                    DB::table('user')->where('invit_code', $invitCode)->increment('invit_num', 1);
                    $userData['pid'] = $upUser->id;
                }

            }
            DB::table('user')->where('id', $userInfo->id)->update($userData);
            DB::commit();
            return $userInfo->id;
        } catch (\Exception $e) {

            DB::rollback();
            $newResponse = $this->response->withStatus(400);
            $newResponse = $newResponse->withJson([
                'state' => -2,
                'message' => '注册失败！',
                'ts' => time(),
            ]);
            throw new BaseException($this->request, $newResponse);
        }
    }

};