<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 添加观看记录
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run() {

        (new BaseValidate(
            [
                'movie_id'=>'require',
                'movie_title'=>'require',
            ],
            [],
            [
                'movie_id'=>'电影',
                'movie_title'=>'电影名称',
            ]
        ))->paramsCheck('',$this->request,$this->response);
        $params = $this->request->getParams();
        $udid = $_SERVER['HTTP_UDID'];
        //如果今天已经看过此部电影，直接返回成功
        $movieExists = $this->redis->hget(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid,$params['movie_id']);
        if($movieExists)
            return $this->lang->set(0);

        $todayViewMoviesExpire = $this->redis->ttl(\Logic\Define\CacheKey::$perfix['todayViewMovies']);
        if($todayViewMoviesExpire<0){

            $ttl = get_ttl();
            $this->redis->expire(\Logic\Define\CacheKey::$perfix['todayViewMovies'],$ttl);
        }
        $verify = $this->auth->verfiyToken();
        //如果是游客，获取游客可观影次数
        if (!$verify->allowNext()) {
            $defaultLevel = DB::table('level')->find(1);
            $viewable = $defaultLevel->viewable;
        }else{
            $userId = $this->auth->getUserId();
            $userInfo = DB::table('user')->selectRaw('mobile,name,invit_code,sex,viewable,avatar,invit_num,level')->find($userId);
            $viewable = $userInfo->viewable;
        }
        $todayViews = $this->redis->hlen(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid);
        if($todayViews >= $viewable){
            return $this->lang->set(20);
        }
        //如果是游客，只记录redis
        if (!$verify->allowNext()) {
            $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid,$params['movie_id'],$params['movie_title']);
//            echo 7777;
//            print_r($this->redis->hgetall(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid));
            return $this->lang->set(0);
        }
        //注册用户添加浏览记录
        try{

            $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid,$params['movie_id'],$params['movie_title']);

            DB::beginTransaction();

            DB::table('user_view')->insert(['user_id'=>$userId,'movie_id'=>$params['movie_id'],'movie_title'=>$params['movie_title']]);
            DB::table('user_data')->where('user_id',$userId)->increment('views',1);
            DB::commit();
        }catch (\Exception $e){
            DB::rollback();
            return $this->lang->set(-2);
        }
//        echo 888;
//        print_r($this->redis->hgetall(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid));
        return $this->lang->set(0);

    }
};