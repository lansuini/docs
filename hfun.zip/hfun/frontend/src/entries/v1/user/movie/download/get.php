<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 收藏列表
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [

    ];
    public function run() {

        $verify = $this->auth->verfiyToken();
        //如果是游客，获取游客可观影次数
        if (!$verify->allowNext()) {
            return $verify;
        }
        $userId = $this->auth->getUserId();
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',2);
        $query = DB::table('user_download as ud')
            ->leftJoin('movie as m','ud.movie_id','=','m.id')
            ->where('user_id',$userId)
            ->select(['m.id','m.title','m.cover','m.cover2,','like','dislike','uc.created','tmp_views as views']);

        $total = $query->count();
        $downloads = $query->forPage($page,$page_size)->get()->toArray();

        $attributes['total'] = $total;
        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;

        return $this->lang->set(0,[],$downloads,$attributes);

    }
};