<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 添加观看记录
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [

    ];
    public function run() {

        $verify = $this->auth->verfiyToken();
        //如果是游客，获取游客可观影次数
        if (!$verify->allowNext()) {
            return $verify;
        }
        $userId = $this->auth->getUserId();

        (new BaseValidate(
            [
                'movie_id'=>'require',
            ],
            [],
            [
                'movie_id'=>'电影',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $exists = DB::table('user_collection')->where('user_id',$userId)->where('movie_id',$params['movie_id'])->first(['movie_id']);
        if($exists) return $this->lang->set(0);
        DB::table('movie')->where('id',$params['movie_id'])->increment('collection',1);
        $res = DB::table('user_collection')->insert(['user_id'=>$userId,'movie_id'=>$params['movie_id']]);
        if(!$res)
            return $this->lang->set(89);

        return $this->lang->set(0);

    }
};