<?php
use Utils\Www\Action;
use lib\validate\BaseValidate;
use Model\UserView;
/**
 * 收藏列表
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [];

    public function run() {
        $verify = $this->auth->verfiyToken();
        if (!$verify->allowNext()) {
            return $verify;
        }
        $userId = $this->auth->getUserId();

        $id = $this->request->getParam('id');
        if(empty($id)){
            return $this->lang->set(886, ['id不能为空']);
        }

        $ids = explode(',', $id);
        $exists = DB::table('user_view')->where('user_id',$userId)->whereIn('movie_id', $ids)->first(['movie_id']);

        if(!$exists){
            return $this->lang->set(886, ['影片信息不存在']);
        }

        $res = DB::table('user_view')->where('user_id',$userId)->whereIn('movie_id',$ids)->delete();
        if(!$res){
            return $this->lang->set(-2);
        }
        return $this->lang->set(0);
    }
};