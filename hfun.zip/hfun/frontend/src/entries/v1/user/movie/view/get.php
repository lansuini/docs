<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 收藏列表
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [

    ];
    public function run($day = 0) {

        $params = $this->request->getParams();
        if(isset($params['day']) && is_numeric($params['day']))
            $day = $params['day'];
        $verify = $this->auth->verfiyToken();
        //如果是游客，获取游客可观影次数
        if (!$verify->allowNext()) {
            return $verify;
        }

        switch ($day){
            case 1:
                $start_date = date("Y-m-d",strtotime("-1 days")).' 23:59:59';
                $end_date = date("Y-m-d").' 23:59:59';
                break;
            case 7:
                $end_date = date("Y-m-d",strtotime("-1 days")).' 23:59:59';
                $start_date = date("Y-m-d",strtotime("-8 days")).' 23:59:59';
                break;
            case 30:
                $end_date = date("Y-m-d",strtotime("-8 days")).' 23:59:59';
                $start_date = date("Y-m-d",strtotime("-30 days")).' 23:59:59';
                break;
            default:
                $end_date = date("Y-m-d").' 23:59:59';
                $start_date = date("Y-m-d",strtotime("-30 days")).' 23:59:59';
                break;
        }
        $userId = $this->auth->getUserId();
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        $query = DB::table('user_view as uv')
            ->leftJoin('movie as m','uv.movie_id','=','m.id')
            ->where('user_id',$userId)
//            ->where('uv.deleted_at',null)
            ->where('uv.created','>',$start_date)
            ->where('uv.created','<=',$end_date)
            ->select(['m.id','m.title','m.cover','m.cover2','like','dislike','uv.created','tmp_views as views']);

        $total = $query->count();
        $views = $query->forPage($page,$page_size)->orderByDesc('uv.created')->get()->toArray();

        $attributes['total'] = $total;
        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;
        return $this->lang->set(0,[],$views,$attributes);

    }
};