<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/10/31
 * Time: 16:58
 */
use Utils\Www\Action;
use lib\validate\BaseValidate;

return new class extends Action {


    public function run() {


        $verify = $this->auth->verfiyToken();
        if (!$verify->allowNext()) {
            return $verify;
        }
        $userId = $this->auth->getUserId();
        $pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : '未知';
        //是否永久
        $permanentKey =  DB::table('cdkey')->where('user_id',$userId)->where('status',2)->where('is_new',1)->first();

        if($permanentKey && empty($permanentKey->dlength))
            return $this->lang->set(10048);

        (new BaseValidate(
            [
                "token"    => "require|length:32",
                "image_code"     => "require|length:4",
                'code'=>'length:12',
            ],
            [],
            [
                'token'=>'验证码',
                'image_code'=>'验证码',
                'code'=>'兑换码',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();

        $val = (new \Logic\Captcha\Captcha($this->ci))->validateImageCode($params['token'], $params['image_code']);
        if (!$val) {
            return $this->lang->set(10045);
        }

        $cdkey = DB::table('cdkey')->where('status',1)->where('code',$params['code'])->lockForUpdate()->first();
        if(!$cdkey){
            return $this->lang->set(10047);
        }

//        $userInfo = DB::table('user')->find($userId);

        try{
            DB::beginTransaction();
            //是否永久
            if($cdkey->dlength === 0){
//                DB::table('user')->where('id',$userId)->update(['vip'=>2]);
                if($permanentKey){
                    DB::table('cdkey')->where('id',$permanentKey->id)->update(['is_new'=>0]);
                }
                DB::table('cdkey')->where('id',$cdkey->id)->update(['user_id'=>$userId,'status'=>2,'origin'=>$pv,'act_date'=>date('Y-m-d H:i:s')]);
            }else{
                if($permanentKey){

                    $currentExp = strtotime($permanentKey->end_date);
                    $exp = $cdkey->dlength * 86400 + $currentExp;
                    DB::table('cdkey')->where('id',$permanentKey->id)->update(['is_new'=>0]);
                }else{
                    $now = time();
                    $exp = $cdkey->dlength * 86400 + $now;
                }

//                DB::table('user')->where('id',$userId)->update(['vip'=>1,'vip_exp'=>date('Y-m-d H:i',$exp)]);
                DB::table('cdkey')->where('id',$cdkey->id)->update(['user_id'=>$userId,'status'=>2,'end_date'=>date('Y-m-d H:i',$exp),'origin'=>$pv,'act_date'=>date('Y-m-d H:i:s')]);

            }

            DB::commit();

        }catch (\Exception $e){

            DB::rollback();
            throw $e;
            return $this->lang->set(-2);
        }

    }
};