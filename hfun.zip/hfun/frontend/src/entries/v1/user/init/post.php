<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/1
 * Time: 9:57
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;

return new class extends Action {
    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public $pv = 'mango';

    public function run() {

        $this->pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : 'mango';
        $udid = md5($_SERVER['HTTP_UDID']);
        $invitCode = $this->request->getParam('invit_code','');

        $user = DB::table('user')->where('udid',$udid)->first();

        if($user){

            $userId = $user->id;
        }else{
            $level = DB::table('level')->where('level',1)->first();
            $code = random(8);
            $userData = [
                'udid'=>$udid,
                'name'=>18125644 .$code,
                'invit_code'=>$code,
                'viewable'=>$level->viewable,
                'downloadable'=>$level->downloadable,
                'device_type'=>get_device_type(),
                'register_ip' => DB::getIPv6(),
                'region' => \Utils\Utils::gerIpRegion2(\Utils\Client::getIp()),
                'pv' => $this->pv,
                'last_login_ip'   => DB::getIPv6(),
            ];
            try{
                DB::beginTransaction();

                $userId = DB::table('user')->insertGetId($userData);
                DB::table('user_info')->insert(['user_id'=>$userId]);
                DB::table('user_data')->insert(['user_id'=>$userId]);
                if(!empty($invitCode)){
                    $upUser = DB::table('user')->where('invit_code',$invitCode)->first();
                    DB::table('user')->where('invit_code',$invitCode)->increment('invit_num',1);
                    DB::table('user')->where('id',$userId)->update(['pid'=>$upUser->id]);
                }
                DB::commit();
                return $this->lang->set(0);
            }catch (\Exception $e){

                DB::rollback();
//                throw $e;
                return $this->lang->set(-2);
            }
        }
        $device_type = get_device_type();
        if($user->device_type != $device_type){
            DB::table('user')->where('udid',$udid)->update(['device_type'=>$device_type]);

        }
        $this->redis->zadd(\Logic\Define\CacheKey::$perfix['onlineUsers'],time(),$userId);

        //活跃统计
        $date = date('Y-m-d');
        $bitmap = 'user_active:'.$date;
        if(!$this->redis->getBit($bitmap,$userId)){
            \Utils\MQServer::send('sum_active', [
                'user_id'   => $userId,
                'device_type' => $device_type,
                'platform'=>$this->pv
            ]);
        }

        return $this->lang->set(0);


    }
};