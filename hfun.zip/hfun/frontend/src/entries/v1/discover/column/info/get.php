<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run($id = '') {

        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
//        $order = $this->request->getQueryParam('order','');

        $column = DB::table('column')->where('display',1)->where('type',2)->find($id);
        if(!$column)
            return $this->lang->set(61);

        $subQuery = DB::table('column_tag as ct')
            ->leftJoin('movie_tag as mt','ct.tag_id','=','mt.tag_id')
            ->where('column_id',$id)
            ->selectRaw('distinct(mt.movie_id)')

            ;
        $total = $subQuery->count(DB::raw('DISTINCT mt.movie_id'));
        if(!$total)
            return [];
        $res = DB::table( DB::raw("({$subQuery
            ->forPage($page,$page_size)
            ->toSql()}) as mt"))
            ->mergeBindings($subQuery)
            ->leftJoin('movie as m','mt.movie_id','=','m.id')
            ->where('status',1)
            ->where('display',1)
            ->selectRaw('id,title,cover,cover2,`like`,dislike')
            ->get()
            ->toArray();
        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$res,$attributes);
    }
};

