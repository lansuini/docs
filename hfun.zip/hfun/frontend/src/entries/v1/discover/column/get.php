<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $columns = DB::table('column')
            ->where('display',1)
            ->selectRaw('id,name,cover')
            ->where('type',2)
            ->orderBy('sort')
            ->get()
            ->toArray();
        return (array)$columns;
    }
};

