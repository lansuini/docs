<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',20);


        $query = DB::table('movie')
            ->where('status',1)
            ->where('display',1)
            ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views');

        $total = $query->count();
        $movies = $query->forPage($page,$page_size)
            ->orderBy('created','desc')
            ->get()
            ->toArray();
        $verify = $this->auth->verfiyToken();
        if($verify->allowNext()){
            $userId = $this->auth->getUserId();
            foreach ($movies as $movie){
                $movie->iscollect = 0;
                $collect = DB::table('user_collection')->where('movie_id',$movie->id)->where('user_id',$userId)->first();
                if($collect)
                    $movie->iscollect = 1;
            }
        }else{
            foreach ($movies as $movie){
                $movie->iscollect = 0;
            }
        }


        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$movies,$attributes);
    }
};

