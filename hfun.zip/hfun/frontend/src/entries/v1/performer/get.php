<?php

use Utils\Www\Action;
return new class extends Action
{


    public function run()
    {

        $params = $this->request->getParams();
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        $order = $this->request->getQueryParam('order','hot');

        $query = DB::table('performer')
            ->where('sex',2)
            ->selectRaw('id,name,des,avatar,cup,height,bwh,movies');

        if(isset($params['cup']) && !empty($params['cup'])){
            if(strtoupper($params['cup']) == 'G'){
                $query = $query->where('cup','>=','G');
            }else{
                $query = $query->where('cup',$params['cup']);
            }
        }
//        $query = isset($params['cup']) && !empty($params['cup']) ? $query->where('cup',$params['cup']) : $query;
        $countQuery = clone $query;
        $attributes['total'] = $countQuery->count();

        $query = $order == 'movies'? $query->orderBy('movies','desc') : $query;
        $query = $order == 'hot'? $query->orderBy('views','desc') : $query;

        $performers = $query
            ->forPage($page,$page_size)
            ->orderBy('sort')
            ->orderBy('created')
            ->get()
            ->toArray();

        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;

        return $this->lang->set(0,[],$performers,$attributes);

    }
};
