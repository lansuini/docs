<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run($id = '') {

        $order = $this->request->getQueryParam('order','new');
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
//        $order = $this->request->getQueryParam('order','');

        $performer = DB::table('performer')->selectRaw('id,name,des,bwh,cup,avatar,height')->find($id);
        if(!$performer)
            return $this->lang->set(63);

        $subQuery = DB::table('performer_movie')
            ->where('performer_id',$id)
            ->selectRaw('movie_id');
        $total = $subQuery->count();
        $query = DB::table( DB::raw("({$subQuery
            
            ->toSql()}) as t_pm"))
            ->mergeBindings($subQuery)
            ->leftJoin('movie as m','pm.movie_id','=','m.id')
            ->where('status',1)
            ->where('display',1)
            ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views')
            ->forPage($page,$page_size)
            ;
        $query = $order == 'hot'? $query->orderBy('m.views','desc') : $query;
        $performer->movies = $query->orderBy('m.created','desc')->get()->toArray();
//        print_r(DB::getQueryLog());
        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;

        return $this->lang->set(0,[],$performer,$attributes);

    }
};

