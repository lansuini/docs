<?php
/**
 * Created by PhpStorm.
 * User: 95684
 * Date: 2018/12/12
 * Time: 20:17
 */

use Utils\Www\Action;
use lib\service\push\Umeng;
return new class extends Action
{



    public function run($id = ''){

        $this->checkID($id);
        $push = DB::table('push_outside')->where('status',1)->find($id);
        if(!$push)
            return $this->lang->set(10015);
        $pv = DB::table('advert_group')->find($push->pv);

        $push_setting = $this->ci->get('settings')['push'][$pv->channel];
        // Set your appkey and master secret here
        switch($push->platform){
            case 1:
                try{
                    $options['app_key'] = $push_setting['android']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['android']['app_master_secret']; //友盟MasterSecret
                    $android_push = new Umeng($options['app_key'], $options['appMasterSecret']);
                    $android_push->sendAndroidBroadcast($push);

                    $options['app_key'] = $push_setting['ios']['app_key']; //友盟key;
                    $options['appMasterSecret'] = $push_setting['ios']['app_master_secret']; //友盟MasterSecret
                    $ios_push = new Umeng($options['app_key'], $options['appMasterSecret']);
                    $ios_push->sendIOSBroadcast($push);

                }catch (\Exception $e){
                    return $this->lang->set(10012, [$e->getMessage()]);
                }

                break;
            case 2:

                $options['app_key'] = $push_setting['ios']['app_key']; //友盟key;
                $options['appMasterSecret'] = $push_setting['ios']['app_master_secret']; //友盟MasterSecret
                $demo = new Umeng($options['app_key'], $options['appMasterSecret']);
                $demo->sendIOSBroadcast($push);
                break;
            case 3:
                $options['app_key'] = $push_setting['android']['app_key']; //友盟key;
                $options['appMasterSecret'] = $push_setting['android']['app_master_secret']; //友盟MasterSecret

                $demo = new Umeng($options['app_key'], $options['appMasterSecret']);
                $demo->sendAndroidBroadcast($push);
                break;
            default:
                $options['app_key'] = $push_setting['android']['app_key']; //友盟key;
                $options['appMasterSecret'] = $push_setting['android']['app_master_secret']; //友盟MasterSecret

                $demo = new Umeng($options['app_key'], $options['appMasterSecret']);
                $demo->sendAndroidBroadcast($push);
                $options['app_key'] = $push_setting['ios']['app_key']; //友盟key;
                $options['appMasterSecret'] = $push_setting['ios']['app_master_secret']; //友盟MasterSecret
                $demo = new Umeng($options['app_key'], $options['appMasterSecret']);
                $demo->sendIOSBroadcast($push);
                break;
        }
        echo 666;
        exit;

        $demo = new Umeng("your appkey", "your app master secret");
        $demo->sendAndroidUnicast();
        /* these methods are all available, just fill in some fields and do the test
         * $demo->sendAndroidBroadcast();
         * $demo->sendAndroidFilecast();
         * $demo->sendAndroidGroupcast();
         * $demo->sendAndroidCustomizedcast();
         * $demo->sendAndroidCustomizedcastFileId();
         *
         * $demo->sendIOSBroadcast();
         * $demo->sendIOSUnicast();
         * $demo->sendIOSFilecast();
         * $demo->sendIOSGroupcast();
         * $demo->sendIOSCustomizedcast();
         */
    }



};