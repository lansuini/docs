<?php
use Utils\Www\Action;
/**
 * test列表
 */
use GuzzleHttp\Client;
return new class extends Action {

    //前置方法
    protected $beforeActionList = [

    ];
    public function run($day = 1) {

        $ip =  \Utils\Client::getIp();
        echo $ip;
        echo "<pre/>";
        echo $this->getIp();
        $res = DB::table('user')->selectRaw("inet_ntoa(last_login_ip) as ip")->limit(10)->orderByDesc('id')->get()->toArray();
        print_r($res);
        exit;


        $ip = $_SERVER['REMOTE_ADDR'];
        $logSetting = $this->ci->get('settings')['log'];
        $log = $logSetting['path'] . 'request.log';
        $client = new Client();
        $res = $client->request('GET', 'http://ip.taobao.com/service/getIpInfo.php?ip='.$ip);

        file_put_contents($log, date('Y-m-d H:i:s') . ":\n" . $res->getStatusCode() . " ip:".$ip . "\n" . $res->getBody() . "\n\n", FILE_APPEND);

        exit;
//        {"where":{"and":[{"or":{"tag":"L1"}}]}}
//        {"where":{"and": [{"tag": "L1"}] }}
//        {"where":{"and":{"tag":"L1"}}}
//        {"where":{"and":[{"tag":"L1"}]}}
//        {"where":{"and":[{"or":[{"tag":"L1"}]}]}}
        $json = '{"policy":{"expire_time":"2018-12-17 16:03:18"},"description":"pkofjiohio","production_mode":true,"appkey":"5c1082b0f1f55661c1000167","payload":{"body":{"title":"gydhuiwk","ticker":"gydhuiwk","text":"hwjjdk","after_open":"go_app","play_vibrate":"false","play_lights":"false","play_sound":"true"},"display_type":"notification"},"filter":{"where":{"and":[{"or":[{"tag":"L1"}]}]}},"type":"groupcast","timestamp":"1544779982898"}';

        print_r(json_decode($json,true));exit;

        $todayViews = $this->redis->exists(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_' . md5(158));
        $todayViewMoviesExpire = $this->redis->ttl(\Logic\Define\CacheKey::$perfix['todayViewMovies'] . '_' . md5(258));
//        var_dump($todayViewMoviesExpire);exit;
        if($todayViewMoviesExpire < 0){
            $ttl = get_ttl();
            $this->redis->set(\Logic\Define\CacheKey::$perfix['todayViewMovies'] .':'.md5(258),$ttl);
        }
        print_r($todayViews);exit;
        echo 666;exit;
//        $verify = $this->auth->verfiyToken();
//        //如果是游客，获取游客可观影次数
//        if (!$verify->allowNext()) {
//            return $verify;
//        }
        if($day>1){
            $date = date("Y-m-d",strtotime("-$day days")).' 23:59:59';
        }else{
            $date = date("Y-m-d");
        }
        $userId = $this->auth->getUserId();
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        $query = DB::table('user_view as uv')
            ->leftJoin('movie as m','uv.movie_id','=','m.id')
            ->where('user_id',$userId)
            ->where('uv.created',$date)
            ->selectRaw('m.id,m.title,m.cover,`like`,dislike,uv.created');

        $views = $query->forPage($page,$page_size)->get()->toArray();

        return (array)$views;

    }


    //获取用户IP地址
    public function getIp()
    {

        if(!empty($_SERVER["HTTP_CLIENT_IP"]))
        {
            $cip = $_SERVER["HTTP_CLIENT_IP"];
        }
        else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
        {
            $cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        }
        else if(!empty($_SERVER["REMOTE_ADDR"]))
        {
            $cip = $_SERVER["REMOTE_ADDR"];
        }
        else
        {
            $cip = '';
        }
        $cip = '2409:8934:8a1d:862a:6b65:8b2d:be89:6074';
        preg_match("/[\d\.]{7,15}/", $cip, $cips);
        $cip = isset($cips[0]) ? $cips[0] : 'unknown';
        unset($cips);

        return $cip;
    }

};