<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 发送短信
 */
return new class extends Action {
    const TITLE = "GET 发送手机验证码";
    const TYPE = "text/json";
    const PARAMs = [
       "telphone" => "string(required) #手机号码",
       "token" => "string(required) #验证码",
       "code" => "string(required) #验证码"
   ];
    const SCHEMAs = [
       200 => [
           "telphone" => "string(required) #手机号码"
       ]
   ];

    public function run() {

        (new BaseValidate(
            [
//                'token'=>'require',
//                'code'=>'require',
                'telphone_code'=>'require',
                'telphone'=>'require',
            ],
            [],
            [
//                'token'=>'验证码',
//                'code'=>'验证码',
                'telphone_code'=>'手机区号',
                'telphone'=>'手机号',
            ]
        ))->paramsCheck('',$this->request,$this->response);

//        $val = (new \Logic\Captcha\Captcha($this->ci))->validateImageCode($params['token'], $params['code']);
//        if (!$val) {
//            return $this->lang->set(10045);
//        }

        $captcha = new \Logic\Captcha\Captcha($this->ci);
        return $captcha->sendTextCode($this->request->getParam('telphone_code').$this->request->getParam('telphone'));

        $code1 = $this->redis->get(\Logic\Define\CacheKey::$perfix['captchaText'] . $this->request->getParam('telphone_code').$this->request->getParam('telphone'));
        $code2 = $this->redis->get(\Logic\Define\CacheKey::$perfix['captchaText'] . $this->request->getParam('telphone'));
        echo '1:'.$code1;
        echo '2:'.$code2;

    }
};