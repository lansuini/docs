<?php
use Utils\Www\Action;
use lib\validate\BaseValidate;
use Model\UserView;
/**
 * 收藏列表
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [

    ];
    public function run() {

//        $verify = $this->auth->verfiyToken();
//        //如果是游客，获取游客可观影次数
//        if (!$verify->allowNext()) {
//            return $verify;
//        }
        print_r($this->request->getHeaders());
        (new BaseValidate(
            [
                'movie_ids'=>'require|array'
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $movie_ids = $this->request->getParsedBodyParam('movie_ids',[]);
        print_r($movie_ids);exit;
        $res = UserView::whereIn('id',$movie_ids)->delete();
        if(!$res)
            return $this->lang->set(-2);

        return $this->lang->set(0);

    }
};