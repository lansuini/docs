<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
return new class extends Action {


    public function run() {

        $cachekey = Logic\Define\CacheKey::$perfix['homeColumn'];
        $data = $this->redis->get($cachekey);
        if(empty($data)){
            $columns = DB::table('column')
                ->where('display',1)
                ->where('type',1)
                ->selectRaw('id,name,des,icon,cover,type')
                ->orderBy('sort')
                ->get()
                ->toArray();
            $this->redis->setex($cachekey,60,json_encode($columns));
        }else{
            $columns = json_decode($data,true);
        }

        return (array)$columns;
    }
};

