<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run($id = '') {

        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        $order = $this->request->getQueryParam('order','');
        if(is_numeric($id) && $id == 0){
//            name,des,icon,cover,type
            $column = ['id'=>0,'name'=>'全部','des'=>'','icon'=>'','cover'=>'','type'=>1,'movies'=>[]] ;

            $query = DB::table('movie')
                ->where('status',1)
                ->where('display',1)
                ->selectRaw('id,title,cover,cover2,tmp_views as views,`like`,dislike,rating');

            $total = $query->count();

            $query = $order == 'hot'? $query->orderBy('views','desc') : $query;
            $query = $order == 'collect'? $query->orderBy('collection','desc') : $query;

            $column['movies'] = $query->forPage($page,$page_size)
                ->orderByDesc('id')
                ->get()
                ->toArray();
        }else{
            $column = DB::table('column')->selectRaw('id,name,des,icon,cover,type')->where('display',1)->find($id);
            if(!$column)
                return $this->lang->set(61);

//            $subQuery = DB::table('column_tag as ct')
//                ->leftJoin('movie_tag as mt','ct.tag_id','=','mt.tag_id')
//                ->where('column_id',$id)
//                ->selectRaw('distinct(t_mt.movie_id)')
//
//            ;
//            $total = $subQuery->count(DB::raw('DISTINCT t_mt.movie_id'));
//            if(!$total)
//                return [];

            $query = DB::table( 'column_movie as mt')
                ->leftJoin('movie as m','mt.movie_id','=','m.id')
                ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views,rating')
                ->where('mt.column_id',$id)
                ->where('status',1)
                ->where('display',1);

            $total = $query->count();

            $query = $order == 'hot'? $query->orderBy('m.views','desc') : $query;
            $query = $order == 'collect'? $query->orderBy('m.collection','desc') : $query;

            $column->movies = $query->forPage($page,$page_size)
                ->orderByDesc('mt.created')
                ->get()
                ->toArray();
        }


        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$column,$attributes);
    }
};

