<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',4);


        $subQuery = DB::table('user_view as uv')
            ->leftJoin('movie as m','uv.movie_id','=','m.id')
            ->where('m.status',1)
            ->where('m.display',1)
            ->selectRaw('movie_id')

            ;
//        $data = $subQuery
//            ->groupBy('movie_id')
//            ->forPage($page,$page_size)
//            ->orderBy(DB::raw('count(movie_id)'),'desc')
//            ->get()
//            ->toArray();
//        print_r($data);exit;
//        $total = $subQuery->count(DB::raw('DISTINCT mt.movie_id'));
        $total = $subQuery->count(DB::raw('DISTINCT movie_id'));
        if(!$total)
            return [];
        $res = DB::table( DB::raw("({$subQuery
            ->groupBy('movie_id')
            ->forPage($page,$page_size)
            ->orderBy(DB::raw('count(movie_id)'),'desc')
            ->toSql()}) as t_mt"))
            ->mergeBindings($subQuery)
            ->leftJoin('movie as m','mt.movie_id','=','m.id')
//            ->where('display',1)
            ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views,rating')
            ->get()
            ->toArray();
        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$res,$attributes);
    }
};

