<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $cachekey = Logic\Define\CacheKey::$perfix['homeTopColumn'];
        $data = $this->redis->get($cachekey);
        if(empty($data)) {

            $columns = DB::table('column_sort as cs')
                ->leftJoin('column as c', 'c.id', '=', 'cs.id')
                ->where('cs.sort_type', '=', 1)
                ->select(['c.id', 'c.name', 'des', 'icon', 'cover', 'c.type', 'created'])
                ->orderBy('cs.sort')
                ->get()
                ->toArray();

            foreach ($columns as $column) {

                $limit = 4;
                if ($column->type == 2)
                    $limit = 6;

                $column->movies = DB::table('column_movie as cm')
                    ->leftJoin('movie as m', 'cm.movie_id', '=', 'm.id')
                    ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views,rating')
                    ->where('column_id', $column->id)
                    ->limit($limit)
                    ->get()
                    ->toArray();
            }

            $this->redis->setex($cachekey,60,json_encode($columns));
        }else{
            $columns = json_decode($data,true);
        }
//        print_r(DB::getQueryLog());exit;
        return (array)$columns;
    }
};

