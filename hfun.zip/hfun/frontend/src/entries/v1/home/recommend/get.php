<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $verify = $this->auth->verfiyToken();
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        if (!$verify->allowNext()) {
            //如果没登录，返回收藏最多的
            $subQuery = DB::table('user_collection')
                ->selectRaw('movie_id');

            $total = $subQuery->count(DB::raw('DISTINCT movie_id'));
            if(!$total)
                return [];
            $res = DB::table( DB::raw("({$subQuery
            ->groupBy('movie_id')
            ->forPage($page,$page_size)
            ->orderBy(DB::raw('count(movie_id)'),'desc')
            ->toSql()}) as t_mt"))
                ->mergeBindings($subQuery)
                ->leftJoin('movie as m','mt.movie_id','=','m.id')
                ->where('status',1)
                ->where('display',1)
                ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views')
                ->get()
                ->toArray();
        }else{
            //已经登录，返回观看最多的电影标签系列电影
            $userId = $this->auth->getUserId();

            $tag = DB::table('user_view as uv')
                ->leftJoin('movie_tag as mt','uv.movie_id','=','mt.movie_id')
                ->where('uv.user_id',$userId)
                ->groupBy('mt.tag_id')
                ->orderBy(DB::raw('count(t_mt.tag_id)'),'desc')
                ->first(['mt.tag_id'])
            ;


            $subQuery = DB::table('movie_tag')
                ->selectRaw('movie_id')
                ->where('tag_id',$tag->tag_id)
            ;

            $query = DB::table( DB::raw("({$subQuery
            ->forPage($page,$page_size)
            ->orderBy('created','desc')
            ->toSql()}) as t_mt"))
                ->mergeBindings($subQuery)
                ->leftJoin('movie as m','mt.movie_id','=','m.id')
                ->where('status',1)
                ->where('display',1);

            $total = $query->count('mt.movie_id');
            $res = $query->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views')
                ->get()
                ->toArray();
        }

        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$res,$attributes);
    }
};

