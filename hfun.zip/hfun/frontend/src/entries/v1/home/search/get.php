<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run() {

        (new BaseValidate(
            [
                'keyword'=>'require|max:20'
            ],
            [],
            ['keyword'=>'关键词']
        ))->paramsCheck('',$this->request,$this->response);


        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        $params = $this->request->getParams();

        try{
            $udid = $this->auth->getUdid();
            $userInfo = DB::table('user')->where('udid',$udid)->first();
            if(!$userInfo){
                $data['user_id'] = 0;
            }else{
                $data['user_id'] = $userInfo->id;
            }
            $data['content'] = $params['keyword'];
            DB::table('user_search')->insert($data);
            $query  = DB::table('movie as m')
                ->leftJoin('movie_tag as mt','m.id','=','mt.movie_id')
                ->leftJoin('tag as t','mt.tag_id','=','t.id')
                ->leftJoin('performer_movie as pm','pm.movie_id','=','m.id')
                ->leftJoin('performer as p','pm.performer_id','=','p.id')
                ->leftJoin('region as r','r.id','=','m.region')
                ->where('m.display',1)
                ->where('m.status',1)
                ->where(function($query) use ($params){
                    $query->where('m.title','like',"%{$params['keyword']}%")
                        ->orWhere('t.name','like',"%{$params['keyword']}%")
                        ->orWhere('p.name','like',"%{$params['keyword']}%")
                        ->orWhere('r.name','like',"%{$params['keyword']}%");
                });
//                ->orWhere('m.title','like',"%{$params['keyword']}%")
//                ->orWhere('t.name','like',"%{$params['keyword']}%");

            $total = $query->count();
            $movies = $query->select([\DB::raw('DISTINCT t_m.id'),'m.title','m.cover','m.cover2','m.like','m.dislike','m.tmp_views as views','m.rating'])
                ->forPage($page,$page_size)
                ->orderByDesc('m.created')
                ->get()
                ->toArray();

        }catch (\Exception $e){
//            throw $e;
            $query = DB::table('movie')
                ->where('status',1)
                ->where('display',1)
                ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views,rating');
            $total = $query->count();
            $movies = $query->forPage($page,$page_size)
                ->orderBy('created','desc')
                ->get()
                ->toArray();
        }

        if(empty($movies)){
            $movies = DB::table('movie')
                ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views,rating')
                ->where('status',1)
                ->where('display',1)
                ->inRandomOrder()
                ->take(10)
                ->get()->toArray();
        }
        foreach ($movies as $movie){
            $movie->tags = DB::table('tag as t')
                ->leftJoin('movie_tag as mt','t.id', '=', 'mt.tag_id')
                ->where('mt.movie_id',$movie->id)
                ->select(['t.id','t.name'])
                ->get()
                ->toArray();
        }
        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
        return $this->lang->set(0,[],$movies,$attributes);


    }
};

