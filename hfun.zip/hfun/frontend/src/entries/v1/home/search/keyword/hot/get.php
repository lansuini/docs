<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);

        $res = DB::table('user_search')
            ->groupBy('content')
            ->forPage($page,$page_size)
            ->orderBy(DB::raw('count(content)'),'desc')
            ->pluck('content')
            ->toArray();

        return (array)$res;
    }
};

