<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);


        $query = DB::table('movie')
            ->where('status',1)
            ->where('display',1)
            ->selectRaw('id,title,cover,cover2,`like`,dislike,tmp_views as views,rating');

        $total = $query->count();
        $res = $query->forPage($page,$page_size)
            ->orderBy('created','desc')
            ->get()
            ->toArray();
        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$res,$attributes);
    }
};

