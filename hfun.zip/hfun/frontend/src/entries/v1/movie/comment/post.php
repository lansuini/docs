<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 添加评论
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [

    ];
    public function run() {

        $verify = $this->auth->verfiyToken();
        //如果是游客，获取游客可观影次数
        if (!$verify->allowNext()) {
            return $verify;
        }
        $userId = $this->auth->getUserId();

        (new BaseValidate(
            [
                'movie_id'=>'require',
                'content'=>'require|max:250',
                'user_name'=>'require|max:50',
            ],
            [],
            [
                'movie_id'=>'电影id',
                'user_name'=>'用户名',
                'content'=>'评论内容',
            ]
        ))->paramsCheck('',$this->request,$this->response);

        $params = $this->request->getParams();


        $res = DB::table('comment')->insert(['user_id'=>$userId,'user_name'=>$params['user_name'],'movie_id'=>$params['movie_id'],'content'=>$params['content']]);
        if(!$res)
            return $this->lang->set(-2);

        return $this->lang->set(0);

    }
};