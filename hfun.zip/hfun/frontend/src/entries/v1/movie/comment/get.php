<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
/**
 * 添加观看记录
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run($id = '') {


        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);

        $query = DB::table('comment')
            ->where('movie_id',$id);
        $total = $query->count();

        $comments = $query->selectRaw('id,user_name,content,created')
            ->forPage($page,$page_size)->get()->toArray();

        $attributes['total'] = $total;
        $attributes['page'] = $page;
        $attributes['page_size'] = $page_size;

        return $this->lang->set(0,[],$comments,$attributes);
    }
};