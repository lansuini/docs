<?php
use Utils\Www\Action;
use lib\validate\BaseValidate;
use lib\exception\BaseException;
/**
 * 添加观看记录
 */

return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public $pv = 'mango';
    public function run($id = '') {

        $this->pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : 'mango';
        $udid = md5($_SERVER['HTTP_UDID']);

        $movie = DB::table('movie')->selectRaw('id,title,des,url,cover,cover2,tmp_views as views,created,`like`,dislike,rating,size,duration')
            ->where('id',$id)
            ->where('status',1)
            ->first();

        if(empty($movie)){
            return $this->lang->set(87);
        }
        $tags = DB::table('movie_tag as mt')
            ->leftJoin('tag as t','mt.tag_id','=','t.id')
            ->where('movie_id',$id)
            ->select(['t.id','t.name'])
            ->get()
            ->toArray();

        $movie->tags = $tags;
        $movie->iscollect = 0;
        $verify = $this->auth->verfiyToken();
        if($verify->allowNext()){
            $userId = $this->auth->getUserId();
            $collect = DB::table('user_collection')->where('movie_id',$id)->where('user_id',$userId)->first();
            if($collect)
                $movie->iscollect = 1;
            $download = DB::table('user_download')->where('movie_id',$id)->where('user_id',$userId)->first();
            if($download)
                $movie->isdownload = 1;
        }else{
            $userInfo = DB::table('user')->where('udid',$udid)->first();
            if(!$userInfo){
                $userId = $this->registerByEmptyUser($udid);
            }else{
                $userId = $userInfo->id;
            }
        }

        $this->redis->zadd(\Logic\Define\CacheKey::$perfix['onlineUsers'],time(),$userId);
        //如果今天已经看过此部电影，直接返回成功
        $movieExists = $this->redis->hexists(\Logic\Define\CacheKey::$perfix['todayViewMovies'].':'.$udid,$movie->id);

        if($movieExists){
            DB::table('movie')->where('id',$movie->id)->increment('views',1);
            return (array)$movie;

        }



        //如果是游客，获取游客可观影次数
        if (!$verify->allowNext()) {
            $userInfo = DB::table('user')->where('udid',$udid)->first();
            if(!$userInfo){
                $level = DB::table('level')->where('level',1)->first();
                $code = random(8);
                $userData = [
                    'udid'=>$udid,
                    'name'=>18125644 .$code,
                    'invit_code'=>$code,
                    'viewable'=>$level->viewable,
                    'downloadable'=>$level->downloadable,
                    'device_type'=>get_device_type(),
                    'register_ip' => DB::getIPv6(),
                    'region' => \Utils\Utils::gerIpRegion2(\Utils\Client::getIp()),
                    'pv'          => $this->pv
                ];
                try{
                    DB::beginTransaction();

                    $userId = DB::table('user')->insertGetId($userData);
                    DB::table('user_info')->insert(['user_id'=>$userId]);
                    DB::table('user_data')->insert(['user_id'=>$userId]);

                    DB::commit();
                }catch (\Exception $e){

                    DB::rollback();
                    return $verify;
//                    return $this->lang->set(-2);
                }
                $userInfo = DB::table('user')->where('udid',$udid)->first();

            }

        }else{
            $userId = $this->auth->getUserId();
            $userInfo = DB::table('user')->find($userId);
            $isvip = DB::table('cdkey')
                ->where('user_id',$userId)
                ->where('status',2)
                ->where('is_new',1)
                ->where(function($query) {
                    $query->where('end_date','>',date('Y-m-d H:i:s'))
                        ->orWhere('dlength',0);
                        })
                ->get()->toArray();

            if($isvip){
                $this->addViewRecord(2,$movie,$udid,$userId);
                return (array)$movie;
            }

        }
        $updata = [];
        $device_type = get_device_type();
        if($userInfo->device_type != $device_type){
            $updata['device_type'] = $device_type;
        }

        if(empty($userInfo->region)){
            $updata['region'] = \Utils\Utils::gerIpRegion2(\Utils\Client::getIp());
        }

        if($updata){
            DB::table('user')->where('udid',$udid)->update($updata);

        }

        $viewable = DB::table('level')->where('level','<=',$userInfo->level)->sum('viewable');

        $api_logic = new \Logic\Task\Apidata($this->ci);
        $times = $api_logic->getTaskTimes($userInfo->id);//福利任务对应的观影次数和缓存次数
        $viewable = $viewable + $times['look_times'];
        //判断观影次数是否足够
        $todayViews = $this->redis->hlen(\Logic\Define\CacheKey::$perfix['todayViewMovies'].':'.$udid);
        if($todayViews >= $viewable){
            if(!$verify->allowNext()){
                return $verify;
            }
            return $this->lang->set(20);
        }

        //如果是游客，只记录redis
        if (!$verify->allowNext()) {
            $this->addViewRecord(1,$movie,$udid,'');

//            $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid,$movie->id,$movie->title);
//            DB::table('movie')->where('id',$movie->id)->increment('views',1);
            return (array)$movie;
        }


        //注册用户添加浏览记录
        $this->addViewRecord(2,$movie,$udid,$userId);
//        try{
//
//            $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayViewMovies'].'_'.$udid,$movie->id,$movie->title);
//
//            DB::beginTransaction();
//
//            DB::table('user_view')->insert(['user_id'=>$userId,'movie_id'=>$movie->id,'movie_title'=>$movie->title]);
//            DB::table('user_data')->where('user_id',$userId)->increment('views',1);
//            DB::table('movie')->where('id',$movie->id)->increment('views',1);
//            DB::commit();
//        }catch (\Exception $e){
//            DB::rollback();
//            throw $e;
//            return $this->lang->set(-2);
//        }
        return (array)$movie;

    }


    public function addViewRecord($type = 1,$movie = '',$udid = '',$userId = '' ){
        if($type == 1){
            $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayViewMovies'].':'.$udid,$movie->id,$movie->title);
            DB::table('movie')->where('id',$movie->id)->increment('views',1);
        }else{
            //注册用户添加浏览记录
            try{

                $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayViewMovies'].':'.$udid,$movie->id,$movie->title);

                DB::beginTransaction();

                DB::table('user_view')->insert(['user_id'=>$userId,'movie_id'=>$movie->id]);
                DB::table('user_data')->where('user_id',$userId)->increment('views',1);
                DB::table('movie')->where('id',$movie->id)->increment('views',1);
                DB::commit();
            }catch (\Exception $e){
                DB::rollback();
                throw $e;
                return $this->lang->set(-2);
            }
        }
        $todayViewMoviesExpire = $this->redis->ttl(\Logic\Define\CacheKey::$perfix['todayViewMovies'] .':'.$udid);
        if($todayViewMoviesExpire<0){
            $ttl = get_ttl();
            $this->redis->expire(\Logic\Define\CacheKey::$perfix['todayViewMovies'] .':'.$udid,$ttl);
        }
    }

    private function registerByEmptyUser($udid){

        $level = DB::table('level')->where('level', 1)->first();
        $code = random(8);
        $userData = [
            'udid' => $udid,
            'name' => 18125644 . $code,
            'invit_code' => $code,
            'viewable' => $level->viewable,
            'downloadable' => $level->downloadable,
            'device_type' => get_device_type(),
            'register_ip' => DB::getIPv6(),
            'pv' => $this->pv,
            'region' => \Utils\Utils::gerIpRegion2(\Utils\Client::getIp()),
        ];
        try {
            DB::beginTransaction();

            $userId = DB::table('user')->insertGetId($userData);
            DB::table('user_info')->insert(['user_id'=>$userId]);
            DB::table('user_data')->insert(['user_id'=>$userId]);

            DB::commit();
            return $userId;
        } catch (\Exception $e) {

            DB::rollback();
            $newResponse = $this->response->withStatus(400);
            $newResponse = $newResponse->withJson([
                'state' => -2,
                'message' => '注册设备失败！',
                'ts' => time(),
            ]);
            throw new BaseException($this->request, $newResponse);
        }


    }
};