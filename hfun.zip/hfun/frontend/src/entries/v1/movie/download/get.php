<?php
use Utils\Www\Action;
use lib\validate\IDMustBePositiveInteger;
/**
 * 添加观看记录
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run($id = '') {

        (new \Logic\Validate\Common($this->ci))->checkID($id);

        $verify = $this->auth->verfiyToken();
        if(!$verify->allowNext()){
            return $verify;
        }
        $userId = $this->auth->getUserId();

        $movie = DB::table('movie')->selectRaw('id,title,des,url,cover,cover2,`like`,dislike,size,duration')
            ->where('id',$id)
            ->where('status',1)
            ->first();

        if(empty($movie)){
            return $this->lang->set(87);
        }
        $userInfo = DB::table('user')->selectRaw('mobile,name,invit_code,sex,viewable,downloadable,avatar,invit_num,level,vip,vip_exp')->find($userId);
        $api_logic = new \Logic\Task\Apidata($this->ci);
        $times = $api_logic->getTimes($userId);//福利任务对应的观影次数和缓存次数
        $downloadable = $userInfo->downloadable + $times['cache_times'];


        $udid = md5($_SERVER['HTTP_UDID']);
        //如果今天已经下载过此部电影，直接返回成功
        $movieExists = $this->redis->hexists(\Logic\Define\CacheKey::$perfix['todayDownMovies'].'_'.$udid,$movie->id);
        if($movieExists)
            return (array)$movie;
        $isvip = DB::table('cdkey')
            ->where('user_id',$userId)
            ->where('status',2)
            ->where('is_new',1)
            ->where(function($query) {
                $query->where('end_date','>',date('Y-m-d H:i:s'))
                    ->orWhere('dlength',0);
            })
            ->get()->toArray();
        if($isvip){
            try{

                $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayDownMovies'].':'.$udid,$movie->id,$movie->title);

                DB::beginTransaction();

                DB::table('user_download')->insert(['user_id'=>$userId,'movie_id'=>$movie->id,'movie_title'=>$movie->title]);
                DB::table('user_data')->where('user_id',$userId)->increment('download',1);
                DB::table('movie')->where('id',$movie->id)->increment('download',1);
                DB::commit();
                return (array)$movie;
            }catch (\Exception $e){
                DB::rollback();
                throw $e;
                return $this->lang->set(-2);
            }
        }

        $todayDownMoviesExpire = $this->redis->ttl(\Logic\Define\CacheKey::$perfix['todayDownMovies'].':'.$udid);
        if($todayDownMoviesExpire<0){
            $ttl = get_ttl();
            $this->redis->expire(\Logic\Define\CacheKey::$perfix['todayDownMovies'].':'.$udid,$ttl);
        }

        //判断下载次数是否足够
        $todayDowns = $this->redis->hlen(\Logic\Define\CacheKey::$perfix['todayDownMovies'].':'.$udid);
        if($todayDowns >= $downloadable){
//            echo $downloadable;
            return $this->lang->set(21);
        }


        //注册用户添加浏览记录
        try{

            $this->redis->hset(\Logic\Define\CacheKey::$perfix['todayDownMovies'].':'.$udid,$movie->id,$movie->title);

            DB::beginTransaction();
            $movieExists = DB::table('user_download')->where('user_id',$userId)->where('movie_id',$movie->id)->first();
            if($movieExists){
                DB::table('user_download')->where('user_id',$userId)->where('movie_id',$movie->id)->update(['created'=>date('Y-m-d H:i:s')]);
            }else{
                DB::table('user_download')->insert(['user_id'=>$userId,'movie_id'=>$movie->id]);
                DB::table('user_data')->where('user_id',$userId)->increment('download',1);
                DB::table('movie')->where('id',$movie->id)->increment('download',1);
            }

            DB::commit();
            return (array)$movie;
        }catch (\Exception $e){
            DB::rollback();
            throw $e;
            return $this->lang->set(-2);
        }

    }
};