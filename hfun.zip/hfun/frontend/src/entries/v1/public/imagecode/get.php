<?php
use Utils\Www\Action;
/**
 * 图形验证码
 */
return new class extends Action {
    //前置方法
    protected $beforeActionList = [
        'establish'

    ];
    public function run() {
        return (new \Logic\Captcha\Captcha($this->ci))->getImageCode();
    }
};