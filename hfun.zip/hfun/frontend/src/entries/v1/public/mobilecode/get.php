<?php
use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {
    const TITLE = "GET 发送手机验证码";
    const TYPE = "text/json";
    const QUERY = [
       "telphone" => "string(required) #手机号码"
   ];
    const SCHEMAs = [
       200 => [
           "telphone" => "string(required) #手机号码"
       ]
   ];


    public function run() {

        (new BaseValidate(
            [
                'telphone_code'=>'require',
                'telphone'=>'require',
            ],
            [],
            [
                'telphone_code'=>'手机区号',
                'telphone'=>'手机号',
            ]
        ))->paramsCheck('',$this->request,$this->response);


        $phoneCode = $this->request->getQueryParam('telphone_code', '+86');
        $mobile = $this->request->getQueryParam('telphone');
        //手机号
        if(!empty($mobile)){
            $len=strlen($phoneCode);
            $phoneCode=substr($phoneCode,1,$len);
            if($phoneCode=='86'){
                if(!preg_match("/^1[3456789]{1}\d{9}$/",$mobile)){
                    return $this->lang->set(140);
                }

                if(strlen($mobile)>11){
                    return $this->lang->set(141);
                }
                if(strlen($mobile)<11){
                    return $this->lang->set(141);
                }
            }

            if(!preg_match("/^\d*$/",$mobile)){
                return $this->lang->set(140);
            }

            if(strlen($mobile)>15){
                return $this->lang->set(143);
            }
        }
        $mobile = Utils\Utils::RSAEncrypt($mobile);
        if(\Model\User::where('mobile', $mobile)->count() > 0){
            return $this->lang->set(144);
        }

        return [];
    }
};