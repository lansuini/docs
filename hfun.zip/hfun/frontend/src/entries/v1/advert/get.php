<?php

use Utils\Www\Action;
use Model\Advert;
return new class extends Action {


    public function run()
    {
        $pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : 'mango';

        $platform = DB::table('platform')->where('channel',$pv)->first();
        if($platform){
            $group_id = $platform->id;
        }else{
            $group_id = 1;
        }
        $cachekey = Logic\Define\CacheKey::$perfix['advert'];
        $data = $this->redis->get($cachekey);
        if(empty($data)){
            $key = \Logic\Set\SetConfig::SET_GLOBAL;
            $adverts = Logic\Set\SetConfig::DATA[$key]['base']['advert'];//获取各个模块的默认值
            $res = Advert::where('status',1)->where('group_id',$group_id)->orderBy('sort')->get()->groupBy('position');
            $data = [];
            foreach ($adverts  as $k=>$val){

                $single['position'] = $k;
                $single['compart'] = $val;

                $single['list'] = isset($res[$k]) ? $res[$k]->makeHidden(['sort','group_id','type','position','compart','content','status','created','updated','deleted_at'])->toArray() : [];

                array_push($data,$single);
            }
            $this->redis->setex($cachekey,30,json_encode($data));
        }else{
            $data = json_decode($data,true);
        }

        return $data;

    }
};
