<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use Respect\Validation\Validator as V;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $cachekey = Logic\Define\CacheKey::$perfix['channelTag'];
        $data = $this->redis->get($cachekey);
        if(empty($data)) {

            $attrs = DB::table('tag_attr')->select(['id', 'name'])->get()->toArray();
            foreach ($attrs as &$attr) {
                $attr->tags = DB::table('tag')->where('attr_id', $attr->id)->get(['id', 'name'])->toArray();
            }
            $this->redis->setex($cachekey,60,json_encode($attrs));
        }else{
            $attrs = json_decode($data,true);
        }
        return $attrs;
    }
};

