<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {
        (new BaseValidate(
            [
                'tags'=>'require|array'
            ],
            [],
            ['tags'=>'标签']
        ))->paramsCheck('',$this->request,$this->response);
        $page = $this->request->getQueryParam('page',1);
        $page_size = $this->request->getQueryParam('page_size',10);
        $params = $this->request->getParams();
//        print_r($params);exit;
        $query = DB::table('movie_tag as mt')
            ->leftJoin('movie as m','mt.movie_id','=','m.id')
            ->whereIn('mt.tag_id',$params['tags'])
            ->where('status',1)
            ->where('m.display',1);
        $total = $query->count();
        $movies = $query->selectRaw('distinct(`id`),title,cover,cover2,`like`,dislike,tmp_views as views,rating')
            ->orderByDesc('m.created')
            ->forPage($page,$page_size)
            ->get()
            ->toArray();
        foreach ($movies as $movie){
            $movie->tags = DB::table('tag as t')
                ->leftJoin('movie_tag as mt','t.id', '=', 'mt.tag_id')
                ->where('mt.movie_id',$movie->id)
                ->select(['t.id','t.name'])
                ->get()
                ->toArray();
        }
        $attributes['total'] = $total;
        $attributes['number'] = $page;
        $attributes['size'] = $page_size;
//        print_r(DB::getQueryLog());
        return $this->lang->set(0,[],$movies,$attributes);
    }
};

