<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/14
 * Time: 14:08
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {


        $cachekey = Logic\Define\CacheKey::$perfix['channelPerformerHot'];
        $data = $this->redis->get($cachekey);
        if(empty($data)) {
            $performers = DB::table('performer_sort as ps')
                ->leftJoin('performer as p', 'ps.id', '=', 'p.id')
                ->select(['p.id', 'p.name', 'des', 'avatar', 'cup', 'height', 'bwh'])
                ->orderBy('ps.sort')
                ->get()
                ->toArray();

            foreach ($performers as $performer) {

                $performer->movies_count = DB::table('performer_movie')->where('performer_id', $performer->id)->count();

                $performer->movies = DB::table('performer_movie as pm')
                    ->leftJoin('movie as m', 'pm.movie_id', '=', 'm.id')
                    ->where('pm.performer_id', $performer->id)
                    ->selectRaw('t_m.id,title,cover,cover2,des,`like`,dislike,tmp_views as views')
                    ->orderBy('m.created', 'desc')
                    ->limit(10)
                    ->get()
                    ->toArray();
            }
            $this->redis->setex($cachekey,60,json_encode($performers));
        }else{
            $performers = json_decode($data,true);
        }
//        print_r(DB::getQueryLog());
        return (array)$performers;
    }
};