<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/11/5
 * Time: 14:38
 */

use Utils\Www\Action;
use lib\validate\BaseValidate;
return new class extends Action {


    public function run() {

        $cachekey = Logic\Define\CacheKey::$perfix['channelTopColumn'];
        $data = $this->redis->get($cachekey);
        if(empty($data)) {
            $columns = DB::table('column_sort as cs')
                ->join('column as c',function($join){
                    $join->on('c.id','=','cs.id')
                        ->where('cs.sort_type','=',2);
                }, null,null,'left')
                ->where('c.type',2)
                ->select(['c.id','c.name','des','icon','cover','c.type','created'])
                ->orderBy('cs.sort')
                ->get()
                ->toArray();
            $this->redis->setex($cachekey,60,json_encode($columns));
        }else{
            $columns = json_decode($data,true);
        }

        return (array)$columns;
    }
};

