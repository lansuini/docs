<?php
use Utils\Www\Action;
/**
 * 获取公告信息
 * @author Taylor 2018-11-26
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'
    ];

    public function run() {
        $movie = DB::table('notice')->where('status',1)->first();

        if(empty($movie)){
            return $this->lang->set(886, ['公告不存在']);
        }

        $date = date('Y-m-d H:i:s');
        if($date < $movie->s_time){
            return $this->lang->set(886, ['公告未到时间']);
        }
        if($date > $movie->e_time){
            return $this->lang->set(886, ['公告已过期']);
        }

        return $this->lang->set(0, [], ['title'=>$movie->title, 'content'=>$movie->content]);
    }
};