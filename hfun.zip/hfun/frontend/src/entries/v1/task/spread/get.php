<?php
use Utils\Www\Action;
/**
 * 获取推广信息
 * @author Taylor 2018-11-26
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'
    ];

    public function run() {

        $pv = isset($_SERVER['HTTP_PV']) && !empty($_SERVER['HTTP_PV']) ? $_SERVER['HTTP_PV'] : 'mango';
        $api = new \Logic\Task\Apidata($this->ci);
        $userId = $api->getUserId();

        if(empty($userId)){
            return $this->lang->set(886, ['用户信息不存在']);
        }

        //查询邀请码
        $code = DB::table('user')->where('id', $userId)->pluck('invit_code')->first();
        $invite_code = $code ?? '';

        $conf = DB::table('platform')->where('channel',$pv)->first();
        if(empty($conf)){
            $invite_url = '';
            $invite_content = '';
        }else{
            $invite_url = $conf->spread_url.'?invite_code='.$invite_code;
            $invite_content = str_replace(['【TGM】', '【LJ】'], [$invite_code, $invite_url], $conf->spread_content);
        }

        return $this->lang->set(0, [], ['invite_code'=>$invite_code, 'invite_url'=>$invite_url, 'invite_content'=>$invite_content]);
    }
};