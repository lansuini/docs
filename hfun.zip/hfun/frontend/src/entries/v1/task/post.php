<?php
use Utils\Www\Action;
/**
 * 演员数据同步
 * @author Taylor 2018-11-29
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
//        'establish'
    ];

    public function run() {
        $post_data = $this->request->getParams();
        $this->logger->info("【python演员数据同步】", $post_data);

        $m_data['des'] = $post_data['briefIntroduction'];//简介
        $m_data['bwh'] = "{$post_data['bust']}-{$post_data['waist']}-{$post_data['hips']}";//胸围-腰围-臀围
        $m_data['bust'] = $post_data['bust'];//胸围
        $m_data['cup'] = $post_data['cup'];//罩杯
        $m_data['height'] = $post_data['height'];//身高
        $m_data['hips'] = $post_data['hips'];//臀部
        $m_data['waist'] = $post_data['waist'];//腰部
        $m_data['name'] = $post_data['nameCn'];//中文名
        $m_data['name_en'] = $post_data['nameEn'];//英文名
        $m_data['name_jpn'] = $post_data['nameJpn'];//日文名
        $m_data['avatar'] = $post_data['photoUrl'];//图像地址
        $m_data['req_json'] = json_encode($post_data);//请求的json
        DB::table('performer_bak')->insert($m_data);

        return $this->lang->set(0);
    }
};