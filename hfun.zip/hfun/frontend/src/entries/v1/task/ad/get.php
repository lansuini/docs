<?php
use Utils\Www\Action;
/**
 * 点击广告领取福利
 * @author Taylor 2018-11-27
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'
    ];

    public function run($id = '') {

        checkID($id,'广告');
        $advert = DB::table('advert')->find($id);
        if(!$advert){
            return;
        }

        $api = new \Logic\Task\Apidata($this->ci);
        $userId = $api->getUserId();

        if(empty($userId)){
            return $this->lang->set(886, ['用户信息不存在']);
        }
        \Utils\MQServer::send('ad_click', [
            'user_id'   => $userId,
            'advert_id' => $id,
            'position' => $advert->position,
            'pv' => $_SERVER['HTTP_PV'],
        ]);
//        点击广告，新增福利
        $api->dailyAddTimes($userId);
        return $this->lang->set(0);
    }
};