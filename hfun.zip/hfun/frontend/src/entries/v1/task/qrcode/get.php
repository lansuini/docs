<?php
use Utils\Www\Action;
/**
 * 保存二维码
 * @author Taylor 2018-11-27
 */
return new class extends Action {

    //前置方法
    protected $beforeActionList = [
        'establish'
    ];

    public function run() {
        $api = new \Logic\Task\Apidata($this->ci);
        $userId = $api->getUserId();

        if(empty($userId)){
            return $this->lang->set(886, ['用户信息不存在']);
        }

        $api->taskAddTimes($userId, 'EWM');
        return $this->lang->set(0);
    }
};