<?php
use Utils\Www\Action;
/**
 * 添加观看记录
 */
return new class extends Action {

    public function run() {
        echo \Utils\Client::getIp(); die();
    }
};