<?php
/**
 * Created by PhpStorm.
 * User: ben
 * Date: 2018/4/8
 * Time: 13:41
 */

function createRsponse($response, $status = 200, $state = 0, $message = 'ok', $data = null, $attributes = null) {

    return $response
        // ->withHeader('Access-Control-Allow-Origin', '*')
        // ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        // ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
        ->withStatus($status)
        ->withJson([
            'data'       => $data,
            'attributes' => $attributes,
            'state'      => $state,
            'message'    => $message,
            'ts'         => time(),
        ]);
}

/**
 * 判断值是否是大于0的正整数
 *
 * @param $value
 *
 * @return bool
 */
function isPositiveInteger($value) {
    if (is_numeric($value) && is_int($value + 0) && ($value + 0) > 0) {
        return true;
    } else {
        return false;
    }
}


/**
 * 使用正则验证数据
 *
 * @access public
 *
 * @param string $value
 *            要验证的数据
 * @param string $rule
 *            验证规则
 *
 * @return boolean
 */
function regex($value, $rule) {

    $validate = [
        'require'      => '/\S+/',
        'email'        => '/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/',
        'mobile'       => '/^((13[0-9]{1})|(14[5,7,8,9]{1})|(15[0-35-9]{1})|(166)|(17[0234678]{1})|(18[0-9]{1})|(19[89]{1}))\d{8}$/',
        'phone'        => '/^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/',
        'url'          => '/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(:\d+)?(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/',
        'currency'     => '/^\d+(\.\d+)?$/',
        'number'       => '/^\d+$/',
        'zip'          => '/^\d{6}$/',
        'integer'      => '/^[-\+]?\d+$/',
        'double'       => '/^[-\+]?\d+(\.\d+)?$/',
        'english'      => '/^[A-Za-z]+$/',
        'bankcard'     => '/^\d{14,19}$/',
        'safepassword' => '/^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}$/',
        'chinese'      => '/^[\x{4e00}-\x{9fa5}]+$/u',
        'oddsid'       => '/^([+]?\d+)|\*$/',//验证赔率设置id
        'qq'           => '/^[1-9]\\d{4,14}/',//验证qq格式
    ];
    // 检查是否有内置的正则表达式
    if (isset ($validate [strtolower($rule)])) {
        $rule = $validate [strtolower($rule)];
    }

    return 1 === preg_match($rule, $value);
}

    function random($length=12,$type="all"){
        $int_arr = array("0","1","2","3","4","5","6","7","8","9","0");
        $letter_arr = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l");
        $len_data = array();
        for($i=0;$i<$length;$i++){
            switch($type){
                case "int":
                    $rand =  $int_arr;
                    break;
                case "letter":
                    $rand =  $letter_arr;
                    break;
                default:
                    $rand =  array_merge($int_arr,$letter_arr);
                    break;
            }
            $len_data[] = $rand[rand(0,count($rand)-1)];
        }
        return implode("",$len_data);
    }

function is_json($string) {
    json_decode($string);
    return (json_last_error() == JSON_ERROR_NONE);
}

function get_device_type(){
    $agent = strtolower($_SERVER['HTTP_USER_AGENT']);
//    echo $agent;
//    echo "<pre/>";
    $type = 'android';
    if(strpos($agent, 'iphone') || strpos($agent, 'ipad') || strpos($agent, 'ios')){
        $type = 'ios';
    }

    return $type;
}

function get_ttl(){
    $y = date("Y");
    $m = date("m");
    $d = date("d");
    $day_end = mktime(23,59,59,$m,$d,$y);
    $ttl = $day_end - time();
    return $ttl;
}

function checkID($id,$param = ''){
    global $app;
    if (empty($id)) {
        $newResponse = $app->getContainer()->response->withStatus(400);
        $newResponse = $newResponse->withJson([
            'state' => -1,
            'message' => $param.'id不能为空',
            'ts' => time(),
        ]);
        throw new \Slim\Exception\SlimException($app->getContainer()->request,$newResponse);
    }

    if (is_numeric($id) && is_int($id + 0) && ($id + 0) > 0) {
        return true;
    }

    $newResponse = $this->response->withStatus(400);
    $newResponse = $newResponse->withJson([
        'state' => -1,
        'message' => $param.'id必须为正整数',
        'ts' => time(),
    ]);
    throw new BaseException($this->request,$newResponse);
}