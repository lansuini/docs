/* eslint-disable react/react-in-jsx-scope */
import React from "react";
import UploadNewNumber from "./child/UploadNewNumber";
import UploadUsedNumber from "./child/UploadUsedNumber";
import UploadReNumber from "./child/UploadReNumber";
import UploadTickling from "./child/UploadTickling";
import UploadEnNumber from "./child/UploadEnNumber";
import UploadRiskNumber from "./child/UploadRiskNumber";
import UploadEmptyNumber from "./child/UploadEmptyNumber";
import UploadNameNumber from "./child/UploadNameNumber";

import { Table, Popover } from 'antd'
import { ExclamationCircleOutlined } from "@ant-design/icons";
const InvalidTable = (data)=>{
  return (
    <Table
        style={{width:'300px'}}
        scroll={{ x: 200, y: 300 }}
        locale={{
          emptyText: "暂无数据",
        }}
        bordered
        rowKey="id"
        columns={[{
          title: "无效号码",
          dataIndex: "number",
          align: "center",
          width:200
        }]}
        dataSource={data}
        pagination={false}
      />
  );
}




const InvalidList = ({item})=>{
  const list = item.invalid_number_json.map((x,index)=>{
    return {number:x,id:index};
  })
  if(item.invalid_sum === 0){
  return <span>{item.invalid_sum}</span>
  }else{
    return (<Popover content={InvalidTable(list)} title="详情">
              <span>{item.invalid_sum} <ExclamationCircleOutlined/>   </span>
            </Popover>)
  }
};



export const tabList = [
  {
    name: "提交新号码",
    component: (props) => <UploadNewNumber props={props} />,
    id: 1,
  },
  {
    name: "提交使用号码",
    component: (props) => <UploadUsedNumber props={props} />,
    id: 2,
  },
  {
    name: "提交注册号",
    component: (props) => <UploadReNumber props={props} />,
    id: 3,
  },
  {
    name: "提交反馈号",
    component: (props) => <UploadTickling props={props} />,
    id: 4,
  },
  {
    name: "提交沉默号码",
    component: (props) => <UploadEnNumber props={props} />,
    id: 5,
  },
  {
    name: "提交风险号",
    component: (props) => <UploadRiskNumber props={props} />,
    id: 6,
  },
  {
    name: "提交空号",
    component: (props) => <UploadEmptyNumber props={props} />,
    id: 7,
  },
  {
    name: "提交号码姓名",
    component: (props) => <UploadNameNumber props={props} />,
    id: 7,
  },
];

export const UploadNewNumberData = {
  UploadNewNumberTips: [
    "1.文件格式仅支持TXT格式文件，每行一个11位手机号，请确保号码正确无误",
    "2 请确保TXT文件名称包含准确的运营商名称及城市名称，如：北京移动、桂林_联通、xxx_上海_电信_xxx、广州虚拟，系统会自动识别文件名称包含的运营商及城市名称作为入库数据",
    "3.若上传多个文件，请将txt文件打包成后缀为zip格式的压缩包文件后上传",
  ],
  UploadNewNumberTipsColumns: [
    {
      title: "号码",
      key: "num",
      dataIndex: "num",
      align: "center",
      width: 100,
    },
    {
      title: "备注",
      key: "dec",
      dataIndex: "dec",
      align: "center",
      width: 300,
    },
  ],
  UploadNewNumberTipsData: [
    { key: "1", num: "13800138000", dec: "备注内容" },
    { key: "2", num: "13800138000", dec: "备注内容" },
  ],

  UploadNewNumberResultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 200,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      render(text,item){
        return InvalidList({item});
      },
      width: 300,
    },
    {
      title: "实际提交数",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "移动号",
      key: "cmcc_sum",
      dataIndex: "cmcc_sum",
      align: "center",
      width: 300,
    },
    {
      title: "联通号",
      key: "cucc_sum",
      dataIndex: "cucc_sum",
      align: "center",
      width: 300,
    },
    {
      title: "电信号",
      key: "ctcc_sum",
      dataIndex: "ctcc_sum",
      align: "center",
      width: 300,
    },
    {
      title: "虚拟号",
      key: "virtual_sum",
      dataIndex: "virtual_sum",
      align: "center",
      width: 300,
    },
    {
      title: "已关联多个号码包的号码",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 200,
    },
  ],
};

export const UploadUsedNumberData = {
  Tips: [
    "1.文件格式仅支持TXT格式文件，每行一个11位手机号，请确保号码正确无误",
    "2.若上传多个文件，请将txt文件打包成后缀为zip格式的压缩包文件后上传",
    "3.请尽量导入该号码包中已有的号码",
  ],
  TipsColumns: [
    {
      title: "号码",
      key: "num",
      dataIndex: "num",
      align: "center",
      width: 100,
    },
    {
      title: "运营商",
      key: "inter",
      dataIndex: "inter",
      align: "center",
      width: 100,
    },
    {
      title: "归属省",
      key: "sheng",
      dataIndex: "sheng",
      align: "center",
      width: 100,
    },
    {
      title: "归属市",
      key: "shi",
      dataIndex: "shi",
      align: "center",
      width: 100,
    },
    {
      title: "备注",
      key: "desc",
      dataIndex: "desc",
      align: "center",
      width: 100,
    },
  ],
  TipsData: [
    {
      key: "1",
      num: "13800138000",
      inter: "移动",
      sheng: "广西",
      shi: "桂林",
      desc: "",
    },
    {
      key: "1",
      num: "13800138000",
      inter: "联通",
      sheng: "广西",
      shi: "桂林",
      desc: "",
    },
  ],
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      width: 300,
      render(text,item){
        return InvalidList({item});
      },
    },
    {
      title: "实际提交数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "提交平台",
      key: "platform_name",
      dataIndex: "platform_name",
      align: "center",
      width: 300,
    },
    {
      title: "关联多个号码包的号码",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 300,
    },
  ],
};

export const UploadReNumberData = {
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      width: 300,
      render(text,item){
        return InvalidList({item});
      },
    },
    {
      title: "实际提交数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "提交平台",
      key: "platform_name",
      dataIndex: "platform_name",
      align: "center",
      width: 300,
    },
    {
      title: "关联多个号码包的号码",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 300,
    },
  ],
};
const _UploadTicklingData = {
  TipsColumns: [
    {
      title: "号码",
      key: "num",
      dataIndex: "num",
      align: "center",
      width: 100,
    },
    {
      title: "充值金额",
      key: "money1",
      dataIndex: "money1",
      align: "center",
      width: 100,
    },
    {
      title: "盈亏金额",
      key: "money2",
      dataIndex: "money2",
      align: "center",
      width: 100,
    },
  ],
  TipsData: [
    {
      key: "1",
      num: "13800138001",
      inter: "9999",
      sheng: "广西",
      shi: "桂林",
      desc: "",
      money1: "100",
      money2: "300",
      origin: "移动",
    },
    {
      key: "2",
      num: "13800138002",
      inter: "9999",
      sheng: "广西",
      shi: "桂林",
      desc: "",
      money1: "300",
      money2: "-500",
      origin: "联通",
    },
  ],
};

export const UploadTicklingData = {
  Tips: [
    "1.请DBA导出从数据库提取数据时，以Excel的格式（xls、xlxs、cvs）导出",
    "2.数据格式如下：",
    <Table
      columns={_UploadTicklingData.TipsColumns}
      dataSource={_UploadTicklingData.TipsData}
      pagination={false}
      bordered
      size="small"
    ></Table>,
    "3.当盈亏金额为负数时，务必带上负号，以便系统识别",
    "4.已有的号码不会重复导入",
    "5.请尽量导入该号码包中已有的号码",
  ],
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      width: 300,
      render(text,item){
        return InvalidList({item});
      },
    },
    {
      title: "实际提交数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "提交平台",
      key: "platform_name",
      dataIndex: "platform_name",
      align: "center",
      width: 300,
    },
    {
      title: "关联多个号码包的号码",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 300,
    },
  ],
};

export const UploadEnData = {
  Tips: [
    "1.文件格式仅支持TXT格式文件，每行一个11位手机号，请确保号码正确无误",
    "2.若上传多个文件，请将txt文件打包成后缀为zip格式的压缩包文件后上传",
    "3.请尽量导入该号码包中已有的号码，上传后会将号码属性更新为：沉默号",
  ],
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      width: 300,
      render(text,item){
        return InvalidList({item});
      },
    },
    {
      title: "实际提交数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "关联多个号码包号码",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 300,
    },
  ],
};

export const UploadRiskData = {
  Tips: [
    "1.文件格式仅支持TXT格式文件，每行一个11位手机号，请确保号码正确无误",
    "2.若上传多个文件，请将txt文件打包成后缀为zip格式的压缩包文件后上传",
    "3.请尽量导入该号码包中已有的号码，上传后会将号码属性更新为：风险号",
  ],
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "实际导入数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      width: 300,
      render(text,item){
        return InvalidList({item});
      },
    },
    {
      title: "存在其他文件号码数",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 300,
    },
  ],
};

export const UploadEmpytData = {
  Tips: [
    "1.文件格式仅支持TXT格式文件，每行一个11位手机号，请确保号码正确无误",
    "2.若上传多个文件，请将txt文件打包成后缀为zip格式的压缩包文件后上传",
    "3.请尽量导入该号码包中已有的号码，上传后会将号码属性更新为：空号",
  ],
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "实际导入数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    {
      title: "剔除重复号码",
      key: "file_reply_sum",
      dataIndex: "file_reply_sum",
      align: "center",
      width: 300,
    },
    {
      title: "无效数据",
      key: "invalid_sum",
      dataIndex: "invalid_sum",
      align: "center",
      width: 300,
      render(text,item){
        return InvalidList({item});
      },
    },
    {
      title: "存在其他文件号码数",
      key: "other_package_reply_sum",
      dataIndex: "other_package_reply_sum",
      align: "center",
      width: 300,
    },
  ],
};


export const UploadNameData = {
  Tips: [
    "1.文件格式仅支持TXT格式文件，每行一个11位手机号和姓名, 以逗号','分隔，请确保号码正确无误",
    "2.若上传多个文件，请将txt文件打包成后缀为zip格式的压缩包文件后上传",
    "3.请尽量导入该号码包中已有的号码，上传后会将姓名属性更新为文件中号码对应的姓名",
  ],
  resultCol: [
    {
      title: "文件名",
      key: "old_file_name",
      dataIndex: "old_file_name",
      align: "center",
      width: 300,
    },
    {
      title: "原文件号码数量",
      key: "total",
      dataIndex: "total",
      align: "center",
      width: 300,
    },
    {
      title: "实际导入数量",
      key: "real_total",
      dataIndex: "real_total",
      align: "center",
      width: 300,
    },
    // {
    //   title: "剔除重复号码",
    //   key: "file_reply_sum",
    //   dataIndex: "file_reply_sum",
    //   align: "center",
    //   width: 300,
    // },
    // {
    //   title: "无效数据",
    //   key: "invalid_sum",
    //   dataIndex: "invalid_sum",
    //   align: "center",
    //   width: 300,
    //   render(text,item){
    //     return InvalidList({item});
    //   },
    // },
    // {
    //   title: "存在其他文件号码数",
    //   key: "other_package_reply_sum",
    //   dataIndex: "other_package_reply_sum",
    //   align: "center",
    //   width: 300,
    // },
  ],
};
