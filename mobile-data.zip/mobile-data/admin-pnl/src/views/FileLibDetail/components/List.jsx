import React, { useState, useEffect, useContext } from "react";
import { Table } from "antd";
import { BusContext } from "./context";
import { useSelector } from "react-redux";

const List = () => {
  const { pageOpt, setPageOpt, getList, loading } = useContext(BusContext);
  const { columns, list } = useSelector((s) => s.fileLibDetail);

  // 过滤 visible 数据
  const [_columns, set_columns] = useState([]);
  useEffect(() => {
    set_columns(columns.filter((v) => v.visible));
  }, [columns]);

  return (
    <div>
      <Table
        locale={{
          emptyText: "暂无数据",
        }}
        bordered
        columns={_columns}
        rowKey="id"
        loading={loading}
        dataSource={list}
        pagination={{
          ...pageOpt,
          showSizeChanger: true,
        }}
        onChange={(e) => {
          // total
          // eslint-disable-next-line no-unused-vars
          const { current, total, pageSize } = e;
          setPageOpt({
            ...pageOpt,
            total,
            current,
            pageSize,
          });
          getList(current);
        }}
      ></Table>
    </div>
  );
};

export default List;
