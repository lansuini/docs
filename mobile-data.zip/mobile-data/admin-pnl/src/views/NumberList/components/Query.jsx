import React, { useState, useCallback, useEffect, useContext } from "react";
import {
  Button,
  Card,
  Input,
  Form,
  Row,
  Col,
  Select,
  DatePicker,
  message,
} from "antd";
import { BusContext } from "./context";
import { useSelector, useDispatch } from "react-redux";
import TableSet from "@/components/TableSet/index.jsx";
import { _set as setNumberList } from "@/store/actions/numberList.js";
import { getQueryList, includeDate } from "./list";
import { exportPhone } from "@/services";
import { Link } from "react-router-dom";

const SIZE = "middle";
const rules = [{ required: true, message: "请输入字段" }];

const Query = () => {
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const { getList } = useContext(BusContext);
  const { columns } = useSelector((state) => state.numberListData);

  const [exportLoadingExcel, setExportLoadingExcel] = useState(false);
  const [exportLoadingTxt, setExportLoadingTxt] = useState(false);

  // 表头设置
  const [headersInfo, setHeadersInfo] = useState({
    show: false,
    selects: [],
  });
  const showSetHeader = useCallback(
    () => setHeadersInfo(Object.assign({}, headersInfo, { show: true })),
    [headersInfo]
  );

  const onClose = useCallback(() => {
    setHeadersInfo(Object.assign({}, headersInfo, { show: false }));
  }, [headersInfo]);

  const setColumns = useCallback(
    (columns) => {
      dispatch(setNumberList({ columns }));
    },
    [dispatch]
  );

  const queryFormat = useCallback((query) => {
    const res = {};
    query &&
      query.forEach((v) => {
        // 对时间的处理
        if (includeDate.includes(v.key)) {
          const _val = [v.value[0].unix(), v.value[1].unix()];
          if (!res[v.key]) {
            res[v.key] = [_val];
          } else {
            res[v.key].push(_val);
          }
          return;
        }

        // 对归属地处理 location
        if (v.key === "location") {
          // province 处理省
          ["province", "city"].forEach((x) => {
            const _not = [];
            const _is = [];
            if (v.condition === "not") {
              v[x] && _not.push(v[x]);
            } else if (v.condition === "is") {
              v[x] && _is.push(v[x]);
            }

            if (!res[x]) {
              res[x] = {
                is: _is,
                not: _not,
              };
            } else {
              Object.assign(res[x], {
                is: [...res[x].is, ..._is],
                not: [...res[x].not, ..._not],
              });
            }
          });
          return;
        }

        // condition  key  value
        const _not = [];
        const _is = [];

        // 对 value 格式化
        let val = v.value;
        if (v.key === "export_at") {
          val = v.value.format("YYYY-MM-DD");
        }

        if (v.condition === "not") {
          _not.push(val);
        } else if (v.condition === "is") {
          _is.push(val);
        }
        if (!res[v.key]) {
          res[v.key] = {
            is: _is,
            not: _not,
          };
        } else {
          Object.assign(res[v.key], {
            is: [...res[v.key].is, ..._is],
            not: [...res[v.key].not, ..._not],
          });
        }
      });
    return res;
  }, []);

  const search = useCallback(
    (params) => {
      const { query } = params;
      const res = queryFormat(query);
      // 这里还要写查询条件
      getList(1, res);
    },
    [getList, queryFormat]
  );

  const reset = useCallback(() => {
    form.resetFields();
    form.submit();
  }, [form]);

  const showorhide = useCallback((fileType, flag) => {
    if (fileType === 1) {
      setExportLoadingExcel(flag);
    } else if (fileType === 2) {
      setExportLoadingTxt(flag);
    }
  }, []);
  const exportHandle = useCallback(
    async (fileType) => {
      showorhide(fileType, true);
      try {
        const fields = columns
          .filter((x) => x.visible && !["operation"].includes(x.id))
          .map((x) => x.id);
        // .join(",");

        const { query } = await form.validateFields();

        const _query = queryFormat(query);
        const res = await exportPhone({
          fileType, //导出类型  1为excel  2为phone
          exportType: 2,
          title: fields,
          ..._query,
        });
        if (res) message.error(res);
        showorhide(fileType, false);
      } catch (error) {
        showorhide(fileType, false);
        message.error(error);
      }
    },
    [columns, form, queryFormat, showorhide]
  );

  return (
    <div>
      <Card bordered={false}>
        <Form form={form} onFinish={search} autoComplete="off">
          <Form.List name="query">
            {(fields, { add, remove }) => {
              return (
                <>
                  {fields.map((field, index) => {
                    return (
                      <QueryItem
                        key={field.key}
                        field={field}
                        form={form}
                        remove={remove}
                      ></QueryItem>
                    );
                  })}

                  {/* add */}
                  <Form.Item>
                    <Row gutter={[16, 0]}>
                      <Col>
                        <TableSet
                          headersInfo={headersInfo}
                          onClose={onClose}
                          columns={columns}
                          setColumns={setColumns}
                          localKey="file-lib-detail-header-list"
                        ></TableSet>
                        <Button
                          type="primary"
                          onClick={() => {
                            add();
                          }}
                          size={SIZE}
                        >
                          +添加新条件
                        </Button>
                      </Col>
                      <Col>
                        <Button
                          type="primary"
                          size={SIZE}
                          onClick={() => {
                            return form.submit();
                          }}
                          ghost
                        >
                          查询
                        </Button>
                      </Col>
                      <Col>
                        <Button
                          type="primary"
                          size={SIZE}
                          ghost
                          onClick={reset}
                        >
                          重置
                        </Button>
                      </Col>
                      <Col>
                        <Button
                          type="primary"
                          size={SIZE}
                          ghost
                          loading={exportLoadingExcel}
                          onClick={() => {
                            exportHandle(1);
                          }}
                        >
                          导出Excel
                        </Button>
                      </Col>
                      <Col>
                        <Button
                          type="primary"
                          size={SIZE}
                          ghost
                          loading={exportLoadingTxt}
                          onClick={() => {
                            exportHandle(2);
                          }}
                        >
                          导出纯号码
                        </Button>
                      </Col>
                      <Col>
                        <Button
                          type="primary"
                          onClick={showSetHeader}
                          size={SIZE}
                          ghost
                        >
                          表头设置
                        </Button>
                      </Col>
                      <Col>
                        <Link to={`/export-log`}>
                          <Button type="primary" size={SIZE} ghost>
                            导出日志
                          </Button>
                        </Link>
                      </Col>
                    </Row>
                    {/* </Space> */}
                  </Form.Item>
                </>
              );
            }}
          </Form.List>
        </Form>
      </Card>
    </div>
  );
};

export default Query;

function QueryItem({ field, form, remove }) {
  const { platformList } = useSelector((s) => s.fileLib);
  useEffect(() => {
    setList(getQueryList({ platformList }));
  }, [platformList]);
  const [list, setList] = useState([]);

  const [_key, _setKey] = useState("");
  const [selectKeyLabel, setSelectKeyLabel] = useState("label");
  const [selectKeyId, setSelectKeyId] = useState("id");
  const [type, setType] = useState("");
  const [conditionList, setConditionList] = useState([]);
  const [select, setSelect] = useState([]);
  // list.js 中的当前选择的一项
  const [curListItem, setCurListItem] = useState({});
  const [provinceKey, setProvinceKey] = useState("");

  useEffect(() => {
    const res = list.find((x) => x.key === _key);
    if (res) {
      setCurListItem(res);
      // selectKeyId = res.selectKeyId;
      // selectKeyLabel = res.selectKeyLabel;
      setSelectKeyId(res.selectKeyId);
      setSelectKeyLabel(res.selectKeyLabel);
      setConditionList(res.conditions);
      setType(res.type);
      setSelect(res.select || []);
    }
  }, [_key, list]);

  return (
    <Row gutter={[16, 0]} key={field.key}>
      <Col>
        <Form.Item
          name={[field.name, "key"]}
          fieldKey={[field.fieldKey, "key"]}
          rules={rules}
        >
          <Select
            style={{ width: 200 }}
            placeholder="选择查询"
            onChange={(e) => {
              _setKey(e);
              const _query = Object.assign([], form.getFieldValue().query, {
                [field.name]: {
                  key: e,
                  condition: undefined,
                  // 其他的都充值未  空
                },
              });
              form.setFieldsValue({ query: [..._query] });
            }}
          >
            {list.map((v) => {
              return (
                <Select.Option key={v.key} value={v.key}>
                  {v.label}
                </Select.Option>
              );
            })}
          </Select>
        </Form.Item>
      </Col>
      <Col>
        <Form.Item
          name={[field.name, "condition"]}
          rules={rules}
          fieldKey={[field.fieldKey, "condition"]}
        >
          <Select style={{ width: 200 }} placeholder="选择查询">
            {conditionList.map((v) => {
              return (
                <Select.Option key={v.id} value={v.id}>
                  {v.label}
                </Select.Option>
              );
            })}
          </Select>
        </Form.Item>
      </Col>
      <Col>
        {type === "input" && (
          <Form.Item
            name={[field.name, "value"]}
            rules={rules}
            fieldKey={[field.fieldKey, "value"]}
          >
            <Input />
          </Form.Item>
        )}
        {type === "input-phoneSegment" && (
          <Form.Item
            name={[field.name, "value"]}
            rules={[...rules]}
            fieldKey={[field.fieldKey, "value"]}
          >
            <Input maxLength={3} />
          </Form.Item>
        )}
        {type === "select" && (
          <Form.Item
            name={[field.name, "value"]}
            rules={rules}
            fieldKey={[field.fieldKey, "value"]}
          >
            <Select style={{ width: 200 }} placeholder="选择查询">
              {select.map((v) => {
                v.id = v[selectKeyId || "id"];
                v.label = v[selectKeyLabel || "label"];
                return (
                  <Select.Option key={v.id} value={v.id}>
                    {v.label}
                  </Select.Option>
                );
              })}
            </Select>
          </Form.Item>
        )}

        {type === "date" && (
          <Form.Item
            name={[field.name, "value"]}
            rules={rules}
            fieldKey={[field.fieldKey, "value"]}
          >
            <DatePicker.RangePicker placeholder={["开始时间", "结束时间"]} />
          </Form.Item>
        )}
        {type === "single-date" && (
          <Form.Item
            name={[field.name, "value"]}
            rules={rules}
            fieldKey={[field.fieldKey, "value"]}
          >
            {/* <DatePicker.RangePicker placeholder={["开始时间", "结束时间"]} /> */}
            <DatePicker />
          </Form.Item>
        )}
      </Col>
      {/* location 归属省市联动 */}
      {type === "secondLevelSelect" && (
        <>
          <Col>
            <Form.Item
              name={[field.name, "province"]}
              rules={rules}
              fieldKey={[field.fieldKey, "province"]}
            >
              <Select
                style={{ width: 200 }}
                placeholder="选择查询"
                onChange={(e) => {
                  setProvinceKey(e);
                  const query = form.getFieldValue().query;
                  const _query = Object.assign([], query, {
                    [field.name]: {
                      ...query[field.name],
                      city: undefined,
                    },
                  });
                  form.setFieldsValue({ query: [..._query] });
                }}
              >
                {(() => {
                  const itemNode = [];
                  for (const val in curListItem.provinceSelect || {}) {
                    itemNode.push(
                      <Select.Option key={val} value={val}>
                        {val}
                      </Select.Option>
                    );
                  }
                  return itemNode;
                })()}
              </Select>
            </Form.Item>
          </Col>
          <Col>
            <Form.Item
              name={[field.name, "city"]}
              fieldKey={[field.fieldKey, "city"]}
            >
              <Select style={{ width: 200 }} placeholder="选择查询">
                {curListItem.provinceSelect[provinceKey] &&
                  curListItem.provinceSelect[provinceKey].map((val) => {
                    return (
                      <Select.Option key={val} value={val}>
                        {val}
                      </Select.Option>
                    );
                  })}
                );
              </Select>
            </Form.Item>
          </Col>
        </>
      )}
      <Col>
        <img
          style={{ cursor: "pointer" }}
          width={30}
          src={require("@/assets/images/close.png")}
          alt=""
          onClick={() => {
            remove(field.name);
          }}
        />
      </Col>
    </Row>
  );
}
