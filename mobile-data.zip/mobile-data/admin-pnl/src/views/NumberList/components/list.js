import city from "@/assets/js/city.js";

export const getQueryList = ({ platformList }) => {
  return [
    {
      label: "手机号", // 第一个 select 展示的中文
      key: "phone", // id 给后端的 key
      type: "input", // 第三个 form.item 的类型
      resType: "condition", // 格式化成后端需要的格式 的类型  enum: condition、date
      conditions: [
        // 第二个框的 条件
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
    },
    {
      label: "号码段（号码前三位）", // 第一个 select 展示的中文
      key: "phone_segment",
      type: "input-phoneSegment",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
    },
    {
      label: "运营商",
      key: "company",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: [
        // 第三个框的数据
        {
          id: "1",
          label: "移动",
        },
        {
          id: "2",
          label: "联通",
        },
        {
          id: "3",
          label: "电信",
        },
        {
          id: "4",
          label: "虚拟",
        },
        {
          id: "0",
          label: "为空",
        },
      ],
    },
    // 这个很特殊 需要做联动
    {
      label: "归属地",
      key: "location",
      type: "secondLevelSelect", // 二级联动
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      provinceSelect: city,
      citySelect: [],
    },
    // {
    //   label: "归属省",
    //   key: "province",
    //   type: "select",
    //   resType: "condition",
    //   conditions: [
    //     {
    //       id: "is",
    //       label: "是",
    //     },
    //     {
    //       id: "not",
    //       label: "不是",
    //     },
    //   ],
    //   select: [],
    // },
    // {
    //   label: "归属市",
    //   key: "city",
    //   type: "select",
    //   resType: "condition",
    //   conditions: [
    //     {
    //       id: "is",
    //       label: "是",
    //     },
    //     {
    //       id: "not",
    //       label: "不是",
    //     },
    //   ],
    //   select: [],
    // },
    {
      label: "号码属性",
      key: "type",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: [
        //  0未验证,1活跃号,2沉默号,3危险号,4空号
        // {
        //   id: "0",
        //   label: "未验证",
        // },
        {
          id: "1",
          label: "活跃号",
        },
        {
          id: "2",
          label: "沉默号",
        },
        {
          id: "3",
          label: "风险号",
        },
        {
          id: "4",
          label: "空号",
        },
      ],
    },
    {
      label: "注册状态",
      key: "is_register",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: [
        {
          id: "0",
          label: "未注册",
        },
        {
          id: "1",
          label: "已注册",
        },
      ],
    },
    {
      label: "注册平台",
      key: "register_platform",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: platformList,
      selectKeyId: "id", //  select 数组中 的 id key
      selectKeyLabel: "platform_name", //  //  select 数组中 的 label key
    },
    {
      label: "充值状态",
      key: "is_use",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: [
        {
          id: "0",
          label: "未充值",
        },
        {
          id: "1",
          label: "已充值",
        },
      ],
    },
    {
      label: "使用平台",
      key: "use_platform",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: platformList,
      selectKeyId: "id",
      selectKeyLabel: "platform_name",
    },
    {
      label: "使用日期",
      key: "use_time",
      type: "date",
      resType: "date",
      conditions: [
        {
          id: "1",
          label: "介于",
        },
      ],
    },
    {
      label: "最后使用日期",
      key: "use_last_time",
      type: "date",
      resType: "date",
      conditions: [
        {
          id: "1",
          label: "介于",
        },
      ],
    },
    {
      label: "反馈状态",
      key: "is_feedback",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: [
        // #反馈状态  0 未反馈  1反馈
        {
          id: "0",
          label: "未反馈",
        },
        {
          id: "1",
          label: "已反馈",
        },
      ],
    },
    {
      label: "反馈平台",
      key: "feedback_platform",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: platformList,
      selectKeyId: "id",
      selectKeyLabel: "platform_name",
    },
    {
      label: "最后反馈日期",
      key: "feedback_last_time",
      type: "date",
      resType: "date",
      conditions: [
        {
          id: "1",
          label: "介于",
        },
      ],
    },
    {
      label: "关联号码包",
      key: "number_package",
      type: "input",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
    },
    {
      label: "导出状态",
      key: "export_state",
      type: "select",
      resType: "condition",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
      select: [
        // 第三个框的数据
        {
          id: "1",
          label: "导出过",
        },
        {
          id: "0",
          label: "未导出",
        },
      ],
    },
    {
      label: "导出日期",
      key: "export_at",
      type: "single-date",
      resType: "date",
      conditions: [
        {
          id: "is",
          label: "是",
        },
        {
          id: "not",
          label: "不是",
        },
      ],
    },
    {
      label: "入库时间",
      key: "created_at",
      type: "date",
      resType: "date",
      conditions: [
        {
          id: "1",
          label: "介于",
        },
      ],
    },
    {
      label: "修改时间",
      key: "updated_at",
      type: "date",
      resType: "date",
      conditions: [
        {
          id: "1",
          label: "介于",
        },
      ],
    },
  ];
};

export const includeDate = [
  "use_time",
  "use_last_time",
  "feedback_last_time",
  "created_at",
  "updated_at",
];
