import React, { useContext, useMemo, useState } from "react";
import { Card, Button, Space, Col, Row, Tag } from "antd";
import { BusContext } from "./context";
import { useSelector } from "react-redux";
import { useParams } from "react-router";
import Create from "@/components/ForeignFileLib/Create";
import TopBack from "@/components/TopBack";
import { Link } from "react-router-dom";
import NumberPackLog from "@/components/NumberPackLog";

const list = [
  { label: "当前号码数量", key: "total" },
  // { label: "移动号", key: "cmcc_sum" },
  // { label: "联通号", key: "cucc_sum" },
  // { label: "电信号", key: "ctcc_sum" },
  // { label: "虚拟号", key: "virtual_sum" },
  // { label: "活跃号", key: "good_sum" },
  // { label: "沉默号", key: "sleep_sum" },
  // { label: "风险号", key: "risk_sum" },
  // { label: "空号", key: "vacant_sum" },
  // { label: "已使用号码", key: "used_sum" },
  // { label: "未使用号码", key: "no_used_sum" },
  // { label: "已反馈号码", key: "feedback_sum" },
  // { label: "未反馈号码", key: "no_feedback_sum" },
  // { label: "已注册号码", key: "register_sum" },
  // { label: "未注册号码", key: "no_register_sum" },
  { label: "数据金额", key: "amount", format: (val) => `${val}元` },
  { label: "平均单价", key: "one_amount" },
  { label: "导入次数", key: "import_sum" },
  { label: "导出次数", key: "export_sum" },
  { label: "记录日期", key: "date" },
  { label: "创建日期", key: "created_at" },

  // { label: "近15天内注册未充值", key: "last_week_recharge_sum" },
  // { label: "上一个月活跃号", key: "last_month_good_sum" },
  // { label: "已充值号码", key: "recharge_sum" },

  { label: "标签", key: "tags" },

  { label: "占比", key: "proportion" },

  // { label: "A+数据占比", key: "created_at" },
  // { label: "A数据占比", key: "created_at" },
  // { label: "B数据占比", key: "created_at" },

  // { label: "实际可用号码数量", key: "real_total" },
  // { label: "未验证号", key: "unverified_sum" },

];

const Header = () => {
  const { headData } = useSelector((s) => s.foreignFileLibDetail);
  const { getDetail } = useContext(BusContext);
  const ListNode = useMemo(() => {
    if (!headData.package) return;
    return (
      <Row gutter={[0, 10]}>
        {list.map((v, i) => (
          <ListItem key={i} props={v} headData={headData}></ListItem>
        ))}
      </Row>
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [headData]);

  return (
    <div>
      <Card title={Title(headData.package)} extra={Extra(headData, getDetail)}>
        {ListNode}
      </Card>
    </div>
  );
};

// const ListItemLabelStyles = { textAlign: "right" };

const ListItem = ({ props, headData }) => {
  const { label, key, format } = props;
  const { package: headDataPackage, label: headDataLabel = [], label_category_count: labelCategoryCount = [] } = headData;
  // console.log('cate:', labelCategoryCount)
  if (key === "tags") {
    return (
      <Col xs={24} sm={24} md={10} lg={8} xl={6} xxl={4} span={6}>
        <Row>
          <Col span={12}>{label}：</Col>
          <Col span={12}>
          {headDataLabel.map((v) => (
              <Tag key={v.label_id}>{v.label_name}</Tag>
            ))}
            </Col>
          </Row>
      </Col>
    );
  }

  if (key === 'proportion') {
    return (
      
      <React.Fragment>
      {labelCategoryCount.map((v) => (
        <Col xs={24} sm={24} md={10} lg={8} xl={6} xxl={4} span={6} key={v.label_id}>
        <Row>
            <Col span={12}>{v.label_name}数据占比：</Col>
            <Col span={12}>
              {v.label_total ? ( <span>{v.label_total} ({v.proportion}%) </span> ) : ( <span>0 (00.00%) </span> ) }
            </Col>
        </Row>
      </Col>
      ))}
      </React.Fragment>
     
    );
  }
  return (
    <Col xs={24} sm={24} md={10} lg={8} xl={6} xxl={4} span={6}>
      <Row>
        <Col span={12}>{label}：</Col>
        <Col span={12}>
          {typeof format === "function"
            ? format(headDataPackage[key])
            : headDataPackage[key]}
        </Col>
      </Row>
    </Col>
  );
};

const Title = (headDataPackage = {}) => {
  return <TopBack>{headDataPackage.package_name}</TopBack>;
};
const Extra = (headData, getDetail) => {
  const [visible, setVisible] = useState(false);
  const nation = useParams().nation;

  let data = {};
  if (headData.package) {
    const { package: headDataPackage = {}, label = [] } = headData;
    data = {
      id: headDataPackage.package_id,
      package_name: headDataPackage.package_name,
      date: headDataPackage.date,
      amount: headDataPackage.amount,
      label,
    };
  }
  return (
    <>
      <Space>
        <Button
          type="primary"
          onClick={() => {
            setVisible(true);
          }}
        >
          编辑号码包
        </Button>

        <Button loading={!data.package_name}>
          <Link to={`/foreign-number-upload/${nation}/${data.id}/${data.package_name}`}>
            提交号码
          </Link>
        </Button>
        <Log id={data.id} />
      </Space>
      <Create
        // 编辑 2
        data={data}
        type={2}
        visible={visible}
        callBack={() => {
          getDetail();
        }}
        close={() => {
          setVisible(false);
        }}
      />
    </>
  );
};

// 日志
function Log({ id }) {
  const [visible, setVisible] = useState(false);
  return (
    <>
      <Button
        type="dashed"
        size={"middle"}
        onClick={() => {
          setVisible(true);
        }}
      >
        日志
      </Button>
      <NumberPackLog
        id={id}
        visible={visible}
        type={2}
        onClose={() => {
          setVisible(false);
        }}
      />
    </>
  );
}

export default Header;
