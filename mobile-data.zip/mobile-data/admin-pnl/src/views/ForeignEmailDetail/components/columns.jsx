import React, { useState } from "react";
import { Space, Button } from "antd";
import dayjs from "dayjs";
import Log from "@/components/ForLog/Log.jsx";

const SIZE = "small";

// 	id:0 visible:true, 都是给自己预留是用的  做隐藏展示的功能
const columns = [
  {
    title: "序号",
    dataIndex: "id",
    id: "id",
    visible: true,
    align: "center",
    width: 70,
    render: (text, row, index) => {
      return index + 1;
    },
  },
  {
    title: "邮箱",
    dataIndex: "email",
    id: "email",
    visible: true,
    align: "center",
    width: 140,
  },
  // {
  //   title: "运营商",
  //   dataIndex: "company",
  //   id: "company",
  //   visible: true,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     // 1为移动 2为联通 3为电信
  //     switch (text) {
  //       case 1:
  //         return "移动";
  //       case 2:
  //         return "联通";
  //       case 3:
  //         return "电信";
  //       case 4:
  //         return "虚拟号";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  // {
  //   title: "归属省",
  //   dataIndex: "province",
  //   id: "province",
  //   visible: true,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     return text || "--";
  //   },
  // },
  // {
  //   title: "归属市",
  //   dataIndex: "city",
  //   id: "city",
  //   visible: true,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     return text || "--";
  //   },
  // },
  // {
  //   title: "号码属性",
  //   dataIndex: "type",
  //   id: "type",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     // 0未验证,1活跃号,2沉默号,3危险号,4空号
  //     switch (text) {
  //       case 0:
  //       // eslint-disable-next-line no-fallthrough
  //       case 1:
  //         return "活跃号";
  //       case 2:
  //         return "沉默号";
  //       case 3:
  //         return "风险号";
  //       case 4:
  //         return "空号";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  // {
  //   title: "充值状态",
  //   dataIndex: "is_use",
  //   id: "is_use",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     // 是否使用 1为使用0 未使用
  //     switch (text) {
  //       case 0:
  //         return "未充值";
  //       case 1:
  //         return "已充值";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  {
    title: "使用平台",
    dataIndex: "use_platform_name",
    id: "use_platform_name",
    visible: true,
    align: "center",
    width: 90,
    render: (text) => {
      return text.join("、") || "--";
    },
  },
  {
    title: "注册状态",
    dataIndex: "is_register",
    id: "is_register",
    visible: true,
    align: "center",
    width: 90,
    render: (text) => {
      // 是否使用 1为使用0 未使用
      switch (text) {
        case 0:
          return "未注册";
        case 1:
          return "已注册";
        default:
          return "--";
      }
    },
  },
  {
    title: "注册平台",
    dataIndex: "register_platform_name",
    id: "register_platform_name",
    visible: true,
    align: "center",
    width: 90,
    render: (text) => {
      return text.join("、") || "--";
    },
  },
  // {
  //     title: "是否代理",
  //     dataIndex: "is_agent",
  //     id: "is_agent",
  //     visible: true,
  //     align: "center",
  //     width: 90,
  //     render: (text) => {
  //         switch (text) {
  //             case "1":
  //                 return "普通用户";
  //             case "2":
  //                 return "活跃代理";
  //             case "3":
  //                 return "非活跃代理";
  //             default:
  //                 return "--";
  //         }
  //     },
  // },
  // {
  //   title: "反馈平台",
  //   dataIndex: "feedback_platform",
  //   id: "feedback_platform",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text = [], row) => {
  //     return row.feedback_platform_name.join("、") || "--";
  //   },
  // },
  // {
  //   title: "反馈状态",
  //   dataIndex: "is_feedback",
  //   id: "is_feedback",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     switch (text) {
  //       case 0:
  //         return "未反馈";
  //       case 1:
  //         return "已反馈";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  // {
  //   title: "最后反馈日期",
  //   dataIndex: "feedback_last_time",
  //   id: "feedback_last_time",
  //   visible: true,
  //   align: "center",
  //   width: 90,
  //   render(text) {
  //     if (text) {
  //       return dayjs(text * 1000).format("YYYY-MM-DD");
  //     }
  //     return "--";
  //   },
  // },
  // {
  //   title: "最后使用日期",
  //   dataIndex: "use_last_time",
  //   id: "use_last_time",
  //   visible: true,
  //   align: "center",
  //   width: 90,
  //   render(text) {
  //     if (text) {
  //       return dayjs(text * 1000).format("YYYY-MM-DD");
  //     }
  //     return "--";
  //   },
  // },
  {
    title: "关联号码包",
    dataIndex: "number_package_name",
    id: "number_package_name",
    visible: true,
    align: "center",
    width: 90,
    render: (text) => {
      return text.join("、") || "--";
    },
  },
  // {
  //   title: "备注内容",
  //   dataIndex: "remark",
  //   id: "remark",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     return text || "--";
  //   },
  // },
  // {
  //   title: "最后充值",
  //   dataIndex: "last_recharge_date",
  //   id: "last_recharge_date",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     return text || "--";
  //   },
  // },
  {
    title: "导出状态",
    dataIndex: "export_state",
    id: "export_state",
    visible: false,
    align: "center",
    width: 90,
    render: (text) => {
      switch (text) {
        case 0:
          return "未导出";
        case 1:
          return "导出";
        default:
          return "--";
      }
    },
  },
  {
    title: "导出次数",
    dataIndex: "export_count",
    id: "export_count",
    visible: false,
    align: "center",
    width: 90,
  },
  // {
  //   title: "号码状态",
  //   dataIndex: "number_status",
  //   id: "number_status",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     switch (text) {
  //       case 0:
  //         return "正常";
  //       case 1:
  //         return "封号";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  // {
  //   title: "近15日是否充值",
  //   dataIndex: "last_week_is_recharge",
  //   id: "last_week_is_recharge",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     switch (text) {
  //       case 0:
  //         return "未充值";
  //       case 1:
  //         return "充值";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  // {
  //   title: "设备类型",
  //   dataIndex: "os",
  //   id: "os",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     switch (text) {
  //       case 1:
  //         return "IOS";
  //       case 2:
  //         return "Android";
  //       default:
  //         return "--";
  //     }
  //   },
  // },
  // {
  //   title: "渠道号",
  //   dataIndex: "client_id",
  //   id: "client_id",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  //   render: (text) => {
  //     return text.join("、") || "--";
  //   },
  // },
  // {
  //   title: "姓名",
  //   dataIndex: "name",
  //   id: "name",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  // },
  // {
  //   title: "入库价格",
  //   dataIndex: "price",
  //   id: "price",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  // },
  {
    title: "入库时间",
    dataIndex: "created_at",
    id: "created_at",
    visible: true,
    align: "center",
    width: 90,
    render(text) {
      if (text) {
        return dayjs(text * 1000).format("YYYY-MM-DD");
      }
      return "--";
    },
  },
  // {
  //   title: "操作",
  //   dataIndex: "operation",
  //   id: "operation",
  //   visible: true,
  //   align: "center",
  //   render(text, record, index) {
  //     return <Edit email={record.email}></Edit>;
  //   },
  //   width: 160,
  // },
];

function Edit(props) {
  const [logInfo, setLogInfo] = useState({ show: false, num: props.email });
  const showLog = () => {
    console.log(logInfo, "_____________****");
    setLogInfo(Object.assign({}, logInfo, { show: true }));
  };
  return (
    <>
      <Log props={logInfo}></Log>
      <Space size={SIZE}>
        <Button type="link" size={SIZE} onClick={showLog}>
          查看日志
        </Button>
      </Space>
    </>
  );
}

export default columns;
