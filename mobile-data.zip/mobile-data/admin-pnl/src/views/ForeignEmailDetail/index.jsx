import React, { useState, useCallback, useEffect } from "react";
import { message } from "antd";
import Header from "./components/Header";
import Query from "./components/Query";
import List from "./components/List.jsx";
import { BusContext } from "./components/context";
import { foreignEmailInfo as packageDetail, foreignEmailList } from "@/services";
import { getTags, getPlat } from "@/store/actions/foreignEmail";
import { useParams } from "react-router";
import { useDispatch } from "react-redux";
import { _set as setEmailDetail } from "@/store/actions/foreignEmailDetail.js";

let pageOpt = {
  total: 0, // 总条数
  current: 1,
  // count: 0,
  pageSize: 10, // 每页条数
};
const setPageOpt = (opt) => {
  pageOpt = { ...pageOpt, ...opt };
};
// 查询条件
let lastQuery = {};

const FileLibDetail = () => {
  const dispatch = useDispatch();

  const [loading, setLoading] = useState(false);
  const package_id = useParams().id;
  const nation = useParams().nation;
  const getDetail = useCallback(async () => {
    try {
      const res = await packageDetail({ package_id, nation });
      if (res.code === 200) {
        dispatch(setEmailDetail({ headData: res.data }));
      }
    } catch (error) {}
  }, [dispatch, package_id, nation]);
  const getList = useCallback(
    async (page = 1, query) => {
      // query = undefined 取上次的
      setLoading(true);
      if (query) {
        lastQuery = query;
      }
      try {
        const res = await foreignEmailList({
          nation,
          package_id: package_id,
          page: page,
          page_size: pageOpt.pageSize,
          ...lastQuery,
          ...query,
        });
        setLoading(false);
        if (res.code === 200) {
          pageOpt.total = res.data.count;
          pageOpt.count = res.data.total;
          pageOpt.current = res.data.currentPage;
          dispatch(setEmailDetail({ list: res.data.data }));
        } else {
          message.error(res.msg);
        }
      } catch (error) {
        setLoading(false);
        message.error(error);
      }
    },
    [dispatch, nation, package_id]
  );

  useEffect(() => {
    dispatch(getTags());
    dispatch(getPlat());
  }, [dispatch]);

  useEffect(() => {
    getDetail();
    getList();
    return () => {
      lastQuery = {};
    };
  }, [getDetail, getList]);

  const value = {
    loading,
    getDetail,
    getList,
    pageOpt,
    setPageOpt,
  };
  return (
    <BusContext.Provider value={value}>
      <div>
        <Header />
        <Query />
        <List />
      </div>
    </BusContext.Provider>
  );
};

export default FileLibDetail;
