import React from "react";
import Settings from "@/components/Settings";
const Platform = () => {
  return <Settings menuType="platform" />;
};
export default Platform;
