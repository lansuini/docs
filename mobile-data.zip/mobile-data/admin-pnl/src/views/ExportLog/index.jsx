import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { Card } from 'antd';
import TopBack from "@/components/TopBack";
import styles from './index.module.less';
import { columns } from './exportLogData';
import { pckExportLog } from "@/services";
import List from "./components/list";


const Extra = () => {
  return <div className={styles.tipsPadding}>导出的日志超过15天后，仅保留记录，不再支持下载</div>;
};

function ExportLog(props) {
  const { id,name } = props.match.params
  const [pageLoading, setPageLoading] = useState(false);
  const [data, setData] = useState([])
  const PAGESIZE = 10;
  const getData = useCallback(
    async (page = 1, pagesize = PAGESIZE) => {
      try {
        setPageLoading(true);
        const res = await pckExportLog({
          page,
          pagesize,
          package_id:id
        })

        if (res.code === 200) {
          setData(res.data);
        }
        setPageLoading(false);
      } catch (error) {
        setData([]);
        setPageLoading(false)
      }
    }, [id]
  )
  useEffect(() => {
    getData();
  }, [getData]);

  const title = useMemo(() => {
    return <TopBack>{`${name ? name + '' : '所有号码'}-导出日志`}</TopBack>;
  }, [name]);




  return (
    <>
      <Card title={title} bordered={false} extra={Extra()}></Card>
      <List
        columns={columns}
        loading={pageLoading}
        pageSize={PAGESIZE}
        data={data}
        getData={getData}
      />
    </>
  );
}

export default ExportLog;
