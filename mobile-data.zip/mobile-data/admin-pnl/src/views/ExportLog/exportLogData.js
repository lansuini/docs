import React from "react";
import { Button,message } from "antd";
import dayjs from "dayjs";
import { downloadHandle } from '@/services'
export const columns = [
  {
    title: "时间",
    dataIndex: "created_at",
    align: "center",
    render(text) {
      const d = dayjs.unix(text);
      return d.format("YYYY-MM-DD HH:mm:ss");
    },
  },
  {
    title: "文件名",
    dataIndex: "file_name",
    align: "center",
  },
  {
    title: "导出筛选条件",
    dataIndex: "condition",
    align: "center",
  },
  {
    title: "操作人",
    dataIndex: "account",
    align: "center",
  },
  {
    title: "下载",
    dataIndex: "user",
    align: "center",
    render(text, item) {
      if (item.is_ok) {
        return (
          <Button
            type="link"
            onClick={async () => {
              try {
                downloadHandle({fileName:item.file_name})
              } catch (error) {
                message.error(error)
              }
            }
          }
          >
            下载
          </Button>
        );
      } else {
        return "已过期";
      }
    },
  },
]