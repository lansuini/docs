import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import md5 from "blueimp-md5";
import { message, Form, Input, Button, notification } from "antd";
import { SmileOutlined } from "@ant-design/icons";
import { getCaptcha, login } from "@/services";
import styles from "./index.module.less";
import { _set as SETUSER } from "@/store/actions/user";

const layout = {
  labelCol: { span: 0 },
  wrapperCol: { span: 24 },
};

const Login = () => {
  const dispatch = useDispatch();
  // 表单
  const [form] = Form.useForm();
  // loading
  const [loading, setLoading] = useState(false);
  // 图形验证码
  // eslint-disable-next-line no-unused-vars
  const [captcha, setCaptcha] = useState("");
  // 验证码token
  const [captchaToken, setCaptchaToken] = useState("");
  const history = useHistory();
  const openNotification = () => {
    notification.open({
      duration: 1.2,
      message: "登录成功",
      description: `欢迎回来,${window.localStorage.getItem("account")}`,
      icon: <SmileOutlined style={{ color: "#108ee9" }} />,
    });
  };
  useEffect(() => {
    onGetCaptchaAction();
  }, []);
  // 获取验证码
  const onGetCaptchaAction = async () => {
    const res = await getCaptcha();
    setCaptcha(res.data.img_base64);
    setCaptchaToken(res.data.token);
  };
  // 登录
  const onLoginAction = async () => {
    const params = await form.validateFields();
    try {
      setLoading(true);
      params.password = md5(params.password);
      params.token = captchaToken;
      const res = await login(params);
      if (res.code === 200) {
        dispatch(SETUSER({ isLogin: true }))
        window.localStorage.setItem("token", res.data.token);
        window.localStorage.setItem("account", res.data.account);
        window.localStorage.setItem("id", res.data.id);
        setLoading(false);
        openNotification();
        history.replace("/");
      } 
    } catch (errorInfo) {
      setLoading(false);
      message.destroy();
      message.error(errorInfo);
      onGetCaptchaAction();
    }
  };
  return (
    <div className={styles.loginWrap}>
      <div className={styles.loginArea}>
        <h3 className={styles.title}>
          <img
            className={styles.logo}
            src={require("@/assets/images/logo.png")}
            alt="logo"
          />
        </h3>
        <div className={styles.loginForm}>
          <Form {...layout} name="basic" form={form}>
            <Form.Item
              label="username"
              name="account"
              rules={[{ required: true, message: "请输入账号!" }]}
            >
              <Input placeholder="请输入账号..." />
            </Form.Item>
            <Form.Item
              label="password"
              name="password"
              rules={[{ required: true, message: "请输入密码!" }]}
            >
              <Input.Password placeholder="请输入密码..." />
            </Form.Item>
            <Form.Item
              label="google_password"
              name="google_password"
              rules={[{ required: true, message: "请输入谷歌验证码!" }]}
            >
              <Input placeholder="请输入谷歌验证码..." />
            </Form.Item>
            {/*<Form.Item noStyle>*/}
              {/*<Form.Item*/}
                {/*label="verify_code"*/}
                {/*name="verify_code"*/}
                {/*rules={[{ required: true, message: "请输入验证码!" }]}*/}
                {/*style={{ display: "inline-block", width: "70%" }}*/}
              {/*>*/}
                {/*<Input*/}
                  {/*maxLength="4"*/}
                  {/*placeholder="请输入验证码..."*/}
                  {/*onKeyDown={(e) => e.keyCode === 13 && onLoginAction()}*/}
                {/*/>*/}
              {/*</Form.Item>*/}
              {/*<span className={styles.verifyCode} onClick={onGetCaptchaAction}>*/}
                {/*{captcha ? <img src={captcha} alt="图形验证码" /> : <Spin />}*/}
              {/*</span>*/}
            {/*</Form.Item>*/}
          </Form>
        </div>
        <div className={styles.submit}>
          <Button type="primary" loading={loading} onClick={onLoginAction}>
            登录
          </Button>
        </div>
      </div>
    </div>
  );
};
export default Login;
