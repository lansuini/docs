import React, { useRef, useState, useCallback } from "react";
import styles from "../index.module.less";
import { Form, Button, message } from "antd";
import {
  UploadNumber,
  UploadnewNumberTips,
  UploadCommonResult,
} from "./common";
import { UploadNewNumberData } from "../numberUploadData";
import { uploadIntMobile, getOnePackageUploadLog } from "@/services";

const UploadNewNumber = ({ props }) => {
  const { setLoading, setTipFn, package_id, nation } = props;
  const [upFile, setUpFlie] = useState(null);
  const [dataSource, setDataSource] = useState([]);
  const formEl = useRef(null);
  const layout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 19 },
  };
  const tailLayout = {
    wrapperCol: { offset: 5, span: 19 },
  };
  const validateMessages = {
    required(type) {
      switch (type) {
        case "file":
          if (!upFile) return "上传号码文件不能为空";
          else return false;
        case "number":
          return "本次数据金额不能为空";
        default:
          return null;
      }
    },
    type: {
      // number:'${label} 必须为数字'
    },
  };

  const submit = () => {};

  const changeFile = (file) => {
    formEl.current.setFieldsValue({
      file,
    });
    setUpFlie(file);
  };

  const onFinish = () => {
    runToUpload(formEl.current.getFieldValue());
  };

  const runToUpload = useCallback(
    async (v) => {
      setDataSource([]);
      setLoading(true);
      try {
        const result = await uploadIntMobile({
          nation,
          package_id,
          // money: v.number,
          phone: v.file.originFileObj,
        });
        if (result.code === 200) {
          message.success("上传成功")
          formEl.current.resetFields();
          // setTipFn("上传成功,等待服务器更新...");
          setLoading(false);
          // const log = await getOnePackageUploadLog(
          //   { id: result.data.id },
          //   setTipFn
          // );
          // if (log.code === 200) {
          //   if (log.data.data.is_deal === 1) {
          //     setDataSource([log.data.data]);
          //     // message.success("上传成功");
          //     formEl.current.resetFields();
          //   } else if (log.data.data.is_deal === 2) {
          //     // 这里是失败了
          //   }
          //   setLoading(false);
          // } else {
          //   setLoading(false);
          //   message.error(log.msg);
          // }
        } else {
          message.error(result.msg);
          setLoading(false);
        }
      } catch (error) {
        message.error(error || "上传失败，请重新上传");
        setLoading(false);
      }

      // setTipFn('正在上传中...');
    },
    [nation, package_id, setLoading]
  );

  return (
    <>
      <Form
        {...layout}
        name="upload-form"
        validateMessages={validateMessages}
        className={styles.form}
        ref={formEl}
        onFinish={onFinish}
      >
        <Form.Item
          name="file"
          label="上传号码文件"
          rules={[{ required: true }]}
        >
          <UploadNumber changeFile={(file) => changeFile(file)}></UploadNumber>
        </Form.Item>
        {/* <Form.Item name="number" label="本次数据金额" rules={[{ required: true }]}>
          <InputNumber style={{ width: '138px' }} min={0} />
        </Form.Item> */}
        <Form.Item {...tailLayout}>
          <Button type="primary" htmlType="submit" onClick={() => submit()}>
            确认提交
          </Button>
        </Form.Item>
        <Form.Item label="说明">
          <UploadnewNumberTips></UploadnewNumberTips>
        </Form.Item>
      </Form>
      <UploadCommonResult
        dataSource={dataSource}
        columns={UploadNewNumberData.UploadNewNumberResultCol}
      ></UploadCommonResult>
    </>
  );
};
export default UploadNewNumber;
