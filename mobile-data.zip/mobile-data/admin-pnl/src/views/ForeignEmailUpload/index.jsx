import React, { useState, useCallback, useEffect, useMemo } from "react";
// import styles from './index.module.less';
import { Tabs, Spin, Card, Button, Space } from "antd";
import NumberPackLog from "@/components/NumberPackLog";
import { tabList } from "./numberUploadData.js";
import { PlatFormServicve } from "@/services";
import TopBack from "@/components/TopBack";

const NumberUpload = (props) => {
  const { id, name, nation } = (props.match && props.match.params) || {};
  const { TabPane } = Tabs;
  // 展示加载
  const [showSpin, setShowSpin] = useState(false);

  // 上传文字设置
  const [tip, setTip] = useState("正在上传中...");

  // 平台列表
  const [platformList, setPlatformList] = useState([]);

  const setTipFn = useCallback((v) => {
    setTip(v);
  }, []);

  // 获取平台和标签
  const getPlat = useCallback(async () => {
    const plat = await PlatFormServicve.read({
      pagesize: 999999999,
    });
    if (plat.code === 200) {
      setPlatformList(plat.data.data);
      return plat;
    }
  }, []);

  // 获取 平台和标签
  useEffect(() => {
    getPlat();
  }, [getPlat]);

  const title = useMemo(() => {
    return <TopBack>{`${name} - 提交号码`}</TopBack>;
  }, [name]);

  const ChildTab = useMemo(() => {
    return (
      <Tabs>
        {tabList.map((x, index) => {
          return (
            <TabPane key={index} tab={x.name} className="tabPane">
              {/* <div className={styles.content} key={index}> */}
              {x.component({
                setLoading: setShowSpin,
                setTipFn,
                platformList,
                package_id: id,
                nation,
              })}
              {/* </div> */}
            </TabPane>
          );
        })}
      </Tabs>
    );
  }, [setTipFn, platformList, id, nation]);

  return (
    <>
      <Spin spinning={showSpin} tip={tip} wrapperClassName={"tabPane"}>
        <Card title={title} bordered={false} extra={Extra(id)}>
          {ChildTab}
        </Card>
      </Spin>
    </>
  );
};

export default NumberUpload;

const Extra = (id) => {
  return (
    <>
      <Space>
        <Log id={id} />
      </Space>
    </>
  );
};

// 日志
function Log({ id }) {
  const [visible, setVisible] = useState(false);
  return (
    <>
      <Button
        type="dashed"
        size={"middle"}
        onClick={() => {
          setVisible(true);
        }}
      >
        提交日志
      </Button>
      <NumberPackLog
        tabkey="2"
        id={id}
        type={2}
        visible={visible}
        onClose={() => {
          setVisible(false);
        }}
      />
    </>
  );
}
