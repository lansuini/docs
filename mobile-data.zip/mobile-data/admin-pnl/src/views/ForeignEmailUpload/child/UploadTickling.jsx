import React, { useRef, useState, useCallback } from "react";
import styles from "../index.module.less";
import { Form, Button, Select, message } from "antd";
import { UploadNumber, UploadTickTips, UploadCommonResult } from "./common";
import { UploadTicklingData } from "../numberUploadData";
import { uploadFeedbackMobile, getOnePackageUploadLog } from "@/services";

const { Option } = Select;

const UploadReNumber = ({ props }) => {
  const { setLoading, setTipFn, platformList, package_id } = props;
  const [upFile, setUpFlie] = useState(null);
  const [dataSource, setDataSource] = useState([]);
  const formEl = useRef(null);
  const layout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 19 },
  };
  const tailLayout = {
    wrapperCol: { offset: 5, span: 19 },
  };
  const validateMessages = {
    required(type) {
      switch (type) {
        case "file":
          if (!upFile) return "上传号码文件不能为空";
          else return false;
        case "origin":
          return "请选择反馈平台";
        default:
          return null;
      }
    },
  };

  const submit = () => {};

  const changeFile = (file) => {
    formEl.current.setFieldsValue({
      file,
    });
    setUpFlie(file);
  };

  const onFinish = () => {
    runToUpload(formEl.current.getFieldValue());
  };

  const runToUpload = useCallback(
    async (v) => {
      setDataSource([]);
      setLoading(true);
      try {
        const result = await uploadFeedbackMobile({
          package_id,
          platform_id: v.origin,
          phone: v.file.originFileObj,
        });
        if (result.code === 200) {
          setTipFn("上传成功,等待服务器更新...");
          const log = await getOnePackageUploadLog(
            { id: result.data.id },
            setTipFn
          );
          console.log(log, "---->最后产生的额");
          if (log.code === 200) {
            if (log.data.data.is_deal === 1) {
              setDataSource([log.data.data]);
              // message.success("上传成功");
              formEl.current.resetFields();
            } else if (log.data.data.is_deal === 2) {
              // 这里是失败了
            }
            setLoading(false);
          } else {
            setLoading(false);
            message.error(log.msg);
          }
        } else {
          message.error(result.msg);
          setLoading(false);
        }
      } catch (error) {
        message.error(error || "上传失败，请重新上传");
        setLoading(false);
      }

      // setTipFn("正在上传中...");
    },
    [package_id, setTipFn, setLoading]
  );

  return (
    <>
      <Form
        {...layout}
        name="upload-form"
        validateMessages={validateMessages}
        className={styles.form}
        ref={formEl}
        onFinish={onFinish}
      >
        <Form.Item
          name="file"
          label="上传号码文件"
          rules={[{ required: true }]}
        >
          <UploadNumber
            changeFile={(file) => changeFile(file)}
            type={".xlsx, .xls, .csv"}
          ></UploadNumber>
        </Form.Item>
        <Form.Item name="origin" label="反馈平台" rules={[{ required: true }]}>
          <Select style={{ width: 133 }} placeholder={"选择对应平台"}>
            {platformList.map((v) => {
              return (
                <Option value={v.id} key={v.id}>
                  {v.platform_name}
                </Option>
              );
            })}
          </Select>
        </Form.Item>
        <Form.Item {...tailLayout}>
          <Button type="primary" htmlType="submit" onClick={() => submit()}>
            确认入库
          </Button>
        </Form.Item>
        <Form.Item label="说明">
          <UploadTickTips></UploadTickTips>
        </Form.Item>
      </Form>
      <UploadCommonResult
        dataSource={dataSource}
        columns={UploadTicklingData.resultCol}
      ></UploadCommonResult>
    </>
  );
};
export default UploadReNumber;
