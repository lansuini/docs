import React, { useState } from "react";
import { Upload, Button, Table } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import {
  UploadNewNumberData,
  UploadUsedNumberData,
  UploadTicklingData,
  UploadEmpytData,
  UploadEnData,
  UploadRiskData,
  UploadNameData,
} from "../numberUploadData";
import styles from "../index.module.less";

export const UploadNumber = (props) => {
  const [info, setInfo] = useState({ fileList: [] });
  const { type } = props;
  const uploadProps = {
    name: "file",
    accept: type || ".txt, .zip",
    multiple: false,
    onChange(info) {
      info.fileList = [info.fileList.pop()];
      setInfo(info);
      props.changeFile(info.fileList[0]);
    },
    beforeUpload(file) {
      return false;
    },
    showUploadList: {
      showRemoveIcon: false,
    },
  };

  return (
    <>
      <Upload {...uploadProps} fileList={info.fileList}>
        <Button>
          <UploadOutlined /> 选择上传文件
        </Button>
        <span>{info.name}</span>
      </Upload>
    </>
  );
};

const InfoList = (data) => {
  return (
    <ul>
      {data.map((x, index) => {
        return (
          <li key={index} className={styles.tipsInfo}>
            {typeof x === "string" ? <span>{x}</span> : x}
          </li>
        );
      })}
    </ul>
  );
};

export const UploadCommonResult = (props) => {
  const { dataSource, columns } = props;
  // 默认展示表格
  if (!dataSource || !dataSource.length) return <></>;
  let dataList = dataSource.map((x, index) => {
    x.key = index;
    return x;
  });
  return (
    <>
      <p className={styles.centerP}>本次提交结果</p>
      <Table
        columns={columns}
        dataSource={dataList}
        pagination={false}
        bordered
        size="small"
        locale={{ emptyText: "暂无数据" }}
      ></Table>
      <p className={styles.bottomP}>
        本次提交结果离开此页面后会不再显示，具体每次提交的结果可在文件日志中查看
      </p>
    </>
  );
};

export const UploadnewNumberTips = () => {
  const { UploadNewNumberTips } = UploadNewNumberData;
  return <>{InfoList(UploadNewNumberTips)}</>;
};

export const UploadUsedTips = () => {
  const { Tips } = UploadUsedNumberData;
  return <>{InfoList(Tips)}</>;
};

export const UploadEmptyTips = () => {
  const { Tips } = UploadEmpytData;
  return <>{InfoList(Tips)}</>;
};
export const UploadEnTips = () => {
  const { Tips } = UploadEnData;
  return <>{InfoList(Tips)}</>;
};
export const UploadTickTips = () => {
  const { Tips } = UploadTicklingData;
  return <>{InfoList(Tips)}</>;
};
export const UploadRiskTips = () => {
  const { Tips } = UploadRiskData;
  return <>{InfoList(Tips)}</>;
};
export const UploadNameTips = () => {
  const { Tips } = UploadNameData;
  return <>{InfoList(Tips)}</>;
};