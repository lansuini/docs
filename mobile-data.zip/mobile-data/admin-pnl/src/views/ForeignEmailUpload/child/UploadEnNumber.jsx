import React, { useRef, useState, useCallback } from "react";
import styles from "../index.module.less";
import { Form, Button, message } from "antd";
import { UploadNumber, UploadEnTips, UploadCommonResult } from "./common";
import { UploadEnData } from "../numberUploadData";
import { uploadSetTypeMobile, getOnePackageUploadLog } from "@/services";

const UploadEnNumber = ({ props }) => {
  const { setLoading, setTipFn, package_id } = props;
  const [upFile, setUpFlie] = useState(null);
  const [dataSource, setDataSource] = useState([]);
  const formEl = useRef(null);
  const layout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 19 },
  };
  const tailLayout = {
    wrapperCol: { offset: 5, span: 19 },
  };
  const validateMessages = {
    required(type) {
      switch (type) {
        case "file":
          if (!upFile) return "上传号码文件不能为空";
          else return false;
        default:
          return null;
      }
    },
  };

  const submit = () => {};

  const changeFile = (file) => {
    formEl.current.setFieldsValue({
      file,
    });
    setUpFlie(file);
  };

  const onFinish = () => {
    runToUpload(formEl.current.getFieldValue());
  };

  const runToUpload = useCallback(
    async (v) => {
      setDataSource([]);
      setLoading(true);
      try {
        const result = await uploadSetTypeMobile({
          package_id,
          type: 5,
          phone: v.file.originFileObj,
        });
        if (result.code === 200) {
          setTipFn("上传成功,等待服务器更新...");
          const log = await getOnePackageUploadLog(
            { id: result.data.id },
            setTipFn
          );
          console.log(log, "---->最后产生的额");
          if (log.code === 200) {
            if (log.data.data.is_deal === 1) {
              setDataSource([log.data.data]);
              // message.success("上传成功");
              formEl.current.resetFields();
            } else if (log.data.data.is_deal === 2) {
              // 这里是失败了
            }
            setLoading(false);
          } else {
            setLoading(false);
            message.error(log.msg);
          }
        } else {
          message.error(result.msg);
          setLoading(false);
        }
      } catch (error) {
        message.error(error || "上传失败，请重新上传");
        setLoading(false);
      }
      // setTipFn('正在上传中...');
    },
    [package_id, setLoading, setTipFn]
  );

  return (
    <>
      <Form
        {...layout}
        name="upload-form"
        validateMessages={validateMessages}
        className={styles.form}
        ref={formEl}
        onFinish={onFinish}
      >
        <Form.Item
          name="file"
          label="上传号码文件"
          rules={[{ required: true }]}
        >
          <UploadNumber changeFile={(file) => changeFile(file)}></UploadNumber>
        </Form.Item>
        <Form.Item {...tailLayout}>
          <Button type="primary" htmlType="submit" onClick={() => submit()}>
            确认提交
          </Button>
        </Form.Item>
        <Form.Item label="说明">
          <UploadEnTips></UploadEnTips>
        </Form.Item>
      </Form>
      <UploadCommonResult
        dataSource={dataSource}
        columns={UploadEnData.resultCol}
      ></UploadCommonResult>
    </>
  );
};
export default UploadEnNumber;
