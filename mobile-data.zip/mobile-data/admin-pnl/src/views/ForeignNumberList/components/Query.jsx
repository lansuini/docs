import React, {  useEffect, useMemo,useState, useCallback, useContext } from "react";
import {
  Button,
  Card,
  Input,
  Form,
  // Row,
  // Col,
  Select,
  // DatePicker,
  message,
  Space
} from "antd";
import { BusContext } from "./context";
import { useSelector, useDispatch } from "react-redux";
import TableSet from "@/components/TableSet/index.jsx";
import { _set as setFileLibDetail } from "@/store/actions/foreignFileLibDetail";
// import { includeDate } from "./list";
import { exportIntMobile as exportPhone } from "@/services";
import { useParams } from "react-router";
import {DatePicker} from "antd/lib/index";

const { Option } = Select;
const SIZE = "middle";
// const rules = [{ required: true, message: "请输入字段" }];
const platformInit = [{ id: 0, platform_name: "全部平台" }];
// const tagInit = [{ id: 0, label_name: "全部标签" }];
const { RangePicker } = DatePicker;
const layout = {
  labelCol: {
    span: 0,
  },
  wrapperCol: {
    span: 3,
  },
  layout: "inline",
};

const initialValues = {
  nation: 'Thailand',
  phone: "",
  register_platform: [],
  // timeValue: defaultTime,
  is_register: "",
  is_use: "",
  number_status: "",
  type: "",
  is_b15dsrc: "",
  is_agent: "",
  is_agent_gold: "",
  day1_recharge_gold: "",
  rwdv_percent: "",
  day30_spread_increase: "",
  is_gold_flow: "",
    last_flow_time: [],
  is_get_lottery: "",
    last_bonus_time: [],
    use_last_time: [],
};

const Query = () => {
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const { loading, getList, pageOpt } = useContext(BusContext);
  const { platformList} = useSelector((s) => s.foreignFileLib);
  // eslint-disable-next-line no-unused-vars
  const { columns, headData } = useSelector((state) => state.foreignFileLibDetail);
  const package_id = useParams().id;
  const nation = useParams().nation;
  const [exportLoadingExcel, setExportLoadingExcel] = useState(false);
  const [exportLoadingTxt, setExportLoadingTxt] = useState(false);

  const _platformList = [...platformInit, ...platformList];
  
  // eslint-disable-next-line no-unused-vars
  const platformOptionNode = useMemo(
    () =>
      _platformList.map((v) => (
        <Option value={v.id} key={v.id}>
          {v.platform_name}
        </Option>
      )),
    [_platformList]
  );

  // 表头设置
  const [headersInfo, setHeadersInfo] = useState({
    show: false,
    selects: [],
  });
  const showSetHeader = useCallback(
    () => setHeadersInfo(Object.assign({}, headersInfo, { show: true })),
    [headersInfo]
  );

  const onClose = useCallback(() => {
    setHeadersInfo(Object.assign({}, headersInfo, { show: false }));
  }, [headersInfo]);

  const setColumns = useCallback(
    (columns) => {
      dispatch(setFileLibDetail({ columns }));
    },
    [dispatch]
  );
    
  // const queryFormat = useCallback((query) => {
  //   const res = {};
  //   query &&
  //     query.forEach((v) => {
  //       // 对时间的处理
  //       if (includeDate.includes(v.key)) {
  //         const _val = [v.value[0].unix(), v.value[1].unix()];
  //         if (!res[v.key]) {
  //           res[v.key] = [_val];
  //         } else {
  //           res[v.key].push(_val);
  //         }
  //         return;
  //       }

  //       // 对归属地处理 location
  //       if (v.key === "location") {
  //         // province 处理省
  //         ["province", "city"].forEach((x) => {
  //           const _not = [];
  //           const _is = [];
  //           if (v.condition === "not") {
  //             v[x] && _not.push(v[x]);
  //           } else if (v.condition === "is") {
  //             v[x] && _is.push(v[x]);
  //           }

  //           if (!res[x]) {
  //             res[x] = {
  //               is: _is,
  //               not: _not,
  //             };
  //           } else {
  //             Object.assign(res[x], {
  //               is: [...res[x].is, ..._is],
  //               not: [...res[x].not, ..._not],
  //             });
  //           }
  //         });
  //         return;
  //       }

  //       // condition  key  value
  //       const _not = [];
  //       const _is = [];

  //       // 对 value 格式化
  //       let val = v.value;
  //       if (v.key === "export_at") {
  //         val = v.value.format("YYYY-MM-DD");
  //       }

  //       if (v.condition === "not") {
  //         _not.push(val);
  //       } else if (v.condition === "is") {
  //         _is.push(val);
  //       }
  //       if (!res[v.key]) {
  //         res[v.key] = {
  //           is: _is,
  //           not: _not,
  //         };
  //       } else {
  //         Object.assign(res[v.key], {
  //           is: [...res[v.key].is, ..._is],
  //           not: [...res[v.key].not, ..._not],
  //         });
  //       }
  //     });
  //   return res;
  // }, []);

  useEffect(() => {
    form.submit();
  }, [form]);

  function search(params) {
    // eslint-disable-next-line no-unused-vars
    const { nation, phone, register_platform, is_register, is_use, number_status, type, is_b15dsrc ,is_agent,is_agent_gold,day1_recharge_gold,rwdv_percent,day30_spread_increase,is_gold_flow,last_flow_time=[],is_get_lottery,last_bonus_time=[],use_last_time=[]} = params;
    // console.log('params:', params)
    const query = {
      nation,
      phone,
      register_platform: register_platform,
      is_register: is_register,
      is_use: is_use,
      number_status: number_status,
      type: type,
      is_b15dsrc: is_b15dsrc,
        is_agent: is_agent,
        is_agent_gold: is_agent_gold,
        day1_recharge_gold: day1_recharge_gold,
        rwdv_percent: rwdv_percent,
        day30_spread_increase: day30_spread_increase,
        is_gold_flow: is_gold_flow,
        last_flow_time: (last_flow_time || []).map(function (item) {
            return Date.parse(item) /1000;
        }),
        is_get_lottery: is_get_lottery,
        last_bonus_time: (last_bonus_time || []).map(function (item) {
            return Date.parse(item) /1000;
        }),
        use_last_time: (use_last_time || []).map(function (item) {
            return Date.parse(item) /1000;
        }),
      // date: timeValue ? timeValue.format("YYYY-MM-DD") : "",
      // field: '',
    };
    // 这里还要写查询条件
    getList(1, query);
  }

  const reset = useCallback(() => {
    form.resetFields();
    form.submit();
  }, [form]);
  const showorhide = useCallback((fileType, flag) => {
    if (fileType === 1) {
      setExportLoadingExcel(flag);
    } else if (fileType === 2) {
      setExportLoadingTxt(flag);
    }
  }, []);
  const exportHandle = useCallback(
    async (fileType) => {
      showorhide(fileType, true);
      try {
        const fields = columns
          .filter((x) => x.visible && !["operation"].includes(x.id))
          .map((x) => x.id);
        // .join(",");

        // const { query } = await form.validateFields();

        // const _query = queryFormat(query);
        const _query = await form.getFieldsValue();
        const res = await exportPhone({
          fileType, //导出类型  1为excel  2为phone
          package_id,
          nation,
          exportType: 2,
          title: fields,
          ..._query,
        });
        if (res) message.error(res);
        showorhide(fileType, false);
      } catch (error) {
        showorhide(fileType, false);
        message.error(error);
      }
    },
    [columns, form, nation, package_id, showorhide]
  );

  return (
    <div>
      <Card title="" bordered={false}>
        <TableSet
          headersInfo={headersInfo}
          onClose={onClose}
          columns={columns}
          setColumns={setColumns}
          localKey="foreign-file-lib-detail-header-ids"
          okCallBack={() => {
            // okCallBack
            // 重新请求一次  只有要改 field
            getList(pageOpt.current, undefined);
          }}
        ></TableSet>
        <div>
          {/* 查询 重置 表头设置 */}
          <Form
            {...layout}
            form={form}
            name="basic"
            initialValues={initialValues}
            onFinish={search}
          >
            <Form.Item label="" name="nation">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="国家"
                optionFilterProp="children"
              >
                <Option value="Thailand" key="Thailand">泰国</Option>
                <Option value="Japan" key="Japan">日本</Option>
                <Option value="Taiwan" key="Taiwan">台湾</Option>
                <Option value="India" key="India">印度</Option>
                <Option value="Indonesia" key="Indonesia">印尼</Option>
                <Option value="Brazil" key="Brazil">巴西</Option>
                <Option value="America" key="America">美国</Option>
              </Select>
            </Form.Item>
            <Form.Item label="" name="phone">
              <Input placeholder="手机号码" style={{ width: 140 }} />
            </Form.Item>

            <Form.Item label="" name="register_platform">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="注册平台"
                mode="multiple"
                allowClear
              >
                {platformOptionNode}
              </Select>
            </Form.Item>

            <Form.Item label="" name="is_register">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="注册状态"
                optionFilterProp="children"
              >
                <Option value="">注册状态</Option>
                <Option value="0">未注册</Option>
                <Option value="1">已注册</Option>
              </Select>
            </Form.Item>

              <Form.Item label="最后登录时间" name="use_last_time">
                  <RangePicker
                      style={{ minWidth: 215 }}
                      format="YYYY-MM-DD"
                      allowEmpty={[false, false]}
                  />
              </Form.Item>

              {/* <Form.Item label="" name="is_agent">
                  <Select
                      showSearch
                      style={{ width: 140 }}
                      placeholder="是否代理"
                      optionFilterProp="children"
                  >
                      <Option value="">是否代理</Option>
                      <Option value="1">普通用户</Option>
                      <Option value="2">活跃代理</Option>
                      <Option value="3">非活跃代理</Option>
                  </Select>
              </Form.Item> */}

            {/* <Form.Item label="" name="is_use">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="充值状态"
                optionFilterProp="children"
              >
                <Option value="">充值状态</Option>
                <Option value="0">未充值</Option>
                <Option value="1">已充值</Option>
              </Select>
            </Form.Item> */}

            {/* <Form.Item label="" name="is_b15dsrc">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="近15天充值"
                optionFilterProp="children"
              >
                <Option value="">近15天充值</Option>
                <Option value="0">未充值</Option>
                <Option value="1">已充值</Option>
              </Select>
            </Form.Item> */}

            {/* <Form.Item label="" name="day1_recharge_gold">
                <Select
                    showSearch
                    style={{ width: 160 }}
                    placeholder="单日累计充值金额"
                    optionFilterProp="children"
                >
                    <Option value="">单日累计充值金额</Option>
                    <Option value="1">5000以上</Option>
                    <Option value="2">500-5000</Option>
                    <Option value="3">500以下</Option>
                </Select>
            </Form.Item> */}

            {/* <Form.Item label="" name="rwdv_percent">
                <Select
                    showSearch
                    style={{ width: 140 }}
                    placeholder="存取差百分比"
                    optionFilterProp="children"
                >
                    <Option value="">存取差百分比</Option>
                    <Option value="1">50%以上</Option>
                    <Option value="2">30%-50%</Option>
                    <Option value="3">30%以下</Option>
                </Select>
            </Form.Item> */}

            {/* <Form.Item label="" name="is_agent_gold">
                <Select
                    showSearch
                    style={{ width: 140 }}
                    placeholder="有无代理收益"
                    optionFilterProp="children"
                >
                    <Option value="">有无代理收益</Option>
                    <Option value="1">有</Option>
                    <Option value="2">无</Option>
                </Select>
            </Form.Item> */}

            {/* <Form.Item label="" name="day30_spread_increase">
                <Select
                    showSearch
                    style={{ width: 180 }}
                    placeholder="直属下级30天内有无增长"
                    optionFilterProp="children"
                >
                    <Option value="">直属下级30天内有无增长</Option>
                    <Option value="1">有</Option>
                    <Option value="2">无</Option>
                </Select>
            </Form.Item> */}
{/* 
            <Form.Item label="" name="is_get_lottery">
                <Select
                    showSearch
                    style={{ width: 160 }}
                    placeholder="是否领取彩金"
                    optionFilterProp="children"
                >
                    <Option value="">是否领取彩金</Option>
                    <Option value="1">是</Option>
                    <Option value="2">否</Option>
                </Select>
            </Form.Item>
          <Form.Item label="最后领取彩金时间" name="last_bonus_time">
              <RangePicker
                  style={{ minWidth: 215 }}
                  format="YYYY-MM-DD"
              />
          </Form.Item>
        <Form.Item label="" name="is_gold_flow">
            <Select
                showSearch
                style={{ width: 160 }}
                placeholder="是否有流水"
                optionFilterProp="children"
            >
                <Option value="">是否有流水</Option>
                <Option value="1">是</Option>
                <Option value="2">否</Option>
            </Select>
        </Form.Item>
          <Form.Item label="最后产生流水时间" name="last_flow_time">
              <RangePicker
                  style={{ minWidth: 215 }}
                  format="YYYY-MM-DD"
              />
          </Form.Item>
            <Form.Item label="" name="number_status">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="号码状态"
                optionFilterProp="children"
              >
                <Option value="">号码状态</Option>
                <Option value="1">已封号</Option>
                <Option value="0">未封号</Option>
              </Select>
            </Form.Item> */}

            {/* <Form.Item label="" name="type">
              <Select
                showSearch
                style={{ width: 140 }}
                placeholder="号码属性"
                optionFilterProp="children"
              >
                <Option value="">号码属性</Option>
                <Option value="2">沉默号</Option>
                <Option value="3">风险号</Option>
                <Option value="4">空号</Option>
                <Option value="1">活跃号</Option>
                <Option value="0">新号码</Option>
              </Select>
            </Form.Item> */}

            <Space>
              <Button
                type="primary"
                htmlType="submit"
                size={SIZE}
                loading={loading}
              >
                查询
              </Button>
              <Button type="primary" size={SIZE} ghost onClick={reset}>
                重置
              </Button>
              <Button type="primary" onClick={showSetHeader} size={SIZE} ghost>
                表头设置
              </Button>

              <Button
                type="primary"
                size={SIZE}
                ghost
                loading={exportLoadingExcel}
                onClick={() => {
                exportHandle(1);
                }}
            >
                导出Excel
            </Button>
            
            <Button
                type="primary"
                size={SIZE}
                ghost
                loading={exportLoadingTxt}
                onClick={() => {
                exportHandle(2);
                }}
            >
                导出纯号码
            </Button>
            </Space>
          </Form>
        </div>
      </Card>
    
    </div>
  );
};

export default Query;

// let selectKeyId = "id";
// let selectKeyLabel = "label";
// function QueryItem({ field, form, remove }) {
//   const { platformList } = useSelector((s) => s.fileLib);
//   useEffect(() => {
//     setList(getQueryList({ platformList }));
//   }, [platformList]);
//   const [list, setList] = useState([]);

//   const [_key, _setKey] = useState("");
//   const [selectKeyLabel, setSelectKeyLabel] = useState("label");
//   const [selectKeyId, setSelectKeyId] = useState("id");
//   const [type, setType] = useState("");
//   const [conditionList, setConditionList] = useState([]);
//   const [select, setSelect] = useState([]);
//   // list.js 中的当前选择的一项
//   const [curListItem, setCurListItem] = useState({});
//   const [provinceKey, setProvinceKey] = useState("");

//   useEffect(() => {
//     const res = list.find((x) => x.key === _key);
//     if (res) {
//       setCurListItem(res);
//       // selectKeyId = res.selectKeyId;
//       // selectKeyLabel = res.selectKeyLabel;
//       setSelectKeyId(res.selectKeyId);
//       setSelectKeyLabel(res.selectKeyLabel);
//       setConditionList(res.conditions);
//       setType(res.type);
//       setSelect(res.select || []);
//     }
//   }, [_key, list]);

//   return (
//     <Row gutter={[16, 0]} key={field.key}>
//       <Col>
//         <Form.Item
//           name={[field.name, "key"]}
//           fieldKey={[field.fieldKey, "key"]}
//           rules={rules}
//         >
//           <Select
//             style={{ width: 200 }}
//             placeholder="选择查询"
//             onChange={(e) => {
//               _setKey(e);
//               const _query = Object.assign([], form.getFieldValue().query, {
//                 [field.name]: {
//                   key: e,
//                   condition: undefined,
//                   // 其他的都充值未  空
//                 },
//               });
//               form.setFieldsValue({ query: [..._query] });
//             }}
//           >
//             {list.map((v) => {
//               return (
//                 <Select.Option key={v.key} value={v.key}>
//                   {v.label}
//                 </Select.Option>
//               );
//             })}
//           </Select>
//         </Form.Item>
//       </Col>
//       <Col>
//         <Form.Item
//           name={[field.name, "condition"]}
//           rules={rules}
//           fieldKey={[field.fieldKey, "condition"]}
//         >
//           <Select style={{ width: 200 }} placeholder="选择查询">
//             {conditionList.map((v) => {
//               return (
//                 <Select.Option key={v.id} value={v.id}>
//                   {v.label}
//                 </Select.Option>
//               );
//             })}
//           </Select>
//         </Form.Item>
//       </Col>
//       <Col>
//         {type === "input" && (
//           <Form.Item
//             name={[field.name, "value"]}
//             rules={rules}
//             fieldKey={[field.fieldKey, "value"]}
//           >
//             <Input />
//           </Form.Item>
//         )}
//         {type === "input-phoneSegment" && (
//           <Form.Item
//             name={[field.name, "value"]}
//             rules={[...rules]}
//             fieldKey={[field.fieldKey, "value"]}
//           >
//             <Input maxLength={3} />
//           </Form.Item>
//         )}
//         {type === "select" && (
//           <Form.Item
//             name={[field.name, "value"]}
//             rules={rules}
//             fieldKey={[field.fieldKey, "value"]}
//           >
//             <Select style={{ width: 200 }} placeholder="选择查询">
//               {select.map((v) => {
//                 v.id = v[selectKeyId || "id"];
//                 v.label = v[selectKeyLabel || "label"];
//                 return (
//                   <Select.Option key={v.id} value={v.id}>
//                     {v.label}
//                   </Select.Option>
//                 );
//               })}
//             </Select>
//           </Form.Item>
//         )}

//         {type === "date" && (
//           <Form.Item
//             name={[field.name, "value"]}
//             rules={rules}
//             fieldKey={[field.fieldKey, "value"]}
//           >
//             <DatePicker.RangePicker placeholder={["开始时间", "结束时间"]} />
//           </Form.Item>
//         )}
//         {type === "single-date" && (
//           <Form.Item
//             name={[field.name, "value"]}
//             rules={rules}
//             fieldKey={[field.fieldKey, "value"]}
//           >
//             {/* <DatePicker.RangePicker placeholder={["开始时间", "结束时间"]} /> */}
//             <DatePicker />
//           </Form.Item>
//         )}
//       </Col>
//       {/* location 归属省市联动 */}
//       {type === "secondLevelSelect" && (
//         <>
//           <Col>
//             <Form.Item
//               name={[field.name, "province"]}
//               rules={rules}
//               fieldKey={[field.fieldKey, "province"]}
//             >
//               <Select
//                 style={{ width: 200 }}
//                 placeholder="选择查询"
//                 onChange={(e) => {
//                   setProvinceKey(e);
//                   const query = form.getFieldValue().query;
//                   const _query = Object.assign([], query, {
//                     [field.name]: {
//                       ...query[field.name],
//                       city: undefined,
//                     },
//                   });
//                   form.setFieldsValue({ query: [..._query] });
//                 }}
//               >
//                 {(() => {
//                   const itemNode = [];
//                   for (const val in curListItem.provinceSelect || {}) {
//                     itemNode.push(
//                       <Select.Option key={val} value={val}>
//                         {val}
//                       </Select.Option>
//                     );
//                   }
//                   return itemNode;
//                 })()}
//               </Select>
//             </Form.Item>
//           </Col>
//           <Col>
//             <Form.Item
//               name={[field.name, "city"]}
//               fieldKey={[field.fieldKey, "city"]}
//             >
//               <Select style={{ width: 200 }} placeholder="选择查询">
//                 {curListItem.provinceSelect[provinceKey] &&
//                   curListItem.provinceSelect[provinceKey].map((val) => {
//                     return (
//                       <Select.Option key={val} value={val}>
//                         {val}
//                       </Select.Option>
//                     );
//                   })}
//                 );
//               </Select>
//             </Form.Item>
//           </Col>
//         </>
//       )}
//       <Col>
//         <img
//           style={{ cursor: "pointer" }}
//           width={30}
//           src={require("@/assets/images/close.png")}
//           alt=""
//           onClick={() => {
//             remove(field.name);
//           }}
//         />
//       </Col>
//     </Row>
//   );
// }
