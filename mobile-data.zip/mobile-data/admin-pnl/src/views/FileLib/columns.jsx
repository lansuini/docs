import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import { Space, Button, Modal, message } from "antd";
import dayjs from "dayjs";
import Create from "@/components/FileLib/Create";
import NumberPackLog from "@/components/NumberPackLog";
import { BusContext } from "./components/context";
import { deleteLib } from "@/services/flieLib.js";
const ReachableContext = React.createContext();

const SIZE = "small";

// 	id:0 visible:true, 都是给自己预留是用的，做隐藏展示的功能
const columns = [
  {
    title: "序号",
    dataIndex: "id",
    id: "id",
    visible: true,
    align: "center",
    width: 70,
    render: (text, row, index) => {
      return index + 1;
    },
  },
  {
    title: "号码包名称",
    dataIndex: "package_name",
    id: "package_name",
    visible: true,
    align: "center",
    width: 150,
  },
  {
    title: "当前号码数量",
    dataIndex: "total",
    id: "total",
    visible: true,
    align: "center",
    width: 90,
  },
  // {
  //   title: "实际可用数量",
  //   dataIndex: "real_total",
  //   id: "real_total",
  //   visible: true,
  //   align: "center",
  //   width: 90,
  // },
  {
    title: "移动号",
    dataIndex: "cmcc_sum",
    id: "cmcc_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "联通号",
    dataIndex: "cucc_sum",
    id: "cucc_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "电信号",
    dataIndex: "ctcc_sum",
    id: "ctcc_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "虚拟号",
    dataIndex: "virtual_sum",
    id: "virtual_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  // {
  //   title: "未验证号码",
  //   dataIndex: "unverified_sum",
  //   id: "unverified_sum",
  //   visible: false,
  //   align: "center",
  //   width: 90,
  // },
  {
    title: "活跃号",
    dataIndex: "good_sum",
    id: "good_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "空号",
    dataIndex: "vacant_sum",
    id: "vacant_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "沉默号",
    dataIndex: "sleep_sum",
    id: "sleep_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "风险号",
    dataIndex: "risk_sum",
    id: "risk_sum",
    visible: true,
    align: "center",
    width: 90,
  },
  {
    title: "已注册号码",
    dataIndex: "register_sum",
    id: "register_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "已反馈号码",
    dataIndex: "feedback_sum",
    id: "feedback_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "未反馈号码",
    dataIndex: "no_feedback_sum",
    id: "no_feedback_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "已使用号码",
    dataIndex: "used_sum",
    id: "used_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "未使用号码",
    dataIndex: "no_used_sum",
    id: "no_used_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "未注册号码",
    dataIndex: "no_register_sum",
    id: "no_register_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "数据包金额",
    dataIndex: "amount",
    id: "amount",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "平均单价",
    dataIndex: "one_amount",
    id: "one_amount",
    visible: false,
    align: "center",
    width: 90,
  },
  {
      title: "数据包占比",
      dataIndex: "ratio",
      id: "ratio",
      visible: true,
      align: "center",
      render(text = [], record, index) {
          if (text.length > 0) {
              return text.map((v) => <li key={v.package_name}>{v.package_name}  -- {v.dug_ratio/100}%</li>);
          }
          return "--";
      },
      width: 200,
  },
  {
    title: "标签",
    dataIndex: "label",
    id: "label",
    visible: true,
    align: "center",
    render(text = [], record, index) {
      if (text.length > 0) {
        return text.map((v) => v.label_name).join("、");
      }
      return "--";
      // array label_id: 16 label_name: "金龙"; package_id: 1;
    },
    width: 120,
  },
  {
    title: "记录日期",
    dataIndex: "date",
    id: "date",
    visible: true,
    align: "center",
    width: 120,
  },
  {
    title: "导出次数",
    dataIndex: "export_sum",
    id: "export_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "导入次数",
    dataIndex: "import_sum",
    id: "import_sum",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "创建人",
    dataIndex: "admin_name",
    id: "admin_name",
    visible: false,
    align: "center",
    width: 90,
  },
  {
    title: "创建时间",
    dataIndex: "created_at",
    id: "created_at",
    visible: false,
    align: "center",
    width: 90,
    render(text) {
      if (text) {
        return dayjs(text * 1000).format("YYYY-MM-DD HH:mm:ss");
      }
      return "--";
    },
  },
  {
    title: "操作",
    dataIndex: "operation",
    id: "operation",
    visible: true,
    align: "center",
    render(text, record, index) {
      return (
        <Space size={SIZE}>
          <Link to={`/file-lib/${record.id}`}>
            <Button type="link" size={SIZE}>
              管理
            </Button>
          </Link>
          <Edit row={record}></Edit>
          <Log id={record.id} />
          <Delete id={record.id} />
        </Space>
      );
    },
    width: 160,
  },
];

const DeleteModalConfig = (id, getList) => {
  return {
    title: "是否删除该包？",
    async onOk(close) {
      try {
        const res = await deleteLib({ id });
        if (res.code === 200) {
          getList();
        } else {
          message.info(res.msg);
        }
      } catch (err) {
        message.info(err);
      }
    },
    okText: "删除",
    cancelText: "取消",
  };
};

// 删除
function Delete({ id }) {
  const [modal, contextHolder] = Modal.useModal();
  const { getList } = useContext(BusContext);

  // deleteLib
  return (
    <>
      <Button
        type="dashed"
        danger
        size={SIZE}
        onClick={() => {
          modal.confirm(DeleteModalConfig(id, getList));
        }}
      >
        删除
      </Button>
      <ReachableContext.Provider value={id}>
        {contextHolder}
      </ReachableContext.Provider>
    </>
  );
}
// 编辑
function Edit(Props) {
  const { row } = Props;
  const [visible, setVisible] = useState(false);
  const { getList } = useContext(BusContext);

  return (
    <>
      <Button
        type="dashed"
        size={SIZE}
        onClick={() => {
          console.log(JSON.stringify(row));
          setVisible(true);
        }}
      >
        编辑
      </Button>
      <Create
        // 编辑 2
        callBack={() => {
          getList();
        }}
        data={{ ...row }}
        type={2}
        visible={visible}
        close={() => {
          setVisible(false);
        }}
      />
    </>
  );
}
// 日志
function Log({ id }) {
  const [visible, setVisible] = useState(false);
  return (
    <>
      <Button
        type="link"
        size={SIZE}
        onClick={() => {
          setVisible(true);
        }}
      >
        日志
      </Button>
      <NumberPackLog
        id={id}
        visible={visible}
        onClose={() => {
          setVisible(false);
        }}
      />
    </>
  );
}
export default columns;
