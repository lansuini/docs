// 列表
import React, { useMemo, useContext } from "react";
import { useSelector } from "react-redux";
import { Table } from "antd";
import { BusContext } from "./context";

function List() {
  const { columns } = useSelector((state) => state.fileLib);
  const { loading, pageOpt, list, getList, setPageOpt } = useContext(BusContext);
  const _columns = useMemo(() => columns.filter((v) => v.visible), [columns])

  return (
    <div>
      <Table
        locale={{
          emptyText: "暂无数据",
        }}
        scroll={{ x: true }}
        bordered
        rowKey="id"
        columns={_columns}
        dataSource={list}
        loading={loading}
        onChange={(e) => {
          // total
          // eslint-disable-next-line no-unused-vars
          const { current, total, pageSize } = e;
          setPageOpt({
            ...pageOpt,
            total,
            current,
            pageSize,
          });
          getList(current);
        }}
        pagination={{
          ...pageOpt,
          showSizeChanger: true,
        }}
      />
    </div>
  );
}

export default List;
