import React from "react";

export const BusContext = React.createContext();
