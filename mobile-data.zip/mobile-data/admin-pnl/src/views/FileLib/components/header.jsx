// 查询条件
import React, {
  useState,
  useContext,
  useMemo,
  useEffect,
  useCallback,
} from "react";
import { useSelector, useDispatch } from "react-redux";
import { Card, Button, Space, Form, Input, Select, DatePicker } from "antd";
import Create from "@/components/FileLib/Create";
import TableSet from "@/components/TableSet/index.jsx";
import { _set as setFileLibColumns } from "@/store/actions/fileLib";
import { BusContext } from "./context";

const { Option } = Select;
const SIZE = "middle";
const platformInit = [{ id: 0, platform_name: "全部平台" }];
const tagInit = [{ id: 0, label_name: "全部标签" }];

const layout = {
  labelCol: {
    span: 0,
  },
  wrapperCol: {
    span: 3,
  },
  layout: "inline",
};

function Header(props) {
  const dispatch = useDispatch();
  const { tagList, platformList, columns } = useSelector((s) => s.fileLib);
  const { loading, getList, pageOpt } = useContext(BusContext);
  // 表头设置
  const [headersInfo, setHeadersInfo] = useState({
    show: false,
    selects: [],
  });
  const showSetHeader = () => setHeadersInfo({ ...headersInfo, show: true });
  const onClose = () => setHeadersInfo({ ...headersInfo, show: false });

  const setColumns = useCallback(
    (columns) => dispatch(setFileLibColumns({ columns })),
    [dispatch]
  );

  const _tagList = [...tagInit, ...tagList];
  const _platformList = [...platformInit, ...platformList];

  // eslint-disable-next-line no-unused-vars
  const platformOptionNode = useMemo(
    () =>
      _platformList.map((v) => (
        <Option value={v.id} key={v.id}>
          {v.platform_name}
        </Option>
      )),
    [_platformList]
  );
  const tagOptionNode = useMemo(
    () =>
      _tagList.map((v) => (
        <Option value={v.id} key={v.id}>
          {v.label_name}
        </Option>
      )),
    [_tagList]
  );

  const [form] = Form.useForm();
  const initialValues = {
    keyword: "",
    platformValue: 0,
    // timeValue: defaultTime,
    timeValue: "",
    tagValue: 0,
  };

  useEffect(() => {
    form.submit();
  }, [form]);

  const search = params => {
    // eslint-disable-next-line no-unused-vars
    const { keyword, platformValue, timeValue, tagValue } = params;
    const query = {
      keyword,
      label_id: tagValue,
      date: timeValue ? timeValue.format("YYYY-MM-DD") : "",
      // field: '',
    };
    // 这里还要写查询条件
    getList(1, query);
  }

  const reset = useCallback(() => {
    form.resetFields();
    form.submit();
  }, [form]);

  return (
    <Card title="号码包列表" bordered={false} extra={HeaderExtra({ getList })}>
      <TableSet
        headersInfo={headersInfo}
        onClose={onClose}
        columns={columns}
        setColumns={setColumns}
        localKey="file-lib-header-ids"
        okCallBack={() => {
          // 重新请求一次  只有要改 field
          getList(pageOpt.current, undefined);
        }}
      ></TableSet>
      <div>
        {/* 查询 重置 表头设置 */}
        <Form
          {...layout}
          form={form}
          name="basic"
          initialValues={initialValues}
          onFinish={search}
        >
          <Form.Item label="" name="keyword">
            <Input placeholder="输入号码包名称搜索" style={{ width: 140 }} />
          </Form.Item>
          {/* 暂时先隐藏平台 */}
          {/* <Form.Item label="" name="platformValue">
            <Select
              showSearch
              style={{ width: 140 }}
              placeholder="搜索平台"
              optionFilterProp="children"
            >
              {platformOptionNode}
            </Select>
          </Form.Item> */}
          <Form.Item label="" name="timeValue">
            <DatePicker placeholder="请选择记录日期" style={{ width: 140 }} />
          </Form.Item>
          <Form.Item label="" name="tagValue">
            <Select
              showSearch
              style={{ width: 140 }}
              placeholder="搜索标签"
              optionFilterProp="children"
            >
              {tagOptionNode}
            </Select>
          </Form.Item>
          <Space>
            <Button
              type="primary"
              htmlType="submit"
              size={SIZE}
              loading={loading}
            >
              查询
            </Button>
            <Button type="primary" size={SIZE} ghost onClick={reset}>
              重置
            </Button>
            <Button type="primary" onClick={showSetHeader} size={SIZE} ghost>
              表头设置
            </Button>
          </Space>
        </Form>
      </div>
    </Card>
  );
}

// 卡片右上角的操作区域
function HeaderExtra({ getList }) {
  const [visible, setVisible] = useState(false);
  return (
    <>
      <Button
        type="primary"
        size={SIZE}
        onClick={() => {
          setVisible(true);
        }}
      >
        创建号码包
      </Button>
      {/* 创建 1 */}
      <Create
        type={1}
        callBack={() => {
          getList();
        }}
        visible={visible}
        close={() => {
          setVisible(false);
        }}
      />
    </>
  );
}

export default Header;
