import React from "react";
import Settings from "@/components/Settings";
const Tags = () => {
  return <Settings />;
};
export default Tags;
