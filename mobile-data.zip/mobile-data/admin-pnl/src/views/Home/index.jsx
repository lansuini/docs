import React, { useState, useEffect } from "react";

const Home = () => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    setCount(3);
  }, []);
  return (
    <div>
      <p>you clicked {count} times</p>
      <button type="button" onClick={() => setCount(count + 1)}>
        click me
      </button>
    </div>
  );
};
export default Home;
