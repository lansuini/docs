// 号码包列表
import React, { useEffect, useState, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import Header from "./components/header";
import List from "./components/list";
import styles from "./index.module.less";
import { BusContext } from "./components/context";
import { getTags, getPlat } from "@/store/actions/foreignEmail";
import { getForeignEmailList } from "@/services";

let pageOpt = {
  total: 0,
  current: 1,
  count: 0,
  pageSize: 10, // 每页条数
};
const setPageOpt = (opt) => {
  pageOpt = { ...pageOpt, ...opt };
};
// 查询条件
let lastQuery = {};

const FileLib = () => {
  const dispatch = useDispatch();
  const { columns } = useSelector((state) => state.foreignEmail);  
  const [loading, setLoading] = useState(false);
  const [list, setList] = useState([]);

  // 第一次 getlist 在 header 中
  // 获取 平台和标签
  useEffect(() => {
    dispatch(getPlat());
    dispatch(getTags());
  }, [dispatch]);

  const getList = useCallback(async (page = 1, query) => {
    // query = undefined 取上次的
    if (query) {
      lastQuery = query;
    }
    const fields = columns
      .filter((x) => x.visible && !["operation"].includes(x.id))
      .map((x) => x.id)
      .join(",");

    try {
      setLoading(true);
      const res = await getForeignEmailList({
        page: page,
        pagesize: pageOpt.pageSize,
        ...lastQuery,
        ...query,
        field: fields,
      });
      if (res.code === 200) {
        const {
          data: { total, currentPage, count, data },
        } = res;
        setList(data);
        setPageOpt({
          ...pageOpt,
          total,
          count,
          current: currentPage,
        });
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value = {
    loading,
    pageOpt,
    setPageOpt,
    getList,
    list,
  };

  return (
    <BusContext.Provider value={value}>
      <div className={styles.fileLib}>
        <Header />
        <List />
      </div>
    </BusContext.Provider>
  );
};

export default FileLib;
