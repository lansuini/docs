import React from "react";
import { Modal, Tabs } from "antd";
import ModifyLog from "./modifyLog";
import CommitLog from "./commitLog";
import ExportLog from "./exportLog";

const { TabPane } = Tabs;
// 号码日志，type 1 国内号码包，2 外国号码包
const NumberPackLog = ({ id, visible, onClose, tabkey = "1", type = 1 }) => {
  return (
    <>
      <Modal
        // forceRender
        title="号码包日志"
        footer={null}
        maskClosable={true}
        destroyOnClose={true}
        visible={visible}
        onCancel={onClose}
        width="95%"
      >
        <Tabs type="card" defaultActiveKey={tabkey}>
          <TabPane tab="修改日志" key="1">
            <ModifyLog id={id} type={type} />
          </TabPane>
          <TabPane tab="提交日志" key="2">
            <CommitLog id={id} type={type} />
          </TabPane>
          <TabPane tab="导出日志" key="3">
            <ExportLog id={id} type={type} />
          </TabPane>
        </Tabs>
      </Modal>
    </>
  );
};

export default NumberPackLog;
