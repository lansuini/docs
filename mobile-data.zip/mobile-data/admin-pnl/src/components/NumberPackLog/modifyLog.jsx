import React, { useState, useEffect, useCallback } from "react";
import dayjs from "dayjs";
import List from "./components/list";
import { pckModifyLog, pckForeignModifyLog, emailChangeLog } from "@/services";
const columns = [
  {
    title: "时间",
    dataIndex: "created_at",
    align: "center",
    render(text) {
      const d = dayjs.unix(text);
      return d.format("YYYY-MM-DD HH:mm:ss");
    },
  },
  {
    title: "修改内容",
    dataIndex: "content",
    align: "center",
  },
  {
    title: "操作人",
    dataIndex: "account",
    align: "center",
  },
];
const PAGESIZE = 10;
const ModifyLog = ({ id, type }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const getData = useCallback(
    async (page = 1, pagesize = PAGESIZE) => {
      try {
        setLoading(true);
        let api = ''
        if (type === 1) {
          api = pckModifyLog
        } else if (type === 2) {
          api = pckForeignModifyLog
        } else if (type === 3) {
          api = emailChangeLog
        }
        const res = await api({
          package_id: id,
          page,
          pagesize,
        });
        setData(res.data);
        setLoading(false);
      } catch (e) {
        setData([]);
        setLoading(false);
      }
    },
    [id, type]
  );
  useEffect(() => {
    getData();
  }, [getData]);

  return (
    <List
      columns={columns}
      loading={loading}
      pageSize={PAGESIZE}
      data={data}
      getData={getData}
    />
  );
};

export default ModifyLog;
