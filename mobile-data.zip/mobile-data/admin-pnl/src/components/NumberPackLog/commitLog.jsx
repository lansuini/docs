import React, { useState, useEffect, useCallback } from "react";
import { Popover, Button } from "antd";
import List from "./components/list";
import { pckCommitLog, pckForeignCommitLog, emailUploadLog } from "@/services";
import dayjs from "dayjs";
import CommitLogDetail from "./commitLogDetail";

const columns = [
  {
    title: "提交时间",
    dataIndex: "created_at",
    align: "center",
    render(text) {
      const d = dayjs.unix(text);
      return d.format("YYYY-MM-DD HH:mm:ss");
    },
  },
  {
    title: "文件名",
    dataIndex: "old_file_name",
    align: "center",
  },
  {
    title: "提交类型",
    dataIndex: "type",
    align: "center",
    render(type) {
      const text = {
        1: "新号",
        2: "使用号",
        3: "注册号",
        4: "反馈号",
        5: "沉默号",
        6: "风险号",
        7: "空号",
        8: "姓名号码",
      }[type];
      return text;
    },
  },
  {
    title: "原文件号码数量",
    dataIndex: "total",
    align: "center",
  },
  {
    title: "剔除重复号码",
    dataIndex: "file_reply_sum",
    align: "center",
  },
  {
    title: "无效数据",
    dataIndex: "invalid_sum",
    align: "center",
  },
  {
    title: "实际提交数量",
    dataIndex: "real_total",
    align: "center",
  },
  {
    title: "提交平台",
    dataIndex: "platform_name",
    align: "center",
    render(text) {
      return <span>{text || "--"}</span>;
    },
  },
  {
    title: "关联多个号码包的号码",
    dataIndex: "other_package_reply_sum",
    align: "center",
  },
  {
    title: "提交详情",
    align: "center",
    render(text, item) {
      // 新号显示详情 ,其他没详情
      return item.type === 1 ? (
        <Popover
          placement="leftBottom"
          content={<CommitLogDetail data={item} />}
          title="提交详情"
          trigger="hover"
        >
          <Button type="dashed">查看</Button>
        </Popover>
      ) : (
        "-"
      );
    },
  },
  {
    title: "操作人",
    dataIndex: "account",
    align: "center",
  },
];
const PAGESIZE = 10;
const CommitLog = ({ id, type }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const getData = useCallback(
    async (page = 1, pagesize = PAGESIZE) => {
      try {
        setLoading(true);

        let api = ''
        if (type === 1) {
          api = pckCommitLog
        } else if (type === 2) {
          api = pckForeignCommitLog
        } else if (type === 3) {
          api = emailUploadLog
        }

        const res = await api({
          package_id: id,
          page,
          pagesize,
        });
        setData(res.data);
        setLoading(false);
      } catch (e) {
        setData([]);
        setLoading(false);
      }
    },
    [id, type]
  );
  useEffect(() => {
    getData();
  }, [getData]);
  return (
    <List
      columns={columns}
      loading={loading}
      pageSize={PAGESIZE}
      data={data}
      getData={getData}
    />
  );
};

export default CommitLog;
