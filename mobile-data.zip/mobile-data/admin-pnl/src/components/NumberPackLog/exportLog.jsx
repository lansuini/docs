import React, { useState, useEffect, useCallback } from "react";
import { Button,message } from "antd";
import dayjs from "dayjs";
import List from "./components/list";
import { pckExportLog, pckForeignExportLog, emailExportLog } from "@/services";
import { downloadHandle } from '@/services'
const columns = [
  {
    title: "时间",
    dataIndex: "created_at",
    align: "center",
    render(text) {
      const d = dayjs.unix(text);
      return d.format("YYYY-MM-DD HH:mm:ss");
    },
  },
  {
    title: "文件名",
    dataIndex: "file_name",
    align: "center",
  },
  {
    title: "导出筛选条件",
    dataIndex: "condition",
    align: "center",
  },
  {
    title: "操作人",
    dataIndex: "account",
    align: "center",
  },
  {
    title: "下载",
    dataIndex: "user",
    align: "center",
    render(text, item) {
      if (item.is_ok) {
        return (
          <Button
            type="link"
            onClick={async () => {
              try {
                downloadHandle({ fileName: item.file_name })
              } catch (error) {
                message.error(error)
              }
            }}
          >
            下载
          </Button>
        );
      } else {
        return "已过期";
      }
    },
  },
];
const PAGESIZE = 10;
const ExportLog = ({ id, type }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const getData = useCallback(
    async (page = 1, pagesize = PAGESIZE) => {
      try {
        setLoading(true);
        
        let api = ''
        if (type === 1) {
          api = pckExportLog
        } else if (type === 2) {
          api = pckForeignExportLog
        } else if (type === 3) {
          api = emailExportLog
        }
        
        const res = await api({
          package_id: id,
          page,
          pagesize,
        });
        setData(res.data);
        setLoading(false);
      } catch (e) {
        setData([]);
        setLoading(false);
      }
    },
    [id, type]
  );
  useEffect(() => {
    getData();
  }, [getData]);
  return (
    <List
      columns={columns}
      loading={loading}
      pageSize={PAGESIZE}
      data={data}
      getData={getData}
    />
  );
};

export default ExportLog;
