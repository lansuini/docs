import React from "react";
import { Table } from "antd";
const columns = [
  {
    title: "移动号",
    dataIndex: "cmcc_sum",
    align: "center",
  },
  {
    title: "联通号",
    dataIndex: "cucc_sum",
    align: "center",
  },
  {
    title: "电信号",
    dataIndex: "ctcc_sum",
    align: "center",
  },
  {
    title: "虚拟号",
    dataIndex: "virtual_sum",
    align: "center",
  },

  // {
  //   title: "数据金额",
  //   dataIndex: "money_sum",
  //   align: "center",
  //   render(text) {
  //     return `${text}元`;
  //   },
  // },
  // {
  //   title: "平均价格",
  //   dataIndex: "money_avg",
  //   align: "center",
  //   render(text) {
  //     return `${text}元/条`;
  //   },
  // },
];
const CommitLogDetail = ({ data }) => {
  return (
    <>
      <Table
        locale={{
          emptyText: "暂无数据",
        }}
        bordered
        rowKey="id"
        columns={columns}
        dataSource={[data]}
        pagination={false}
      />
    </>
  );
};
export default CommitLogDetail;
