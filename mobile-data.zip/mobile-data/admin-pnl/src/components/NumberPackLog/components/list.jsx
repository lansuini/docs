import React from "react";
import { Table } from "antd";

function List({ loading, columns, data, pageSize, getData }) {
  // 切换页码
  const changePage = (page) => {
    getData(page);
  };

  return (
    <>
      <Table
        locale={{
          emptyText: "暂无数据",
        }}
        bordered
        rowKey="id"
        columns={columns}
        dataSource={data.data}
        loading={loading}
        pagination={{
          showSizeChanger: false,
          pageSize,
          total: data.total,
          current: data.currentPage,
          onChange: changePage,
        }}
      />
    </>
  );
}

export default List;
