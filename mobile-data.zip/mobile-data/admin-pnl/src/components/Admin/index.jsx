import React, { Fragment } from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import { Layout } from "antd";
import routers from "@/router/routes";
import AdminHeader from "@/components/AdminHeader";
import AdminMenu from "@/components/AdminMenu";
import NoMatch from "@/components/NoMatch";
import styles from "./index.module.less";
const { Content } = Layout;
const Admin = () => {
  return (
    <Fragment>
      <Layout style={{ minHeight: "100vh" }}>
        <AdminHeader></AdminHeader>
        <Layout>
          <AdminMenu></AdminMenu>
          <Layout className={styles.containerWrap}>
            <Content>
              <div className={styles.container}>
                <Switch>
                  <Route
                    path="/"
                    exact
                    render={() => <Redirect to="/file-lib" />}
                  ></Route>
                  {routers.map((route) => (
                    <Route
                      key={route.path}
                      path={route.path}
                      component={route.component}
                      exact={route.exact}
                    ></Route>
                  ))}
                  <Route path="*">
                    <NoMatch />
                  </Route>
                </Switch>
              </div>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </Fragment>
  );
};

export default Admin;
