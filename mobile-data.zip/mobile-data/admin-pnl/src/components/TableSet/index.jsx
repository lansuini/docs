import React, { useEffect, useCallback } from "react";
import { Modal, Checkbox, Row, Col } from "antd";
import propTypes from "prop-types";

TableSet.propTypes = {
  headersInfo: propTypes.object.isRequired, // 显示和隐藏
  onClose: propTypes.func.isRequired, // 关闭
  columns: propTypes.array.isRequired,
  setColumns: propTypes.func.isRequired,
  disabled: propTypes.array, // 不让用户选择的
  localKey: propTypes.string.isRequired, //  window.localStorage.setItem 中要用的 key
  okCallBack: propTypes.func,
};
const _disabled = ["id", "package_name", "operation"];

let ids = [];
let defaultValue = [];
function TableSet({
  headersInfo,
  onClose,
  columns,
  setColumns,
  localKey,
  disabled = _disabled,
  okCallBack,
}) {
  useEffect(() => {
    defaultValue = columns.filter((v) => v.visible).map((v) => v.id);
    ids = JSON.parse(JSON.stringify(defaultValue));
  }, [columns]);

  const onChange = useCallback((checkedValues) => {
    ids = JSON.parse(JSON.stringify(checkedValues));
  }, []);

  const onOk = useCallback(() => {
    columns.forEach((v) => {
      v.visible = !!ids.includes(v.id);
    });
    window.localStorage.setItem(localKey, JSON.stringify(ids));
    setColumns([...columns]);
    onClose();

    typeof okCallBack === "function" && okCallBack();
  }, [columns, localKey, okCallBack, onClose, setColumns]);

  const plainOptions = columns.map((x) => {
    return { label: x.title, value: x.id };
  });

  return (
    <Modal
      title={`设置表头字段`}
      visible={headersInfo.show}
      onCancel={() => {
        onClose();
        // setModalStatus(false);
      }}
      okText="确认"
      cancelText="取消"
      onOk={onOk}
      width={800}
      destroyOnClose={true}
    >
      <Checkbox.Group defaultValue={defaultValue} onChange={onChange}>
        <Row>
          {plainOptions.map((v) => {
            return (
              <Col
                span={10}
                key={v.value}
                offset={2}
                style={{ marginBottom: "10px" }}
              >
                <Checkbox disabled={disabled.includes(v.value)} value={v.value}>
                  {v.label}
                </Checkbox>
              </Col>
            );
          })}
        </Row>
      </Checkbox.Group>
    </Modal>
  );
}

export default TableSet;
