import React from "react";
import dayjs from "dayjs";
import { Space, Button, Modal } from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";

const getColumns = (menuType, toggleModal, deleteAction) => {
  const title = menuType === "tags" ? "标签" : "平台";
  const key = menuType === "tags" ? "label_name" : "platform_name";
  const confirm = (item) => {
    Modal.confirm({
      title: "提示",
      icon: <ExclamationCircleOutlined />,
      content: `您确定要删除 ${item[key]} 吗? 删除后数据将不可恢复!`,
      okText: "确认",
      cancelText: "取消",
      maskClosable: true,
      onOk() {
        return new Promise(async (resolve) => {
          await deleteAction(item.id);
          resolve();
        });
      },
    });
  };
  const columns = [
    {
      title,
      dataIndex: key,
      align: "center",
    },
    {
      title: "添加时间",
      dataIndex: "created_at",
      align: "center",
      render(text) {
        const d = dayjs.unix(text);
        return d.format("YYYY-MM-DD HH:mm:ss");
      },
    },
    {
      title: "操作",
      align: "center",
      render(text, item, index) {
        return (
          <Space size="small">
            <Button
              type="link"
              size="small"
              onClick={() => toggleModal(true, 2, item.id, item[key])}
            >
              编辑
            </Button>
            <Button type="dashed" size="small" onClick={() => confirm(item)}>
              删除
            </Button>
          </Space>
        );
      },
    },
  ];
  return columns;
};
export default getColumns;
