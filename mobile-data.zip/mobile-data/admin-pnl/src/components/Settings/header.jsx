import React from "react";
import { Card, Button } from "antd";
const Header = ({ menuType, toggleModal }) => {
  const title = menuType === "tags" ? "标签" : "平台";
  return (
    <Card
      title={`${title}管理`}
      bordered={false}
      extra={
        <Button
          type="primary"
          size="middle"
          onClick={() => {
            toggleModal();
          }}
        >
          添加{title}
        </Button>
      }
    ></Card>
  );
};
export default Header;
