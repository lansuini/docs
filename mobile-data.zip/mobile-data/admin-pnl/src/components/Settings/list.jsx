import React from "react";
import { Table } from "antd";
import getColumns from "./columns";

function List({
  menuType,
  loading,
  data,
  pageSize,
  getData,
  toggleModal,
  deleteAction,
}) {
  const columns = getColumns(menuType, toggleModal, deleteAction);
  // 切换页码
  const changePage = (page) => {
    getData(page);
  };
  return (
    <>
      <Table
        // scroll={{ x: true }}
        locale={{
          emptyText: "暂无数据",
        }}
        bordered
        rowKey="id"
        columns={columns}
        dataSource={data.data}
        loading={loading}
        pagination={{
          pageSize,
          total: data.total,
          current: data.currentPage,
          onChange: changePage,
        }}
      />
    </>
  );
}

export default List;
