import React, { useState, useCallback, useEffect } from "react";
import { TagsService, PlatFormServicve } from "@/services";
import { message } from "antd";
import Header from "./header";
import List from "./list";
import CreateOrUpdate from "./createOrUpdate";
const PAGESIZE = 10;

const Settings = ({ menuType = "tags" }) => {
  const SettingService = menuType === "tags" ? TagsService : PlatFormServicve;
  // 数据
  const [dataSource, saveDataSource] = useState([]);
  // loading
  const [loading, setLoading] = useState([]);
  // 对话框可见状态
  const [visible, setVisible] = useState(false);
  // 操作类型 (新增:1,编辑:2)
  const [operateType, setOperateType] = useState(1);
  // 操作id (用于修改/删除 操作)
  const [operateId, setOperateId] = useState(0);
  // 旧的本文 (用于编辑 显示)
  const [oldText, setOldText] = useState("");
  // 切换弹框(新增/编辑)
  const toggleModal = useCallback(
    (state = true, type = 1, id, text = "") => {
      setOperateType(type);
      setOldText(text);
      ![null, undefined].includes(id) && setOperateId(id);
      setVisible(state);
      console.log(oldText);
    },
    [oldText]
  );
  // 获取列表
  const getData = useCallback(
    async (page = 1, pagesize = PAGESIZE) => {
      setLoading(true);
      try {
        const res = await SettingService.read({
          page,
          pagesize,
        });
        saveDataSource(res.data);
        setLoading(false);
      } catch (e) {
        saveDataSource([]);
        setLoading(false);
      }
    },
    [SettingService]
  );
  // 新增
  const create = useCallback(
    async (params) => {
      try {
        await SettingService.create(params);
        toggleModal(false);
        getData();
      } catch (errInfo) {
        message.destroy();
        message.error(errInfo);
        return new Promise().reject();
      }
    },
    [SettingService, getData, toggleModal]
  );
  // 编辑
  const update = useCallback(
    async (params) => {
      try {
        await SettingService.update(params);
        toggleModal(false);
        getData();
      } catch (errInfo) {
        message.destroy();
        message.error(errInfo);
        return new Promise().reject();
      }
    },
    [SettingService, getData, toggleModal]
  );
  // 删除
  const del = useCallback(
    async (id) => {
      try {
        await SettingService.delete(id);
        getData();
      } catch (errInfo) {
        message.destroy();
        message.error(errInfo);
        return new Promise().reject();
      }
    },
    [SettingService, getData]
  );
  useEffect(() => {
    getData();
  }, [getData]);
  return (
    <>
      {/* 头部 */}
      <Header menuType={menuType} toggleModal={toggleModal} />
      {/* 列表 */}
      <List
        menuType={menuType}
        data={dataSource}
        pageSize={PAGESIZE}
        getData={getData}
        loading={loading}
        toggleModal={toggleModal}
        deleteAction={del}
      />
      {/* 新增/修改 */}
      <CreateOrUpdate
        visible={visible}
        menuType={menuType}
        operateType={operateType}
        operateId={operateId}
        name={oldText}
        toggleModal={toggleModal}
        createAction={create}
        updateAction={update}
      />
    </>
  );
};
export default Settings;
