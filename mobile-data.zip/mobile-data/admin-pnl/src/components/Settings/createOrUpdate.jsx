import React, { useState, useCallback, useEffect } from "react";
import { Modal, Form, Input } from "antd";
const CreateOrUpdate = ({
  menuType,
  operateType,
  operateId,
  visible,
  name,
  toggleModal,
  createAction,
  updateAction,
}) => {
  const layout = {
    labelCol: { span: 0 },
    wrapperCol: { span: 24 },
  };
  // 菜单标题
  const title = menuType === "tags" ? "标签" : "平台";
  // 标题
  const modalTitle = operateType === 1 ? `新增${title}` : `修改${title}`;
  // 表单
  const [form] = Form.useForm();
  useEffect(() => {
    form.setFieldsValue({ name: name });
  }, [form, name]);
  // loading
  const [loading, setLoading] = useState(false);
  const submit = useCallback(async () => {
    const params = await form.validateFields();
    setLoading(true);
    try {
      operateType === 1
        ? await createAction(params)
        : await updateAction({
            id: operateId,
            ...params,
          });
      form.setFieldsValue({ name: "" });
      setLoading(false);
    } catch (e) {
      setLoading(false);
    }
  }, [createAction, form, operateId, operateType, updateAction]);
  const close = useCallback(() => {
    toggleModal(false, operateType);
    form.setFieldsValue({ name: "" });
  }, [form, operateType, toggleModal]);
  return (
    <Modal
      forceRender
      cancelText="取消"
      okText="确定"
      title={modalTitle}
      visible={visible}
      confirmLoading={loading}
      onOk={submit}
      onCancel={close}
    >
      <Form {...layout} form={form} name="basic">
        <Form.Item
          label="名称"
          name="name"
          rules={[
            {
              required: true,
              message: "请填写名称",
            },
            {
              max: 35,
              message: "名称不得超过35",
            },
          ]}
          getValueFromEvent={(event) => {
            return event.target.value.replace(/\s+/g, "");
          }}
        >
          <Input />
        </Form.Item>
      </Form>
    </Modal>
  );
};
export default CreateOrUpdate;
