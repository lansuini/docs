import React from "react";
import { useDispatch } from "react-redux";
import { Layout, message } from "antd";
import { useHistory } from "react-router-dom";
import styles from "./index.module.less";
import { logout } from "@/services";
import { _set as SETUSER } from "@/store/actions/user";

const { Header } = Layout;
const AdminHeader = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const onLogoutAction = async () => {
    try {
      await logout();
      dispatch(SETUSER({ isLogin: false }))
      window.localStorage.clear();
      history.push("/login");
    } catch (errorInfo) {
      message.destroy();
      message.error(errorInfo);
    }
  };
  return (
    <Header className={styles.header}>
      <img
        className={styles.logo}
        src={require("@/assets/images/logo.png")}
        alt="logo"
      />
      <div className={styles.userInfo}>
        {/* 按产品要求，先隐藏用户名，只保留退出按钮 */}
        {/* <span>{window.localStorage.getItem("account")}</span>
        <em>|</em> */}
        <span className={styles.exit} onClick={onLogoutAction}>
          退出
        </span>
      </div>
      {/* <h3 className={styles.title}>号码库</h3> */}
    </Header>
  );
};

export default AdminHeader;
