import React from 'react';
import { useHistory } from 'react-router-dom'
import styles from './index.module.less';
const backImg = require('../../assets/images/back.png');

function TopBack(props) {
  const history = useHistory();
  return (
    <div className={styles.backWrap}>
      <img src={backImg} className={styles.backArr} alt="" onClick={()=>{history.goBack()}} />
      <span className={styles.title}>{props.children}</span>
    </div>
  );
}

export default TopBack;