import React from "react";
import { Route, Redirect } from "react-router";
import { useSelector } from "react-redux";

const PrivateRoute = ({ children, ...props }) => {
  // const loggedIn = window.localStorage.getItem("token");
  // const [loggedIn] = useState(() => window.localStorage.getItem("token"));
  const { isLogin } =  useSelector((state) => state.user);  
  return (
    <Route
      {...props}
      render={() =>
        isLogin ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: "/login",
            }}
          />
        )
      }
    />
  );
};
export default PrivateRoute;
