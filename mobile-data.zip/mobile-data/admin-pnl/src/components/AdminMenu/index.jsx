import React from "react";
import { Layout, Menu } from "antd";
import { Link, useLocation } from "react-router-dom";
import { menuList } from "@/router/routes";
const { SubMenu } = Menu;
const { Sider } = Layout;
const AdminMenu = () => {
  const location = useLocation();
  return (
    <Sider width={200} className="site-layout-background">
      <Menu
        theme="dark"
        mode="inline"
        selectedKeys={[location.pathname]}
        defaultOpenKeys={["0", "1"]}
        style={{ height: "100%", borderRight: 0 }}
      >
        {menuList.map((menu, index) => (
          <SubMenu key={index} icon={<menu.icon />} title={menu.name}>
            {menu.subMenu.map((subMenu) => (
              <Menu.Item key={`${subMenu.path}`}>
                <Link to={subMenu.path}>{subMenu.name}</Link>
              </Menu.Item>
            ))}
          </SubMenu>
        ))}
      </Menu>
    </Sider>
  );
};

export default AdminMenu;
