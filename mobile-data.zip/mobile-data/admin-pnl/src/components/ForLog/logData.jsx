import React from "react";
import dayjs from "dayjs";

export const cols = {
  edit: [
    {
      title: "提交时间",
      key: "created_at",
      dataIndex: "created_at",
      align: "center",
      width: 200,
      render(text) {
        const d = dayjs.unix(text);
        return d.format("YYYY-MM-DD HH:mm:ss");
      },
    },
    {
      title: "修改类型",
      key: "content",
      dataIndex: "content",
      align: "center",
      width: 300,
    },
    {
      title: "操作人",
      key: "admin_name",
      dataIndex: "admin_name",
      align: "center",
    },
  ],
  use: [
    {
      title: "使用日期",
      key: "use_time",
      dataIndex: "use_time",
      align: "center",
      width: 200,
      render(text) {
        const d = dayjs.unix(text);
        return d.format("YYYY-MM-DD");
      },
    },
    {
      title: "使用平台",
      key: "platform_name",
      dataIndex: "platform_name",
      align: "center",
      width: 300,
    },
    {
      title: "操作人",
      key: "admin_name",
      dataIndex: "admin_name",
      align: "center",
    },
  ],
  tick: [
    {
      title: "反馈日期",
      key: "created_at",
      dataIndex: "created_at",
      align: "center",
      width: 150,
      render(text) {
        const d = dayjs.unix(text);
        return d.format("YYYY-MM-DD HH:mm:ss");
      },
    },
    {
      title: "反馈平台",
      key: "platform_name",
      dataIndex: "platform_name",
      align: "center",
      width: 200,
    },
    {
      title: "充值金额",
      key: "chargeMoney",
      dataIndex: "chargeMoney",
      align: "center",
      width: 100,
    },
    {
      title: "盈亏金额",
      key: "profitMoney",
      dataIndex: "profitMoney",
      align: "center",
      width: 100,
      render(text) {
        const color = text.includes("-") ? "#00CC33" : "#FF0000";
        return (
          <span style={{ color: color }}>
            {text.includes("-")?text:`+${text}`}
          </span>
        );
      },
    },
    {
      title: "提交人",
      key: "admin_name",
      dataIndex: "admin_name",
      align: "center",
    },
  ],
  export:[
    {
      title: "导出日期",
      key: "export_at",
      dataIndex: "export_at",
      align: "center",
      width: 200,
      render(text) {
        const d = dayjs.unix(text);
        return d.format("YYYY-MM-DD HH:mm:ss");
      },
    },
    {
      title: "导出文件名称",
      key: "file_name",
      dataIndex: "file_name",
      align: "center",
      width: 300,
    },
    {
      title: "导出人",
      key: "admin_name",
      dataIndex: "admin_name",
      align: "center",
    },
  ]
};
