import React, { useState } from 'react';
import {Button} from 'antd'
import Log from './Log';


function LoginBtn() {
  const [logInfo,setLogInfo] = useState({show:false,selects:[]})  
  const showLog = () => setLogInfo(Object.assign({},logInfo,{show:true}));
  return (<>
    <Log props={logInfo}></Log>
    <Button onClick={showLog}>日志</Button>
  </>);
}

export default LoginBtn;