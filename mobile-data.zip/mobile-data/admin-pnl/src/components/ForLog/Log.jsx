import React, { useState, useEffect, useCallback } from 'react';
import { Modal, Spin, Tabs, Table, message } from 'antd';

import { cols } from './logData';
import { getPhoneLog } from '@/services';

const { TabPane } = Tabs;

function Log({ props }) {
  const { num } = props;
  const [modalStatus, setModalStatus] = useState(false);
  const [editDataSource, setEditDataSource] = useState([]);
  const [usedDataSource, setUsedDataSource] = useState([]);
  const [tickDataSource, setTickDataSource] = useState([]);
  const [exportSource, setExportSource] = useState([]);
  const [spin, setSpin] = useState(false);
  const getData = useCallback(async () => {
    try {
      setSpin(true);
      const res1 = await getPhoneLog({ type: 1, mobile: num, pageSize: 99999 });
      const res2 = await getPhoneLog({ type: 2, mobile: num, pageSize: 99999 });
      const res3 = await getPhoneLog({ type: 3, mobile: num, pageSize: 99999 });
      const res4 = await getPhoneLog({ type: 4, mobile: num, pageSize: 99999 });
      if (res1.code === 200) {
        setEditDataSource(res1.data.data);
      } else {
        message.error(res1.msg);
      }
      if (res2.code === 200) {
        setUsedDataSource(res2.data.data);
      } else {
        message.error(res2.msg);
      }
      if (res3.code === 200) {
        setTickDataSource(res3.data.data);
      } else {
        message.error(res3.msg);
      }
      if (res4.code === 200) {
        setExportSource(res4.data.data);
      } else {
        message.error(res4.msg);
      }
      console.log(res1, res2, res3, res4, '09090')
      setSpin(false);
    } catch (error) {
      message.error(error||'请求错误')
    }

  }, [setEditDataSource, setSpin, setTickDataSource, setUsedDataSource, setExportSource, num]);

  useEffect(() => {
    // show 然后做一个请求然后hide
    if (props.show) {
      setModalStatus(true);
      getData();
    }
  }, [props, getData, setModalStatus]);

  return (
    <Modal
      title={`号码日志 (${num})`}
      footer={[]}
      visible={modalStatus}
      onCancel={() => {
        setModalStatus(false);
      }}
      width={800}
    >
      <Spin spinning={spin}>
        <Tabs defaultActiveKey="1" type="card">
          <TabPane tab="修改日志" key="1">
            <Table size="small" locale={{
              emptyText: "暂无数据",
            }} rowKey={'id'} scroll={{ y: 600 }} columns={cols.edit} dataSource={editDataSource} pagination={false} bordered></Table>
          </TabPane>
          <TabPane tab="使用日志" key="2">
            <Table size="small" locale={{
              emptyText: "暂无数据",
            }} rowKey={'id'} scroll={{ y: 600 }} columns={cols.use} dataSource={usedDataSource} pagination={false} bordered></Table>
          </TabPane>
          <TabPane tab="反馈日志" key="3">
            <Table size="small" locale={{
              emptyText: "暂无数据",
            }} rowKey={'id'} scroll={{ y: 600 }} columns={cols.tick} dataSource={tickDataSource} pagination={false} bordered></Table>
          </TabPane>
          <TabPane tab="导出日志" key="4">
            <Table size="small" locale={{
              emptyText: "暂无数据",
            }} rowKey={'id'} scroll={{ y: 600 }} columns={cols.export} dataSource={exportSource} pagination={false} bordered></Table>
          </TabPane>
        </Tabs>
      </Spin>
    </Modal>
  );
}

export default Log;
