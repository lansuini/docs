import React from "react";
import { Result, Button } from "antd";
import { useHistory } from "react-router-dom";
const NoMatch = () => {
  const history = useHistory();
  const goBack = () => {
    history.replace("/file-lib");
  };
  return (
    <Result
      status="404"
      title="404"
      subTitle="Oh~~您的页面好像飞走了~."
      extra={
        <Button type="primary" onClick={goBack}>
          返回首页
        </Button>
      }
    />
  );
};
export default NoMatch;
