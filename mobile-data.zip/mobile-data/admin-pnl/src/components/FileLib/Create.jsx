//  创建号码包
import React, { useMemo, useState } from "react";
import { useSelector } from "react-redux";
import {
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
  message,
  InputNumber,
} from "antd";
import dayjs from "dayjs";
import PropTypes from "prop-types";
import { createLib, editLib } from "@/services";

const layout = {
  labelCol: {
    span: 6,
  },
  wrapperCol: {
    span: 16,
  },
};

const defaultTime = dayjs();
const SIZE = "middle";

function Create(props) {
  const { close, visible, type, data, callBack } = props;
  const [form] = Form.useForm();
  const { tagList } = useSelector((s) => s.fileLib);
  const [loading, setLoading] = useState(false);

  // 初始化
  let initialValues = {
    time: defaultTime,
    amount: 0.0,
  };
  let title = "创建号码包";
  let okText = "确定";
  if (type === 2) {
    title = "修改号码包";
    okText = "修改";
    form.resetFields();
    initialValues = {
      name: data.package_name,
      time: dayjs(data.date),
      amount: Number(data.amount),
      tags: data.label && data.label.map((v) => v.label_id),
    };
  }

  const tagOptionNode = useMemo(() => {
    return tagList.map((v, i) => (
      <Select.Option value={v.id} key={i}>
        {v.label_name}
      </Select.Option>
    ));
  }, [tagList]);

  const submit = async () => {
    // form.submit();
    const params = await form.validateFields();
    try {
      const { name, tags = [], time, amount } = params;
      setLoading(true);
      // tag 暂时为空先 20201220
      let res = {};
      const _name = name.replace(/ /g, "");
      if (type === 1) {
        res = await createLib({
          name: _name,
          label_id_str: tags.join(","),
          date: time.format("YYYY-MM-DD"),
          amount: amount,
        });
      } else if (type === 2) {
        res = await editLib({
          package_id: data.id,
          name: _name,
          label_id_str: tags.join(","),
          date: time.format("YYYY-MM-DD"),
          amount: amount,
        });
      }
      if (res.code === 200) {
        close();
        form.resetFields();
        message.success("操作成功");
        typeof callBack === "function" && callBack();
      } else {
        message.info(res.msg);
      }
    } catch (error) {
      message.info(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title={title}
      visible={visible}
      confirmLoading={loading}
      onOk={submit}
      okText={okText}
      cancelText="取消"
      onCancel={() => {
        close();
        form.resetFields();
      }}
    >
      <Form {...layout} form={form} initialValues={initialValues}>
        <Form.Item
          label="名称"
          name="name"
          rules={[
            {
              required: true,
              message: "请填写名称",
            },
            {
              whitespace: true,
              message: "名称不能为空",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="记录日期"
          name="time"
          rules={[
            {
              required: true,
              message: "请填写记录日期",
            },
          ]}
        >
          <DatePicker size={SIZE} />
        </Form.Item>
        <Form.Item
          label="数据金额"
          name="amount"
          rules={[
            {
              type: "number",
              message: "必须为数字",
            },
          ]}
        >
          <InputNumber min={0} />
        </Form.Item>
        <Form.Item label="设置标签" name="tags">
          <Select
            mode="multiple"
            style={{ width: "100%" }}
            onChange={(value) => {
              console.log(`selected ${value}`);
            }}
          >
            {tagOptionNode}
          </Select>
        </Form.Item>
      </Form>
    </Modal>
  );
}

Create.propTypes = {
  visible: PropTypes.bool.isRequired,
  close: PropTypes.func.isRequired,
  type: PropTypes.number.isRequired, // 1 创建 2 编辑
  data: PropTypes.object, // 编辑才有的数据
  callBack: PropTypes.func.isRequired, // 执行完的回调
};

export default Create;
