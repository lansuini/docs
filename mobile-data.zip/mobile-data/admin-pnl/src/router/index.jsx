import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import PrivateRoute from "@/components/Route/PrivateRoute";

import Admin from "@/components/Admin";
import Login from "@/views/Login";

const Routes = () => {
  return (
    <Router>
      <Switch>
        <Route path="/login">
          <Login />
        </Route>
        <PrivateRoute>
          <Admin />
        </PrivateRoute>
      </Switch>
    </Router>
  );
};
export default Routes;
