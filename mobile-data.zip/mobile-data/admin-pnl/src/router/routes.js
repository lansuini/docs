import React, { lazy, Suspense } from "react";
import { WhatsAppOutlined, SettingOutlined } from "@ant-design/icons";
const FileLibComponent = lazy(() => import("@/views/FileLib"));
const ForeignFileLibComponent = lazy(() => import("@/views/ForeignFileLib"));
const NumberListComponent = lazy(() => import("@/views/NumberList"));
const ForeignNumberListComponent = lazy(() => import("@/views/ForeignNumberList"));
const NumberUploadComponent = lazy(() => import("@/views/NumberUpload"));
const ForeignNumberUploadComponent = lazy(() => import("@/views/ForeignNumberUpload"));
const ForeignEmailUploadComponent = lazy(() => import("@/views/ForeignEmailUpload"));
const TagsComponent = lazy(() => import("@/views/Tags"));
const PlatformComponent = lazy(() => import("@/views/Platform"));
const ExportLogComponent = lazy(() => import("@/views/ExportLog"));
const FileLibDetailComponent = lazy(() => import("@/views/FileLibDetail"));
const ForeignFileLibDetailComponent = lazy(() => import("@/views/ForeignFileLibDetail"));
const ForeignEmailComponent = lazy(() => import("@/views/ForeignEmail"));
const ForeignEmailDetailComponent = lazy(() => import("@/views/ForeignEmailDetail"));
const ForeignEmailListComponent = lazy(() => import("@/views/ForeignEmailList"));

// 号码包
const FileLib = (props) => {
  return (
    <Suspense fallback={null}>
      <FileLibComponent {...props}></FileLibComponent>
    </Suspense>
  );
};
// 号码包详情
const FileLibDetail = (props) => {
  return (
    <Suspense fallback={null}>
      <FileLibDetailComponent {...props}></FileLibDetailComponent>
    </Suspense>
  );
};
// 所有号码
const NumberList = (props) => {
  return (
    <Suspense fallback={null}>
      <NumberListComponent {...props}></NumberListComponent>
    </Suspense>
  );
};
// 外国号码包
const ForeignFileLib = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignFileLibComponent {...props}></ForeignFileLibComponent>
    </Suspense>
  );
};
// 外国号码包详情
const ForeignFileLibDetail = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignFileLibDetailComponent {...props}></ForeignFileLibDetailComponent>
    </Suspense>
  );
};
// 外国所有号码
const ForeignNumberList = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignNumberListComponent {...props}></ForeignNumberListComponent>
    </Suspense>
  );
};
// 外国邮箱
const ForeignEmail = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignEmailComponent {...props}></ForeignEmailComponent>
    </Suspense>
  );
};
// 外国邮箱详情
const ForeignEmailDetail = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignEmailDetailComponent {...props}></ForeignEmailDetailComponent>
    </Suspense>
  );
};
// 外国邮箱列表
const ForeignEmailList = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignEmailListComponent {...props}></ForeignEmailListComponent>
    </Suspense>
  );
};
// 标签管理
const Tags = (props) => {
  return (
    <Suspense fallback={null}>
      <TagsComponent {...props}></TagsComponent>
    </Suspense>
  );
};
// 上传号码
const NumberUpload = (props) => {
  return (
    <Suspense fallback={null}>
      <NumberUploadComponent {...props}></NumberUploadComponent>
    </Suspense>
  );
};
// 上传号码
const ForeignNumberUpload = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignNumberUploadComponent {...props}></ForeignNumberUploadComponent>
    </Suspense>
  );
};
// 上传号码
const ForeignEmailUpload = (props) => {
  return (
    <Suspense fallback={null}>
      <ForeignEmailUploadComponent {...props}></ForeignEmailUploadComponent>
    </Suspense>
  );
};
// 所有号码导出日志
const ExportLog = (props) => {
  return (
    <Suspense fallback={null}>
      <ExportLogComponent {...props}></ExportLogComponent>
    </Suspense>
  );
};

// 平台管理
const Platform = (props) => {
  return (
    <Suspense fallback={null}>
      <PlatformComponent {...props}></PlatformComponent>
    </Suspense>
  );
};

// 号码库菜单
const numberLibRoutes = [
  {
    path: "/file-lib",
    name: "号码包",
    exact: true,
    component: FileLib,
  },
  {
    path: "/number-list",
    name: "所有号码",
    exact: true,
    component: NumberList,
  },
  {
    path: "/foreign-file-lib",
    name: "外国号码包",
    exact: true,
    component: ForeignFileLib,
  },
  {
    path: "/foreign-number-list",
    name: "外国所有号码",
    exact: true,
    component: ForeignNumberList,
  },
  {
    path: "/foreign-email",
    name: "外国邮箱",
    exact: true,
    component: ForeignEmail,
  },
  {
    path: "/foreign-email-list",
    name: "外国所有邮箱",
    exact: true,
    component: ForeignEmailList,
  },
];

// 号码库隐藏路由
const hideInNumberLibRouters = [
  {
    path: "/number-upload/:id/:name",
    name: "提交号码",
    exact: true,
    component: NumberUpload,
  },
  {
    path: "/foreign-number-upload/:nation/:id/:name",
    name: "提交号码",
    exact: true,
    component: ForeignNumberUpload,
  },
  {
    path: "/foreign-email-upload/:nation/:id/:name",
    name: "提交号码",
    exact: true,
    component: ForeignEmailUpload,
  },
  {
    path: "/export-log/:id?/:name?",
    name: "导出日志",
    exact: true,
    component: ExportLog,
  },
  // 号码库详情   号码列表
  {
    path: "/file-lib/:id",
    name: "号码列表",
    exact: true,
    component: FileLibDetail,
  },
  {
    path: "/foreign-file-lib/:nation/:id",
    name: "号码列表",
    exact: true,
    component: ForeignFileLibDetail,
  },
  {
    path: "/foreign-email/:nation/:id",
    name: "邮箱列表",
    exact: true,
    component: ForeignEmailDetail,
  },
];

// 设置菜单
const settingsRoutes = [
  {
    path: "/tags",
    name: "标签管理",
    exact: true,
    component: Tags,
  },
  {
    path: "/platform",
    name: "平台管理",
    exact: true,
    component: Platform,
  },
];
// 路由列表
const routers = [
  ...numberLibRoutes,
  ...settingsRoutes,
  ...hideInNumberLibRouters,
];
// 菜单列表

export const menuList = [
  {
    name: "号码库",
    subMenu: numberLibRoutes,
    icon: WhatsAppOutlined,
  },
  {
    name: "设置",
    subMenu: settingsRoutes,
    icon: SettingOutlined,
  },
];

export default routers;
