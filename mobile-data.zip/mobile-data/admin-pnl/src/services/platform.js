import http from "@/http/http";
import api from "@/http/api";

// 标签管理
export class PlatFormServicve {
  // 增
  static async create(data) {
    return await http.post(api.platform, data);
  }
  // 删
  static async delete(id) {
    return await http.delete(`${api.platform}/${id}`);
  }
  // 改
  static async update(data) {
    return await http.put(api.platform, data);
  }
  // 查
  static async read(data) {
    return await http.get(api.platform, data);
  }
}
