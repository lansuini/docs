import http from "@/http/http";
import api from "@/http/api";

// 创建包 post
export async function createForeignEmail(data) {
  return await http.post(api.addEmailPackage, data);
}
export async function getForeignEmailList(data) {
  return await http.get(api.getEmailPackage, data);
}
export async function deleteForeignEmail(data) {
  return await http.delete(api.deleteEmailPackage + data.id);
}
// 编辑  put editPackage
export async function editForeignEmail(data) {
  return await http.put(api.updateEmailPackage, data);
}
// 包 详情
export async function foreignEmailInfo(data) {
  return await http.get(api.foreignEmailInfo, data);
}
// 包 详情 中的列表查询
export async function foreignEmailList(data) {
  return await http.post(api.foreignEmailList, data);
}
