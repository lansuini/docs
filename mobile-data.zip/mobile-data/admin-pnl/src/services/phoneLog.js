import http from '@/http/http';
import api from '@/http/api';

// 号码提交日志
export async function getPhoneLog(data) {
  return await http.get(api.phoneLog, data);
}
