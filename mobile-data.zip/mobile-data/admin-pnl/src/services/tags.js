import http from "@/http/http";
import api from "@/http/api";

// 标签管理
export class TagsService {
  // 增
  static async create(data) {
    return await http.post(api.tags, data);
  }
  // 删
  static async delete(id) {
    return await http.delete(`${api.tags}/${id}`);
  }
  // 改
  static async update(data) {
    return await http.put(api.tags, data);
  }
  // 查
  static async read(data) {
    return await http.get(api.tags, data);
  }
}
