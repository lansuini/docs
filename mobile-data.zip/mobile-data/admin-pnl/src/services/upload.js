import http from "@/http/http";
import api from "@/http/api";
import { notification } from "antd";

// 上传新号码
export async function uploadNewMobile(data) {
  return await http.upload(api.uploadNewMobile, data);
}

// 上传新号码
export async function uploadIntMobile(data) {
  return await http.upload(api.uploadIntMobile, data);
}

// 上传邮箱
export async function uploadEmail(data) {
  return await http.upload(api.uploadEmail, data);
}


// 上传使用号码
export async function uploadUseMobile(data) {
  return await http.upload(api.uploadUseMobile, data);
}

// 上传注册号码
export async function uploadRegisterMobile(data) {
  return await http.upload(api.uploadRegisterMobile, data);
}

// 上反馈号码，
export async function uploadFeedbackMobile(data) {
  return await http.upload(api.uploadFeedbackMobile, data);
}
// 上传沉默，风险，空号
export async function uploadSetTypeMobile(data) {
  return await http.upload(api.uploadSetTypeMobile, data);
}
// 上传名字号码
export async function uploadNameMobile(data) {
  return await http.upload(api.uploadNameMobile, data);
}

const openNotificationWithIconSuccess = (type, data) => {
  notification[type]({
    message: "上传成功",
    description: `上传 ${data.old_file_name} 文件成功! 用时:${data.deal_time}秒`,
    duration: null,
  });
};
const openNotificationWithIconError = (type, data) => {
  notification[type]({
    message: "上传失败",
    description: `上传 ${data.old_file_name} 文件失败: ${data.error_log}`,
    duration: null,
  });
};

export async function getOnePackageUploadLog(data, setTipFn) {
  // let time = 1;
  return new Promise((resolve, reject) => {
    http
      .get(api.onePackageUploadLog, data)
      .then((res) => {
        if (res.code === 200) {
          setTipFn(`正在上传中 ${res.data.data.deal_schedule}`);
          if (res.data.data.is_deal === 1) {
            openNotificationWithIconSuccess("success", res.data.data);
            resolve(res);
          } else if (res.data.data.is_deal === 2) {
            openNotificationWithIconError("error", res.data.data);
            resolve(res);
          } else {
            setTimeout(async () => {
              // time++;
              // if (time >= 300) {
              //   // 这里去掉超时的判定  永不超时
              //   resolve({
              //     msg: "上传超时,请重新上传",
              //   });
              // } else {
              resolve(await getOnePackageUploadLog(data, setTipFn));
              // }
            }, 1000);
          }
        }
      })
      .catch((res) => {
        console.log(res);
        reject(res);
      });
  });
}
