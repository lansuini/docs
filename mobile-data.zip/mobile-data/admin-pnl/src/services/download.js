import http from "@/http/http";
import api from "@/http/api";
import globalConfig from "@/config";

// 号码提交日志
export async function getDownloadToken({ fileName }) {
  return await http.get(`${api.getDownloadToken}/${fileName}`);
}

export function download({ fileName, token }) {
  const id = window.localStorage.getItem("id");
  const res = `${globalConfig.host}/${api.download}/${fileName}/${token}/${id}`;
  window.open(res);
}

// 导出
export async function exportPhone(data) {
  const res = await http.post(api.exportPhone, data);
  const id = window.localStorage.getItem("id");
  if (res.code === 200)
    window.open(
      `${globalConfig.host}/${api.download}/${res.data.file}/${res.data.token}/${id}`
    );
}

export async function exportIntMobile(data) {
  const res = await http.post(api.exportIntMobile, data);
  const id = window.localStorage.getItem("id");
  if (res.code === 200)
    window.open(
      `${globalConfig.host}/${api.download}/${res.data.file}/${res.data.token}/${id}`
    );
}

export async function exportEmail(data) {
  const res = await http.post(api.exportEmail, data);
  const id = window.localStorage.getItem("id");
  if (res.code === 200)
    window.open(
      `${globalConfig.host}/${api.download}/${res.data.file}/${res.data.token}/${id}`
    );
}


// 下载
export async function downloadHandle({ fileName }) {
  const res = await http.get(`${api.getDownloadToken}/${fileName}`);
  const id = window.localStorage.getItem("id");
  if (res.code === 200) {
    const { token } = res.data;
    window.open(
      `${globalConfig.host}/${api.download}/${fileName}/${token}/${id}`
    );
  } else {
    return res.msg;
  }
}
