import http from "@/http/http";
import api from "@/http/api";

// 获取登录图形验证码
export async function getCaptcha() {
  return await http.get(api.captcha);
}
// 登录
export async function login(data) {
  return await http.post(api.login, data);
}

// 退出登录
export async function logout() {
  return await http.post(api.logout);
}
