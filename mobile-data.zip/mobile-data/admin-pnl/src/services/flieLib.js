import http from "@/http/http";
import api from "@/http/api";

// 创建包 post
export async function createLib(data) {
  return await http.post(api.createPackage, data);
}
export async function getLibList(data) {
  return await http.get(api.getPackage, data);
}
export async function deleteLib(data) {
  return await http.delete(api.deletePackage + data.id);
}
// 编辑  put editPackage
export async function editLib(data) {
  return await http.put(api.editPackage, data);
}
// 包 详情
export async function packageDetail(data) {
  return await http.get(api.packageDetail, data);
}
// 包 详情 中的列表查询
export async function phoneList(data) {
  return await http.post(api.phoneList, data);
}
