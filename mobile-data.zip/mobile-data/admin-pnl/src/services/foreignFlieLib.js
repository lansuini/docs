import http from "@/http/http";
import api from "@/http/api";

// 创建包 post
export async function createForeignLib(data) {
  return await http.post(api.addIntPackage, data);
}
export async function getForeignLibList(data) {
  return await http.get(api.getIntPackage, data);
}
export async function deleteForeignLib(data) {
  return await http.delete(api.deleteForeignPackage + data.id);
}
// 编辑  put editPackage
export async function editForeignLib(data) {
  return await http.put(api.editForeignPackage, data);
}
// 包 详情
export async function foreignPackageDetail(data) {
  return await http.get(api.foreignPackageDetail, data);
}
// 包 详情 中的列表查询
export async function foreignPhoneList(data) {
  return await http.post(api.foreignPhoneList, data);
}
