import http from "@/http/http";
import api from "@/http/api";

// 号码包修改日志列表
export async function pckModifyLog(data) {
  return await http.get(api.pckModifyLog, data);
}

// 号码包提交日志列表
export async function pckCommitLog(data) {
  return await http.get(api.pckCommitLog, data);
}

// 号码包导出日志列表
export async function pckExportLog(data) {
  return await http.get(api.pckExportLog, data);
}

// 号码包修改日志列表
export async function pckForeignModifyLog(data) {
  return await http.get(api.pckForeignModifyLog, data);
}

// 号码包提交日志列表
export async function pckForeignCommitLog(data) {
  return await http.get(api.pckForeignCommitLog, data);
}

// 号码包导出日志列表
export async function pckForeignExportLog(data) {
  return await http.get(api.pckForeignExportLog, data);
}


// 号码包修改日志列表
export async function emailChangeLog(data) {
  return await http.get(api.emailChangeLog, data);
}

// 号码包提交日志列表
export async function emailUploadLog(data) {
  return await http.get(api.emailUploadLog, data);
}

// 号码包导出日志列表
export async function emailExportLog(data) {
  return await http.get(api.emailExportLog, data);
}

