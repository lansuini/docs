import axios from "axios";
import qs from "qs";
import { message } from "antd";
import globalConfig from "@/config";

// 请求拦截
axios.interceptors.request.use(
  function (config) {
    return config;
  },
  function (error) {
    console.log(error);
    return Promise.reject(error);
  }
);
// 响应拦截
axios.interceptors.response.use(
  function (response) {
    if (response && response.data && response.data.code !== 200) {
      return Promise.reject(response.data.msg);
    }
    return response.data;
  },
  function (error) {
    // 401 token失效
    if (error.response) {
      if (error.response.status === 401) {
        message.destroy();
        message.warning("登录信息过期,请重新登录");
        window.localStorage.clear();
        setTimeout(() => {
          window.location.href = "/login";
        }, 800);
      } else if (error.response.status >= 500) {
      }
      return Promise.reject(error.response.statusText);
    }
    if (error.message) {
      return Promise.reject(error.message);
    }
    if (error.request) {
      return Promise.reject(error.request.responseText);
    }
    return Promise.reject(error);
  }
);

function fetch(config) {
  const contentType = config["Content-Type"] || "application/json";
  // console.log(contentType, config, "re24");
  const token = window.localStorage.getItem("token");
  axios.defaults.baseURL = globalConfig.host;
  axios.defaults.headers.post["Content-Type"] = contentType;
  token && (axios.defaults.headers.common["token"] = token);

  return axios({
    method: "get",
    headers: {},
    ...config,
  });
}
const http = {
  async get(url, data = {}) {
    return await fetch({
      url: `${url}?${qs.stringify(data)}`,
    });
  },
  async post(url, data) {
    return await fetch({
      method: "post",
      url,
      data,
    });
  },
  async put(url, data) {
    return await fetch({
      method: "put",
      url,
      data,
    });
  },
  async delete(url) {
    return await fetch({
      method: "delete",
      url,
    });
  },
  async upload(url, data) {
    const formData = new FormData();
    for (const key in data) {
      formData.append(key, data[key]);
    }
    console.log(data, "**********((((");

    return await fetch({
      method: "post",
      url,
      data: formData,
      "Content-Type": "multipart/form-data",
    });
  },
};

export default http;
