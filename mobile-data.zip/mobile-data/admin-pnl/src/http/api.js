const api = {
  // 获取图形验证码
  captcha: "/getcaptcha",
  // 登录
  login: "/login",
  // 退出登录
  logout: "/logout",
  // 创建包 post
  createPackage: "packet",
  deletePackage: "/packet/",
  // 修改包 put
  editPackage: "packet",
  // 获取包列表 get
  getPackage: "packet",
  // 获取外国包列表 get
  getIntPackage: "getIntPackage",
  // 创建外国号码包
  addIntPackage: "addIntPackage",
  // 删除外国号码包
  deleteForeignPackage: "/deleteIntPackage/",
  // 修改外国包 put
  editForeignPackage: "updateIntPackage",
  // 包详情
  packageDetail: "/onePackage",
  // 外国包详情
  foreignPackageDetail: "/intPackage",
  // 外国邮箱详情
  foreignEmailInfo: "/emailInfo",
  // 获取外国邮箱列表 get
  getEmailPackage: "getEmailPackage",
  // 创建外国邮箱
  addEmailPackage: "addEmailPackage",
  // 删除外国邮箱
  deleteEmailPackage: "/deleteEmailPackage/",
  // 修改邮箱
  updateEmailPackage: "updateEmailPackage",
  // 标签管理
  tags: "/label",
  // 平台管理
  platform: "/platform",
  // 上传新号码
  uploadNewMobile: "/uploadNewMobile",
  // 上传外国新号码
  uploadIntMobile: "/uploadIntMobile",
  // 上传邮箱
  uploadEmail: '/uploadEmail',
  // 上传使用号码
  uploadUseMobile: "/uploadUseMobile",
  // 上传注册号码
  uploadRegisterMobile: "/uploadRegisterMobile",
  // 上传反馈号码
  uploadFeedbackMobile: "/uploadFeedbackMobile",
  // 上传沉默，风险 空号
  uploadSetTypeMobile: "/uploadSetTypeMobile",
  // 上传号码名字
  uploadNameMobile: "/uploadNameMobile",
  // 号码包修改日志列表
  pckModifyLog: "/packageChangeLog",
  // 号码包提交日志列表
  pckCommitLog: "/packageUploadLog",
  // 号码包导出日志列表
  pckExportLog: "/packageExportLog",
  // 外国号码包修改
  pckForeignModifyLog: "/intPackageChangeLog",
  // 外国号码包修改
  pckForeignCommitLog: "/intPackageUploadLog",
  // 外国号码包修改
  pckForeignExportLog: "/intPackageExportLog",
  // 外国号码包修改
  emailChangeLog: "/emailChangeLog",
  // 外国号码包修改
  emailUploadLog: "/emailUploadLog",
  // 外国号码包修改
  emailExportLog: "/emailExportLog",
  // 号码提交日志
  phoneLog: "/phoneLog",
  // 获取一条号码包的提交日志
  onePackageUploadLog: "/onePackageUploadLog",
  // 下载获取token
  getDownloadToken: "/getDownloadToken",
  // 下载文件
  download: "download",
  // 导出
  exportPhone: "/exportPhone",
  // 导出外国号码包
  exportIntMobile: "/exportIntMobile",
  // 导出邮箱
  exportEmail: '/exportEmail',
  // 查询列表 列表搜索
  phoneList: "/phoneList",
  // 外国查询列表 列表搜索
  foreignPhoneList: "/intPhoneList",
  // 邮箱列表
  foreignEmailList: '/emailList'
};

export default api;


