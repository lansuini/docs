import {
  SETFILELIB,
  SETFILELIBPACKAGELIST,
  SETFILELIBCOLUMNS,
} from "../constants/index.js";
import columns from "@/views/FileLib/columns.jsx";

// file-lib-header-ids
// 获取本地 ids 对 columns 设置
const ids = JSON.parse(
  window.localStorage.getItem("file-lib-header-ids") || "[]"
);

const _columns = columns.map((v) => {
  // 为空时取默认值
  const visible = ids.length > 0 ? !!ids.includes(v.id) : v.visible;
  return { ...v, visible };
});

const fileLibState = {
  columns: _columns,
  list: [],
  platformList: [],
  tagList: [],
};

function fileLib(state = fileLibState, action) {
  switch (action.type) {
    // 公共的 set 方法
    case SETFILELIB:
      return {
        ...state,
        ...action.payload,
      };
    case SETFILELIBPACKAGELIST:
      return {
        ...state,
        list: action.payload,
      };
    case SETFILELIBCOLUMNS:
      return {
        ...state,
        columns: action.columns,
      };
    default:
      return state;
  }
}
export default fileLib;
