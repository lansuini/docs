import { SETFOREIGNFILELIBDETAIL } from "../constants/index.js";
import columns from "@/views/ForeignFileLibDetail/components/columns";

// foreign-file-lib-detail-header-ids
// 获取本地 ids 对 columns 设置
const ids = JSON.parse(
  window.localStorage.getItem("foreign-file-lib-detail-header-ids") || "[]"
);

const _columns = columns.map((v) => {
  // 为空时取默认值
  const visible = ids.length > 0 ? !!ids.includes(v.id) : v.visible;
  return { ...v, visible };
});

const foreignFileLibDetailState = {
  headData: {},
  columns: _columns,
  list: [],
};

function foreignFileLibDetail(state = foreignFileLibDetailState, action) {
  switch (action.type) {
    // 公共的 set 方法
    case SETFOREIGNFILELIBDETAIL:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
}
export default foreignFileLibDetail;
