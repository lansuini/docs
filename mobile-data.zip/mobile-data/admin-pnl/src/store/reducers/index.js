import { combineReducers } from "redux";
import user from "./user";
import fileLib from "./fileLib";
import fileLibDetail from "./fileLibDetail";
import foreignFileLib from "./foreignFileLib";
import foreignFileLibDetail from "./foreignFileLibDetail";
import foreignEmail from "./foreignEmail";
import foreignEmailDetail from "./foreignEmailDetail";
import numberListData from "./numberList";

export default combineReducers({ 
  user, 
  fileLib, 
  fileLibDetail, 
  foreignFileLib, 
  foreignFileLibDetail, 
  foreignEmail,
  foreignEmailDetail,
  numberListData 
});
