import {
  SETFOREIGNFILELIB,
  SETFOREIGNFILELIBPACKAGELIST,
  SETFOREIGNFILELIBCOLUMNS,
} from "../constants/index.js";
import columns from "@/views/ForeignFileLib/columns.jsx";

// foreign-file-lib-header-ids
// 获取本地 ids 对 columns 设置
const ids = JSON.parse(
  window.localStorage.getItem("foreign-file-lib-header-ids") || "[]"
);

const _columns = columns.map((v) => {
  // 为空时取默认值
  const visible = ids.length > 0 ? !!ids.includes(v.id) : v.visible;
  return { ...v, visible };
});

const foreignFileLibState = {
  columns: _columns,
  list: [],
  platformList: [],
  tagList: [],
};

function foreignFileLib(state = foreignFileLibState, action) {
  switch (action.type) {
    // 公共的 set 方法
    case SETFOREIGNFILELIB:
      return {
        ...state,
        ...action.payload,
      };
    case SETFOREIGNFILELIBPACKAGELIST:
      return {
        ...state,
        list: action.payload,
      };
    case SETFOREIGNFILELIBCOLUMNS:
      return {
        ...state,
        columns: action.columns,
      };
    default:
      return state;
  }
}
export default foreignFileLib;
