import { SETUSER } from "../constants/index.js";

const isLogin = !!window.localStorage.getItem("token")
const userState = {
  isLogin,
};

function user(state = userState, action) {
  switch (action.type) {
    // 公共的 set 方法
    case SETUSER:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
}
export default user;
