import { SETNUMBERLIST } from "../constants/index.js";

export const _set = (payload) => {
  return {
    type: SETNUMBERLIST,
    payload,
  };
};
