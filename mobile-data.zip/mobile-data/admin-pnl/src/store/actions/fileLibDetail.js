import { SETFILELIBDETAIL } from "../constants/index.js";

export const _set = (payload) => {
  return {
    type: SETFILELIBDETAIL,
    payload,
  };
};
