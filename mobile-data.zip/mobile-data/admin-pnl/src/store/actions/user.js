import { SETUSER } from "../constants/index.js";

export const _set = (payload) => {
  return {
    type: SETUSER,
    payload,
  };
};