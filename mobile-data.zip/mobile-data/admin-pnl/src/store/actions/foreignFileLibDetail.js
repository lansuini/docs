import { SETFOREIGNFILELIBDETAIL } from "../constants/index.js";

export const _set = (payload) => {
  return {
    type: SETFOREIGNFILELIBDETAIL,
    payload,
  };
};
