import {
  SETFOREIGNFILELIB,
  SETFOREIGNFILELIBPACKAGELIST,
  SETFOREIGNFILELIBCOLUMNS,
} from "../constants/index.js";
import { getForeignLibList as getLibList, TagsService, PlatFormServicve } from "@/services";

export const setPackageList = (payload) => {
  return {
    type: SETFOREIGNFILELIBPACKAGELIST,
    payload,
  };
};

export const setColumns = (columns) => {
  return {
    type: SETFOREIGNFILELIBCOLUMNS,
    columns,
  };
};

// 公共的 set 方法  避免每一个都写一个 set
export const _set = (payload) => {
  return {
    type: SETFOREIGNFILELIB,
    payload,
  };
};

export const getPlat = () => {
  return async (dispatch) => {
    try {
      const plat = await PlatFormServicve.read({
        pagesize: 999999999,
      });
      if (plat.code === 200) {
        dispatch(_set({ platformList: plat.data.data }));
      }
    } catch (error) {}
  };
};
export const getTags = () => {
  return async (dispatch) => {
    try {
      const tags = await TagsService.read({
        pagesize: 999999999,
      });
      if (tags.code === 200) {
        dispatch(_set({ tagList: tags.data.data }));
      }
    } catch (error) {}
  };
};

export const getPackageList = (params) => {
  return (dispatch) => {
    return new Promise(async (resolve, reject) => {
      try {
        const res = await getLibList(params);
        if (res.code === 200) {
          resolve(res);
          return dispatch(setPackageList({ list: res.data.data }));
        }
        reject(res);
      } catch (error) {
        reject(error);
      }
    });
    // let res;
    // try {
    //   res = await getLibList(params);
    //   if (res.code === 200) {
    //     dispatch(_set({ list: res.data.data }));
    //   }
    // } catch {}
    // return res;
  };
};
