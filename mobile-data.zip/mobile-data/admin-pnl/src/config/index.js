const config = {
  host: process.env.REACT_APP_SECRET_API_HOST,
};

export default config;
