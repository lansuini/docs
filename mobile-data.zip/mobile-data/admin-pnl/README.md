### 开发

`npm run dev`

### 打包

`npm run build`

### 发布到测试环境

`npm run update`

