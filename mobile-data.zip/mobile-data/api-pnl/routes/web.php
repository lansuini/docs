<?php
/*
 * @Author: your name
 * @Date: 2020-05-08 17:04:14
 * @LastEditTime: 2020-06-11 16:24:10
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\routes\web.php
 */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

use Elasticsearch\ClientBuilder;

use App\Lib\Phone;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;

set_time_limit(0);
ini_set('memory_limit', '2048M');
ini_set('default_socket_timeout', -1);
$router->get('/', function () use ($router) {
    //创建

});

$router->group(['namespace' => '\App\Http\Controllers', 'middleware' => []], function () use ($router) {


    //需要登录的路由
    $router->group(['middleware' => ['loginAuth', 'ipWhite:API']], function () use ($router) {
        $router->post('logout', 'Login@logout');  //退出登录

        $router->get('platform', 'Platform@getPlatform'); //获取平台列表
        $router->put('platform', 'Platform@updatePlatform'); //修改平台名称
        $router->post('platform', 'Platform@addPlatform'); //添加平台名称
        $router->delete('platform/{id}', 'Platform@deletePlatform'); //添加平台名称


        $router->get('label', 'Label@getLabel');  //获取标签
        $router->put('label', 'Label@updateLabel');  //修改标签
        $router->post('label', 'Label@addLabel');  //添加标签
        $router->delete('label/{id}', 'Label@deleteLabel');  //添加标签

        $router->get('packet', 'Package@getPackage');  //号码包列表
        $router->post('packet', 'Package@addPackage');  //添加号码包
        $router->put('packet', 'Package@updatePackage');  //修改号码包
        $router->delete('packet/{id}', 'Package@deletePackage');  //删除包

        $router->get('onePackage', 'Package@getOnePackage');  //获取一个号码包内容包括标签信息
        $router->post('uploadNewMobile', 'Mobile@uploadNewMobile'); //上传新号码
        $router->post('uploadNameMobile', 'Mobile@uploadNameMobile'); //上传号码姓名
        $router->post('uploadUseMobile', 'Mobile@uploadUseMobile'); //上传使用号码
        $router->post('uploadRegisterMobile', 'Mobile@uploadRegisterMobile'); //上传注册号码
        $router->post('uploadFeedbackMobile', 'Mobile@uploadFeedbackMobile'); //上传反馈号码
        $router->post('uploadSetTypeMobile', 'Mobile@uploadSetTypeMobile'); //上传沉默、风险、空号 号码

        $router->get('packageChangeLog', 'Package@getPackageChangeLog');  //号码包修改日志
        $router->get('packageUploadLog', 'Package@getPackageUploadLog');  //号码包提交日志
        $router->get('onePackageUploadLog', 'Package@getOnePackageUploadLog');  //一条号码包提交日志
        $router->get('packageExportLog', 'Package@getPackageExportLog');  //号码包提交日志
        $router->get('phoneLog', 'Mobile@phoneLog');  //号码提交日志
        $router->post('phoneList', 'Mobile@phoneList');  //号码列表
        $router->post('exportPhone', 'Mobile@exportPhone');  //导出

        $router->get('getDownloadToken/{name}', 'Package@getDownloadToken');  //获取下载token
        // $router->get('download/{name}', function ($name) {
        //     return response()->download(base_path('public/package') . '/' . $name);
        // });


        //国际电话包
        $router->get('getIntPackage','Package@getIntPackage');
        $router->post('addIntPackage','Package@addIntPackage');
        $router->put('updateIntPackage','Package@updateIntPackage');
        $router->delete('deleteIntPackage/{id}','Package@deleteIntPackage');


        $router->post('intPhoneList','Mobile@intPhoneList');//国际电话列表
        $router->get('intPackage', 'Package@intPackage');  //
        $router->get('intPackageChangeLog', 'Package@intPackageChangeLog');  //修改日志
        $router->get('intPackageUploadLog', 'Package@intPackageUploadLog');  //上传日志
        $router->get('intPackageExportLog', 'Package@intPackageExportLog');  //导出日志
        //上传
        $router->post('uploadIntMobile','Mobile@uploadIntMobile');
        $router->post('exportIntMobile','Mobile@exportIntMobile');

        //邮箱
        $router->get('getEmailPackage','Package@getEmailPackage');
        $router->post('addEmailPackage','Package@addEmailPackage');
        $router->put('updateEmailPackage','Package@updateEmailPackage');
        $router->delete('deleteEmailPackage/{id}','Package@deleteEmailPackage');

        $router->post('uploadEmail', 'Email@uploadEmail'); //上传新邮箱
        $router->post('exportEmail','Email@exportEmail');

        $router->post('emailList','Email@emailList');//邮箱列表
        $router->get('emailInfo', 'Email@emailInfo');  //包参数

        $router->get('emailChangeLog', 'Package@emailChangeLog');  //修改日志
        $router->get('emailUploadLog', 'Package@emailUploadLog');  //上传日志
        $router->get('emailExportLog', 'Package@emailExportLog');  //导出日志

    });



    // $router->group(['middleware' => 'ipWhite'], function () use ($router) {
    //     $router->post('uploadFeedbackMobileSc', 'Mobile@uploadFeedbackMobile'); //上传反馈号码(自动上传)
    //     $router->post('uploadRegisterMobileSc', 'Mobile@uploadRegisterMobile'); //上传反馈号码(自动上传)
    //     $router->post('uploadNewMobileSc', 'Mobile@uploadNewMobile'); //上传新号码
    // });

    //无需登录的路由
    $router->group([], function () use ($router) {
        $router->get('getcaptcha', 'Login@getcaptcha'); //获取图形验证码
        // $router->post('login', 'Login@login');  //登录
        $router->get('download/{name}/{token}/{id}', 'Package@download');  //下载
    });

    $router->group(['middleware' => ['ipWhite:API','LumenCors']], function () use ($router) {
        // $router->get('getcaptcha', 'Login@getcaptcha'); //获取图形验证码
        $router->post('login', 'Login@login');  //登录
        // $router->get('download/{name}/{token}/{id}', 'Package@download');  //下载
    });
});
