<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:37:50
 * @LastEditTime: 2020-06-10 11:54:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\dealData.php
 */

namespace App\Library;

set_time_limit(0);
ini_set('memory_limit', '2048M');

use App\Lib\Log;
use App\Model\Mobile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Elasticsearch\ClientBuilder;
use \Workerman\Worker;
use Illuminate\Http\Request;


require_once __DIR__ . '/../../bootstrap/app.php';

$fileInfo = Redis::lindex('phoneUploadTest',0);

$fileInfo = json_decode($fileInfo, true);
Mobile::handleFileInfo($fileInfo);
echo "刷新" . PHP_EOL;

// $fileInfo = '{"package_id":"1","money_sum":"222222","old_file_name":"add.xlsx","new_file_name":"add_2020_05_12_11_26_30_6232838.xlsx","is_deal":0,"type":1,"created_at":1589282790,"updated_at":1589282790,"uid":0,"package_name":"\u5c0f\u7b3c\u53052","upload_id":46}';
