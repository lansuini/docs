<?php
/**
 * Created by PhpStorm.
 * User: luobinhan
 * Date: 2021/2/27
 * Time: 16:57
 */
//批量增删改查
namespace App\Library;

use Elasticsearch\ClientBuilder;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

require_once __DIR__ . '/../../bootstrap/app.php';
//$response = app('es')->indices()->refresh();
//print_r($response);exit;
$hosts = [
    // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
    [
        'host' => env('ES_HOST'),
        'port' => env('ES_PORT'),
        'scheme' => 'http',
        'user' => env('ES_USERNAME'),
        'pass' => env('ES_PASSWORD'),
    ],
    #可传多个节点
];
$client = ClientBuilder::create()->setHosts($hosts)->build();
//$response = $client->indices()->getMapping(['index' => 'phone_info',]);
//print_r($response);exit;
$page = 1;
$pageSize = 20;
$from = ($page - 1) * $pageSize;

$params = [
    'index' => 'phone_info',
    'body' => [
        "query" => [
            "bool" => [
                'must' => [
                    [
//                        'match' => [
//                            'phone' => 17700000001,
//                            'phone' => 15867435230,
//                        ],
                        ['term'=>['number_package'=>7]],
                        ['term'=>['labels'=>4]]
                    ]

                ],
                 'must_not' =>[
                     'exists'=>['field'=>'is_get_lottery']
                 ],
            ]
        ]
    ],
];

$response = $client->deleteByQuery($params);
print_r($response);exit;
var_dump($response['hits']['hits'][0]);exit;
$params = [
    'index' => 'phone_info',
    'body' => [
        "query" => [

            'bool' => [
                'must' => [
                    [
                        'term' => [
                            'number_package' => 3,
                        ],
                    ],

                ],
            ],

        ],
    ],
];



$params = [
    'body' => [
        [
            'index' => [
                '_index' => 'test',
                '_id' => '1',
            ],
        ],
        [
            'field1' => 'value1',
        ],
        [
            'delete' => [
                '_index' => 'test',
                '_id' => '2',
            ],
        ],
        [
            'create' => [
                '_index' => 'test',
                '_id' => '3',
            ],
        ],
        [
            'field1' => 'value3',
        ],
        [
            'update' => [
                '_id' => '1',
                '_index' => 'test',
            ],
        ],
        [
            'doc' => [
                'field2' => 'value2',
            ],
        ],
    ],
];
$response = $client->bulk($params);

