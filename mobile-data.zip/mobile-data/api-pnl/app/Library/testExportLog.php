<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:37:50
 * @LastEditTime: 2020-06-11 14:40:59
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\dealData.php
 */

namespace App\Library;

set_time_limit(0);
ini_set('memory_limit', '2048M');

use App\Lib\Log;
use App\Lib\Tools;
use App\Model\Mobile;
use Elasticsearch\ClientBuilder;
use Illuminate\Support\Facades\Redis;

require_once __DIR__ . '/../../bootstrap/app.php';

while (true) {

    $fileInfo = Redis::lpop('exportLogQueue');

    // $fileInfo = '{"package_id":"1","money_sum":"222222","old_file_name":"add.xlsx","new_file_name":"add_2020_05_12_11_26_30_6232838.xlsx","is_deal":0,"type":1,"created_at":1589282790,"updated_at":1589282790,"uid":0,"package_name":"\u5c0f\u7b3c\u53052","upload_id":46}';
    try {

        if ($fileInfo) {
            //开始处理
            echo '初始内存' . PHP_EOL;
            echo Tools::format_bytes(memory_get_usage());
            // Redis::rpush('exportLogQueue', $fileInfo);
            $fileInfo = json_decode($fileInfo, 1);
            // var_dump($fileInfo);

            $fileName = $fileInfo['file_name'];
            $forCount = ceil(count($fileInfo['phone']) / 4000);
            $hosts = [
                // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
                [
                    'host' => env('ES_HOST'),
                    'port' => env('ES_PORT'),
                    'scheme' => 'http',
                    'user' => env('ES_USERNAME'),
                    'pass' => env('ES_PASSWORD'),
                ],
                #可传多个节点
            ];

            $client = ClientBuilder::create() // Instantiate a new ClientBuilder
                ->setHosts($hosts) // Set the hosts
                ->build();

            for ($i = 0; $i < $forCount; $i++) {
                //存储从ES查询出来的数据

                $tmpStart = $i * 4000;
                $tmpArr = array_slice($fileInfo['phone'], $tmpStart, 4000);

                $params = [
                    'index' => 'phone_info',
                    'body' => [
                        "query" => [
                            "bool" => [
                                'must' => [
                                    'terms' => [
                                        'phone' => $tmpArr,
                                    ],
                                ],
                            ],

                        ],
                        "script" => [
                            "inline" => "ctx._source.export_state = params.export_state;ctx._source.export_count =ctx._source.export_count+params.export_count;ctx._source.export_at.add(params.export_at)",
                            "params" => [
                                "export_state" => 1,
                                "export_count" => 1,
                                'export_at' => $fileInfo['exportTime'],

                            ],
                            "lang" => "painless",
                        ],

                    ],

                ];

                echo 'update结果' . PHP_EOL;
                $client->updateByQuery($params);
                $insertArr = [];
                foreach ($tmpArr as $insertValue) {
                    $tmpinsertArr = [];
                    $tmpinsertArr['mobile'] = $insertValue;
                    $tmpinsertArr['file_name'] = $fileName;
                    $tmpinsertArr['type'] = 4;
                    $tmpinsertArr['admin_name'] = $fileInfo['admin_name'];
                    $tmpinsertArr['admin_id'] = $fileInfo['admin_id'];
                    $tmpinsertArr['created_at'] = time();
                    $tmpinsertArr['export_at'] = $fileInfo['export_at'];
                    $insertArr[] = $tmpinsertArr;
                }
                Mobile::insertLog($insertArr);
                //根据查询update

            }

            echo 'end内存' . PHP_EOL;
            echo Tools::format_bytes(memory_get_usage());
        }
        unset($fileInfo);
        unset($fileInfo);
    } catch (\Exception $e) {
        Log::info($e, 'exportLog');
        echo $e->getMessage() . PHP_EOL;
        echo $e->getFile() . PHP_EOL;
        echo $e->getLine() . PHP_EOL;
    }
    sleep(3);
}
