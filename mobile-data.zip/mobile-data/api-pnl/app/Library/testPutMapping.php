<?php
/*
 * @Author: your name
 * @Date: 2020-05-19 15:03:42
 * @LastEditTime: 2020-06-01 10:39:24
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\createESTable.php
 */

namespace App\Library;

use Illuminate\Support\Facades\DB;
use Elasticsearch\ClientBuilder;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

require_once __DIR__ . '/../../bootstrap/app.php';

$hosts = [
    [
        'host' => env('ES_HOST'),
        'port' => env('ES_PORT'),
        'scheme' => 'http',
        'user' => env('ES_USERNAME'),
        'pass' => env('ES_PASSWORD'),
    ]
];

$logger = new Logger('putMapping');
$logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/test.log', Logger::WARNING));
$client = ClientBuilder::create() // Instantiate a new ClientBuilder
->setHosts($hosts) // Set the hosts
->setLogger($logger) // Set the logger
->build();
//$response = $client->indices()->getSettings();
//print_r($response);exit;
//$params = [
//    'index' => 'phone_info',
//    'body' => [
//        'settings' => [
//            "index.indexing.slowlog.threshold.index.warn"=> "10s",
//            "index.indexing.slowlog.threshold.index.info"=> "5s",
//            "index.indexing.slowlog.threshold.index.debug"=> "2s",
//            "index.indexing.slowlog.threshold.index.trace"=> "500ms",
//            "index.indexing.slowlog.level"=> "info",
//            "index.indexing.slowlog.source"=> "1000"
//        ],
//    ]
//];
//$client->indices()->putSettings($params);

//和创建映射不一样，添加映射不用内嵌mappings，直接把字段添加到body里
$params = [
    'index' => 'phone_info',
    "body" => [
        "properties" => [
            'is_get_lottery' => ['type' => 'long'],//是否领取彩金
            'is_gold_flow' => ['type' => 'long'],//是否有流水
            'is_agent_gold' => ['type' => 'long'],//是否有代理收益
            'day30_spread_increase' => ['type' => 'long'],//30天内直属下级是否新增
            'day1_recharge_gold' => ['type' => 'long'],//一天充值总金额
            'day1_withdraw_gold' => ['type' => 'long'],//一天取款总金额
            'day1_rwdv_percent' => ['type' => 'long'],//充兑差值百分比
//            'client_id' => ['type' => 'keyword'],
        ]
    ]
];
//
//
$response = $client->indices()->putMapping($params);
print_r($response);
$packages = DB::table('package')->where('is_delete',0)->get(DB::raw('id,package_name,mobile_table_sign,total,real_total'))->toArray();
echo $start = time();
foreach ($packages as $package){
    $params = [
        'index' => 'phone_info',
        'conflicts' => 'proceed',
        'body' => [
            'query' => [
                'term' => [
                    'number_package' => $package->id,
                ],
            ],
            'script' => [
                'source' => "ctx._source.is_get_lottery = 2;ctx._source.is_gold_flow = 2;ctx._source.is_agent_gold = 2;ctx._source.day30_spread_increase = 2;ctx._source.day1_recharge_gold = 0;ctx._source.day1_withdraw_gold = 0;ctx._source.day1_rwdv_percent = 0;",
            ],
        ],
    ];
    $response = $client->updateByQuery($params);
    print_r($response);

    echo '-----';
    echo $end = time();
    echo '-->'.($end - $start);
}
exit;
//$response = $client->bulk($params);


$params = [
    'index' => 'phone_info',
    'id' => '15867435230',
    'type' => '_doc',
//    'doc_as_upsert' => True,
    'body' => [
        'script' => 'ctx._source.is_agent=1',
//        'params' => [
//            'count' => 4
//        ],
//        'doc' => [
//            'is_test' => '1'
//        ],
//        'upsert' => [
//            'is_test' => 1
//        ]
    ]
];

// Update doc at /my_index/my_type/my_id
$response = $client->update($params);

exit;

