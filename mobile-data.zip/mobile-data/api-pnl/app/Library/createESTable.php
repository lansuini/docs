<?php
/*
 * @Author: your name
 * @Date: 2020-05-19 15:03:42
 * @LastEditTime: 2020-06-01 10:39:24
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\createESTable.php
 */

namespace App\Library;

use Elasticsearch\ClientBuilder;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

require_once __DIR__ . '/../../bootstrap/app.php';

$hosts = [
    [
        'host' => env('ES_HOST'),
        'port' => env('ES_PORT'),
        'scheme' => 'http',
        'user' => env('ES_USERNAME'),
        'pass' => env('ES_PASSWORD'),
    ]
];

$logger = new Logger('putMapping');
$logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/test.log', Logger::WARNING));
$client = ClientBuilder::create() // Instantiate a new ClientBuilder
->setHosts($hosts) // Set the hosts
->setLogger($logger) // Set the logger
->build();
$hosts = [
    // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
    [
        'host' => env('ES_HOST'),
        'port' => env('ES_PORT'),
        'scheme' => 'http',
        'user' => env('ES_USERNAME'),
        'pass' => env('ES_PASSWORD'),
    ]
    #可传多个节点
];
$hosts = [
    // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
    [
        'host' => '127.0.0.1',
        'port' => 9200,
        'scheme' => 'http',
//         'user' => env('ES_USERNAME'),
        // 'pass' => env('ES_PASSWORD'),
    ]
    #可传多个节点
];
// print_r($hosts);
// exit;


$params = [
//    'index' => 'phone_info',
//    'index' => 'phone_taiwan',
//    'index' => 'phone_thailand',
//    'index' => 'phone_japan',
//    'index' => 'phone_indonesia',
    'index' => 'phone_america',
//    'index' => 'phone_brazil',
//    'index' => 'phone_india',
    "body" => [
        "settings" => [
            "number_of_shards" => 3,
            "number_of_replicas" => 2,
            'max_result_window' => 2000000000,
        ],
        "mappings" => [
            '_source' => [
                'enabled' => true
            ],
            "properties" => [
                //不需要分词模糊搜索
                "id" => ["type" => "long"],
                'phone' => ['type' => 'long'],
                'company' => ['type' => 'keyword'],
                "province" => ["type" => "keyword"],
                "city" => ["type" => "keyword"],
                'type' => ['type' => 'long'],
                'is_use' => ['type' => 'long'],
                'use_platform' => ['type' => 'long'],
                'use_platform_name' => ['type' => 'keyword'],
                'is_register' => ['type' => 'long'],
                'register_platform' => ['type' => 'long'],
                'register_platform_name' => ['type' => 'keyword'],
                'is_feedback' => ['type' => 'long'],
                'is_agent' => ['type' => 'long'],
                'feedback_platform' => ['type' => 'long'],
                'feedback_platform_name' => ['type' => 'keyword'],
                'use_last_time' => ['type' => 'long'],
                'use_time' => ['type' => 'long'],
                'feedback_last_time' => ['type' => 'long'],
                'last_bonus_time' => ['type' => 'long'],
                'last_flow_time' => ['type' => 'long'],
                'number_package' => ['type' => 'long'],
                'number_package_name' => ['type' => 'keyword'],
                'remark' => ['type' => 'text', 'index' => 'false'],
                'price' => ['type' => 'double'],
                'created_at' => ['type' => 'long'],
                'package_id' => ['type' => 'long'],
                'export_state' => ['type' => 'long'],
                'export_time' => ['type' => 'long'],
                'export_at' => ['type' => 'keyword'],
                'export_count' => ['type' => 'long'],
                'phone_segment' => ['type' => 'long'],
                'number_status' => ['type' => 'long'],
                // 'last_week_is_recharge' => ['type' => 'long'],
                'is_recharge' => ['type' => 'long'],
                'os' => ['type' => 'long'],
                'client_id' => ['type' => 'keyword'],
                // 'client_id_name' => ['type' => 'keyword'],
                'last_recharge_date' => ['type' => 'long'],
            ]
        ]
    ]
];
//$client = ClientBuilder::create()           // Instantiate a new ClientBuilder
//    ->setHosts($hosts)      // Set the hosts
//    ->build();

$response = $client->indices()->create($params);

var_dump($response);
