<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:37:50
 * @LastEditTime: 2020-06-10 11:54:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\dealData.php
 */

namespace App\Library;

set_time_limit(0);
ini_set('memory_limit', '2048M');

use App\Lib\Log;
use App\Model\Mobile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Elasticsearch\ClientBuilder;
use \Workerman\Worker;
use Illuminate\Http\Request;

require_once __DIR__ . '/../../bootstrap/app.php';

//Mobile::pushPackageRatioQueue(1);
//Mobile::pushPackageRatioQueue(2);
//Mobile::pushPackageRatioQueue(3);
//Mobile::popPackageRatioQueue();
//exit;
$runKey = 'runPackageRatio';
if(Redis::get($runKey)){
    echo '正在运行中';
    return;
}
Redis::setex($runKey,1,3600);
$hosts = [
    // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
    [
        'host' => env('ES_HOST'),
        'port' => env('ES_PORT'),
        'scheme' => 'http',
        'user' => env('ES_USERNAME'),
        'pass' => env('ES_PASSWORD'),
    ],
    #可传多个节点
];

$page = 1;
$pageSize = 20;
$from = ($page - 1) * $pageSize;
$client = ClientBuilder::create()->setHosts($hosts)->build();
//从ES查询实时数据
$comPackages = $packages = DB::table('package')->where('is_delete',0)->get(DB::raw('id,package_name,mobile_table_sign,total,real_total'))->toArray();
if(count($packages) < 2){
    echo "号码包少于2个！";
    return false;
}
foreach ($packages as &$pack){
    $params = [
        'index' => 'phone_info',
        'body' => [
            "query" => [
                "bool" => [
                    'must' => [
                        [
                            'term' => [
                                'number_package' => $pack->id
                            ]
                        ]
                    ]
                ]
            ]
        ],
    ];

    $countResult = $client->count($params);
    $pack->counts = $countResult['count'];
    $pack->dugCounts = [];

}

foreach ($packages as $key=>$package){

    unset($comPackages[$key]);
    foreach ($comPackages as $cpk=>$comPack){
        $package->dugCounts[$comPack->id] = 0;
    }
    $params = [
        'index' => 'phone_info',
        'body' => [
            "query" => [
                "bool" => [
                    'must' => [
                        [
                            'term' => [
                                'number_package' => $package->id
                            ]
                        ]
                    ]
                ]
            ]
        ],
    ];

    $countResult = $client->count($params);
    $counts = $countResult['count'];
    $pages = ceil($counts/$pageSize);
    for($page=1;$page<=$pages;$page++){
        $params = [
            'index' => 'phone_info',
            'body' => [
                "query" => [
                    "bool" => [
                        'must' => [
                            [
                                'term' => [
                                    'number_package' => $package->id
                                ]
                            ]
                        ]
                    ]
                ],
                'size' => $pageSize,
                'from' => ($page - 1) * $pageSize,
            ],
        ];

        $results = $client->search($params);
        $must = [];
        $should = [];
        foreach ($results['hits']['hits'] as $value) {
            $term = [
                'term' => [
                    'phone' => $value['_source']['phone']
                ]
            ];
            array_push($should,$term);
        }


        foreach ($comPackages as $comPackage){

            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
                        "bool" => [
                            'must'=>[
                                ['term'=>['number_package'=>$comPackage->id]],
                                ['bool'=>['should'=>$should]]
                                ],
                        ],
                    ]
                ],
            ];
            $res = $client->count($params);
            $package->dugCounts[$comPackage->id] += $res['count'];
        }
    }
//    print_r($package);
    $comPackages[$key] = $package;
}

foreach ($packages as $pkg){
    foreach ($pkg->dugCounts as $k=>$v){
        try{
            $insert = [];
            $insert['package_id'] = $pkg->id;
            $insert['com_package_id'] = $k;
            $insert['dug_counts'] = $v;
            $insert['dug_ratio'] = round( $v/$pkg->counts , 4) * 10000 ;
            $insert['created_at'] = time() ;
            $insert['updated_at'] = time() ;
            DB::table('package_ratio')->insert($insert);
        }catch (\Exception $e){
            if($e instanceof \Illuminate\Database\QueryException){
                DB::table('package_ratio')->where('package_id',$pkg->id)->where('com_package_id',$k)->update($insert);
            }else{
                echo $e->getMessage();
            }
        }

    }
}
//    print_r($comPackages);

Redis::del($runKey);
echo "刷新" . PHP_EOL;

// $fileInfo = '{"package_id":"1","money_sum":"222222","old_file_name":"add.xlsx","new_file_name":"add_2020_05_12_11_26_30_6232838.xlsx","is_deal":0,"type":1,"created_at":1589282790,"updated_at":1589282790,"uid":0,"package_name":"\u5c0f\u7b3c\u53052","upload_id":46}';
