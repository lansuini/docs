<?php
/*
 * @Author: your name
 * @Date: 2020-05-20 16:42:07
 * @LastEditTime: 2020-05-29 17:27:17
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\deleteESData.php
 */

namespace App\Library;

use Elasticsearch\ClientBuilder;

require_once __DIR__ . '/../../bootstrap/app.php';

$hosts = [
    // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
    [
        'host' => env('ES_HOST'),
        'port' => env('ES_PORT'),
        'scheme' => 'http',
        'user' => env('ES_USERNAME'),
        'pass' => env('ES_PASSWORD'),
    ]
    #可传多个节点
];



$params = [
    'index' => 'phone_info',
    "body" => [
        "settings" => [
            "number_of_shards" => 3,
            "number_of_replicas" => 2,
            'max_result_window' => 2000000000,
        ],
        "mappings" => [
            '_source' => [
                'enabled' => true
            ],
            "properties" => [
                //不需要分词模糊搜索
                "id" => ["type" => "long"],
                'phone' => ['type' => 'long'],
                'company' => ['type' => 'keyword'],
                "province" => ["type" => "keyword"],
                "city" => ["type" => "keyword"],
                'type' => ['type' => 'long'],
                'is_use' => ['type' => 'long'],
                'use_platform' => ['type' => 'long'],
                'use_platform_name' => ['type' => 'keyword'],
                'is_register' => ['type' => 'long'],
                'register_platform' => ['type' => 'long'],
                'register_platform_name' => ['type' => 'keyword'],
                'is_feedback' => ['type' => 'long'],
                'feedback_platform' => ['type' => 'long'],
                'feedback_platform_name' => ['type' => 'keyword'],
                'use_last_time' => ['type' => 'long'],
                'use_time' => ['type' => 'long'],
                'feedback_last_time' => ['type' => 'long'],
                'number_package' => ['type' => 'long'],
                'number_package_name' => ['type' => 'keyword'],
                'remark' => ['type' => 'text', 'index' => 'false'],
                'price' => ['type' => 'double'],
                'created_at' => ['type' => 'long'],
                'package_id' => ['type' => 'long'],
                'export_state' => ['type' => 'long'],
                'export_time' => ['type' => 'long'],
                'export_at' => ['type' => 'keyword'],
                'export_count' => ['type' => 'long'],
                'phone_segment' => ['type' => 'long'],
            ]
        ]
    ]
];
$client = ClientBuilder::create()           // Instantiate a new ClientBuilder
    ->setHosts($hosts)      // Set the hosts
    ->build();

$client->indices()->delete(['index' => 'phone_info']);
$response = $client->indices()->create($params);
var_dump($response);
