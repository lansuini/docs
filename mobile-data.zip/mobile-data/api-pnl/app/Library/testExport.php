<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:37:50
 * @LastEditTime: 2020-06-11 14:40:59
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\dealData.php
 */

namespace App\Library;

set_time_limit(0);
ini_set('memory_limit', '2048M');

use App\Lib\Log;
use App\Lib\Tools;
use App\Model\Mobile;
use Elasticsearch\ClientBuilder;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;

require_once __DIR__ . '/../../bootstrap/app.php';

    try {

        $packageId = 40; //
        $title = [
            "id",
            "phone",
            "company",
            "province",
            "city",
            "use_platform_name",
            "is_register",
            "register_platform_name",
            "is_agent",
            "feedback_last_time",
            "use_last_time",
            "number_package_name",
            "created_at"
        ]; //
        $exportType = 1; //导出类型  1为包内导出  2为全部导出
        $fileType = 2; //导出类型  1为excel  2为phone
        //筛选条件


        $bool = [];


        if (empty($fileType)) {
            $this->error('100809'); #请指定导出文件类型
        }
        if ($fileType == 2) {
            $title = ['phone'];
        }
        if (empty($title)) {
            $this->error('100804'); #请指定导出字段
        }
        foreach ($title as $titleKey => $titleValue) {
            if ($titleValue == 'export_state') {
                $title[$titleKey] = 'export_state';
            }
        }
        if (empty($exportType)) {
            $this->error('100806'); #请指定导出类型
        }
        if ($exportType == 1 && (empty($packageId))) {
            $this->error('100807'); #包id不能为空
        }
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        #export_at=》export_at

        $bool['must'][] = [
            'range' => [
                'number_package' => [
                    'gt' => 0,
                ],
            ],
        ];
        #pack
        if ($packageId) {
            $bool['must'][] = [
                'term' => [
                    'number_package' => $packageId,
                ],
            ];
        } else {
            $ids = DB::table('package')->select('id')->get();
            $ids = $ids->pluck('id')->all();
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $ids,
                ],
            ];
        };


        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
        ->setHosts($hosts) // Set the hosts
        ->build();

        if (count($bool) > 0) {
            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
                        "bool" => $bool,

                    ],
                ],

            ];
        } else {
            $params = [
                'index' => 'phone_info',
                'body' => [],

            ];
        }

        $count = $client->count($params)['count'];
        $size = 200000;
        $params['size'] = $size;
        $params['scroll'] = '1m';
        $searchData = [];
        $params['_source'] = $title;
        if (in_array('use_platform_name', $title)) {
            array_push($params['_source'], 'use_platform');
        }
        if (in_array('register_platform_name', $title)) {
            array_push($params['_source'], 'register_platform');
        }
        if (in_array('feedback_platform', $title)) {
            array_push($params['_source'], 'feedback_platform_name');
        }
        array_push($params['_source'], 'number_package');
        $results = $client->search($params);

        if (count($results['hits']['hits']) < 0) {
            //没搜索到数据  好办
            $this->error(100805);
        }

        $searchCount = ceil($count / $size) - 1;
        $searchCount = 30;
        $searchData = array_merge($searchData, $results['hits']['hits']);
        $scorllId = $results['_scroll_id'];

        for ($i = 0; $i < $searchCount; $i++) {
            $params = [];
            $params['scroll'] = '1m';
            $params['scroll_id'] = $scorllId;
            $results = $client->scroll($params);
            if (count($results['hits']['hits']) < 0) {
                //搜不到了  结束
                break;
            }

            $searchData = array_merge($searchData, $results['hits']['hits']);
        }

        //得到searchData
        //开始写入excel
        $tmp_file_name = date('Y-m-d', time()) . rand(1000, 9999) . 1234;
        $fileTypeName = $fileType == 1 ? 'csv' : 'txt';
        $file_name = base_path('storage/exportfiles/') . $tmp_file_name . '.' . $fileTypeName;
        $fp = fopen($file_name, 'w');

        $titleDic = [
            'id' => '序号',
            'phone' => '号码',
            'is_use' => '使用状态',
            'use_platform_name' => '使用平台',
            'is_register' => '注册状态',
            'register_platform_name' => '注册平台',
            'is_agent' => '是否代理',
            'last_recharge_date' => '最后充值',
            'os' => '设备',
            'client_id' => '渠道号',
            'export_count' => '导出次数',
            'export_state' => '导出状态',
        ];

        $titleArr = [];
        foreach ($title as $key => $value) {

            array_push($titleArr, (array_key_exists($value, $titleDic) ? $titleDic[$value] : ''));
        }
        if ($fileType == 1) {
            fputcsv($fp, $titleArr);
        }

        $platformIds = [];

        //取出
        $number_package_ids = [];
        foreach ($searchData as $value) {
            if (!empty($value['_source']['use_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['use_platform']));
            }

            if (!empty($value['_source']['feedback_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['feedback_platform']));
            }

            if (!empty($value['_source']['register_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['register_platform']));
            }
            if (!empty($value['_source']['number_package'])) {
                $number_package_ids = array_unique(array_merge($number_package_ids, $value['_source']['number_package']));
            }
        }
        $packages = [];
        if (!empty($number_package_ids)) {
            $packages = DB::table('package')->whereIn('id', $number_package_ids)->get();
            $packages = $packages->keyBy('id')->all();
        }

        $platforms = [];
        if (!empty($platformIds)) {
            $platforms = DB::table('platform')->whereIn('id', $platformIds)->where('is_delete', 0)->get();
            $platforms = $platforms->keyBy('id')->all();
        }

        $lineNo = 0;
        foreach ($searchData as $key => $value) {
            $contentArr = [];
            foreach ($title as $titleKey => $titleValue) {
                $tmp = '';
                if (isset($value['_source'][$titleValue])) {

                    $tmp = $value['_source'][$titleValue];

                    if ($titleValue == 'id') {
                        $tmp = ++$lineNo;
                    }

                    if ($titleValue == 'use_platform_name') {
                        $tmp = [];

                        if (!empty($value['_source']['use_platform'])) {
                            foreach ($value['_source']['use_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'register_platform_name') {
                        $tmp = [];
                        if (!empty($value['_source']['register_platform'])) {
                            foreach ($value['_source']['register_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'feedback_platform') {
                        $tmp = [];
                        if (!empty($value['_source']['feedback_platform'])) {
                            foreach ($value['_source']['feedback_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'type') {

                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '未验证';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '正常号';
                        }
                        if ($value['_source'][$titleValue] == 2) {
                            $tmp = '沉默号';
                        }
                        if ($value['_source'][$titleValue] == 3) {
                            $tmp = '危险号';
                        }
                        if ($value['_source'][$titleValue] == 4) {
                            $tmp = '空号';
                        }
                    }
                    if ($titleValue == 'company') {

                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '移动';
                        }
                        if ($value['_source'][$titleValue] == 2) {
                            $tmp = '联通';
                        }
                        if ($value['_source'][$titleValue] == 3) {
                            $tmp = '电信';
                        }
                        if ($value['_source'][$titleValue] == 4) {
                            $tmp = '虚拟号';
                        }
                    }
                    if (in_array($titleValue, ['is_use', 'is_register', 'is_feedback', 'export_state'])) {

                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '否';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '是';
                        }
                    }

                    if ($titleValue == 'is_agent' && $value['_source'][$titleValue]) {
                        $agents = ['','普通用户','活跃代理','非活跃代理'];
                        $tmp = $agents[$value['_source'][$titleValue]];
                    }

                    if (in_array($titleValue, ['number_status'])) {
                        $tmp = '--';
                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '正常';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '封号';
                        }
                    }

                    if (in_array($titleValue, ['last_week_is_recharge'])) {
                        $tmp = '--';
                        if (isset($value['_source']['last_recharge_date']) && $value['_source']['last_recharge_date'] < $b15d) {
                            $tmp = '未充值';
                        }
                        if (isset($value['_source']['last_recharge_date']) && $value['_source']['last_recharge_date'] > $b15d) {
                            $tmp = '已充值';
                        }
                    }

                    if (in_array($titleValue, ['os'])) {
                        $tmp = '--';
                        if (isset($value['_source'][$titleValue]) && $value['_source'][$titleValue] == 1) {
                            $tmp = 'Android';
                        }
                        if (isset($value['_source'][$titleValue]) && $value['_source'][$titleValue] == 2) {
                            $tmp = 'IOS';
                        }
                    }

                    if (in_array($titleValue, ['last_recharge_date'])) {
                        $tmp = isset($value[$titleValue]) ? date('Y-m-d', $value[$titleValue]) : '--';
                    }

                    if (in_array($titleValue, ['client_id'])) {
                        $tmp = '';
                        foreach ($value['_source'][$titleValue] ?? []  as $kk => $vv) {
                            list($cc1, $cc2) = explode(':', $vv);
                            $tmp .= $this->getPlatforms($cc1) . ':' . $cc2;
                        }
                    }

                    if (in_array($titleValue, ['feedback_last_time', 'use_last_time', 'created_at'])) {
                        if (empty($value['_source'][$titleValue])) {
                            $tmp = '';
                        } else {
                            $tmp = date('Y-m-d', $value['_source'][$titleValue]);
                        }
                    }
                    if (in_array($titleValue, ['number_package', 'number_package_name'])) {
                        $packageIds = $value['_source']['number_package'];
                        $tmp = [];
                        foreach ($packageIds as $packageIdsKey => $packageIdsValue) {
                            if (!empty($packages[$packageIdsValue])) {
                                array_push($tmp, $packages[$packageIdsValue]->package_name);
                            }
                        }
                    }
                    if (is_array($tmp)) {
                        $tmp = implode(',', $tmp);
                    }
                }
                if (is_array($tmp)) {
                    $tmp = implode(',', $tmp);
                }
                array_push($contentArr, $tmp);
            }

            fputcsv($fp, $contentArr);
        }
    } catch (\Exception $e) {
        Log::info($e, 'exportLog');
        echo $e->getMessage() . PHP_EOL;
        echo $e->getFile() . PHP_EOL;
        echo $e->getLine() . PHP_EOL;
    }
    exit;
