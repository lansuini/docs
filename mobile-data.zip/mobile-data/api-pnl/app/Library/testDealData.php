<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:37:50
 * @LastEditTime: 2020-06-10 11:54:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\dealData.php
 */

namespace App\Library;

set_time_limit(0);
ini_set('memory_limit', '2048M');

use App\Lib\Log;
use App\Model\Mobile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use \Workerman\Worker;

require_once __DIR__ . '/../../bootstrap/app.php';
while (true) {
    $fileInfo = Redis::lpop(env('REDISQUEUE'));
    if ($fileInfo) {
        $fileInfo = json_decode($fileInfo, 1);
        try {
            $ids = DB::table('package')->select('id')->get();
            $ids = $ids->pluck('id')->all();
            $fileInfo['packageAllIds'] = $ids;
            $fileInfo['startTime'] = time();

            switch ($fileInfo['type']) {
                case 1:
                    #提交新号码
                    Mobile::uploadNewMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                case 2:
                    #使用号码
                    Mobile::uploadUseMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                case 3:
                    #注册号码
                    Mobile::uploadRegMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                case 4:
                    #注册号码
                    Mobile::uploadFeedbackMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                case 5:
                    #注册号码
                    Mobile::uploadSetTypeMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                case 6:
                    #注册号码
                    Mobile::uploadSetTypeMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                case 7:
                    #注册号码
                    Mobile::uploadSetTypeMobile($fileInfo);
                    echo 'done' . PHP_EOL;
                    break;
                default:

                    # code...
                    break;
            }
        } catch (\Exception $e) {
            echo $e->getFile() . PHP_EOL;
            echo $e->getLine() . PHP_EOL;
            echo $e->getMessage() . PHP_EOL;
            Log::info($e, 'dealData');
            $endUpdate = [
                'is_deal' => 2,
                'error_log' => json_encode([
                    'line' => $e->getLine(),
                    'file' => $e->getFile(),
                    'message' => $e->getMessage(),
                ]),
            ];
            DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($endUpdate);
        }
    }
    echo "刷新" . PHP_EOL;
    sleep(3);
}
// $fileInfo = '{"package_id":"1","money_sum":"222222","old_file_name":"add.xlsx","new_file_name":"add_2020_05_12_11_26_30_6232838.xlsx","is_deal":0,"type":1,"created_at":1589282790,"updated_at":1589282790,"uid":0,"package_name":"\u5c0f\u7b3c\u53052","upload_id":46}';
