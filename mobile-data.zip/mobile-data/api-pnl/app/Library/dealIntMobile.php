<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:37:50
 * @LastEditTime: 2020-06-10 11:54:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Library\dealData.php
 */

namespace App\Library;


set_time_limit(0);
ini_set('memory_limit', '2048M');

use App\Model\MobileInt as Mobile;

use \Workerman\Worker;
use \Workerman\Lib\Timer;
use Illuminate\Support\Facades\Redis;
use App\Lib\Log;
use Illuminate\Support\Facades\DB;

require_once __DIR__ . '/../../bootstrap/app.php';


$task = new Worker();
// 开启多少个进程运行定时任务，注意业务是否在多进程有并发问题
$task->count = 10;
$task->onWorkerStart = function ($task) {

    // 每2.5秒执行一次
    $time_interval = 0.5;
    Timer::add($time_interval, function () {
        $fileInfo = Redis::lpop('uploadIntMobile');

        if ($fileInfo) {
            $fileInfo = json_decode($fileInfo, 1);
            print_r($fileInfo);
            try {
                $ids = DB::table('package_international')->select('id')->get();
                $ids = $ids->pluck('id')->all();
                $fileInfo['packageAllIds'] = $ids;
                $fileInfo['startTime'] = time();

                switch ($fileInfo['type']) {
                    case 1:
                        #提交新号码
                        Mobile::uploadNewMobile($fileInfo);
                        echo 'done' . PHP_EOL;
                        break;
                    case 2:
                        #使用号码
                        Mobile::uploadUseMobile($fileInfo);
                        echo 'done' . PHP_EOL;
                        break;
                    case 3:
                        #注册号码
                        Mobile::uploadRegMobile($fileInfo);
                        echo 'done' . PHP_EOL;
                        break;
                    default:

                        # code...
                        break;
                }
            } catch (\Exception $e) {
                echo $e->getFile() . PHP_EOL;
                echo $e->getLine() . PHP_EOL;
                echo $e->getMessage() . PHP_EOL;
                Log::info($e, 'dealData');
                $endUpdate = [
                    'is_deal' => 2,
                    'error_log' => json_encode([
                        'line' => $e->getLine(),
                        'file' => $e->getFile(),
                        'message' => $e->getMessage(),
                    ])
                ];
                DB::table('package_int_upload_log')->where('id', $fileInfo['upload_id'])->update($endUpdate);
            }
        }
        // $fileInfo = '{"package_id":"1","money_sum":"222222","old_file_name":"add.xlsx","new_file_name":"add_2020_05_12_11_26_30_6232838.xlsx","is_deal":0,"type":1,"created_at":1589282790,"updated_at":1589282790,"uid":0,"package_name":"\u5c0f\u7b3c\u53052","upload_id":46}';

    });
};

// 运行worker
Worker::runAll();
