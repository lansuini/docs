<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-06-12 11:53:11
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Model\AreaCode.php
 */

namespace App\Model;

use App\Lib\Hash;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use App\Lib\Phone;
use App\Model\Common\CommonModel;
use Illuminate\Support\Facades\DB;
use Phar;
use Elasticsearch\ClientBuilder;
use App\Lib\Tools;
use Illuminate\Support\Facades\Redis;

class Mobile extends CommonModel
{
    public static $logTable = [];

    public static function uploadNewMobile($fileInfo)
    {
        //新增号码
        //读取excel

        $txtArr = self::getTxtList($fileInfo);


        //循环 一个个文件来
        // $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file);
        // $sheet = $spreadsheet->getSheet(0);
        // $highestRow = $sheet->getHighestRow();           // 取得总行数  
        $tmpArr = [];
        $cmcc_sum = 0;
        $cucc_sum = 0;
        $ctcc_sum = 0;
        //虚拟号码
        $virtual_sum = 0;


        $insert_cmcc_sum = 0;
        $insert_cucc_sum = 0;
        $insert_ctcc_sum = 0;
        //虚拟号码
        $insert_virtual_sum = 0;

        //总数
        $total = 0;
        //可用
        $good_sum = 0;
        //文件重复
        $file_reply_num = 0;
        //无效
        $invalid_sum = 0;
        //数据库重复
        $has_sum = 0;
        $other_package_use = 0;
        $other_package_not_use = 0;
        $other_package_reg = 0;
        $other_package_not_reg = 0;
        $other_package_feedback = 0;
        $other_package_not_feedback = 0;
        //单价
        $price = 0;
        //除去无效和文件重复的数量
        $realTotal = 0;
        //存在其他包的数量
        $other_package_reply_sum = 0;

        //存在其他包的各类type的数量
        $other_package_reply_normal = 0;
        $other_package_reply_sleep = 0;
        $other_package_reply_risk = 0;
        $other_package_reply_vacant = 0;






        $start = memory_get_usage();
        echo '初始内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        $allPhone = [];
        $invalid_number = [];
        foreach ($txtArr as $txtDir) {
            $tmpTxtArr = [];
            $file = fopen($txtDir, "r");



            //得出文件的运营商和归属地
            while (!feof($file)) {
                //是否有效
                $tmpPhone = (int) fgets($file);
                if (!$tmpPhone) {
                    continue;
                }
                $total++;

                $checkRe = Phone::checkOperator($tmpPhone);

                if (!$checkRe) {
                    $invalid_sum++;
                    $invalid_number[] = $tmpPhone;
                    continue;
                }

                $tmpTxtArr[] = $tmpPhone;
            }

            $tmpUniqueArr = array_unique($tmpTxtArr);

            $file_reply_num += count($tmpTxtArr) - count($tmpUniqueArr);
            $allPhone[$txtDir] = $tmpUniqueArr;

            fclose($file);
        }

        $invalid_number_json = '';
        if ($invalid_sum > 0) {
            $invalid_number_json = json_encode($invalid_number);
        }
        $realTotal = $total - $invalid_sum - $file_reply_num; //实际提交数
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        // Instantiate a new ClientBuilder
        $table = 'mobile_' . $fileInfo['package_id'];
        self::createPhoneTable('pnl_' . $table);
        echo '遍历完文件内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        //存储新平台日志号码
        $newPlatformLogArr = [];
        //存储新入库的日志号码
        $newPhoneArr = [];
        $dealCount = 0;
        foreach ($allPhone as $txtName => $phoneArr) {
            //一个个文件循环即可
            echo '遍历完phone开始内存' . PHP_EOL;
            echo '打印所有次数' . PHP_EOL;
            var_dump(count($phoneArr));
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            $city = !empty($fileInfo['city_arr'][$txtName]) ? $fileInfo['city_arr'][$txtName] : '';
            if ($city) {
                $province = config('city.cityToProvince')[$city];
            } else {
                $province = $fileInfo['province_arr'][$txtName];
            }

            $companyName = $fileInfo['company_arr'][$txtName];
            $companyId = self::getIdByName($companyName);
            $forCount  = ceil(count($phoneArr) / 2000);

            echo '总次数-----------------------------------------------------------------------------------' . PHP_EOL;
            var_dump($forCount);
            var_dump(count($phoneArr));
            for ($i = 0; $i < $forCount; $i++) {


                echo '第' . $i . '次' . PHP_EOL;
                echo '第' . $i . '次' . PHP_EOL;
                //存储从ES查询出来的数据
                $queryAll = [];

                $tmpStart = $i * 2000;
                $tmpArr = array_slice($phoneArr, $tmpStart, 2000);
                $dealCount += count($tmpArr);
                //查询下个数
                echo 'deal开始' . PHP_EOL;
                var_dump((count($tmpArr)));
                $params = [
                    'index' => 'phone_info',
                    'body' => [
                        "query" => [

                            'bool' => [
                                'must' => [
                                    [
                                        'terms' => [
                                            'phone' => $tmpArr
                                            // 'phone' => [1]
                                        ]
                                    ],
                                    [
                                        'terms' => [
                                            'number_package' => $fileInfo['packageAllIds']
                                        ]
                                    ]


                                ]
                            ]

                        ],
                        'size' => 2000,
                        'from' => 0,
                    ]
                ];
                $results = $client->search($params);
                $replyCount = $results['hits']['total']['value'];
                $has_sum += $replyCount;
                $queryAll = $results['hits']['hits'];
                $queryAll  = array_column($queryAll, null, '_id');
                //得到总得查询数据
                $insert = [];
                $params = ['body' => []];


                #比对运营商和归属地
                $tmpUpdatePhone = [];

                if ($companyId == 1) $cmcc_sum += count($tmpArr);
                if ($companyId == 2) $cucc_sum += count($tmpArr);
                if ($companyId == 3) $ctcc_sum += count($tmpArr);
                if ($companyId == 4) $virtual_sum += count($tmpArr);
                foreach ($tmpArr as $key => $value) {
                    //数据库是否存在此号码
                    if (!empty($queryAll[$value])) {

                        if ($queryAll[$value]['_source']['company'] != $companyId) {
                            $tmpUpdatePhone[] = $value;
                        }
                        if ($queryAll[$value]['_source']['province'] != $province) {
                            $tmpUpdatePhone[] = $value;
                        }
                        if ($queryAll[$value]['_source']['city'] != $city) {
                            $tmpUpdatePhone[] = $value;
                        }
                        //此号码包含多个平台
                        if (is_array($queryAll[$value]['_source']['number_package'])) {

                            foreach ($queryAll[$value]['_source']['number_package'] as $packageId => $packageValue) {
                                if (!in_array($packageValue, $fileInfo['packageAllIds'])) {
                                    unset($queryAll[$value]['_source']['number_package'][$packageId]);
                                }
                            }
                            if (in_array($fileInfo['package_id'], $queryAll[$value]['_source']['number_package'])) {
                                if (count($queryAll[$value]['_source']['number_package']) > 1) {
                                    //存在其他包  数量+1
                                    $other_package_reply_sum++;
                                }
                            } else {
                                //存在其他包   需要插入到自己的包  但是不属于新号码
                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $companyId,
                                    'province' => $province,
                                    'city' => $city,
                                    'type' => 1,
                                    'is_use' => 0,
                                    'use_last_time' => 0,
                                    'feedback_last_time' => 0,
                                    'is_register' => 0,
                                    'is_feedback' => 0,
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($companyId == 1) $insert_cmcc_sum++;
                                if ($companyId == 2) $insert_cucc_sum++;
                                if ($companyId == 3) $insert_ctcc_sum++;
                                if ($companyId == 4) $insert_virtual_sum++;

                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;



                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;
                                //存在其他平台的各种type的数量


                                array_push($newPlatformLogArr, $value);
                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                            }
                        } else {
                            if ($fileInfo['package_id'] == $queryAll[$value]['_source']['number_package']) {
                            } else {
                                //存在其他包
                                //需要插入到自己的包  但是不属于新号码

                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $companyId,
                                    'province' => $province,
                                    'city' => $city,
                                    'type' => 1,
                                    'is_use' => 0,
                                    'use_last_time' => 0,
                                    'feedback_last_time' => 0,
                                    'is_register' => 0,
                                    'is_feedback' => 0,
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];

                                if ($companyId == 1) $insert_cmcc_sum++;
                                if ($companyId == 2) $insert_cucc_sum++;
                                if ($companyId == 3) $insert_ctcc_sum++;
                                if ($companyId == 4) $insert_virtual_sum++;
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;
                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;

                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                                array_push($newPlatformLogArr, $value);
                            }
                        }
                    } else {
                        $newPhoneArr[] = $value;
                        //实际插入++
                        $good_sum++;
                        $insert[] = [
                            'mobile' => $value,
                            'company' => $companyId,
                            'province' => $province,
                            'city' => $city,
                            'type' => 1,
                            'is_use' => 0,
                            'use_last_time' => 0,
                            'feedback_last_time' => 0,
                            'is_register' => 0,
                            'is_feedback' => 0,
                            'created_at' => time(),
                            'updated_at' => time(),
                            'package_id' => $fileInfo['package_id']
                        ];
                        if ($companyId == 1) $insert_cmcc_sum++;
                        if ($companyId == 2) $insert_cucc_sum++;
                        if ($companyId == 3) $insert_ctcc_sum++;
                        if ($companyId == 4) $insert_virtual_sum++;
                        //是否有效

                    }
                    $tmpEsAdd = [
                        "id" => $key + 1,
                        'phone' => $value,
                        'company' =>  $companyId,
                        "province" => $province,
                        "city" => $city,
                        'type' => 1,
                        'is_use' => 0,
                        'use_platform' => [],
                        'use_platform_name' => [],
                        'is_register' => 0,
                        'register_platform' =>  [],
                        'register_platform_name' => [],
                        'is_agent' => '',
                        'is_feedback' => 0,
                        'feedback_platform' => [],
                        'feedback_platform_name' => [],
                        #新号码
                        'use_last_time' => 0,
                        'use_time' => [],
                        'feedback_last_time' => 0,
                        'number_package' => [$fileInfo['package_id']],
                        'number_package_name' => [$fileInfo['package_name']],
                        'export_state' => 0,
                        'export_time' => [],
                        'export_count' => 0,
                        'export_at' => [], //存多个
                        'phone_segment' => substr($value, 0, 3), //存多个


                    ];
                    #修改为update
                    $updateMethod = 'index';
                    if (!empty($queryAll[$value])) {

                        $tmpEsAdd = [
                            // "id" => $key + 1,
                            'phone' => $value,
                            'company' =>  $companyId,
                            "province" => $province,
                            "city" => $city,
                            'number_package' => [$fileInfo['package_id']],
                            'number_package_name' => [$fileInfo['package_name']],
                            'updated_at' => time(),
                        ];
                        //存在过数据库
                        $updateMethod = 'update';

                        $tmpRegPackId = $queryAll[$value]['_source']['number_package'];

                        if (empty($tmpRegPackId)) {
                            $tmpRegPackId = [];
                        }
                        array_push($tmpRegPackId, $fileInfo['package_id']);
                        $tmpRegPackNameId = $queryAll[$value]['_source']['number_package_name'];
                        if (empty($tmpRegPackNameId)) {
                            $tmpRegPackNameId = [];
                        }
                        array_push($tmpRegPackNameId, $fileInfo['package_name']);



                        $tmpRegPackId = array_unique($tmpRegPackId);
                        $tmpRegPackId = array_merge($tmpRegPackId);
                        $tmpRegPackNameId = array_unique($tmpRegPackNameId);
                        $tmpRegPackNameId = array_merge($tmpRegPackNameId);
                        $tmpEsAdd['number_package'] = $tmpRegPackId;
                        $tmpEsAdd['number_package_name'] = $tmpRegPackNameId;
                        $a = $tmpEsAdd;
                        $tmpEsAdd = [];
                        //更新要指定参数doc
                        $tmpEsAdd['doc'] = $a;
                    } else {


                        $tmpEsAdd['created_at'] = time();
                    }

                    $params['body'][] = [
                        $updateMethod => [
                            '_index' => 'phone_info',
                            '_id' => $value
                        ]
                    ];


                    $params['body'][] = $tmpEsAdd;
                    // echo 1;
                    // exit;
                }
                if (count($insert) > 0) {
                    echo DB::table($table)->insert($insert);
                    $insert = [];
                }
                if (count($tmpUpdatePhone) > 0) {
                    DB::table($table)->whereIn('mobile', $tmpUpdatePhone)->update([
                        'city' => $city,
                        'company' => $companyId,
                        'province' => $province,
                    ]);
                }

                $responses = $client->bulk($params);
                // var_dump($responses);
                // erase the old bulk request
                unset($params);
                $params = ['body' => []];
                // unset the bulk response when you are done to save memory

                if (count($newPlatformLogArr) > 50000) {
                    //记录关联号码包日志
                    $insertNewPrice = [];
                    foreach ($newPlatformLogArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($newPlatformLogArr);
                    $newPlatformLogArr = [];
                    unset($tmpInsertNewPrice);
                }
                if (count($newPhoneArr) > 50000) {
                    //记录新入库日志
                    //
                    $insertNewPrice = [];
                    foreach ($newPhoneArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    echo '五万数据组装完成' . PHP_EOL;
                    echo '打印一下内存' . PHP_EOL;
                    echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newPhoneArr);
                    $newPhoneArr = [];
                }
                unset($responses);
                unset($tmpArr);
                unset($insert);
                if ($dealCount && $realTotal) {
                    DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => (number_format($dealCount / $realTotal * 0.95, 2) * 100) . '%']);
                }
            }
            unset($queryAll);
            echo '遍历完phone结束内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        }

        echo 'count2' . PHP_EOL;
        var_dump(count($newPlatformLogArr));
        var_dump(count($newPhoneArr));
        if (count($newPlatformLogArr)) {
            //记录关联号码包日志
            $insertNewPrice = [];
            foreach ($newPlatformLogArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($newPlatformLogArr);
            $newPlatformLogArr = [];
            unset($tmpInsertNewPrice);
        }
        if (count($newPhoneArr)) {
            //记录新入库日志
            //
            $insertNewPrice = [];
            foreach ($newPhoneArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }

            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newPhoneArr);
            $newPhoneArr = [];
        }


        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' =>  '100%']);

        //更新总的日志
        $packageUploadLog = [
            'total' => $total,
            'has_sum' => $has_sum,
            'real_total' => $realTotal,
            'cmcc_sum' => $cmcc_sum,
            'cucc_sum' => $cucc_sum,
            'ctcc_sum' => $ctcc_sum,
            'virtual_sum' => $virtual_sum,
            'invalid_sum' => $invalid_sum,
            'file_reply_sum' => $file_reply_num,
            'other_package_reply_sum' => $other_package_reply_sum,
            // 'money_sum' => !empty($fileInfo['money_sum']) ? $fileInfo['money_sum'] : 0,
            // 'money_avg' => $price,
            'insert_sum' => $good_sum,
            'is_deal' => 1,
            'updated_at' => time(),
            'invalid_number_json' => $invalid_number_json,
            'deal_time' => time() - $fileInfo['startTime']
        ];

        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($packageUploadLog);

        $package = DB::table('package')->where('id', $fileInfo['package_id'])->first();
        //更新号码包的统计数据

        $packageUpdate = [
            'total' => $package->total + ($good_sum + $other_package_reply_sum), //号码包总号码等于新号码+存在的别的包但是不存在此包的量
            'real_total' => $package->total + ($good_sum + $other_package_reply_sum), //等于total - 沉默 - 空号 -危险号  但是此处没有这些属性 故=total
            'cmcc_sum' => DB::raw('cmcc_sum+' . $insert_cmcc_sum),
            'cucc_sum' => DB::raw('cucc_sum+' . $insert_cucc_sum),
            'ctcc_sum' => DB::raw('ctcc_sum+' . $insert_ctcc_sum),
            'virtual_sum' => DB::raw('virtual_sum+' . $insert_virtual_sum),
            'good_sum' => DB::raw('good_sum+' . ($good_sum + $other_package_reply_normal)),
            'no_used_sum' => DB::raw('no_used_sum+' . ($good_sum + $other_package_not_use)),
            'no_register_sum' => DB::raw('no_register_sum+' . ($good_sum + $other_package_not_reg)),
            'used_sum' => DB::raw('used_sum+' . $other_package_use),
            'register_sum' => DB::raw('register_sum+' . $other_package_reg),
            'feedback_sum' => DB::raw('feedback_sum+' . $other_package_feedback),
            'no_feedback_sum' => DB::raw('no_feedback_sum+' . ($good_sum + $other_package_not_feedback)),
            'sleep_sum' => DB::raw('sleep_sum+' . ($other_package_reply_sleep)),
            'risk_sum' => DB::raw('risk_sum+' . ($other_package_reply_risk)),
            'vacant_sum' => DB::raw('vacant_sum+' . ($other_package_reply_vacant)),
        ];
        DB::table('package')->where('id', $fileInfo['package_id'])->update($packageUpdate);
        unset($allPhone);
        echo '最后内存' . PHP_EOL;
        echo Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        self::pushPackageRatioQueue($fileInfo['package_id']);

    }

    public static function uploadUseMobile($fileInfo)
    {
        //使用号码
        //读取excel

        $txtArr = self::getTxtList($fileInfo);

        // 取得总行数  
        $tmpArr = [];
        $cmcc_sum = 0;
        $cucc_sum = 0;
        $ctcc_sum = 0;
        $use_time = $fileInfo['use_time'];
        $platform_id = $fileInfo['platform_id'];
        $platform_name = $fileInfo['platform_name'];
        //虚拟号码
        $virtual_sum = 0;
        $insert_cmcc_sum = 0;
        $insert_cucc_sum = 0;
        $insert_ctcc_sum = 0;
        //虚拟号码
        $insert_virtual_sum = 0;


        //总数
        $total = 0;
        //可用
        $good_sum = 0;
        //文件重复
        $file_reply_num = 0;
        //无效
        $invalid_sum = 0;
        //数据库重复
        $has_sum = 0;
        $other_package_use = 0;
        $other_package_not_use = 0;
        $other_package_reg = 0;
        $other_package_not_reg = 0;
        $other_package_feedback = 0;
        $other_package_not_feedback = 0;

        //除去无效和文件重复的数量
        $realTotal = 0;
        //存在其他包的数量
        $other_package_reply_sum = 0;

        $other_package_reply_normal = 0;
        $other_package_reply_sleep = 0;
        $other_package_reply_risk = 0;
        $other_package_reply_vacant = 0;


        $start = memory_get_usage();
        echo '初始内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        $allPhone = [];
        $invalid_number = [];
        $dealCount = 0;
        foreach ($txtArr as $txtDir) {
            $tmpTxtArr = [];
            $file = fopen($txtDir, "r");



            //得出文件的运营商和归属地
            while (!feof($file)) {
                //是否有效
                $tmpPhone = (int) fgets($file);
                if (!$tmpPhone) {
                    continue;
                }
                $total++;

                $checkRe = Phone::checkOperator($tmpPhone);

                if (!$checkRe) {

                    $invalid_number[] = $tmpPhone;
                    $invalid_sum++;
                    continue;
                }

                $tmpTxtArr[] = $tmpPhone;
            }

            $tmpUniqueArr = array_unique($tmpTxtArr);

            $file_reply_num += count($tmpTxtArr) - count($tmpUniqueArr);
            $allPhone[$txtDir] = $tmpUniqueArr;

            fclose($file);
        }
        $invalid_number_json = '';
        if ($invalid_sum > 0) {
            $invalid_number_json = json_encode($invalid_number);
        }
        $realTotal = $total - $invalid_sum - $file_reply_num; //实际提交数
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        // Instantiate a new ClientBuilder
        $table = 'mobile_' . $fileInfo['package_id'];
        self::createPhoneTable('pnl_' . $table);
        echo '遍历完文件内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        //存储新平台日志号码
        $newPlatformLogArr = [];
        //存储新入库的日志号码
        $newPhoneArr = [];
        //从未使用过  要更改后入库
        $newUserArr = [];
        $allUpdateData = [];
        $HasPackNotUserCount = 0;
        $newUserArrCount = 0;
        foreach ($allPhone as $txtName => $phoneArr) {
            //一个个文件循环即可
            echo '遍历完phone开始内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            $city = '';
            $province = '';
            $companyName = '';
            $companyId = 0;
            $forCount  = ceil(count($phoneArr) / 5000);

            echo '总次数-----------------------------------------------------------------------------------' . PHP_EOL;
            var_dump($forCount);

            for ($i = 0; $i < $forCount; $i++) {


                echo '第' . $i . '次' . PHP_EOL;
                //存储从ES查询出来的数据
                $queryAll = [];

                $tmpStart = $i * 5000;
                $tmpArr = array_slice($phoneArr, $tmpStart, 5000);
                //查询下个数
                $dealCount += count($tmpArr);
                $params = [
                    'index' => 'phone_info',
                    'body' => [
                        "query" => [

                            'bool' => [
                                'must' => [
                                    [
                                        'terms' => [
                                            'phone' => $tmpArr
                                            // 'phone' => [1]
                                        ]
                                    ],
                                    [
                                        'terms' => [
                                            'number_package' => $fileInfo['packageAllIds']
                                        ]
                                    ]


                                ]
                            ]

                        ],
                        'size' => 5000,
                        'from' => 0,
                    ]
                ];
                $results = $client->search($params);
                $replyCount = $results['hits']['total']['value'];
                $has_sum += $replyCount;
                $queryAll = $results['hits']['hits'];
                $queryAll  = array_column($queryAll, null, '_id');
                //得到总得查询数据
                $insert = [];
                $params = ['body' => []];


                #比对运营商和归属地
                $tmpUpdatePhone = [];

                // if ($companyId == 1) $cmcc_sum += count($tmpArr);
                // if ($companyId == 2) $cucc_sum += count($tmpArr);
                // if ($companyId == 3) $ctcc_sum += count($tmpArr);
                // if ($companyId == 4) $virtual_sum += count($tmpArr);
                foreach ($tmpArr as $key => $value) {
                    //数据库是否存在此号码
                    if (!empty($queryAll[$value])) {

                        if ($queryAll[$value]['_source']['company'] == 1) {
                            $cmcc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 2) {
                            $cucc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 3) {
                            $ctcc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 4) {
                            $virtual_sum++;
                        }
                        if (empty($queryAll[$value]['_source']['is_use'])) {
                            $newUserArrCount++;
                            array_push($newUserArr, $value);
                        }
                        //此号码包含多个平台
                        if (is_array($queryAll[$value]['_source']['number_package'])) {
                            foreach ($queryAll[$value]['_source']['number_package'] as $packageId => $packageValue) {
                                if (!in_array($packageValue, $fileInfo['packageAllIds'])) {
                                    unset($queryAll[$value]['_source']['number_package'][$packageId]);
                                }
                            }
                            if (in_array($fileInfo['package_id'], $queryAll[$value]['_source']['number_package'])) {
                                if (count($queryAll[$value]['_source']['number_package']) > 1) {
                                    //存在其他包  数量+1
                                    $other_package_reply_sum++;
                                }
                                if (empty($queryAll[$value]['_source']['is_use'])) {
                                    $HasPackNotUserCount++;
                                }
                            } else {
                                //存在其他包   需要插入到自己的包  但是不属于新号码
                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $companyId,
                                    'province' => $province,
                                    'city' => $city,
                                    'type' => 1,
                                    'is_use' => 1,
                                    'use_last_time' => $use_time,
                                    'feedback_last_time' => 0,
                                    'is_register' => 0,
                                    'is_feedback' => 0,
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($queryAll[$value]['_source']['company'] == 1) {
                                    $insert_cmcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 2) {
                                    $insert_cucc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 3) {
                                    $insert_ctcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 4) {
                                    $insert_virtual_sum++;
                                }
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;
                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;
                                array_push($newPlatformLogArr, $value);
                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                            }
                        } else {
                            if ($fileInfo['package_id'] == $queryAll[$value]['_source']['number_package']) {
                                if (empty($queryAll[$value]['_source']['is_use'])) {
                                    $HasPackNotUserCount++;
                                }
                            } else {
                                //存在其他包
                                //需要插入到自己的包  但是不属于新号码

                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $companyId,
                                    'province' => $province,
                                    'city' => $city,
                                    'type' => 1,
                                    'is_use' => 1,
                                    'use_last_time' => $use_time,
                                    'feedback_last_time' => 0,
                                    'is_register' => 0,
                                    'is_feedback' => 0,
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($queryAll[$value]['_source']['company'] == 1) {
                                    $insert_cmcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 2) {
                                    $insert_cucc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 3) {
                                    $insert_ctcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 4) {
                                    $insert_virtual_sum++;
                                }
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;
                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;

                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                                array_push($newPlatformLogArr, $value);
                            }
                        }
                    } else {
                        $newPhoneArr[] = $value;
                        //实际插入++
                        $good_sum++;
                        $insert[] = [
                            'mobile' => $value,
                            'company' => $companyId,
                            'province' => $province,
                            'city' => $city,
                            'type' => 1,

                            'is_use' => 1,
                            'use_last_time' => $use_time,
                            'feedback_last_time' => 0,
                            'is_register' => 0,
                            'is_feedback' => 0,
                            'created_at' => time(),
                            'updated_at' => time(),
                            'package_id' => $fileInfo['package_id']
                        ];

                        //是否有效

                    }
                    $tmpEsAdd = [
                        "id" => $key + 1,
                        'phone' => $value,
                        'company' =>  $companyId,
                        "province" => $province,
                        "city" => $city,
                        'type' => 1,
                        'is_use' => 1,
                        'use_platform' => [$platform_id],
                        'use_platform_name' => [$platform_name],
                        'is_register' => 0,
                        'register_platform' =>  [],
                        'register_platform_name' => [],
                        'is_agent' => '',
                        'is_feedback' => 0,
                        'feedback_platform' => [],
                        'feedback_platform_name' => [],
                        #新号码
                        'use_last_time' => $use_time,
                        'use_time' => [$use_time],
                        'feedback_last_time' => 0,
                        'number_package' => [$fileInfo['package_id']],
                        'number_package_name' => [$fileInfo['package_name']],
                        'export_state' => 0,
                        'export_time' => [],
                        'export_count' => 0,
                        'export_at' => [], //存多个
                        'phone_segment' => substr($value, 0, 3),

//                        'is_get_lottery' => '',//是否领取彩金
//                        'is_gold_flow' => '',//是否有流水
//                        'is_agent_gold' => '',//是否有代理收益
//                        'day30_spread_increase' => '',//30天内直属下级是否新增
//                        'day1_recharge_gold' => '',//一天充值总金额
//                        'day1_withdraw_gold' => '',//一天取款总金额
//                        'day1_rwdv_percent' => '',//充兑差值百分比
//                        'labels' => [],//标签属性


                    ];
                    #修改为update
                    $updateMethod = 'index';
                    if (!empty($queryAll[$value])) {
                        $updateMethod = 'update';
                        $tmpEsAdd = [
                            // "id" => $key + 1,
                            'phone' => $value,
                            'number_package' => [$fileInfo['package_id']],
                            'number_package_name' => [$fileInfo['package_name']],
                            'updated_at' => time(),
                        ];
                        //存在过数据库
                        $tmpEsAdd['is_use'] = 1;
                        $tmpEsAdd['use_last_time'] = $use_time;
                        $tmpEsAdd['updated_at'] = time();
                        $tmpRegPlatId = $queryAll[$value]['_source']['use_platform'];
                        if (empty($tmpRegPlatId)) {
                            $tmpRegPlatId = [];
                        }
                        array_push($tmpRegPlatId, $platform_id);
                        $tmpRegNamePlatId = $queryAll[$value]['_source']['use_platform_name'];
                        if (empty($tmpRegNamePlatId)) {
                            $tmpRegNamePlatId = [];
                        }
                        array_push($tmpRegNamePlatId, $platform_name);
                        $tmpRegPackId = $queryAll[$value]['_source']['number_package'];

                        if (empty($tmpRegPackId)) {
                            $tmpRegPackId = [];
                        }
                        array_push($tmpRegPackId, $fileInfo['package_id']);
                        $tmpRegPackNameId = $queryAll[$value]['_source']['number_package_name'];
                        if (empty($tmpRegPackNameId)) {
                            $tmpRegPackNameId = [];
                        }
                        array_push($tmpRegPackNameId, $fileInfo['package_name']);
                        $tmpUseTime = $queryAll[$value]['_source']['use_time'];
                        if (empty($tmpUseTime)) {
                            $tmpUseTime = [];
                        }
                        array_push($tmpUseTime, $use_time);


                        //去重
                        $tmpRegPlatId = array_unique($tmpRegPlatId);
                        $tmpRegPlatId = array_merge($tmpRegPlatId);
                        $tmpRegNamePlatId = array_unique($tmpRegNamePlatId);
                        $tmpRegNamePlatId = array_merge($tmpRegNamePlatId);
                        $tmpRegPackId = array_unique($tmpRegPackId);
                        $tmpRegPackId = array_merge($tmpRegPackId);
                        $tmpRegPackNameId = array_unique($tmpRegPackNameId);
                        $tmpRegPackNameId = array_merge($tmpRegPackNameId);
                        $tmpUseTime = array_unique($tmpUseTime);
                        $tmpUseTime = array_merge($tmpUseTime);
                        $tmpEsAdd['use_platform'] = $tmpRegPlatId;
                        $tmpEsAdd['use_platform_name'] = $tmpRegNamePlatId;
                        $tmpEsAdd['number_package'] = $tmpRegPackId;
                        $tmpEsAdd['number_package_name'] = $tmpRegPackNameId;
                        $tmpEsAdd['use_time'] = $tmpUseTime;
                        $a = $tmpEsAdd;
                        $tmpEsAdd = [];
                        //更新要指定参数doc
                        $tmpEsAdd['doc'] = $a;
                    } else {


                        $tmpEsAdd['created_at'] = time();
                    }

                    $params['body'][] = [
                        $updateMethod => [
                            '_index' => 'phone_info',
                            '_id' => $value
                        ]
                    ];


                    $params['body'][] = $tmpEsAdd;
                    // echo 1;
                    // exit;
                    $allUpdateData[] = $value;
                }
                if (count($insert) > 0) {
                    echo DB::table($table)->insert($insert);
                    $insert = [];
                }

                $responses = $client->bulk($params);
                // erase the old bulk request
                unset($params);
                $params = ['body' => []];
                // unset the bulk response when you are done to save memory
                echo 'count' . PHP_EOL;

                var_dump(count($newPhoneArr));

                if (count($newPlatformLogArr) > 50000) {
                    //记录关联号码包日志
                    $insertNewPrice = [];
                    foreach ($newPlatformLogArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($newPlatformLogArr);
                    $newPlatformLogArr = [];
                    unset($tmpInsertNewPrice);
                }
                if (count($newPhoneArr) > 50000) {
                    //记录新入库日志
                    //
                    $insertNewPrice = [];
                    foreach ($newPhoneArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    echo '五万数据组装完成' . PHP_EOL;
                    echo '打印一下内存' . PHP_EOL;
                    echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newPhoneArr);
                    $newPhoneArr = [];
                }
                if (count($newUserArr) > 50000) {
                    //存在需要更新使用状态的  记录状态更新日志
                    $insertNewPrice = [];
                    foreach ($newUserArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = '【使用状态】未使用=>已使用【' . $fileInfo['platform_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                        $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                        $tmpInsertNewPrice['lastStatus'] = 0;
                        $tmpInsertNewPrice['nowStatus'] = 1;
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newUserArr);
                    $newUserArr = [];
                }
                if (count($allUpdateData) > 50000) {
                    self::updateAll($table, ['is_use' => 1, 'use_last_time' => $use_time, 'updated_at' => time()], $allUpdateData);
                    $insertNewPrice = [];
                    foreach ($allUpdateData as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = '';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 2;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                        $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                        $tmpInsertNewPrice['use_time'] = $use_time;
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    echo '更新使用日志' . PHP_EOL;
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($allUpdateData);
                    $allUpdateData = [];
                }

                unset($responses);
                unset($tmpArr);
                unset($insert);
                if ($dealCount && $realTotal) {
                    DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => (number_format($dealCount / $realTotal * 0.95, 2) * 100) . '%']);
                }
            }
            unset($queryAll);
            echo '遍历完phone结束内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        }



        if (count($newPlatformLogArr)) {
            //记录关联号码包日志
            $insertNewPrice = [];
            foreach ($newPlatformLogArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($newPlatformLogArr);
            $newPlatformLogArr = [];
            unset($tmpInsertNewPrice);
        }
        if (count($newPhoneArr)) {
            //记录新入库日志
            //
            $insertNewPrice = [];
            foreach ($newPhoneArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            echo '五万数据组装完成' . PHP_EOL;
            echo '打印一下内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newPhoneArr);
            $newPhoneArr = [];
        }
        if (count($newUserArr)) {
            //存在需要更新使用状态的  记录状态更新日志
            $insertNewPrice = [];
            foreach ($newUserArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = '【使用状态】未使用=>已使用【' . $fileInfo['platform_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                $tmpInsertNewPrice['lastStatus'] = 0;
                $tmpInsertNewPrice['nowStatus'] = 1;
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newUserArr);
            $newUserArr = [];
        }

        if (count($allUpdateData)) {
            self::updateAll($table, ['is_use' => 1, 'use_last_time' => $use_time, 'updated_at' => time()], $allUpdateData);
            $insertNewPrice = [];
            foreach ($allUpdateData as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = '';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 2;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                $tmpInsertNewPrice['use_time'] = $use_time;
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            echo '更新使用日志' . PHP_EOL;
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($allUpdateData);
            $allUpdateData = [];
        }


        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' =>  '100%']);





        //更新总的日志
        $packageUploadLog = [
            'total' => $total,
            'has_sum' => $has_sum,
            'real_total' => $realTotal,
            'cmcc_sum' => $cmcc_sum,
            'cucc_sum' => $cucc_sum,
            'ctcc_sum' => $ctcc_sum,
            'virtual_sum' => $virtual_sum,
            'invalid_sum' => $invalid_sum,
            'file_reply_sum' => $file_reply_num,
            'other_package_reply_sum' => $other_package_reply_sum,
            'is_deal' => 1,
            'updated_at' => time(),
            'insert_sum' => $good_sum,
            'invalid_number_json' => $invalid_number_json,
            'deal_time' => time() - $fileInfo['startTime']
        ];




        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($packageUploadLog);
        $package = DB::table('package')->where('id', $fileInfo['package_id'])->first();
        //更新号码包的统计数据

        $packageUpdate = [
            'total' => $package->total + ($good_sum + $other_package_reply_sum), //号码包总号码等于新号码+存在的别的包但是不存在此包的量
            'real_total' => DB::raw('real_total+' . ($good_sum + $other_package_reply_sum)), //等于total - 沉默 - 空号 -危险号  但是此处没有这些属性 故=total
            'cmcc_sum' => DB::raw('cmcc_sum+' . $insert_cmcc_sum),
            'cucc_sum' => DB::raw('cucc_sum+' . $insert_cucc_sum),
            'ctcc_sum' => DB::raw('ctcc_sum+' . $insert_ctcc_sum),
            'virtual_sum' => DB::raw('virtual_sum+' . $insert_virtual_sum),
            'good_sum' => DB::raw('good_sum+' . ($good_sum + $other_package_reply_normal)),
            // 'unverified_sum' => DB::raw('unverified_sum-' . count($newTypeArr)),
            'no_register_sum' => DB::raw('no_register_sum+' . ($good_sum + $other_package_not_reg)),
            'register_sum' => DB::raw('register_sum+' . $other_package_reg),
            'used_sum' => DB::raw('used_sum+' . ($other_package_use + $good_sum + $newUserArrCount)),
            'no_used_sum' => DB::raw('no_used_sum-' . $HasPackNotUserCount),
            'no_feedback_sum' => DB::raw('no_feedback_sum+' . ($good_sum + $other_package_not_feedback)),
            'feedback_sum' => DB::raw('feedback_sum+' . $other_package_feedback),
            'sleep_sum' => DB::raw('sleep_sum+' . ($other_package_reply_sleep)),
            'risk_sum' => DB::raw('risk_sum+' . ($other_package_reply_risk)),
            'vacant_sum' => DB::raw('vacant_sum+' . ($other_package_reply_vacant)),


        ];







        DB::table('package')->where('id', $fileInfo['package_id'])->update($packageUpdate);
        unset($allPhone);
        echo '最后内存' . PHP_EOL;
        echo Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        self::pushPackageRatioQueue($fileInfo['package_id']);
    }

    public static function uploadRegMobile($fileInfo)
    {
        //使用号码
        //读取excel

        $txtArr = self::getTxtList($fileInfo);

        // 取得总行数  
        $tmpArr = [];
        $cmcc_sum = 0;
        $cucc_sum = 0;
        $ctcc_sum = 0;

        $platform_id = $fileInfo['platform_id'];
        $platform_name = $fileInfo['platform_name'];
        //虚拟号码
        $virtual_sum = 0;
        $insert_cmcc_sum = 0;
        $insert_cucc_sum = 0;
        $insert_ctcc_sum = 0;
        //虚拟号码
        $insert_virtual_sum = 0;


        //总数
        $total = 0;
        //可用
        $good_sum = 0;
        //文件重复
        $file_reply_num = 0;
        //无效
        $invalid_sum = 0;
        //数据库重复
        $has_sum = 0;
        $other_package_use = 0;
        $other_package_not_use = 0;
        $other_package_reg = 0;
        $other_package_not_reg = 0;
        $other_package_feedback = 0;
        $other_package_not_feedback = 0;



        $other_package_reply_normal = 0;
        $other_package_reply_sleep = 0;
        $other_package_reply_risk = 0;
        $other_package_reply_vacant = 0;

        //除去无效和文件重复的数量
        $realTotal = 0;
        //存在其他包的数量
        $other_package_reply_sum = 0;
        $dealCount = 0;
        $start = memory_get_usage();
        echo '初始内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        $allPhone = [];
        $invalid_number = [];
        foreach ($txtArr as $txtDir) {
            $tmpTxtArr = [];
            $file = fopen($txtDir, "r");



            //得出文件的运营商和归属地
            while (!feof($file)) {
                //是否有效
                $tmpPhone = (int) fgets($file);
                if (!$tmpPhone) {
                    continue;
                }
                $total++;
                $checkRe = Phone::checkOperator($tmpPhone);

                if (!$checkRe) {

                    $invalid_number[] = $tmpPhone;
                    $invalid_sum++;
                    continue;
                }

                $tmpTxtArr[] = $tmpPhone;
            }

            $tmpUniqueArr = array_unique($tmpTxtArr);

            $file_reply_num += count($tmpTxtArr) - count($tmpUniqueArr);
            $allPhone[$txtDir] = $tmpUniqueArr;

            fclose($file);
        }
        $invalid_number_json = '';
        if ($invalid_sum > 0) {
            $invalid_number_json = json_encode($invalid_number);
        }
        $realTotal = $total - $invalid_sum - $file_reply_num; //实际提交数
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        // Instantiate a new ClientBuilder
        $table = 'mobile_' . $fileInfo['package_id'];
        self::createPhoneTable('pnl_' . $table);
        echo '遍历完文件内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        //存储新平台日志号码
        $newPlatformLogArr = [];
        //存储新入库的日志号码
        $newPhoneArr = [];
        //从未使用过  要更改后入库
        $newUserArr = [];
        $allUpdateData = [];
        //未在本平台注册
        $newRegArr = [];
        $HasPackNotUserCount = 0;
        $newUserArrCount = 0;
        foreach ($allPhone as $txtName => $phoneArr) {
            //一个个文件循环即可
            echo '遍历完phone开始内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            $city = '';
            $province = '';
            $companyName = '';
            $companyId = 0;
            $forCount  = ceil(count($phoneArr) / 5000);
            for ($i = 0; $i < $forCount; $i++) {


                echo '第' . $i . '次' . PHP_EOL;
                //存储从ES查询出来的数据
                $queryAll = [];

                $tmpStart = $i * 5000;
                $tmpArr = array_slice($phoneArr, $tmpStart, 5000);
                $dealCount += count($tmpArr);
                //查询下个数
                $params = [
                    'index' => 'phone_info',
                    'body' => [
                        "query" => [

                            'bool' => [
                                'must' => [
                                    [
                                        'terms' => [
                                            'phone' => $tmpArr
                                            // 'phone' => [1]
                                        ]
                                    ],
                                    [
                                        'terms' => [
                                            'number_package' => $fileInfo['packageAllIds']
                                        ]
                                    ]


                                ]
                            ]

                        ],
                        'size' => 5000,
                        'from' => 0,
                    ]
                ];
                $results = $client->search($params);
                $replyCount = $results['hits']['total']['value'];
                $has_sum += $replyCount;
                $queryAll = $results['hits']['hits'];
                $queryAll  = array_column($queryAll, null, '_id');
                //得到总得查询数据
                $insert = [];
                $params = ['body' => []];


                #比对运营商和归属地
                $tmpUpdatePhone = [];

                // if ($companyId == 1) $cmcc_sum += count($tmpArr);
                // if ($companyId == 2) $cucc_sum += count($tmpArr);
                // if ($companyId == 3) $ctcc_sum += count($tmpArr);
                // if ($companyId == 4) $virtual_sum += count($tmpArr);
                foreach ($tmpArr as $key => $value) {
                    //数据库是否存在此号码
                    if (!empty($queryAll[$value])) {

                        if ($queryAll[$value]['_source']['company'] == 1) {
                            $cmcc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 2) {
                            $cucc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 3) {
                            $ctcc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 4) {
                            $virtual_sum++;
                        }
                        //注册0-》1  记录日志
                        if (empty($queryAll[$value]['_source']['is_register'])) {
                            $newUserArrCount++;
                            array_push($newUserArr, $value);
                        }
                        //未在本平台注册  记录在本平台注册
                        if (empty($queryAll[$value]['_source']['register_platform']) || !in_array($platform_id, $queryAll[$value]['_source']['register_platform'])) {
                            array_push($newRegArr, $value);
                        }
                        //此号码包含多个平台
                        if (is_array($queryAll[$value]['_source']['number_package'])) {
                            foreach ($queryAll[$value]['_source']['number_package'] as $packageId => $packageValue) {
                                if (!in_array($packageValue, $fileInfo['packageAllIds'])) {
                                    unset($queryAll[$value]['_source']['number_package'][$packageId]);
                                }
                            }
                            if (in_array($fileInfo['package_id'], $queryAll[$value]['_source']['number_package'])) {
                                if (count($queryAll[$value]['_source']['number_package']) > 1) {
                                    //存在其他包  数量+1
                                    $other_package_reply_sum++;
                                }
                                //在自己的包里未注册的
                                if (empty($queryAll[$value]['_source']['is_register'])) {
                                    $HasPackNotUserCount++;
                                }
                            } else {
                                //存在其他包   需要插入到自己的包  但是不属于新号码
                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $companyId,
                                    'province' => $province,
                                    'city' => $city,
                                    'type' => 1,
                                    'is_use' => 0,
                                    'use_last_time' => 0,
                                    'feedback_last_time' => 0,
                                    'is_register' => 1,
                                    'is_feedback' => 0,
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($queryAll[$value]['_source']['company'] == 1) {
                                    $insert_cmcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 2) {
                                    $insert_cucc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 3) {
                                    $insert_ctcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 4) {
                                    $insert_virtual_sum++;
                                }
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;

                                array_push($newPlatformLogArr, $value);
                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;

                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                            }
                        } else {
                            if ($fileInfo['package_id'] == $queryAll[$value]['_source']['number_package']) {
                                if (empty($queryAll[$value]['_source']['is_register'])) {
                                    $HasPackNotUserCount++;
                                }
                            } else {
                                //存在其他包
                                //需要插入到自己的包  但是不属于新号码

                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $companyId,
                                    'province' => $province,
                                    'city' => $city,
                                    'type' => 1,
                                    'is_use' => 0,
                                    'use_last_time' => 0,
                                    'feedback_last_time' => 0,
                                    'is_register' => 1,
                                    'is_feedback' => 0,
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($queryAll[$value]['_source']['company'] == 1) {
                                    $insert_cmcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 2) {
                                    $insert_cucc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 3) {
                                    $insert_ctcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 4) {
                                    $insert_virtual_sum++;
                                }
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;

                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;

                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                                array_push($newPlatformLogArr, $value);
                            }
                        }
                    } else {
                        $newPhoneArr[] = $value;
                        //实际插入++
                        $good_sum++;
                        $insert[] = [
                            'mobile' => $value,
                            'company' => $companyId,
                            'province' => $province,
                            'city' => $city,
                            'type' => 1,
                            'is_use' => 0,
                            'use_last_time' => 0,
                            'feedback_last_time' => 0,
                            'is_register' => 1,
                            'is_feedback' => 0,
                            'created_at' => time(),
                            'updated_at' => time(),
                            'package_id' => $fileInfo['package_id']
                        ];

                        //是否有效

                    }
                    $tmpEsAdd = [
                        "id" => $key + 1,
                        'phone' => $value,
                        'company' =>  $companyId,
                        "province" => $province,
                        "city" => $city,
                        'type' => 1,
                        'is_use' => 0,
                        'use_platform' => [],
                        'use_platform_name' => [],
                        'is_register' => 1,
                        'register_platform' =>  [$platform_id],
                        'register_platform_name' => [$platform_name],
                        'is_agent' => '',
                        'is_feedback' => 0,
                        'feedback_platform' => [],
                        'feedback_platform_name' => [],
                        #新号码
                        'use_last_time' => 0,
                        'use_time' => [],
                        'feedback_last_time' => 0,
                        'number_package' => [$fileInfo['package_id']],
                        'number_package_name' => [$fileInfo['package_name']],
                        'export_state' => 0,
                        'export_time' => [],
                        'export_count' => 0,
                        'export_at' => [], //存多个
                        'phone_segment' => substr($value, 0, 3),


                    ];
                    #修改为update
                    $updateMethod = 'index';
                    if (!empty($queryAll[$value])) {
                        $updateMethod = 'update';
                        $tmpEsAdd = [
                            // "id" => $key + 1,
                            'phone' => $value,
                            'number_package' => [$fileInfo['package_id']],
                            'number_package_name' => [$fileInfo['package_name']],
                            'updated_at' => time(),
                        ];
                        //存在过数据库
                        $tmpEsAdd['is_register'] = 1;

                        $tmpEsAdd['updated_at'] = time();
                        $tmpRegPlatId = $queryAll[$value]['_source']['register_platform'];
                        if (empty($tmpRegPlatId)) {
                            $tmpRegPlatId = [];
                        }
                        array_push($tmpRegPlatId, $platform_id);
                        $tmpRegNamePlatId = $queryAll[$value]['_source']['register_platform_name'];
                        if (empty($tmpRegNamePlatId)) {
                            $tmpRegNamePlatId = [];
                        }
                        array_push($tmpRegNamePlatId, $platform_name);
                        $tmpRegPackId = $queryAll[$value]['_source']['number_package'];

                        if (empty($tmpRegPackId)) {
                            $tmpRegPackId = [];
                        }
                        array_push($tmpRegPackId, $fileInfo['package_id']);
                        $tmpRegPackNameId = $queryAll[$value]['_source']['number_package_name'];
                        if (empty($tmpRegPackNameId)) {
                            $tmpRegPackNameId = [];
                        }
                        array_push($tmpRegPackNameId, $fileInfo['package_name']);



                        //去重
                        $tmpRegPlatId = array_unique($tmpRegPlatId);
                        $tmpRegPlatId = array_merge($tmpRegPlatId);
                        $tmpRegNamePlatId = array_unique($tmpRegNamePlatId);
                        $tmpRegNamePlatId = array_merge($tmpRegNamePlatId);
                        $tmpRegPackId = array_unique($tmpRegPackId);
                        $tmpRegPackId = array_merge($tmpRegPackId);
                        $tmpRegPackNameId = array_unique($tmpRegPackNameId);
                        $tmpRegPackNameId = array_merge($tmpRegPackNameId);
                        // $tmpUseTime = array_unique($tmpUseTime);
                        $tmpEsAdd['register_platform'] = $tmpRegPlatId;
                        $tmpEsAdd['register_platform_name'] = $tmpRegNamePlatId;
                        $tmpEsAdd['is_agent'] = '';
                        $tmpEsAdd['number_package'] = $tmpRegPackId;
                        $tmpEsAdd['number_package_name'] = $tmpRegPackNameId;
                        // $tmpEsAdd['use_time'] = $tmpUseTime;
                        $a = $tmpEsAdd;
                        $tmpEsAdd = [];
                        //更新要指定参数doc
                        $tmpEsAdd['doc'] = $a;
                    } else {


                        $tmpEsAdd['created_at'] = time();
                    }

                    $params['body'][] = [
                        $updateMethod => [
                            '_index' => 'phone_info',
                            '_id' => $value
                        ]
                    ];


                    $params['body'][] = $tmpEsAdd;
                    // echo 1;
                    // exit;
                    // $allUpdateData[] = $value;
                }
                if (count($insert) > 0) {
                    echo DB::table($table)->insert($insert);
                    $insert = [];
                }

                $responses = $client->bulk($params);
                // erase the old bulk request
                unset($params);
                $params = ['body' => []];
                // unset the bulk response when you are done to save memory
                echo 'count' . PHP_EOL;

                var_dump(count($newPhoneArr));

                if (count($newPlatformLogArr) > 50000) {
                    //记录关联号码包日志
                    $insertNewPrice = [];
                    foreach ($newPlatformLogArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($newPlatformLogArr);
                    $newPlatformLogArr = [];
                    unset($tmpInsertNewPrice);
                }
                if (count($newPhoneArr) > 50000) {
                    //记录新入库日志
                    //
                    $insertNewPrice = [];
                    foreach ($newPhoneArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    echo '五万数据组装完成' . PHP_EOL;
                    echo '打印一下内存' . PHP_EOL;
                    echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newPhoneArr);
                    $newPhoneArr = [];
                }
                if (count($newUserArr) > 50000) {
                    //存在需要更新使用状态的  记录状态更新日志
                    $insertNewPrice = [];
                    foreach ($newUserArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = '【使用状态】未使用=>已使用【' . $fileInfo['platform_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                        $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                        $tmpInsertNewPrice['lastStatus'] = 0;
                        $tmpInsertNewPrice['nowStatus'] = 1;
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newUserArr);
                    $newUserArr = [];
                }
                if (count($newRegArr) > 5000) {
                    //记录新入库日志
                    //
                    $insertNewPrice = [];
                    foreach ($newRegArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '注册了【' . $fileInfo['platform_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                        $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                        $tmpInsertNewPrice['lastStatus'] = 0;
                        $tmpInsertNewPrice['nowStatus'] = 1;
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);

                    unset($insertNewPrice);
                    unset($newRegArr);
                    $newRegArr = [];
                }

                unset($responses);
                unset($tmpArr);
                unset($insert);
                if ($dealCount && $realTotal) {
                    DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => (number_format($dealCount / $realTotal * 0.95, 2) * 100) . '%']);
                }
            }
            unset($queryAll);
            echo '遍历完phone结束内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        }



        if (count($newPlatformLogArr)) {
            //记录关联号码包日志
            $insertNewPrice = [];
            foreach ($newPlatformLogArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($newPlatformLogArr);
            $newPlatformLogArr = [];
            unset($tmpInsertNewPrice);
        }
        if (count($newPhoneArr)) {
            //记录新入库日志
            //
            $insertNewPrice = [];
            foreach ($newPhoneArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            echo '五万数据组装完成' . PHP_EOL;
            echo '打印一下内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newPhoneArr);
            $newPhoneArr = [];
        }
        if (count($newUserArr)) {
            //存在需要更新使用状态的  记录状态更新日志
            $insertNewPrice = [];
            foreach ($newUserArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = '【使用状态】未使用=>已使用【' . $fileInfo['platform_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                $tmpInsertNewPrice['lastStatus'] = 0;
                $tmpInsertNewPrice['nowStatus'] = 1;
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newUserArr);
            $newUserArr = [];
        }

        if (count($newRegArr)) {
            //记录新入库日志
            //
            $insertNewPrice = [];
            foreach ($newRegArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '注册了【' . $fileInfo['platform_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                $tmpInsertNewPrice['lastStatus'] = 0;
                $tmpInsertNewPrice['nowStatus'] = 1;
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);

            unset($insertNewPrice);
            unset($newRegArr);
            $newRegArr = [];
        }






        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' =>  '100%']);

        //更新总的日志
        $packageUploadLog = [
            'total' => $total,
            'has_sum' => $has_sum,
            'real_total' => $realTotal,
            'cmcc_sum' => $cmcc_sum,
            'cucc_sum' => $cucc_sum,
            'ctcc_sum' => $ctcc_sum,
            'virtual_sum' => $virtual_sum,
            'invalid_sum' => $invalid_sum,
            'file_reply_sum' => $file_reply_num,
            'other_package_reply_sum' => $other_package_reply_sum,
            'is_deal' => 1,
            'updated_at' => time(),
            'insert_sum' => $good_sum,
            'invalid_number_json' => $invalid_number_json,
            'deal_time' => time() - $fileInfo['startTime']
        ];




        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($packageUploadLog);
        $package = DB::table('package')->where('id', $fileInfo['package_id'])->first();
        //更新号码包的统计数据

        $packageUpdate = [
            'total' => $package->total + ($good_sum + $other_package_reply_sum), //号码包总号码等于新号码+存在的别的包但是不存在此包的量
            'real_total' => DB::raw('real_total+' . ($good_sum + $other_package_reply_sum)), //等于total - 沉默 - 空号 -危险号  但是此处没有这些属性 故=total
            'cmcc_sum' => DB::raw('cmcc_sum+' . $insert_cmcc_sum),
            'cucc_sum' => DB::raw('cucc_sum+' . $insert_cucc_sum),
            'ctcc_sum' => DB::raw('ctcc_sum+' . $insert_ctcc_sum),
            'virtual_sum' => DB::raw('virtual_sum+' . $insert_virtual_sum),
            'good_sum' => DB::raw('good_sum+' . ($good_sum + $other_package_reply_normal)),

            'no_register_sum' => DB::raw('no_register_sum-' . $HasPackNotUserCount),
            'register_sum' => DB::raw('register_sum+' . ($other_package_reg + $good_sum + $newUserArrCount)),
            'used_sum' => DB::raw('used_sum+' . $other_package_use),
            'no_used_sum' => DB::raw('no_used_sum+' . ($good_sum + $other_package_not_use)),
            'no_feedback_sum' => DB::raw('no_feedback_sum+' . ($good_sum + $other_package_not_feedback)),
            'feedback_sum' => DB::raw('feedback_sum+' . $other_package_feedback),
            'sleep_sum' => DB::raw('sleep_sum+' . ($other_package_reply_sleep)),
            'risk_sum' => DB::raw('risk_sum+' . ($other_package_reply_risk)),
            'vacant_sum' => DB::raw('vacant_sum+' . ($other_package_reply_vacant)),
        ];







        DB::table('package')->where('id', $fileInfo['package_id'])->update($packageUpdate);
        unset($allPhone);
        echo '最后内存' . PHP_EOL;
        echo Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        self::pushPackageRatioQueue($fileInfo['package_id']);
    }

    public static function uploadFeedbackMobile($fileInfo)
    {
        //注册号码
        //读取excel

        $file = storage_path('upload') . '/' . $fileInfo['new_file_name'];
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file);
        $sheet = $spreadsheet->getSheet(0);
        $highestRow = $sheet->getHighestRow();           // 取得总行数  
        $tmpArr = [];
        $cmcc_sum = 0;
        $cucc_sum = 0;
        $ctcc_sum = 0;
        // $use_time = $fileInfo['use_time'];
        $platform_id = $fileInfo['platform_id'];
        $platform_name = $fileInfo['platform_name'];
        //虚拟号码
        $virtual_sum = 0;

        //总数
        $total = $highestRow - 1;
        //可用
        $good_sum = 0;
        //文件重复
        $file_reply_num = 0;
        //无效
        $invalid_sum = 0;
        //数据库重复
        $has_sum = 0;
        //单价
        $price = 0;
        $insert_cmcc_sum = 0;
        $insert_cucc_sum = 0;
        $insert_ctcc_sum = 0;
        $insert_virtual_sum = 0;
        //虚拟号码

        $other_package_use = 0;
        $other_package_not_use = 0;
        $other_package_reg = 0;
        $other_package_not_reg = 0;
        $other_package_feedback = 0;
        $other_package_not_feedback = 0;
        //存在其他包的数量
        $other_package_reply_sum = 0;
        $other_package_price_sum = 0;




        $other_package_reply_normal = 0;
        $other_package_reply_sleep = 0;
        $other_package_reply_risk = 0;
        $other_package_reply_vacant = 0;

        $dealCount = 0;
        $queryAll = [];
        $data = [];
        $singeData = [];
        $moneyLog = [];
        $invalid_number = [];
        for ($j = 0; $j <= $highestRow - 2; $j++) {
            $phone = trim($spreadsheet->getActiveSheet()->getCell("A" . ($j + 2))->getValue());

            $remark = '';
            $addMoney = $spreadsheet->getActiveSheet()->getCell("B" . ($j + 2))->getValue();
            $reMoney = $spreadsheet->getActiveSheet()->getCell("c" . ($j + 2))->getValue();
            // 
            $companyName = '';
            $province = '';
            $city = '';

            $companyId = 0;
            //是否有效
            $checkRe = Phone::checkOperator($phone);

            $addMoneyRe = Phone::checkMoney($addMoney);
            $reMoneyRe = Phone::checkMoney($reMoney);


            if (!$checkRe || !$addMoneyRe || !$reMoneyRe) {

                $invalid_number[] = $phone;
                //无效
                $invalid_sum++;
                continue;
            }
            $phone = (int) $phone;
            $moneyLog[$phone] = [
                'addMoney' => $addMoney,
                'reMoney' => $reMoney,
            ];

            if (in_array($phone, $singeData)) {
                $file_reply_num++;
                continue;
            }

            // //写入数据库
            $data[$phone] = [

                'mobile' => $phone,
                'remark' => $remark,
                'company' => $companyId,
                'province' => $province,
                'city' => $city,
                'type' => 1,
                'is_register' => 0,

                'is_use' => 0,
                'is_feedback' => 1,
                'use_last_time' => 0,
                'feedback_last_time' => time(),
                'created_at' => time(),
                'updated_at' => time(),
                'package_id' => $fileInfo['package_id']


            ];
            array_push($singeData, $phone);
        }
        $invalid_number_json = '';
        if ($invalid_sum > 0) {
            $invalid_number_json = json_encode($invalid_number);
        }
        echo date('Y-m-d H:i:s') . PHP_EOL;
        //暂时的入库数  还要减去数据库中的
        $tmpRealCount = count($singeData);
        //计算下要循环几次
        $forCount  = ceil($tmpRealCount / 2000);
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];

        $client = ClientBuilder::create()           // Instantiate a new ClientBuilder
            ->setHosts($hosts)      // Set the hosts
            ->build();

        for ($i = 0; $i < $forCount; $i++) {


            echo '第' . $i . '次' . PHP_EOL;
            $tmpStart = $i * 2000;
            $tmpArr = array_slice($singeData, $tmpStart, 2000);
            $dealCount += count($tmpArr);
            //查询下个数
            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [

                        'bool' => [
                            'must' => [
                                [
                                    'terms' => [
                                        'phone' => $tmpArr
                                        // 'phone' => [1]
                                    ]
                                ],
                                [
                                    'terms' => [
                                        'number_package' => $fileInfo['packageAllIds']
                                    ]
                                ]


                            ]
                        ]

                    ],
                    'size' => 2000,
                    'from' => 0,
                ]
            ];

            $results = $client->search($params);

            $replyCount = $results['hits']['total']['value'];

            $tmpRealCount = $tmpRealCount - $replyCount;
            $has_sum += $replyCount;
            $queryArr = $results['hits']['hits'];

            //得到总得查询数据

            $queryAll = array_merge($queryAll, $queryArr);
            if ($dealCount && $tmpRealCount) {
                $tmpDealCount = (number_format($dealCount / $tmpRealCount * 0.3, 2) * 100) . '%';
                DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
            }
        }
        $dealCount = 0;

        $queryAll  = array_column($queryAll, null, '_id');




        // //计算下要循环几次
        $forCount  = ceil(count($singeData) / 2000);
        //存储价格变更的号码
        $newTypeArr = [];
        //存储新平台日志号码
        $newPlatformLogArr = [];
        //存储新入库的日志号码
        $newPhoneArr = [];
        //需要update is_use的
        $newUserArr = [];
        $newUserArrCount = 0;

        $HasPackNotUserCount = 0;

        for ($i = 0; $i < $forCount; $i++) {


            echo '第' . $i . '次' . PHP_EOL;
            $tmpStart = $i * 2000;



            $tmpArr = array_slice($singeData, $tmpStart, 2000);
            $dealCount += count($tmpArr);
            //组装数据库  然后insert 
            $insert = [];
            $params = ['body' => []];
            $update = [];
            $table = 'mobile_' . $fileInfo['package_id'];
            self::createPhoneTable('pnl_' . $table);


            foreach ($tmpArr as $key => $value) {


                //数据库是否存在此号码
                if (!empty($queryAll[$value])) {

                    #以前的号码为未验证  则修改为1
                    if ($queryAll[$value]['_source']['company'] == 1) {
                        $cmcc_sum++;
                    }
                    if ($queryAll[$value]['_source']['company'] == 2) {
                        $cucc_sum++;
                    }
                    if ($queryAll[$value]['_source']['company'] == 3) {
                        $ctcc_sum++;
                    }
                    if ($queryAll[$value]['_source']['company'] == 4) {
                        $virtual_sum++;
                    }

                    if (empty($queryAll[$value]['_source']['is_feedback'])) {
                        array_push($newUserArr, $value);
                        $newUserArrCount++;
                    }
                    //此号码包含多个平台
                    if (is_array($queryAll[$value]['_source']['number_package'])) {
                        foreach ($queryAll[$value]['_source']['number_package'] as $packageId => $packageValue) {
                            if (!in_array($packageValue, $fileInfo['packageAllIds'])) {
                                unset($queryAll[$value]['_source']['number_package'][$packageId]);
                            }
                        }
                        if (in_array($fileInfo['package_id'], $queryAll[$value]['_source']['number_package'])) {
                            if (count($queryAll[$value]['_source']['number_package']) > 1) {
                                //存在其他包  数量+1
                                $other_package_reply_sum++;
                            }
                            //在自己的包里未注册的
                            if (empty($queryAll[$value]['_source']['is_feedback'])) {
                                $HasPackNotUserCount++;
                            }
                        } else {
                            //存在其他包   需要插入到自己的包  但是不属于新号码

                            $data[$value]['price'] = !empty($queryAll[$value]['_source']['price']) ? $queryAll[$value]['_source']['price'] : 0;

                            $insert[] = $data[$value];
                            //新平台  需要记录日志
                            //存在其他包  数量+1
                            $other_package_reply_sum++;
                            $other_package_price_sum += $data[$value]['price'];
                            array_push($newPlatformLogArr, $value);
                            if ($queryAll[$value]['_source']['company'] == 1) {
                                $insert_cmcc_sum++;
                            }
                            if ($queryAll[$value]['_source']['company'] == 2) {
                                $insert_cucc_sum++;
                            }
                            if ($queryAll[$value]['_source']['company'] == 3) {
                                $insert_ctcc_sum++;
                            }
                            if ($queryAll[$value]['_source']['company'] == 4) {
                                $insert_virtual_sum++;
                            }
                            if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                            if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                            if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                            if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;

                            if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                            if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                            if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                            if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                            if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                            if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                        }
                    } else {
                        if ($fileInfo['package_id'] == $queryAll[$value]['_source']['number_package']) {
                            if (empty($queryAll[$value]['_source']['is_feedback'])) {
                                $HasPackNotUserCount++;
                            }
                        } else {
                            //存在其他包
                            //需要插入到自己的包  但是不属于新号码

                            $data[$value]['price'] = !empty($queryAll[$value]['_source']['price']) ? $queryAll[$value]['_source']['price'] : 0;
                            $insert[] = $data[$value];
                            //新平台  需要记录日志
                            //存在其他包  数量+1
                            $other_package_reply_sum++;
                            if ($queryAll[$value]['_source']['company'] == 1) {
                                $insert_cmcc_sum++;
                            }
                            if ($queryAll[$value]['_source']['company'] == 2) {
                                $insert_cucc_sum++;
                            }
                            if ($queryAll[$value]['_source']['company'] == 3) {
                                $insert_ctcc_sum++;
                            }
                            if ($queryAll[$value]['_source']['company'] == 4) {
                                $insert_virtual_sum++;
                            }

                            if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                            if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                            if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                            if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;


                            if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                            if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                            if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                            if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                            if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                            if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                            array_push($newPlatformLogArr, $value);
                        }
                    }
                } else {

                    array_push($newPhoneArr, $value);


                    //实际入库++

                    $good_sum++;
                    $insert[] = $data[$value];
                    //新平台  需要记录日志
                    array_push($newPlatformLogArr, $value);
                }






                $tmpEsAdd = [
                    "id" => $key + 1,
                    'phone' => $value,
                    'company' =>  0,
                    "province" => '',
                    "city" => '',
                    "type" => 1,
                    'is_use' => 0,
                    'use_platform' => [],
                    'use_platform_name' => [],
                    'is_register' => 0,
                    'register_platform' =>  [],
                    'register_platform_name' => [],
                    'is_agent' => '',
                    'is_feedback' => 1,
                    'feedback_platform' =>  [$platform_id],
                    'feedback_platform_name' =>  [$platform_name],
                    #反馈
                    'use_last_time' => 0,
                    'use_time' => [],
                    'feedback_last_time' => time(),
                    'number_package' => [$fileInfo['package_id']],
                    'number_package_name' => [$fileInfo['package_name']],
                    'export_state' => 0,
                    'export_time' => [],
                    'export_count' => 0,
                    'export_at' => [], //存多个
                    'phone_segment' => substr($value, 0, 3),


                ];
                #修改为update
                $updateMethod = 'index';
                if (!empty($queryAll[$value])) {


                    $tmpEsAdd = [
                        // "id" => $key + 1,
                        'phone' => $value,
                        'updated_at' => time(),
                    ];
                    $updateMethod = 'update';

                    $tmpEsAdd['is_feedback'] = 1;
                    $tmpEsAdd['feedback_last_time'] = time();
                    $tmpEsAdd['updated_at'] = time();
                    $tmpRegPlatId = $queryAll[$value]['_source']['feedback_platform'];
                    if (empty($tmpRegPlatId)) {
                        $tmpRegPlatId = [];
                    }
                    array_push($tmpRegPlatId, $platform_id);
                    $tmpRegNamePlatId = $queryAll[$value]['_source']['feedback_platform_name'];
                    if (empty($tmpRegNamePlatId)) {
                        $tmpRegNamePlatId = [];
                    }
                    array_push($tmpRegNamePlatId, $platform_name);
                    $tmpRegPackId = $queryAll[$value]['_source']['number_package'];

                    if (empty($tmpRegPackId)) {
                        $tmpRegPackId = [];
                    }
                    array_push($tmpRegPackId, $fileInfo['package_id']);
                    $tmpRegPackNameId = $queryAll[$value]['_source']['number_package_name'];
                    if (empty($tmpRegPackNameId)) {
                        $tmpRegPackNameId = [];
                    }
                    array_push($tmpRegPackNameId, $fileInfo['package_name']);


                    //去重
                    $tmpRegPlatId = array_unique($tmpRegPlatId);
                    $tmpRegPlatId = array_merge($tmpRegPlatId);
                    $tmpRegNamePlatId = array_unique($tmpRegNamePlatId);
                    $tmpRegNamePlatId = array_merge($tmpRegNamePlatId);
                    $tmpRegPackId = array_unique($tmpRegPackId);
                    $tmpRegPackId = array_merge($tmpRegPackId);
                    $tmpRegPackNameId = array_unique($tmpRegPackNameId);
                    $tmpRegPackNameId = array_merge($tmpRegPackNameId);
                    $tmpEsAdd['feedback_platform'] = $tmpRegPlatId;
                    $tmpEsAdd['feedback_platform_name'] = $tmpRegNamePlatId;
                    $tmpEsAdd['number_package'] = $tmpRegPackId;
                    $tmpEsAdd['number_package_name'] = $tmpRegPackNameId;
                    $a = $tmpEsAdd;
                    $tmpEsAdd = [];
                    var_dump('pack');
                    var_dump($tmpRegPackId);
                    //更新要指定参数doc
                    $tmpEsAdd['doc'] = $a;
                    //存在  则update  register_platform register_platform_name  number_package  number_package_name
                } else {
                    $tmpEsAdd["type"] = 1;
                    $tmpEsAdd['is_use'] = 0;
                    $tmpEsAdd['use_platform'] = [];
                    $tmpEsAdd['use_platform_name'] = [];
                    $tmpEsAdd['is_register'] = 0;
                    $tmpEsAdd['register_platform'] =  [];
                    $tmpEsAdd['register_platform_name'] = [];
                    $tmpEsAdd['is_agent'] = '';
                    $tmpEsAdd['type'] = 1;
                    $tmpEsAdd['price'] = 0;
                    $tmpEsAdd['is_use'] = 0;


                    $tmpEsAdd['updated_at'] = time();
                    $tmpEsAdd['created_at'] = time();
                }
                $params['body'][] = [
                    $updateMethod => [
                        '_index' => 'phone_info',
                        '_id' => $value
                    ]
                ];


                $params['body'][] = $tmpEsAdd;
                // echo 1;
                // exit;
            }
            if (count($insert) > 0) {
                echo DB::table($table)->insert($insert);
                $insert = [];
            }

            $responses = $client->bulk($params);

            // erase the old bulk request
            $params = ['body' => []];
            // unset the bulk response when you are done to save memory
            unset($responses);
            if ($dealCount && $tmpRealCount) {
                $tmpDealCount = (number_format($dealCount / $tmpRealCount * 0.3, 2) * 100) + 30 . '%';
                DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
            }
        }
        //


        $dealCount = 0;
        if (count($newUserArr) > 0) {
            //存在需要更新使用状态的  记录状态更新日志
            // DB::table($table)->whereIn('mobile', $newUserArr)->update(['is_feedback' => 1, 'updated_at' => time()]);
            self::updateAll($table, ['is_feedback' => 1, 'updated_at' => time()], $newUserArr);
            //存在需要更新使用状态的  记录状态更新日志
            $insertNewPrice = [];
            foreach ($newUserArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = '【反馈状态】未反馈=>已反馈【' . $fileInfo['platform_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                $tmpInsertNewPrice['lastStatus'] = 0;
                $tmpInsertNewPrice['nowStatus'] = 1;
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newUserArr);
        }
        $tmpDealCount =   '70%';
        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
        // unset($newUserArr);
        if (count($newPlatformLogArr)) {
            //记录关联号码包日志
            $insertNewPrice = [];
            foreach ($newPlatformLogArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newPlatformLogArr);
        }
        $tmpDealCount =   '80%';
        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
        if (count($newPhoneArr)) {
            //记录新入库日志
            //
            $insertNewPrice = [];
            foreach ($newPhoneArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newPhoneArr);
        }
        $tmpDealCount =   '90%';
        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
        if (count($moneyLog)) {
            //记录全部反馈号  可以多次反馈 并且写入金额日志
            $insertNewPrice = [];
            foreach ($moneyLog as $key => $value) {


                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = '';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $key;
                $tmpInsertNewPrice['type'] = 3;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['platform_id'] = $fileInfo['platform_id'];
                $tmpInsertNewPrice['platform_name'] = $fileInfo['platform_name'];
                $tmpInsertNewPrice['chargeMoney'] = $value['addMoney'];
                $tmpInsertNewPrice['profitMoney'] = $value['reMoney'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($moneyLog);
        }
        $tmpDealCount =   '100%';
        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
        //更新总的日志
        $packageUploadLog = [
            'total' => $total,
            'has_sum' => $has_sum,
            'real_total' => $total - $file_reply_num - $invalid_sum,
            'cmcc_sum' => $cmcc_sum,
            'cucc_sum' => $cucc_sum,
            'ctcc_sum' => $ctcc_sum,
            'virtual_sum' => $virtual_sum,
            'invalid_sum' => $invalid_sum,
            'file_reply_sum' => $file_reply_num,
            'other_package_reply_sum' => $other_package_reply_sum,
            // 'money_sum' => !empty($fileInfo['money_sum']) ? $fileInfo['money_sum'] : 0,
            // 'money_avg' => $price,
            'is_deal' => 1,
            'updated_at' => time(),
            'insert_sum' => $good_sum,
            'invalid_number_json' => $invalid_number_json,
            'deal_time' => time() - $fileInfo['startTime']
        ];




        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($packageUploadLog);
        $package = DB::table('package')->where('id', $fileInfo['package_id'])->first();
        //更新号码包的统计数据
        $packageUpdate = [
            'total' => $package->total + ($good_sum + $other_package_reply_sum), //号码包总号码等于新号码+存在的别的包但是不存在此包的量
            'real_total' => DB::raw('real_total+' . ($good_sum + $other_package_reply_sum)), //等于total - 沉默 - 空号 -危险号  但是此处没有这些属性 故=total
            'cmcc_sum' => DB::raw('cmcc_sum+' . $insert_cmcc_sum),
            'cucc_sum' => DB::raw('cucc_sum+' . $insert_cucc_sum),
            'ctcc_sum' => DB::raw('ctcc_sum+' . $insert_ctcc_sum),
            'virtual_sum' => DB::raw('virtual_sum+' . $insert_virtual_sum),
            'good_sum' => DB::raw('good_sum+' . ($good_sum + $other_package_reply_normal)),
            // 'unverified_sum' => DB::raw('unverified_sum-' .  count($newTypeArr)),
            'no_register_sum' => DB::raw('no_register_sum+' . ($good_sum + $other_package_not_reg)),
            'register_sum' => DB::raw('register_sum+' . ($other_package_reg)),
            'used_sum' => DB::raw('used_sum+' . $other_package_use),
            'no_used_sum' => DB::raw('no_used_sum+' . ($good_sum + $other_package_not_use)),
            'no_feedback_sum' => DB::raw('no_feedback_sum-' . $HasPackNotUserCount),
            'feedback_sum' => DB::raw('feedback_sum+' . ($newUserArrCount + $good_sum + $other_package_feedback)),
            'sleep_sum' => DB::raw('sleep_sum+' . ($other_package_reply_sleep)),
            'risk_sum' => DB::raw('risk_sum+' . ($other_package_reply_risk)),
            'vacant_sum' => DB::raw('vacant_sum+' . ($other_package_reply_vacant)),

        ];

        unset($queryAll);
        unset($data);
        unset($singeData);
        DB::table('package')->where('id', $fileInfo['package_id'])->update($packageUpdate);
        self::pushPackageRatioQueue($fileInfo['package_id']);
    }

    public static function uploadSetTypeMobile($fileInfo)
    {
        //使用号码
        //读取excel

        $txtArr = self::getTxtList($fileInfo);

        // 取得总行数  
        $tmpArr = [];
        $cmcc_sum = 0;
        $cucc_sum = 0;
        $ctcc_sum = 0;


        $dealCount = 0;
        //虚拟号码
        $virtual_sum = 0;
        $insert_cmcc_sum = 0;
        $insert_cucc_sum = 0;
        $insert_ctcc_sum = 0;
        //虚拟号码
        $insert_virtual_sum = 0;


        //总数
        $total = 0;
        //可用
        $good_sum = 0;
        //文件重复
        $file_reply_num = 0;
        //无效
        $invalid_sum = 0;
        //数据库重复
        $has_sum = 0;
        $other_package_use = 0;
        $other_package_not_use = 0;
        $other_package_reg = 0;
        $other_package_not_reg = 0;
        $other_package_feedback = 0;
        $other_package_not_feedback = 0;
        $type = $fileInfo['type'] - 3;
        //除去无效和文件重复的数量
        $realTotal = 0;
        //存在其他包的数量
        $other_package_reply_sum = 0;
        $other_package_reply_normal = 0;
        $other_package_reply_sleep = 0;
        $other_package_reply_risk = 0;
        $other_package_reply_vacant = 0;
        $start = memory_get_usage();
        $typeLog = [];
        $newTypeArr = [];
        echo '初始内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        $allPhone = [];
        $invalid_number = [];
        foreach ($txtArr as $txtDir) {
            $tmpTxtArr = [];
            $file = fopen($txtDir, "r");



            //得出文件的运营商和归属地
            while (!feof($file)) {
                //是否有效
                $tmpPhone = (int) fgets($file);
                if (!$tmpPhone) {
                    continue;
                }
                $total++;
                $checkRe = Phone::checkOperator($tmpPhone);

                if (!$checkRe) {

                    $invalid_number[] = $tmpPhone;
                    $invalid_sum++;
                    continue;
                }

                $tmpTxtArr[] = $tmpPhone;
            }

            $tmpUniqueArr = array_unique($tmpTxtArr);

            $file_reply_num += count($tmpTxtArr) - count($tmpUniqueArr);
            $allPhone[$txtDir] = $tmpUniqueArr;

            fclose($file);
        }

        $invalid_number_json = '';
        if ($invalid_sum > 0) {
            $invalid_number_json = json_encode($invalid_number);
        }
        $realTotal = $total - $invalid_sum - $file_reply_num; //实际提交数
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();


        // Instantiate a new ClientBuilder
        $table = 'mobile_' . $fileInfo['package_id'];
        self::createPhoneTable('pnl_' . $table);
        echo '遍历完文件内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        //存储新平台日志号码
        $newPlatformLogArr = [];
        //存储新入库的日志号码
        $newPhoneArr = [];
        //从未使用过  要更改后入库
        $newUserArr = [];
        $allUpdateData = [];
        //未在本平台注册
        $newRegArr = [];
        $HasPackNotUserCount = 0;
        $newUserArrCount = 0;

        $thisPackSleep = 0;
        $thisPackVacant = 0;
        $thisPackRisk = 0;
        $thisPackNormal = 0;
        $newTypeArrCount = 0;
        foreach ($allPhone as $txtName => $phoneArr) {
            //一个个文件循环即可
            echo '遍历完phone开始内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            $city = '';
            $province = '';
            $companyName = '';
            $companyId = 0;
            $forCount  = ceil(count($phoneArr) / 5000);
            for ($i = 0; $i < $forCount; $i++) {


                echo '第' . $i . '次' . PHP_EOL;
                //存储从ES查询出来的数据
                $queryAll = [];

                $tmpStart = $i * 5000;
                $tmpArr = array_slice($phoneArr, $tmpStart, 5000);

                $dealCount += count($tmpArr);
                //查询下个数
                $params = [
                    'index' => 'phone_info',
                    'body' => [
                        "query" => [

                            'bool' => [
                                'must' => [
                                    [
                                        'terms' => [
                                            'phone' => $tmpArr
                                            // 'phone' => [1]
                                        ]
                                    ],
                                    [
                                        'terms' => [
                                            'number_package' => $fileInfo['packageAllIds']
                                        ]
                                    ]


                                ]
                            ]

                        ],
                        'size' => 5000,
                        'from' => 0,
                    ]
                ];
                $results = $client->search($params);
                $replyCount = $results['hits']['total']['value'];
                $has_sum += $replyCount;
                $queryAll = $results['hits']['hits'];
                $queryAll  = array_column($queryAll, null, '_id');
                //得到总得查询数据
                $insert = [];
                $params = ['body' => []];


                #比对运营商和归属地
                $tmpUpdatePhone = [];

                // if ($companyId == 1) $cmcc_sum += count($tmpArr);
                // if ($companyId == 2) $cucc_sum += count($tmpArr);
                // if ($companyId == 3) $ctcc_sum += count($tmpArr);
                // if ($companyId == 4) $virtual_sum += count($tmpArr);
                foreach ($tmpArr as $key => $value) {
                    //数据库是否存在此号码

                    if (!empty($queryAll[$value]['_source'])) {

                        if ($queryAll[$value]['_source']['company'] == 1) {
                            $cmcc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 2) {
                            $cucc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 3) {
                            $ctcc_sum++;
                        }
                        if ($queryAll[$value]['_source']['company'] == 4) {
                            $virtual_sum++;
                        }
                        //type修改日志
                        if ($queryAll[$value]['_source']['type'] != $type) {
                            $typeLog[$value] = [
                                'last' => !empty($queryAll[$value]['_source']['type']) ? $queryAll[$value]['_source']['type'] : 1,
                                'now' => $type
                            ];
                            $newTypeArrCount++;
                            array_push($newTypeArr, $value);
                        }


                        //此号码包含多个平台
                        if (is_array($queryAll[$value]['_source']['number_package'])) {
                            foreach ($queryAll[$value]['_source']['number_package'] as $packageId => $packageValue) {
                                if (!in_array($packageValue, $fileInfo['packageAllIds'])) {
                                    unset($queryAll[$value]['_source']['number_package'][$packageId]);
                                }
                            }
                            if (in_array($fileInfo['package_id'], $queryAll[$value]['_source']['number_package'])) {
                                if (count($queryAll[$value]['_source']['number_package']) > 1) {
                                    //存在其他包  数量+1
                                    $other_package_reply_sum++;
                                }
                                //在自己的包里
                                if ($queryAll[$value]['_source']['type'] == 1) {
                                    #包内沉默号数量
                                    $thisPackNormal++;
                                }
                                if ($queryAll[$value]['_source']['type'] == 2) {
                                    #包内沉默号数量
                                    $thisPackSleep++;
                                }
                                if ($queryAll[$value]['_source']['type'] == 3) {
                                    #包内危险号
                                    $thisPackRisk++;
                                }
                                if ($queryAll[$value]['_source']['type'] == 4) {
                                    #包内空号
                                    $thisPackVacant++;
                                }
                            } else {
                                //存在其他包   需要插入到自己的包  但是不属于新号码
                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $queryAll[$value]['_source']['company'],
                                    'province' => $queryAll[$value]['_source']['province'],
                                    'city' => $queryAll[$value]['_source']['city'],
                                    'type' => $type,
                                    'is_use' => $queryAll[$value]['_source']['is_use'],
                                    'use_last_time' => $queryAll[$value]['_source']['use_last_time'],
                                    'feedback_last_time' => $queryAll[$value]['_source']['feedback_last_time'],
                                    'is_register' => $queryAll[$value]['_source']['is_register'],
                                    'is_feedback' => $queryAll[$value]['_source']['is_feedback'],
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($queryAll[$value]['_source']['company'] == 1) {
                                    $insert_cmcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 2) {
                                    $insert_cucc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 3) {
                                    $insert_ctcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 4) {
                                    $insert_virtual_sum++;
                                }
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;
                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;
                                array_push($newPlatformLogArr, $value);
                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                            }
                        } else {
                            if ($fileInfo['package_id'] == $queryAll[$value]['_source']['number_package']) {
                                //在自己的包里
                                if ($queryAll[$value]['_source']['type'] == 1) {
                                    #包内沉默号数量
                                    $thisPackNormal++;
                                }
                                if ($queryAll[$value]['_source']['type'] == 2) {
                                    #包内沉默号数量
                                    $thisPackSleep++;
                                }
                                if ($queryAll[$value]['_source']['type'] == 3) {
                                    #包内危险号
                                    $thisPackRisk++;
                                }
                                if ($queryAll[$value]['_source']['type'] == 4) {
                                    #包内空号
                                    $thisPackVacant++;
                                }
                            } else {
                                //存在其他包
                                //需要插入到自己的包  但是不属于新号码

                                $insert[] = [
                                    'mobile' => $value,
                                    'company' => $queryAll[$value]['_source']['company'],
                                    'province' => $queryAll[$value]['_source']['province'],
                                    'city' => $queryAll[$value]['_source']['city'],
                                    'type' => $type,
                                    'is_use' => $queryAll[$value]['_source']['is_use'],
                                    'use_last_time' => $queryAll[$value]['_source']['use_last_time'],
                                    'feedback_last_time' => $queryAll[$value]['_source']['feedback_last_time'],
                                    'is_register' => $queryAll[$value]['_source']['is_register'],
                                    'is_feedback' => $queryAll[$value]['_source']['is_feedback'],
                                    'created_at' => time(),
                                    'updated_at' => time(),
                                    'package_id' => $fileInfo['package_id']


                                ];
                                if ($queryAll[$value]['_source']['company'] == 1) {
                                    $insert_cmcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 2) {
                                    $insert_cucc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 3) {
                                    $insert_ctcc_sum++;
                                }
                                if ($queryAll[$value]['_source']['company'] == 4) {
                                    $insert_virtual_sum++;
                                }
                                //新平台  需要记录日志
                                //存在其他包  数量+1
                                $other_package_reply_sum++;

                                if ($queryAll[$value]['_source']['type'] == 1) $other_package_reply_normal++;
                                if ($queryAll[$value]['_source']['type'] == 2) $other_package_reply_sleep++;
                                if ($queryAll[$value]['_source']['type'] == 3) $other_package_reply_risk++;
                                if ($queryAll[$value]['_source']['type'] == 4) $other_package_reply_vacant++;

                                if ($queryAll[$value]['_source']['is_use'] == 0) $other_package_not_use++;
                                if ($queryAll[$value]['_source']['is_use'] == 1) $other_package_use++;
                                if ($queryAll[$value]['_source']['is_register'] == 0) $other_package_not_reg++;
                                if ($queryAll[$value]['_source']['is_register'] == 1) $other_package_reg++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 0) $other_package_not_feedback++;
                                if ($queryAll[$value]['_source']['is_feedback'] == 1) $other_package_feedback++;
                                array_push($newPlatformLogArr, $value);
                            }
                        }
                    } else {
                        $newPhoneArr[] = $value;
                        //实际插入++
                        $good_sum++;


                        $insert[] = [
                            'mobile' => $value,
                            'company' => $companyId,
                            'province' => $province,
                            'city' => $city,
                            'type' => $type,
                            'is_use' => 0,
                            'use_last_time' => 0,
                            'feedback_last_time' => 0,
                            'is_register' => 0,
                            'is_feedback' => 0,
                            'created_at' => time(),
                            'updated_at' => time(),
                            'package_id' => $fileInfo['package_id']
                        ];
                        //是否有效

                    }
                    $tmpEsAdd = [
                        "id" => $key + 1,
                        'phone' => $value,
                        'company' =>  $companyId,
                        "province" => $province,
                        "city" => $city,
                        'type' => $type,
                        'is_use' => 0,
                        'use_platform' => [],
                        'use_platform_name' => [],
                        'is_register' => 0,
                        'register_platform' =>  [],
                        'register_platform_name' => [],
                        'is_agent' => '',
                        'is_feedback' => 0,
                        'feedback_platform' => [],
                        'feedback_platform_name' => [],
                        #新号码
                        'use_last_time' => 0,
                        'use_time' => [],
                        'feedback_last_time' => 0,
                        'number_package' => [$fileInfo['package_id']],
                        'number_package_name' => [$fileInfo['package_name']],
                        'export_state' => 0,
                        'export_time' => [],
                        'export_count' => 0,
                        'export_at' => [], //存多个
                        'phone_segment' => substr($value, 0, 3),


                    ];
                    #修改为update
                    $updateMethod = 'index';
                    if (!empty($queryAll[$value])) {
                        $updateMethod = 'update';
                        $tmpEsAdd = [
                            // "id" => $key + 1,
                            'phone' => $value,
                            'number_package' => [$fileInfo['package_id']],
                            'number_package_name' => [$fileInfo['package_name']],
                            'updated_at' => time(),
                            'type' => $type
                        ];
                        //存在过数据库



                        $tmpRegPackId = $queryAll[$value]['_source']['number_package'];

                        if (empty($tmpRegPackId)) {
                            $tmpRegPackId = [];
                        }
                        array_push($tmpRegPackId, $fileInfo['package_id']);
                        $tmpRegPackNameId = $queryAll[$value]['_source']['number_package_name'];
                        if (empty($tmpRegPackNameId)) {
                            $tmpRegPackNameId = [];
                        }
                        array_push($tmpRegPackNameId, $fileInfo['package_name']);


                        //去重

                        $tmpRegPackId = array_unique($tmpRegPackId);
                        $tmpRegPackId = array_merge($tmpRegPackId);
                        $tmpRegPackNameId = array_unique($tmpRegPackNameId);
                        $tmpRegPackNameId = array_merge($tmpRegPackNameId);


                        $tmpEsAdd['number_package'] = $tmpRegPackId;
                        $tmpEsAdd['number_package_name'] = $tmpRegPackNameId;

                        $a = $tmpEsAdd;
                        $tmpEsAdd = [];
                        //更新要指定参数doc
                        $tmpEsAdd['doc'] = $a;
                    } else {


                        $tmpEsAdd['created_at'] = time();
                    }

                    $params['body'][] = [
                        $updateMethod => [
                            '_index' => 'phone_info',
                            '_id' => $value
                        ]
                    ];


                    $params['body'][] = $tmpEsAdd;
                    // echo 1;
                    // exit;
                    // $allUpdateData[] = $value;
                }
                if (count($insert) > 0) {
                    echo DB::table($table)->insert($insert);
                    $insert = [];
                }

                $responses = $client->bulk($params);
                // erase the old bulk request
                unset($params);
                $params = ['body' => []];
                // unset the bulk response when you are done to save memory
                echo 'count' . PHP_EOL;



                if (count($newPlatformLogArr) > 50000) {
                    //记录关联号码包日志
                    $insertNewPrice = [];
                    foreach ($newPlatformLogArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($newPlatformLogArr);
                    $newPlatformLogArr = [];
                    unset($tmpInsertNewPrice);
                }
                if (count($newPhoneArr) > 50000) {
                    //记录新入库日志
                    //
                    $insertNewPrice = [];
                    foreach ($newPhoneArr as $value) {
                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    echo '五万数据组装完成' . PHP_EOL;
                    echo '打印一下内存' . PHP_EOL;
                    echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newPhoneArr);
                    $newPhoneArr = [];
                }
                if (count($newTypeArr) > 50000) {
                    //存在需要更新类型的
                    // DB::table($table)->whereIn('mobile', $newTypeArr)->update(['type' => $type, 'updated_at' => time()]);
                    self::updateAll($table, ['type' => $type, 'updated_at' => time()], $newTypeArr);
                    $insertNewPrice = [];
                    $checkType = [

                        '1' => '活跃号',
                        '2' => '沉默号',
                        '3' => '危险号',
                        '4' => '空号',
                    ];
                    foreach ($newTypeArr as $value) {

                        $tmpInsertNewPrice = [];
                        $tmpInsertNewPrice['content'] = '【号码属性】' . $checkType[$typeLog[$value]['last']] . '=>' . $checkType[$typeLog[$value]['now']];
                        $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                        $tmpInsertNewPrice['created_at'] = time();
                        $tmpInsertNewPrice['mobile'] = $value;
                        $tmpInsertNewPrice['type'] = 1;
                        $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                        $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                        $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                        $tmpInsertNewPrice['lastStatus'] = $typeLog[$value]['last'];
                        $tmpInsertNewPrice['nowStatus'] = $typeLog[$value]['now'];
                        array_push($insertNewPrice, $tmpInsertNewPrice);
                    }
                    self::insertLog($insertNewPrice);
                    unset($insertNewPrice);
                    unset($newTypeArr);
                    $newTypeArr = [];
                }


                unset($responses);
                unset($tmpArr);
                unset($insert);
                if ($dealCount && $realTotal) {
                    DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => (number_format($dealCount / $realTotal * 0.95, 2) * 100) . '%']);
                }
            }
            unset($queryAll);
            echo '遍历完phone结束内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        }



        if (count($newPlatformLogArr)) {
            //记录关联号码包日志
            $insertNewPrice = [];
            foreach ($newPlatformLogArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '关联了号码包【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($newPlatformLogArr);
            $newPlatformLogArr = [];
            unset($tmpInsertNewPrice);
        }
        if (count($newPhoneArr)) {
            //记录新入库日志
            //
            $insertNewPrice = [];
            foreach ($newPhoneArr as $value) {
                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = $value . '入库【' . $fileInfo['package_name'] . '】';
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            echo '五万数据组装完成' . PHP_EOL;
            echo '打印一下内存' . PHP_EOL;
            echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newPhoneArr);
            $newPhoneArr = [];
        }

        if (count($newTypeArr)) {
            //存在需要更新类型的
            // DB::table($table)->whereIn('mobile', $newTypeArr)->update(['type' => $type, 'updated_at' => time()]);
            self::updateAll($table, ['type' => $type, 'updated_at' => time()], $newTypeArr);
            $insertNewPrice = [];
            $checkType = [

                '1' => '活跃号',
                '2' => '沉默号',
                '3' => '危险号',
                '4' => '空号',
            ];
            foreach ($newTypeArr as $value) {

                $tmpInsertNewPrice = [];
                $tmpInsertNewPrice['content'] = '【号码属性】' . $checkType[$typeLog[$value]['last']] . '=>' . $checkType[$typeLog[$value]['now']];
                $tmpInsertNewPrice['admin_id'] = $fileInfo['uid'];
                $tmpInsertNewPrice['created_at'] = time();
                $tmpInsertNewPrice['mobile'] = $value;
                $tmpInsertNewPrice['type'] = 1;
                $tmpInsertNewPrice['admin_name'] = $fileInfo['admin_name'];
                $tmpInsertNewPrice['package_id'] = $fileInfo['package_id'];
                $tmpInsertNewPrice['package_name'] = $fileInfo['package_name'];
                $tmpInsertNewPrice['lastStatus'] = $typeLog[$value]['last'];
                $tmpInsertNewPrice['nowStatus'] = $typeLog[$value]['now'];
                array_push($insertNewPrice, $tmpInsertNewPrice);
            }
            self::insertLog($insertNewPrice);
            unset($insertNewPrice);
            unset($newTypeArr);
            $newTypeArr = [];
        }



        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' =>  '100%']);



        //更新总的日志
        $packageUploadLog = [
            'total' => $total,
            'has_sum' => $has_sum,
            'real_total' => $realTotal,
            'cmcc_sum' => $cmcc_sum,
            'cucc_sum' => $cucc_sum,
            'ctcc_sum' => $ctcc_sum,
            'virtual_sum' => $virtual_sum,
            'invalid_sum' => $invalid_sum,
            'file_reply_sum' => $file_reply_num,
            'other_package_reply_sum' => $other_package_reply_sum,
            'is_deal' => 1,
            'updated_at' => time(),
            'insert_sum' => $good_sum,
            'invalid_number_json' => $invalid_number_json,
            'deal_time' => time() - $fileInfo['startTime']
        ];




        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($packageUploadLog);
        $package = DB::table('package')->where('id', $fileInfo['package_id'])->first();
        //更新号码包的统计数据

        $packageUpdate = [
            'total' => $package->total + ($good_sum + $other_package_reply_sum), //号码包总号码等于新号码+存在的别的包但是不存在此包的量
            'real_total' => DB::raw('real_total+' . ($good_sum + $other_package_reply_sum)), //等于total - 沉默 - 空号 -危险号  但是此处没有这些属性 故=total
            'cmcc_sum' => DB::raw('cmcc_sum+' . $insert_cmcc_sum),
            'cucc_sum' => DB::raw('cucc_sum+' . $insert_cucc_sum),
            'ctcc_sum' => DB::raw('ctcc_sum+' . $insert_ctcc_sum),
            'virtual_sum' => DB::raw('virtual_sum+' . $insert_virtual_sum),
            'good_sum' => DB::raw('good_sum-' . $thisPackNormal),
            'register_sum' => DB::raw('register_sum+' . $other_package_reg),
            'no_register_sum' => DB::raw('no_register_sum+' . ($good_sum + $other_package_not_reg)),
            'used_sum' => DB::raw('used_sum+' . $other_package_use),
            'no_used_sum' => DB::raw('no_used_sum+' . ($good_sum + $other_package_not_use)),
            'no_feedback_sum' => DB::raw('no_feedback_sum+' . ($good_sum + $other_package_not_feedback)),
            'feedback_sum' => DB::raw('feedback_sum+' . $other_package_feedback),

        ];
        if ($type == 2) {
            $packageUpdate['sleep_sum'] = DB::raw('sleep_sum+' . ($newTypeArrCount + $good_sum));
            $packageUpdate['risk_sum'] = DB::raw('risk_sum-' . $thisPackRisk);
            $packageUpdate['vacant_sum'] = DB::raw('vacant_sum-' . $thisPackVacant);
        }
        if ($type == 3) {
            $packageUpdate['risk_sum'] = DB::raw('risk_sum+' . ($newTypeArrCount + $good_sum));
            $packageUpdate['sleep_sum'] = DB::raw('sleep_sum-' . $thisPackSleep);
            $packageUpdate['vacant_sum'] = DB::raw('vacant_sum-' . $thisPackVacant);
        }
        if ($type == 4) {
            $packageUpdate['vacant_sum'] = DB::raw('vacant_sum+' . ($newTypeArrCount + $good_sum));
            $packageUpdate['sleep_sum'] = DB::raw('sleep_sum-' . $thisPackSleep);
            $packageUpdate['risk_sum'] = DB::raw('risk_sum-' . $thisPackRisk);
        }
        var_dump($type);
        var_dump($packageUpdate['sleep_sum']);




        DB::table('package')->where('id', $fileInfo['package_id'])->update($packageUpdate);
        unset($allPhone);
        echo '最后内存' . PHP_EOL;
        echo Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        self::pushPackageRatioQueue($fileInfo['package_id']);
    }

    public static function uploadNameMobile($fileInfo)
    {
        echo 'uploadNameMobile'.PHP_EOL;
        $initUpdateParams = [
            "index" => "phone_info",
            "type" => "_doc",
            "body" => [],
        ];
        $updateParams = $initUpdateParams;
        $txtArr = self::getTxtList($fileInfo);
        $total = 0;
        $real_total = 0;
        echo '初始内存' . PHP_EOL;
        echo  Tools::format_bytes(memory_get_usage()) . PHP_EOL;
        $hosts = [
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
        ];
        
        $client = ClientBuilder::create()->setHosts($hosts)->build();

        foreach ($txtArr as $txtDir) {
            $tmpTxtArr = [];
            // echo 'txtDir:'.$txtDir.PHP_EOL;
            $file = fopen($txtDir, "r");

            // 得出文件的运营商和归属地
            while (!feof($file)) {
                $total++;
                // 是否有效
                $tmpPhone = fgets($file);
                if (empty($tmpPhone)) {
                    // echo 'tmpPhone1:'.$tmpPhone.PHP_EOL;
                    continue;
                }

                $temps = explode(',', $tmpPhone);
                $phone = intval($temps[0] ?? '');
                $name = trim($temps[1] ?? '');

                if (empty($name) || $phone == 0) {
                    // echo 'tmpPhone2:'.$tmpPhone.PHP_EOL;
                    continue;
                }

                $real_total++;
                $updateParams['body'][] = [
                    'update' => [
                        '_index' => 'phone_info',
                        '_type' => '_doc',
                        '_id' => $phone,
                    ],
                ];

                $struct['name'] = $name;
                $updateParams['body'][] = [
                    'doc' => $struct,
                ];

                if (count($updateParams['body']) % 500 == 0) {
                    $res = $client->bulk($updateParams);
                    $updateParams = $initUpdateParams;
                    unset($res);
                }
            }

            fclose($file);
        }

        if (!empty($updateParams['body'])) {
            // print_r($updateParams);
            $res = $client->bulk($updateParams);
            $updateParams = $initUpdateParams;
            unset($res);
        }

        echo '最后内存' . PHP_EOL;
        echo Tools::format_bytes(memory_get_usage()) . PHP_EOL;

        $tmpDealCount =   '100%';
        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update(['deal_schedule' => $tmpDealCount]);
        //更新总的日志
        $packageUploadLog = [
            'total' => $total,
            'has_sum' => 0,
            'real_total' => $real_total,
            'cmcc_sum' => 0,
            'cucc_sum' =>0,
            'ctcc_sum' => 0,
            'virtual_sum' => 0,
            'invalid_sum' => 0,
            'file_reply_sum' => 0,
            'other_package_reply_sum' => 0,
            'is_deal' => 1,
            'updated_at' => time(),
            'insert_sum' => 0,
            'invalid_number_json' => '',
            'deal_time' => time() - $fileInfo['startTime']
        ];

        DB::table('package_upload_log')->where('id', $fileInfo['upload_id'])->update($packageUploadLog);
        // self::pushPackageRatioQueue($fileInfo['package_id']);
    }

    public  static function createPhoneTable($table)
    {

        $tableCheck = DB::select('SHOW TABLES LIKE "' . $table . '"');
        if (count($tableCheck) == 0) {
            $sql = "CREATE TABLE " . $table . "  (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `package_id` int(11) NULL DEFAULT NULL,
                `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '手机号码',
                `company` tinyint(2) NULL DEFAULT NULL COMMENT '运营商',
                `province` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '归属省',
                `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '归属地市',
                `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '号码类型,0未验证,1正常号,2沉默号,3危险号,4空号',
                `is_register` int(2) NOT NULL COMMENT ' 0为未注册 1为注册',
                `is_use` int(2) NULL DEFAULT NULL COMMENT ' 0为未使用 1为已使用',
                `is_feedback` int(2) NULL DEFAULT NULL COMMENT ' 0为未反馈 1为已反馈',
                `is_agent` tinyint(2) NULL DEFAULT NULL COMMENT '1为普通用户 2为活跃代理 3为非活跃代理',
                `use_last_time` int(10) NULL DEFAULT NULL COMMENT '上一次使用时间',
                `feedback_last_time` int(10) NULL DEFAULT NULL COMMENT '上次反馈时间',
                `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '入库价格',
                `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                `created_at` int(10) NULL DEFAULT NULL COMMENT '添加时间',
                `updated_at` int(10) NULL DEFAULT NULL COMMENT '更新时间',
                PRIMARY KEY (`id`) USING BTREE,
                INDEX `package_id`(`package_id`) USING BTREE,
                INDEX `mobile`(`mobile`) USING BTREE
                ) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;";
            DB::select($sql);
        }
        //

    }

    public static function getIdByName($name)
    {
        if ($name == '移动') {
            return 1;
        }
        if ($name == '联通') {
            return 2;
        }
        if ($name == '电信') {
            return 3;
        }
        if ($name == '虚拟') {
            return 4;
        }
        return 0;
    }

    public static function insertLog($data)
    {

        $tmpTable = [];



        foreach ($data as $tmpValue) {

            $tmpId  = Hash::getPhoneServerById($tmpValue['mobile']);
            $table = 'package_phone_log_' . $tmpId;
            if (!in_array($table, self::$logTable)) {
                self::createPhoneLogTable('pnl_' . $table);
                self::$logTable[] =  $table;
            }
            if (!empty($tmpTable[$table])) {
                $tmpTable[$table][] = $tmpValue;
            } else {
                $tmpTable[$table] = [$tmpValue];
            }
        }

        echo '插入前组装完成' . PHP_EOL;
        foreach ($tmpTable as $tableName => $insertValue) {

            echo  DB::table($tableName)->insert($insertValue);
        }
        echo '插入组装完成' . PHP_EOL;
        unset($tmpTable);
        unset($data);
    }

    public static function updateAll($table, $data, $whereIn)
    {
        $count = count($whereIn);
        $count = ceil($count / 10000);
        var_dump($count);
        for ($i = 0; $i < (int) $count; $i++) {
            echo '循环:' . $i . PHP_EOL;
            $tmpArr = [];
            $tmpArr = array_slice($whereIn, $i * 10000, 10000);
            var_dump(count($tmpArr));
            echo DB::table($table)->whereIn('mobile', $tmpArr)->update($data);
            unset($tmpArr);
        }
    }

    public  static function createPhoneLogTable($table)
    {

        $tableCheck = DB::select('SHOW TABLES LIKE "' . $table . '"');
        if (count($tableCheck) == 0) {
            $sql = "CREATE TABLE " . $table . "  (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                `admin_id` int(11) NULL DEFAULT NULL,
                `type` int(2) NULL DEFAULT NULL COMMENT '1为修改日志 2为使用日志3为反馈日志',
                `lastStatus` int(2) NULL DEFAULT NULL,
                `nowStatus` int(2) NULL DEFAULT NULL,
                `chargeMoney` decimal(10, 2) NULL DEFAULT NULL,
                `profitMoney` decimal(10, 2) NULL DEFAULT NULL,
                `created_at` int(11) NULL DEFAULT NULL,
                `export_at` int(11) NULL DEFAULT NULL,
                `package_id` int(11) NULL DEFAULT NULL,
                `platform_id` int(11) NULL DEFAULT NULL,
                `admin_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                `file_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                `package_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                `platform_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                `use_time` int(11) NULL DEFAULT NULL,
                `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                PRIMARY KEY (`id`) USING BTREE,
                INDEX `idx_phone`(`mobile`) USING BTREE,
                INDEX `idx_type`(`type`) USING BTREE
              ) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;";
            DB::select($sql);
        }
        //

    }

    public static function getTxtList($fileInfo)
    {
        $txtArr = [];
        if ($fileInfo['file_type'] == 1) {
            //上传文本
            $txtArr[] = storage_path('upload') . '/' . $fileInfo['new_file_name'];
        } else {
            //上传zip
            $txtArr = Tools::getTxtByDir($fileInfo['unzip_dir']);
        }
        return $txtArr;
    }

    public static function pushPackageRatioQueue($packageId){
        $queue = 'packageRatio';
        $lpRes = Redis::lpush($queue, $packageId);
    }

    public static function pushPackageMultiQueue($data){
        $queue = 'packageMulti';
        Redis::lpush($queue, json_encode($data));
    }

    public static function popPackageRatioQueue(){

        $runKey = 'runPackageRatio';
        if(Redis::get($runKey)){
            echo '正在运行中';
            return;
        }
        Redis::setex($runKey,1,3600);
        $queue = 'packageRatio';
        $len = Redis::llen($queue);
//        echo Redis::pop($queue,0,$len);
        if($len){
            $list = Redis::lrange($queue,0,$len);
//            LTRIM key start stop
            Redis::ltrim($queue,$len+1,0);

            $list = array_unique($list);
            foreach ($list as $packageId){
                 self::countPackageRatio($packageId);
            }
            Redis::del($runKey);
        }
        Redis::del($runKey);
    }

    public static function countPackageRatio($packageId){
        $queue = 'packageRatio';
        $logger = new Logger('countPackageRatio');
        $logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/packageRatio.log', Logger::WARNING));
        $comPackages = $packages = DB::table('package')->where('is_delete',0)->pluck('package_name','id')->toArray();
        if(!isset($packages[$packageId])){
            echo "号码包{$packageId}不存在";
            $logger->warn("号码包{$packageId}不存在",[]);
            return false;
        }
        if(count($packages) < 2){
            echo "号码包少于2个";
            $logger->warn('号码包少于2个',[]);
            return false;
        }
        $package = [
            'id'=>$packageId,
            'package_name'=>$comPackages[$packageId],
        ];
        unset($comPackages[$packageId]);
        $hosts = [
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
        ];

        try{
            $client = ClientBuilder::create()->setHosts($hosts)->setLogger($logger)->build();
            $params = [
                'index' => 'phone_info',
                'body' => [
                    'settings' => [
                        "index.indexing.slowlog.threshold.index.warn"=> "10s",
                        "index.indexing.slowlog.threshold.index.info"=> "5s",
                        "index.indexing.slowlog.threshold.index.debug"=> "2s",
                        "index.indexing.slowlog.threshold.index.trace"=> "500ms",
                        "index.indexing.slowlog.level"=> "info",
                        "index.indexing.slowlog.source"=> "1000"
                    ],
                ]
            ];

            $client->indices()->putSettings($params);

            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
                        "bool" => [
                            'must' => [
                                [
                                    'term' => [
                                        'number_package' => $packageId
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
            ];
            $countResult = $client->count($params);
            if(!$countResult['count']){
                echo "号码包{$packageId}数量为0";
                $logger->error("号码包{$packageId}数量为0",[]);
                return false;
            }
            $package['counts'] = $countResult['count'];
            $package['dugCounts'] = [];
            foreach ($comPackages as $cpk=>$comPack){
                $package['dugCounts'][$cpk] = 0;
            }
            $pageSize = 100;
            $pages = ceil($package['counts']/$pageSize);
            for($page=1;$page<=$pages;$page++) {
                echo $page;echo '---';
                $params = [
                    'index' => 'phone_info',
                    'body' => [
                        "query" => [
                            "bool" => [
                                'must' => [
                                    [
                                        'term' => [
                                            'number_package' => $packageId
                                        ]
                                    ]
                                ]
                            ]
                        ],
                        'size' => $pageSize,
                        'from' => ($page - 1) * $pageSize,
                    ],
                ];

                $results = $client->search($params);
                $must = [];
                $should = [];
                foreach ($results['hits']['hits'] as $value) {
                    $term = [
                        'term' => [
                            'phone' => $value['_source']['phone']
                        ]
                    ];
                    array_push($should, $term);
                }
                foreach ($comPackages as $key=>$comPackage){

                    $params = [
                        'index' => 'phone_info',
                        'body' => [
                            "query" => [
                                "bool" => [
                                    'must'=>[
                                        ['term'=>['number_package'=>$key]],
                                        ['bool'=>['should'=>$should]]
                                    ],
                                ],
                            ]
                        ],
                    ];
                    $res = $client->count($params);
                    $package['dugCounts'][$key] += $res['count'];
                }
            }

            foreach ($package['dugCounts'] as $k=>$v){
                try{
                    $insert = [];
                    $insert['package_id'] = $packageId;
                    $insert['com_package_id'] = $k;
                    $insert['dug_counts'] = $v;
                    $insert['dug_ratio'] = round( $v/$package['counts'] , 4) * 10000 ;
                    $insert['created_at'] = time() ;
                    $insert['updated_at'] = time() ;
                    DB::table('package_ratio')->insert($insert);
                }catch (\Exception $e){
                    if($e instanceof \Illuminate\Database\QueryException){
                        DB::table('package_ratio')->where('package_id',$packageId)->where('com_package_id',$k)->update($insert);
                    }else{
                        echo $e->getMessage();
                    }
                }

            }
        }catch (\Exception $e){
            echo $e->getMessage();
            $logger->error("号码包{$packageId} 统计出错 ：".$e->getMessage(),[]);
            Redis::lpush($queue, $packageId);
        }
    }

    public static function popPackageMultiQueue(){
        $runKey = 'runPackageMulti';
        if(Redis::get($runKey)){
            echo '正在运行中';
            return;
        }
        Redis::setex($runKey,1,3600);
        $queue = 'packageMulti';
        $len = Redis::llen($queue);
//        echo Redis::pop($queue,0,$len);
        if($len){
            $lists = Redis::lrange($queue,0,$len);
//            LTRIM key start stop
            Redis::ltrim($queue,$len+1,0);

            foreach ($lists as $list){
                (new self)->runPackageMulti($list);
            }
            Redis::del($runKey);
        }
        Redis::del($runKey);
    }

    public function runPackageMulti($list){

        try{
            $queue = 'packageMulti';
            $logger = new Logger('runPackageMulti');
            $logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/runPackageMulti.log', Logger::WARNING));

            $list = json_decode($list,true);
            if(!$list) return ;
            if(!$list['function'] || !$list['params']) return;
            $function  = $list['function'];
            return $this->$function($list['params']);

        }catch (\Exception $e){

            echo $e->getMessage();
            $logger->error("runPackageMulti出错 ：".$e->getMessage(),$list);
            Redis::lpush($queue, json_encode($list));
        }

    }

    public static function handleFileInfo($fileInfo){
        $label = DB::table('package_label')
            ->where('package_id', $fileInfo['package_id'])
            ->value('label_id');
        if(!$label)
        $txtArr = self::getTxtList($fileInfo);
        print_r($txtArr);exit;
    }

    //更新号码包标签
    public function updateLabels($data){
        print_r($data);
        if(!$data['packageId'] || !$data['labels'] || !$data['action']) return ;
        foreach ($data['labels'] as $label){
            $params = [
                'index' => 'phone_info',
                'conflicts' => 'proceed',
                'refresh' => true,//不为true会添加标签失败，估计是和es的异步执行或缓存有关
                'body' => [
                    'query' => [
                        'term' => [
                            'number_package' => $data['packageId'],
                        ],
                    ],
                    'script' => [
                        "source"=> "if ( ctx._source.containsKey(\"labels\") && ctx._source.labels.contains($label) ){ ctx._source.labels.remove(ctx._source.labels.indexOf($label)) }",
                    ],
                ],
            ];
            if($data['action'] == 'add'){
                $params['body']['script'] = [
                    "source"=>"if ( !ctx._source.containsKey('labels')) { ctx._source.labels = params.labels; }else if (!ctx._source.labels.contains($label)) { ctx._source.labels.add($label); }",
                    "params" =>['labels'=>[$label],'label'=>$label],
                ];
            }
//            print_r($params['body']['script']['source']);exit;
            app('es')->updateByQuery($params);
            app('es')->indices()->refresh();
        }

    }

}
