<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-04-20 15:25:28
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Model\AreaCode.php
 */

namespace App\Model;

use  App\Model\Common\CommonModel;
use Illuminate\Support\Facades\DB;

class Admin extends CommonModel
{
    /**
     * 与模型关联的数据表。
     *
     * @var string
     */
    protected $table = 'admin';

    protected $fillable = [
        'account',
        'password',
        'created_at',
        'updated_at',
    ];

    public function getByAccount($account)
    {
        if (!is_string($account) || $account == '') {
            return null;
        }

        return self::where('account', $account)->first();
    }
}
