<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-05-12 18:57:29
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Model\AreaCode.php
 */

namespace App\Model;

use  App\Model\Common\CommonModel;
use Illuminate\Support\Facades\DB;

class EmailPackageLog extends CommonModel
{
    /**
     * 与模型关联的数据表。
     *
     * @var string
     */
    protected $table = 'email_package_log';

    // protected $fillable = [];

    public function addPackageLog($admin_id,$content,$packageId)
    {
        if (empty($admin_id)) {
            return false;
        }
        if (empty($content)) {
            return false;
        }
        if (empty($packageId)) {
            return false;
        }
        $add['admin_id'] = $admin_id;
        $add['package_id'] = $packageId;
        $add['content'] = $content;
        $add['created_at'] = time();
        return self::insertGetId($add);
    }
}
