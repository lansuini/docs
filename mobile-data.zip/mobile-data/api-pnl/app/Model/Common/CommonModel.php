<?php

namespace App\Model\Common;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use PDO;

class CommonModel extends Model
{
    /**
     * 模型日期列的存储格式
     *
     * @var string
     */
    protected $dateFormat = 'U';

    /**
     * created_at原样返回，避免转换为carbon
     *
     */
    public function getCreatedAtAttribute($value)
    {
        return intval($value);
    }

    /**
     * updated_at原样返回，避免转换为carbon
     *
     */
    public function getUpdatedAtAttribute($value)
    {
        return intval($value);
    }

    // 根据参数获取列表
    public static function getListsByParam($table, $where, $select = '*', $sort = [], $page = 1, $pageSize = 0)
    {

        // $pageSize>0则分页
        $query = DB::table($table)->where($where)->select($select);
        if ($pageSize > 0) {
            $query = $query->offset(($page - 1) * $pageSize)->limit($pageSize);
        }
        if ($sort) {
            foreach ($sort as $key => $value) {

                if ($value == 1) {
                    //为1  由大到小
                    $query = $query->orderByDesc($key);
                } else {
                    $query = $query->orderByAsc($key);
                }
            }
        }
        // 返回数组
        // return $query->get()->map(function ($value) {
        //     return (array) $value;
        // })->toArray();
        //返回对象
        return $query->get();
    }

    public static function getFirstByParam($table, $where, $select = '*')
    {
        // $pageSize>0则分页
        return DB::table($table)->where($where)->select($select)->first();
    }

    public static function updateByParm($table, $where, $data)
    {
        // 
        return DB::table($table)->where($where)->update($data);
    }

    public static function insertByTable($table, $data, $bl = false)
    {

        if ($bl) {
            return DB::table($table)->insertGetId($data);
        } else {
            return DB::table($table)->insert($data);
        }
    }

    public static function insertUnique($table, $insert, $update)
    {
        $insertKey = array_keys($insert);
        $insertKey = implode('`,`', $insertKey);
        $insertKey = '`' . $insertKey . '`';
        $insertValue = array_values($insert);
        $insertValue = implode('","', $insertValue);
        $insertValue = '"' . $insertValue . '"';
        $updateArrStr = '';
        foreach ($update as  $key => $value) {
            $updateArrStr .= ' ' . $key . '="' . $value . '",';
        }

        $updateArrStr = trim($updateArrStr, ',');
        $sql = 'INSERT INTO ' . $table . ' (' . $insertKey . ') VALUES (' . $insertValue . ') ON DUPLICATE KEY update' . $updateArrStr;
        return DB::select($sql);
    }
}
