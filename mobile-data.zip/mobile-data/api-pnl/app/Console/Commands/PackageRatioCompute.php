<?php

namespace App\Console\Commands;

use Elasticsearch\ClientBuilder;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class PackageRatioCompute extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'packageRatioCompute';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '数据包各种占比统计';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $logger = new Logger('putMapping');
        $logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/test.log', Logger::WARNING));
        $hosts = [
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->setLogger($logger)->build();
//        $params = [
//            'index' => 'phone_info',
//            'body' => [
//                'settings' => [
//                    "index.indexing.slowlog.threshold.index.warn"=> "10s",
//                    "index.indexing.slowlog.threshold.index.info"=> "5s",
//                    "index.indexing.slowlog.threshold.index.debug"=> "2s",
//                    "index.indexing.slowlog.threshold.index.trace"=> "500ms",
//                    "index.indexing.slowlog.level"=> "info",
//                    "index.indexing.slowlog.source"=> "1000",
//                    "script.inline" => "on",
//                    "script.indexed" => "on"
//                ],
//            ]
//        ];
//        $client->indices()->putSettings($params);
//        $params = [
//            'index' => 'phone_info',
//            "body" => [
//                "properties" => [
//                    'labels' => ['type' => 'keyword'],
//                ]
//            ]
//        ];
//        $response = $client->indices()->putMapping($params);
//        print_r($response);


        $packages = DB::table('package as p')->leftJoin('package_label as pl','p.id','=','pl.package_id')->where('is_delete',0)->get(['p.id','pl.label_id'])->toArray();
        foreach ($packages as $package){

//            if(!$package->label_id || $package->label_id != 4) continue;
            if(!$package->label_id ) continue;
            echo $package->id . '-' . $package->label_id;echo PHP_EOL;
            var_dump($package->label_id);
            $params = [
                'index' => 'phone_info',
                'conflicts' => 'proceed',
                'refresh' => true,//不为true会添加标签失败，估计是和es的异步执行或缓存有关
                'body' => [
                    'query' => [
                        'term' => [
                            'number_package' => $package->id,
                        ],
                    ],
                    'script' => [
//                        "source" => "ctx._source.remove(\"labels\")",
//                        "source"=> "ctx._source.labels = []",
                        "source"=> "if (!ctx._source.containsKey(\"labels\")) { ctx._source.labels = params.labels; }else if (!ctx._source.labels.contains({$package->label_id})) { ctx._source.labels.add({$package->label_id}); }",
//                        "source"=> "if (!ctx._source.containsKey(\"labels\")) { ctx._source.labels = params.labels; }if (!ctx._source.labels.contains(params.label)) { ctx._source.labels.add(params.label); }",
//                            ""=>"string d = instanceof List",
//                        "source"=> "if ( ctx._source.labels.contains(params.label.0)){ ctx._source.labels.add(6)}",
//                        "lang"=> "painless",
//                        "scripted_upsert" => true,
//                        "upsert" => "docItem",
                        "params" =>['labels'=>[$package->label_id],'label'=>$package->label_id],
                    ],
                ],
            ];
//            var_dump($params['body']['script']['source']);
            $response = $client->updateByQuery($params);
//            exit;
            $client->indices()->refresh();
            print_r($response);
        }

        echo "finish!!!!---" . PHP_EOL; echo time();
    }
}
