<?php

namespace App\Console\Commands;

use App\Lib\Hash;
use Elasticsearch\ClientBuilder;
use Illuminate\Console\Command;

class TestCode extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'TestCode {a1}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'TestCode';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $a1 = $this->argument('a1');
        $tmpId = Hash::getPhoneServerById($a1);
        // echo $tmpId . PHP_EOL;

        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
            ->setHosts($hosts) // Set the hosts
            ->build();

        $updateParams = [
            "index" => "phone_info",
            "type" => "doc",
            "body" => []
        ];

        $updateParams['body'][] = [
            'update' => [
                '_index' => 'phone_info',
                '_type' => '_doc',
                '_id' => '13200000033',
            ],
        ];

        $updateParams['body'][] = [
            'doc' => [
                'type' => 3,
            ]
        ];
        $client->bulk($updateParams);
        echo PHP_EOL;
        // $params = [
        //     "index" => "phone_info",
        //     "type" => "_doc",
        //     "body" => [
        //         "query" => [
        //             "bool" => [
        //                 "must" => ["term" => [
        //                     "phone" => 13200000034,
        //                 ]],
        //             ],
        //         ],
        //         "from" => 0,
        //         "size" => 10,
        //     ],

        // ];
        // $response = $client->search($params);
        // print_r($response);

        // $this->phone_log();
        echo PHP_EOL;
    }

    protected function phone_log()
    {
        $sql = 'truncate table pnl_package_phone_log_';
        for ($i = 1; $i <= 100; $i++) {
            echo $sql . $i . ';' . PHP_EOL;
        }
        echo PHP_EOL;
    }
}
