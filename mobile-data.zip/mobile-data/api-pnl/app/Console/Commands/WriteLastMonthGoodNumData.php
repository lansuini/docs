<?php

namespace App\Console\Commands;

use Elasticsearch\ClientBuilder;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class WriteLastMonthGoodNumData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'WriteLastMonthGoodNumData';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'WriteLastMonthGoodNumData';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // $package = DB::select("select * from pnl_package where is_delete=0");

        $package = DB::table('package')->get();
        $m = date('m');
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        //从ES查询实时数据


        foreach ($package as $v) {
            $v = (array) $v;
            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
    
                        'bool' => [
                            'must' => [
                                [
                                    'term' => [
                                        'number_package' => $v['id'],
                                    ],
                                ],
    
                            ],
                        ],
    
                    ],
                ],
            ];

            if (!empty($v['last_month_write_time']) && date('m', strtotime($v['last_month_write_time'])) == $m) {
                echo "已计算: " . $v['package_name'] . PHP_EOL;
                continue;
            }

            # 活跃号
            $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 1]];
            $good_sum = $client->count($params);
            $good_sum = !empty($good_sum['count']) ? $good_sum['count'] : 0;

            $data = [
                'last_month_good_sum' => $good_sum,
                'good_sum' => $good_sum,
                'last_month_write_time' => date('Y-m-d H:i:s'),
            ];

            DB::table('package')->where('id', $v['id'])->update($data);
            echo "计算: " . $v['package_name'] . ' good_sum:'. $good_sum . PHP_EOL;
        }
        echo "finish!" . PHP_EOL;
    }
}
