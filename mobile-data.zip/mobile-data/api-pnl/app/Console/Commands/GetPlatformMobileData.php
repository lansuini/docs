<?php

namespace App\Console\Commands;

use App\Model\Mobile;
use Elasticsearch\ClientBuilder;
use GuzzleHttp;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Illuminate\Support\Facades\Redis;

class GetPlatformMobileData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'GetPlatformMobileData {platformId} {packageId}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'GetPlatformMobileData';

    protected $platforms = [];

    protected $packages = [];

    protected $isWriteData = true;

    protected $isBreak = true;

    protected $size = 1000;

    protected $redis;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->redis = Redis::connection('data');
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $argPlatformId = $this->argument('platformId');
        $argPackageId = $this->argument('packageId');

        // echo 'hello' . PHP_EOL;
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];
        $logger = new Logger('GetPlatformMobileData');
        $logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/es.log', Logger::WARNING));
        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
            ->setHosts($hosts) // Set the hosts
            ->setLogger($logger) // Set the logger
            ->build();
//        $params = [
//            'body' => [
//                'persistent' => [
//                    'action.auto_create_index' => 'true',
//                ],
//            ],
//        ];
        $params = [
            'index' => 'phone_info',
            'body' => [
                'settings' => [
                    "index.indexing.slowlog.threshold.index.warn"=> "10s",
                      "index.indexing.slowlog.threshold.index.info"=> "5s",
                      "index.indexing.slowlog.threshold.index.debug"=> "2s",
                      "index.indexing.slowlog.threshold.index.trace"=> "500ms",
                      "index.indexing.slowlog.level"=> "info",
                      "index.indexing.slowlog.source"=> "1000"
                ],
            ]
        ];

        $response = $client->indices()->putSettings($params);
//        print_r($response);exit;
        $updateParams = [
            "index" => "phone_info",
            "type" => "_doc",
            "body" => [],
        ];

        $insertDatas = [];
        $platforms = $this->getPlatforms();
        $packages = $this->getPackages();

        if ($argPackageId != 'all') {
            foreach ($packages as $k => $v) {
                if ($k != $argPackageId) {
                    unset($packages[$k]);
                }
            }
        }

        foreach ($platforms as $plId => $plName) {
            if ($argPlatformId != 'all' && $argPlatformId != $plId) {
                continue;
            }

            echo 'Current Platform:' . $plName . PHP_EOL;
            $page = 1;
            while (true) {

                $params = [
                    "index" => "phone_info",
                    "type" => "_doc",
                    "body" => [
                        // "query" => [
                        //     "bool" => [
                        //         // "must" => ["term" => [
                        //         //     "phone" => 13200000034
                        //         // ]]

                        //         // "must" => ["term" => [
                        //         //     "phone" => 17700000001
                        //         // ]]
                        //     ],
                        // ],
                        "from" => ($page - 1) * $this->size,
                        "size" => $this->size,
                    ],

                ];
                echo "plaftofrm: {$plName} page: {$page} from: {$params['body']['from']}  size: {$params['body']['size']}" . PHP_EOL;
                //分页搜索
                $response = $client->search($params);
                if (empty($response['hits']['hits'])) {
                    break;
                }

                if (empty($response['hits']['total']['value'])) {
                    break;
                }

                $phones = [];
                $phoneData = [];
                foreach ($response['hits']['hits'] as $v) {
                    $phones[] = $v['_source']['phone'];
                    $phoneData[$v['_source']['phone']] = [
                        'number_package' => $v['_source']['number_package'],
                        // 'package_id' => $v['_source']['package_id'],
                        'register_platform' => $v['_source']['register_platform'],
                        'feedback_platform' => $v['_source']['feedback_platform'],
                        'client_id' => $v['_source']['client_id'] ?? [],

                        'use_platform' => $v['_source']['use_platform'],
                        'is_use' => $v['_source']['is_use'],

                        'is_agent' => $v['_source']['is_agent'],
                        'is_get_lottery' => $v['_source']['is_get_lottery'] ?? '' ,//是否领取过彩金
                        'last_bonus_time' => $v['_source']['last_bonus_time'] ?? '',//最后领取彩金时间
                        'is_gold_flow' => $v['_source']['is_gold_flow'] ?? '',//是否有流水
                        'last_flow_time' => $v['_source']['last_flow_time'] ?? '',//最后产生流水时间
                        'is_agent_gold' => $v['_source']['is_agent_gold'] ?? '',//是否有代理收益
                        'day30_spread_increase' => $v['_source']['day30_spread_increase'] ?? '',//30天内直属下级是否增长
                        'day1_recharge_gold' => $v['_source']['day1_recharge_gold'] ?? '',//单日累计最大充值金额
                        'day1_withdraw_gold' => $v['_source']['day1_withdraw_gold'] ?? '',//单日累计取款金额(只算最大充值金额那天的)
                        'day1_rwdv_percent' => $v['_source']['day1_rwdv_percent'] ?? '',//单日充兑差百分比
                    ];
                }

                $res = $this->getData($plId, $phones);
//                print_r($res);exit;
                !empty($res) && $this->getBulkParams($plId, $plName, $res, $phoneData, $platforms, $packages, $insertDatas, $updateParams);
//                print_r($updateParams);exit;
                if (!empty($updateParams['body']) && count($updateParams['body']) >= 1000) {
                    echo 'updateParams:' . count($updateParams['body']) . PHP_EOL;
                    if($this->isWriteData){
                        $res = $client->bulk($updateParams);
                        if($res['errors']){
                            $logger->error('updateParams',$res['items'][0]);
                        }
                    }
                    $updateParams['body'] = [];
                }

                if (!empty($insertDatas) && count($insertDatas) >= 1000) {
                    echo 'insertDatas:' . count($insertDatas) . PHP_EOL;
                    $this->isWriteData && Mobile::insertLog($insertDatas);
                    $insertDatas = [];
                }

                // if ($this->isBreak) {
                //     break;
                // }
                $page++;
            }

            if (!empty($updateParams['body'])) {
                echo 'updateParams:' . count($updateParams['body']) . PHP_EOL;
                if($this->isWriteData){
                    $res = $client->bulk($updateParams);
                    print_r($res);
                    if($res['errors']){
                        $logger->error('updateParams',$res['items'][0]);
                    }
                }

                $updateParams['body'] = [];
            }

            if (!empty($insertDatas)) {
                echo 'insertDatas:' . count($insertDatas) . PHP_EOL;
                // print_r($insertDatas);
                $this->isWriteData && Mobile::insertLog($insertDatas);
                $insertDatas = [];
            }

            // if ($this->isBreak) {
            //     break;
            // }
            // sleep(5);
        }
        echo "finish!" . PHP_EOL;
    }

    protected function getData($plId, $phones)
    {
        $url = env('API_GET_' . $plId, null);
        if (empty($url)) {
            echo 'ENV API_GET_' . $plId . ' is null!' . PHP_EOL;
            return [];
        }

        if (empty($phones)) {
            echo 'phones is null' . PHP_EOL;
            return [];
        }

        // $url = 'http://analysis-center.tgyfb.com/apiserver_interface.php?mod=mobileData&act=getdata';
        $client = new GuzzleHttp\Client();

        $response = $client->request('POST', $url . '/apiserver_interface.php?mod=mobileData&act=getdata', [
            'form_params' => [
                'mobiles' => $phones,
            ],
        ]);
        $data = (string) $response->getBody();
        $data = \json_decode($data, true);
        $temp = [];
        foreach ($data['data'] ?? [] as $v) {
            $v['is_banned'] = strtotime($v['banned_time']) > time() ? 1 : 0;
            $temp[$v['mobile']] = $v;
        }

        // echo 'data:';
        // print_r($data);
        // print_r($phones);
        echo 'GetData Url: ' . $url . '/apiserver_interface.php?mod=mobileData&act=getdata' . PHP_EOL;
        echo 'GetData: ' . count($temp) . PHP_EOL;
        // echo 'Phones:' . implode(',', $phones) . PHP_EOL;
        return $temp;
    }

    protected function getBulkParams($plId, $plName, $res, $phoneData, $platforms, $packages, &$insertDatas, &$updateParams)
    {
        // $params = [];
        // $insertDatas = [];
        foreach ($res as $phone => $v) {
            // $m = Hash::getPhoneServerById($phone);
            echo $phone;
            echo '-';
            $updateParams['body'][] = [
                'update' => [
                    '_index' => 'phone_info',
                    '_type' => '_doc',
                    '_id' => $phone,
                ],
            ];

            $register_platform = (array) $phoneData[$phone]['register_platform'];
            $register_platform[] = $plId;
            $register_platform = array_unique($register_platform);
            $register_platform_name = [];
            foreach ($register_platform as $rp) {
                $register_platform_name[] = $platforms[$rp];
            }

            $client_id = (array) $phoneData[$phone]['client_id'];
            foreach ($client_id as $c => $cv) {
                $c1 = explode(':', $cv);
                if ($c1[0] == $plId) {
                    unset($client_id[$c]);
                }
            }

            $client_id[] = $plId . ':' . $v['client_id'];
            $client_id = array_unique($client_id);

            $client_ids = [];
            foreach ($client_id as $ci){
                array_push($client_ids,$ci);
            }


            $feedback_platform = (array) $phoneData[$phone]['feedback_platform'];
            $feedback_platform[] = $plId;
            $feedback_platform = array_unique($feedback_platform);
            $feedback_platform_name = [];
            foreach ($feedback_platform as $rp) {
                $feedback_platform_name[] = $platforms[$rp];
            }

            $use_platform = (array) $phoneData[$phone]['use_platform'];
            $use_platform[] = $plId;
            $use_platform = array_unique($use_platform);

            $use_platform_name = [];
            foreach ($use_platform as $rp) {
                $use_platform_name[] = $platforms[$rp];
            }

            $type = 0;

            /**
            <Option value="2">沉默号</Option>
            <Option value="3">风险号</Option>
            <Option value="4">空号</Option>
            <Option value="1">活跃号</Option>
            <Option value="0">新号码</Option>
             */

            if (strtotime($v['last_logon_time']) > strtotime("-7 days")) {
                $type = 1;
            } else {
                $type = 2;
            }

            if ($v['is_risk_user'] >= 1) {
                $type = 3;
            }

            if ($v['is_banned'] >= 1) {
                $type = 3;
            }

            $day1_recharge_gold = $phoneData[$phone]['day1_recharge_gold'];
            $day1_withdraw_gold = $phoneData[$phone]['day1_withdraw_gold'];
            $day1_rwdv_percent = $phoneData[$phone]['day1_rwdv_percent'];
            if($day1_recharge_gold < $v['max_recharge']){
                $day1_recharge_gold = $v['max_recharge'];
                $day1_withdraw_gold = $v['max_recharge_date_withdraw'];
                $day1_rwdv_percent = (($day1_recharge_gold - $day1_withdraw_gold) / $day1_recharge_gold) * 100;
            }
            $last_bonus_time = $v['last_bonus_time'] ? strtotime($v['last_bonus_time']) : '';
            $last_flow_time = $v['last_flow_time'] ? (int)$v['last_flow_time']: '';
            //因为要判断30天内代理下级是否有增长每次获取每个平台都要对比，不像判断代理收益，有就永远有
            $day30_spread_increase = $this->redis->hget($phone,'day30_spread_increase');
            if($day30_spread_increase != 1){
                $day30_spread_increase = $v['zsxj_add_status'] ;
                $this->redis->hset($phone,'day30_spread_increase',$day30_spread_increase);
            }

            $temp = [
                'is_register' => 1,
                'is_feedback' => 1,
                'is_recharge' => $v['deposits_cnt'] > 0 ? 1 : 0,

                'is_use' => 1,

                // 号码状态
                'number_status' => $v['is_banned'] ?? 0,

                // 上一周是否充值
                // 'last_week_is_recharge' => $v['last_week_recharge_cnt'] > 0 ? 1 : 0,
                'last_recharge_date' => (int)strtotime($v['last_recharge_date'] ?? 0),
                'os' => $v['os'] == 2 ? 2 : 1, // os 1,3 ios 2 是android
                'client_id' => $client_ids,

                'register_platform' => $register_platform,
                'register_platform_name' => $register_platform_name,
                'is_agent'   =>   $phoneData[$phone]['is_agent'] ? $phoneData[$phone]['is_agent'] : (int)$v['is_agent'],
                'use_platform' => $register_platform,
                'use_platform_name' => $register_platform_name,

                'feedback_platform' => $feedback_platform,
                'feedback_platform_name' => $feedback_platform_name,
                'use_time' => strtotime($v['register_time']),
                'use_last_time' => strtotime($v['last_logon_time']),

                'feedback_last_time' => time(),
                //因为可能注册多个平台，如果是1就不要覆写
                'is_get_lottery' => $phoneData[$phone]['is_get_lottery'] ? $phoneData[$phone]['is_get_lottery'] : $v['total_receive_bonus'] >0 ? 1 : 2,//是否领取过彩金
                'last_bonus_time'=>$phoneData[$phone]['last_bonus_time'] >= $last_bonus_time ? $phoneData[$phone]['last_bonus_time'] : $last_bonus_time,
                'is_gold_flow' => $phoneData[$phone]['is_gold_flow'] ? $phoneData[$phone]['is_gold_flow'] : $v['total_bill'] >0 ? 1 : 2,//是否有流水
                'last_flow_time'=>$phoneData[$phone]['last_flow_time'] >= $last_flow_time ? $phoneData[$phone]['last_flow_time'] : $last_flow_time,
                'is_agent_gold' =>$phoneData[$phone]['is_agent_gold'] ? $phoneData[$phone]['is_agent_gold'] : $v['ljsy'] >0 ? 1 : 2,//是否有代理收益
                'day30_spread_increase' => $day30_spread_increase,//30天内直属下级是否增长
                'day1_recharge_gold' => $day1_recharge_gold,//单日累计最大充值金额
                'day1_withdraw_gold' => $day1_withdraw_gold,//单日累计取款金额(只算最大充值金额那天的)
                'day1_rwdv_percent' => $day1_rwdv_percent,//单日充兑差百分比
            ];
            echo $temp['is_get_lottery'];
            echo PHP_EOL;
            $use = strtotime($v['last_recharge_date'] ?? 0) > strtotime($v['register_time']);
            if ($phoneData[$phone]['is_use'] == 0 && $use) {
                $temp['is_use'] = 1;
            }

            if ($use) {
                $temp['use_platform'] = $use_platform;
                $temp['use_platform_name'] = $use_platform_name;
                $temp['use_last_time'] = time();
            }

            $updateParams['body'][] = [
                'doc' => $temp,
            ];

            // print_r($phoneData[$phone]['number_package_name']);
            foreach ($phoneData[$phone]['number_package'] as $package_id) {
                $temp = [
                    'type' => 3,
                    'chargeMoney' => $v['deposits_amount'],
                    'profitMoney' => $v['winlost'],

                    'mobile' => $phone,

                    'platform_id' => $plId,
                    'platform_name' => $plName,

                    'package_name' => $packages[$package_id] ?? '',
                    'package_id' => $package_id,

                    'created_at' => time(),
                ];
                $insertDatas[] = $temp;
            }
        }
    }

    protected function getPlatforms()
    {
        if (empty($this->platforms)) {
            $sql = "select * from pnl_platform";
            $temp = DB::select($sql);
            foreach ($temp as $v) {
                $v = (array) $v;
                $this->platforms[$v['id']] = $v['platform_name'];
            }
        }
        return $this->platforms;
    }

    protected function getPackages()
    {
        if (empty($this->packages)) {
            $sql = "select * from pnl_package where is_delete = 0";
            $temp = DB::select($sql);
            foreach ($temp as $v) {
                $v = (array) $v;
                $this->packages[$v['id']] = $v['package_name'];
            }
        }
        return $this->packages;
    }
}
