<?php
namespace App\Http\Middleware;

use Closure;

class IPWhite
{
    public function handle($request, Closure $next, $type)
    {
        $ips = trim(env($type . '_IP_WHITE'));
        $ips = !empty($ips) ? explode(',', $ips) : [];
        $ip = $request->getClientIp();
        if (!empty($ips) && !in_array($ip, $ips)) {
            return response()->json(['code' => '400', 'msg' => $type . '_IP_WHITE' . ' IP白名单限制, 你的IP:' . $ip, 'data' => []], 401);
        }

        return $next($request);
    }
}
