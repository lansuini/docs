<?php
/*
 * @Author: your name
 * @Date: 2020-05-08 10:42:49
 * @LastEditTime: 2020-06-11 15:18:56
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Http\Middleware\Authenticate.php
 */

namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Factory as Auth;
use App\Lib\JwtToken;
use App\Http\Controllers\Common\Auth as CommonAuth;
use Illuminate\Support\Facades\Cache;

class Authenticate
{
    /**
     * The authentication guard factory instance.
     *
     * @var \Illuminate\Contracts\Auth\Factory
     */
    protected $auth;

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Contracts\Auth\Factory  $auth
     * @return void
     */
    public function __construct(Auth $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        $token = $request->header("token", "");

        if (!JwtToken::getInstance()->verify($token)) {
            return response()->json(['code' => '401', 'msg' => '登录失效，请重新登录', 'data' => []], 401);
        }

        $sessionKey = 'PHPSESSID:' . $token;
        $strSessionData = Cache::get($sessionKey);
        if (empty($strSessionData)) {
            return response()->json(['code' => '401', 'msg' => '登录失效，请重新登录', 'data' => []], 401);
        }

        $arrSessionData = json_decode($strSessionData, true);

        $user['uid'] =  $arrSessionData['uid'];
        $user['userAccount'] = $arrSessionData['account'];
        $user['apiToken'] = $token;
        CommonAuth::$content  = $user;
        //测试  暂时写死
        // $user['uid'] =  1;
        // $user['userAccount'] = 'admin';
        // $user['apiToken'] = 'token';
        // CommonAuth::$content  = $user;
        Cache::put($sessionKey, $strSessionData, config('Session.max_lifetime_seconds'));

        return $next($request);
    }
}
