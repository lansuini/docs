<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-06-11 11:53:49
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Http\Controllers\v1\Agreement.php
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Common\Auth;
use Illuminate\Support\Facades\DB;
use App\Lib\Tools;

class Label extends Auth
{

    /**
     * 标签列表
     */
    public function getLabel(Request $request)
    {

        $pagesize = $request->input('pagesize') ?: 10;

        $results = DB::table('label')
            ->select('id', 'label_name', 'created_at')->orderBy('updated_at', 'desc')
            ->where('is_delete', 0)
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }



    /**
     *  修改标签信息
     *
     * @return Response
     */
    public function updateLabel(Request $request)
    {

        $id =  $request->input('id');
        $name = trim($request->input('name')); #标签名称

        if (empty($id)) {
            $this->error('100430'); #参数有误
        }
        if (empty($name)) {
            $this->error('100431'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100435'); #名称太长了
        }

        $label = DB::table('label')->where('id', $id)->first();

        #该内容不存在
        if (empty($label)) {
            $this->error('100432');
        }

        $label = DB::table('label')->where('label_name', $name)->where('is_delete', 0)->first();

        #该内容已经存在
        if (!empty($label) && $label->label_name === $name && $id != $label->id) {
            $this->error('100433'); #该标签已存在
        }

        $save['label_name'] = $name;
        $save['updated_at'] = time();

        #更新标签组状态
        $result = DB::table('label')->where('id', $id)->update($save);

        if (!$result) {
            $this->error('100434'); #操作失败
        }

        return  $this->success();
    }



    /**
     *  添加标签信息
     *
     * @return Response
     */
    public function addLabel(Request $request)
    {

        $name = trim($request->input('name')); #标签名称

        if (empty($name)) {
            $this->error('100440'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100443'); #名称太长了
        }
        $label = DB::table('label')->where('label_name', $name)->first();

        #该内容已经存在
        if (!empty($label) && $label->label_name === $name) {
            $this->error('100441'); #该标签已存在
        }

        $add['label_name'] = $name;
        $add['created_at'] = time();
        $add['updated_at'] = time();
        #更新标签组状态
        $id = DB::table('label')->insertGetId($add);


        if (!$id) {
            $this->error('100442'); #操作失败
        }

        return  $this->success(array('id' => $id));
    }



    /**
     *  删除标签信息
     *
     * @return Response
     */
    public function deleteLabel(Request $request)
    {

        $id = Tools::routeParameter('id');

        if (empty($id)) {
            $this->error('100450'); #参数有误
        }

        $label = DB::table('label')->where('id', $id)->first();

        #该内容不存在
        if (empty($label)) {
            $this->error('100451');
        }

        #更新标签组状态
        $result = DB::table('label')->where('id', $id)->delete();

        DB::table('package_label')->where('label_id', $id)->delete();

        if (!$result) {
            $this->error('100452'); #操作失败
        }

        return  $this->success();
    }
}
