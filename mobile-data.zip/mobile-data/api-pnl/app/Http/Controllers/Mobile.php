<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-06-12 11:50:34
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Http\Controllers\v1\Agreement.php
 */

namespace App\Http\Controllers;

use App\Http\Controllers\Common\Auth;
use App\Lib\Hash;
use App\Lib\JwtToken;
use App\Lib\Log;
use App\Lib\Phone;
use App\Lib\Tools;
use Elasticsearch\ClientBuilder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache as FacadesCache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class Mobile extends Auth
{
    protected $platforms;


    /**
     * 上传新号码
     */
    public function uploadNewMobile(Request $request)
    {
        $packageId = $request->input('package_id') ?: 0;
        $money = $request->input('money') ?: 0;

        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }

        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }

        if (empty($phone)) {
            $this->error(100703); #文件上传有误
        }

        $package = DB::table('package')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100704); #平台有误
        }
        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();
        $allowType = ['zip', 'txt'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        //新建上传地址

        // $dir = iconv("UTF-8", "GBK", storage_path('upload/'));//文件夹路径
        $tmpFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999);
        $tmpFilename = str_replace('.', '', $tmpFilename);
        $tmpFilename = str_replace('zip', '', $tmpFilename);
        $tmpFilename = str_replace('/', '_', $tmpFilename);
        $tmpFilename = str_replace('txt', '_', $tmpFilename);
        $newFilename = $tmpFilename . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));
        #是否合法
        $unzipDir = '';
        $cityArr = [];
        $provinceArr = [];
        $companyyArr = [];

        if ($mimeType == 'zip') {

            //解压出来看看是否合法
            $unzipDir = storage_path('upload/' . $tmpFilename . '/');

            $unzipBl = Tools::unzip($path, $unzipDir);

            if (!$unzipBl) {
                $this->error(100707); #zip格式有误
            }
            $txtArr = Tools::getTxtByDir($unzipDir);

            if (count($txtArr) == 0) {
                //无合法txt
                $this->error(100707); #解压后txt格式有误
            }

            foreach ($txtArr as $value) {
                $hasCity = 0;
                $hasCompany = 0;
                $hasProvince = 0;
                foreach (config('city.city') as $cityValue) {
                    if (strpos('a' . $value, $cityValue) > 0) {
                        $hasCity = 1;
                        $cityArr[$value] = $cityValue;
                    }
                }
                foreach (config('city.province') as $cityValue) {
                    if (strpos('a' . $value, $cityValue) > 0) {
                        $hasProvince = 1;
                        $provinceArr[$value] = $cityValue;
                    }
                }
                if (!$hasCity && !$hasProvince) {
                    $this->error(100708); #txt文件名中不存在城市名称
                }
                foreach (['移动', '联通', '电信', '虚拟'] as $companyValue) {
                    if (strpos('a' . $value, $companyValue) > 0) {
                        $hasCompany = 1;
                        $companyyArr[$value] = $companyValue;
                    }
                }
                if (!$hasCompany) {
                    $this->error(100709); #txt文件名中不存在归属地名称
                }
            }
        } else {

            $hasCity = 0;
            $hasCompany = 0;
            foreach (config('city.city') as $cityValue) {
                if (strpos('a' . $oldFilenameExp, $cityValue) > 0) {
                    $hasCity = 1;
                    $cityArr[$path] = $cityValue;
                }
            }
            foreach (config('city.province') as $cityValue) {
                if (strpos('a' . $oldFilenameExp, $cityValue) > 0) {
                    $hasCity = 1;
                    $provinceArr[$path] = $cityValue;
                }
            }
            if (!$hasCity) {
                $this->error(100708); #txt文件名中不存在城市名称
            }
            foreach (['移动', '联通', '电信', '虚拟'] as $companyValue) {
                if (strpos('a' . $oldFilenameExp, $companyValue) > 0) {
                    $hasCompany = 1;
                    $companyyArr[$path] = $companyValue;
                }
            }
            if (!$hasCompany) {
                $this->error(100709); #txt文件名中不存在归属地名称
            }
        }
        $insert = [
            'package_id' => (int) $packageId,
            'admin_id' => self::$uid,
            'money_sum' => $money,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'is_deal' => 0,
            'type' => 1,
            'file_type' => $mimeType == 'zip' ? 2 : 1,
            'unzip_dir' => $unzipDir,
            'deal_schedule' => '0.00%',
            'created_at' => time(),
            'updated_at' => time(),

        ];
        $re = DB::table('package_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100706); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
        $insert['city_arr'] = $cityArr;
        $insert['province_arr'] = $provinceArr;
        $insert['company_arr'] = $companyyArr;

        #写入redis

        Redis::Rpush(env('REDISQUEUE'), json_encode($insert));
        // Cache::forever('');
        return $this->success(['id' => $insert['upload_id']]);
    }
    /**
     * 上传使用号码
     */
    public function uploadUseMobile(Request $request)
    {

        $date = $request->input('date') ?: 0;
        $platformId = $request->input('platform_id') ?: 0;
        $packageId = $request->input('package_id') ?: 0;
        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }
        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }
        if (empty($date)) {
            $this->error(100702); #参数有误
        }

        if (!is_numeric($platformId)) {
            $platformId = Tools::getPlatformIdByAlias($platformId);
        }

        if (empty($platformId)) {
            $this->error(100703); #参数有误
        }
        if (empty($phone)) {
            $this->error(100703); #文件上传有误
        }
        $package = DB::table('package')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100704); #平台有误
        }
        $platForm = DB::table('platform')->where('id', $platformId)->first();
        if (empty($platForm)) {
            $this->error(100704); #平台有误
        }
        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();

        $allowType = ['zip', 'txt'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        //新建上传地址
        $tmpFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999);
        $tmpFilename = str_replace('.', '', $tmpFilename);
        $tmpFilename = str_replace('zip', '', $tmpFilename);
        $tmpFilename = str_replace('/', '_', $tmpFilename);
        $tmpFilename = str_replace('txt', '_', $tmpFilename);
        $newFilename = $tmpFilename . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));
        #是否合法
        $unzipDir = '';
        if ($mimeType == 'zip') {

            //解压出来看看是否合法
            $unzipDir = storage_path('upload/' . $tmpFilename . '/');

            $unzipBl = Tools::unzip($path, $unzipDir);
            if (!$unzipBl) {
                $this->error(100707); #zip格式有误
            }
            $txtArr = Tools::getTxtByDir($unzipDir);

            if (count($txtArr) == 0) {
                //无合法txt
                $this->error(100707); #解压后txt格式有误
            }
        }

        $insert = [
            'package_id' => (int) $packageId,
            'admin_id' => self::$uid,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'use_time' => $date,
            'is_deal' => 0,
            'file_type' => $mimeType == 'zip' ? 2 : 1,
            'unzip_dir' => $unzipDir,
            'platform_id' => (int) $platformId,
            'created_at' => time(),
            'updated_at' => time(),
            'deal_schedule' => '0.00%',
            'type' => 2,

        ];
        $re = DB::table('package_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100706); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['platform_name'] = $platForm->platform_name;
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
        #写入redis
        Redis::Rpush(env('REDISQUEUE'), json_encode($insert));
        return $this->success(['id' => $insert['upload_id']]);
    }
    /**
     * 上传号码姓名
     */
    public function uploadNameMobile(Request $request)
    {

        $date = $request->input('date') ?: 0;
        $platformId = $request->input('platform_id') ?: 0;
        $packageId = $request->input('package_id') ?: 0;
        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }
        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }
        if (empty($phone)) {
            $this->error(100703); #文件上传有误
        }
        $package = DB::table('package')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100704); #平台有误
        }

        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();

        $allowType = ['zip', 'txt'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        //新建上传地址
        $tmpFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999);
        $tmpFilename = str_replace('.', '', $tmpFilename);
        $tmpFilename = str_replace('zip', '', $tmpFilename);
        $tmpFilename = str_replace('/', '_', $tmpFilename);
        $tmpFilename = str_replace('txt', '_', $tmpFilename);
        $newFilename = $tmpFilename . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));
        #是否合法
        $unzipDir = '';
        if ($mimeType == 'zip') {

            //解压出来看看是否合法
            $unzipDir = storage_path('upload/' . $tmpFilename . '/');

            $unzipBl = Tools::unzip($path, $unzipDir);
            if (!$unzipBl) {
                $this->error(100707); #zip格式有误
            }
            $txtArr = Tools::getTxtByDir($unzipDir);

            if (count($txtArr) == 0) {
                //无合法txt
                $this->error(100707); #解压后txt格式有误
            }
        }

        $insert = [
            'package_id' => (int) $packageId,
            'admin_id' => self::$uid,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'use_time' => $date,
            'is_deal' => 0,
            'file_type' => $mimeType == 'zip' ? 2 : 1,
            'unzip_dir' => $unzipDir,
            'platform_id' => 0,
            'created_at' => time(),
            'updated_at' => time(),
            'deal_schedule' => '0.00%',
            'type' => 8,

        ];
        $re = DB::table('package_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100706); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['platform_name'] = '';
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
        #写入redis
        Redis::Rpush(env('REDISQUEUE'), json_encode($insert));
        return $this->success(['id' => $insert['upload_id']]);
    }
    /**
     * 上传注册号码
     */
    public function uploadRegisterMobile(Request $request)
    {

        $platformId = $request->input('platform_id') ?: 0;
        $packageId = $request->input('package_id') ?: 0;
        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }
        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }

        if (!is_numeric($platformId)) {
            $platformId = Tools::getPlatformIdByAlias($platformId);
        }

        if (empty($platformId)) {
            $this->error(100702); #参数有误
        }

        if (empty($phone)) {
            $this->error(100703); #文件上传有误
        }
        $package = DB::table('package')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100703); #平台有误
        }
        $platForm = DB::table('platform')->where('id', $platformId)->first();
        if (empty($platForm)) {
            $this->error(100704); #平台有误
        }
        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();
        $allowType = ['zip', 'txt'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        //新建上传地址
        $tmpFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999);
        $tmpFilename = str_replace('.', '', $tmpFilename);
        $tmpFilename = str_replace('zip', '', $tmpFilename);
        $tmpFilename = str_replace('/', '_', $tmpFilename);
        $tmpFilename = str_replace('txt', '_', $tmpFilename);
        $newFilename = $tmpFilename . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));

        #是否合法
        $unzipDir = '';
        if ($mimeType == 'zip') {

            //解压出来看看是否合法
            $unzipDir = storage_path('upload/' . $tmpFilename . '/');

            $unzipBl = Tools::unzip($path, $unzipDir);
            if (!$unzipBl) {
                $this->error(100707); #zip格式有误
            }
            $txtArr = Tools::getTxtByDir($unzipDir);

            if (count($txtArr) == 0) {
                //无合法txt
                $this->error(100707); #解压后txt格式有误
            }
        }
        $insert = [
            'package_id' => (int) $packageId,
            'admin_id' => self::$uid,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'is_deal' => 0,
            'platform_id' => (int) $platformId,
            'file_type' => $mimeType == 'zip' ? 2 : 1,
            'unzip_dir' => $unzipDir,
            'created_at' => time(),
            'updated_at' => time(),
            'type' => 3,
            'deal_schedule' => '0.00%',

        ];
        $re = DB::table('package_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100802); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['platform_name'] = $platForm->platform_name;
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
        #写入redis
        Redis::Rpush(env('REDISQUEUE'), json_encode($insert));
        return $this->success(['id' => $insert['upload_id']]);
    }
    /**
     * 上传反馈号码
     */
    public function uploadFeedbackMobile(Request $request)
    {
        $platformId = $request->input('platform_id') ?: 0;
        $packageId = $request->input('package_id') ?: 0;
        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }
        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }

        if (!is_numeric($platformId)) {
            $platformId = Tools::getPlatformIdByAlias($platformId);
        }

        if (empty($platformId)) {
            $this->error(100702); #参数有误
        }

        if (empty($phone)) {
            $this->error(100703); #文件上传有误
        }
        $package = DB::table('package')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100703); #平台有误
        }
        $platForm = DB::table('platform')->where('id', $platformId)->first();
        if (empty($platForm)) {
            $this->error(100704); #平台有误
        }
        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();
        $allowType = ['xlsx', 'xls', 'csv'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        $newFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999) . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));
        $insert = [
            'package_id' => (int) $packageId,
            'admin_id' => self::$uid,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'is_deal' => 0,
            'platform_id' => (int) $platformId,
            'created_at' => time(),
            'updated_at' => time(),
            'type' => 4,
            'deal_schedule' => '0.00%',

        ];
        $re = DB::table('package_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100706); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
        $insert['platform_name'] = $platForm->platform_name;
        #写入redis
        Redis::Rpush(env('REDISQUEUE'), json_encode($insert));
        return $this->success(['id' => $insert['upload_id']]);
    }

    /**
     * 上传沉默号码/风险/空号码
     */
    public function uploadSetTypeMobile(Request $request)
    {

        $packageId = $request->input('package_id') ?: 0;
        $type = $request->input('type') ?: 0; #5为沉默 6为风险  7为空号
        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }
        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }

        if (empty($phone)) {
            $this->error(100702); #文件上传有误
        }
        if (empty($type)) {
            $this->error(100703); #参数有误
        }
        $package = DB::table('package')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100704); #平台有误
        }
        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();
        $allowType = ['zip', 'txt'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        //新建上传地址
        $tmpFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999);
        $tmpFilename = str_replace('.', '', $tmpFilename);
        $tmpFilename = str_replace('zip', '', $tmpFilename);
        $tmpFilename = str_replace('/', '_', $tmpFilename);
        $tmpFilename = str_replace('txt', '_', $tmpFilename);
        $newFilename = $tmpFilename . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));
        #是否合法
        $unzipDir = '';
        if ($mimeType == 'zip') {

            //解压出来看看是否合法
            $unzipDir = storage_path('upload/' . $tmpFilename . '/');

            $unzipBl = Tools::unzip($path, $unzipDir);
            if (!$unzipBl) {
                $this->error(100707); #zip格式有误
            }
            $txtArr = Tools::getTxtByDir($unzipDir);

            if (count($txtArr) == 0) {
                //无合法txt
                $this->error(100707); #解压后txt格式有误
            }
        }
        $insert = [
            'package_id' => (int) $packageId,
            'admin_id' => self::$uid,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'is_deal' => 0,
            'created_at' => time(),
            'updated_at' => time(),
            'file_type' => $mimeType == 'zip' ? 2 : 1,
            'unzip_dir' => $unzipDir,
            'type' => $type,
            'deal_schedule' => '0.00%',

        ];
        $re = DB::table('package_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100706); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
        #写入redis
        Redis::Rpush(env('REDISQUEUE'), json_encode($insert));
        return $this->success(['id' => $insert['upload_id']]);
    }
    public function phoneLog(Request $request)
    {
        //
        $type = $request->input('type') ?: 0; //1为修改日志  2为使用日志  3为反馈日志
        $mobile = $request->input('mobile') ?: 0; //手机号码
        // $size = $request->input('size') ?: 1; //手机号码
        // $pageSize = $request->input('pageSize') ?: 10; //手机号码

        if (empty($type)) {
            $this->error(100801); #参数有误
        }
        if (empty($mobile)) {
            $this->error(100802); #参数有误
        }
        //创建
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
            ->setHosts($hosts) // Set the hosts
            ->build();

        $params = [
            'index' => 'phone_info',
            'body' => [
                "query" => [

                    'bool' => [
                        'must' => [
                            [
                                'terms' => [
                                    'phone' => [$mobile],
                                    // 'phone' => [1]
                                ],
                            ],
                            // [
                            //     'terms' => [
                            //         'number_package' => $fileInfo['packageAllIds']
                            //     ]
                            // ]

                        ],
                    ],

                ],
            ],
        ];

        $results = $client->search($params);
        $limit = !empty($results['hits']['hits'][0]['_source']['export_count']) ? $results['hits']['hits'][0]['_source']['export_count'] : 0;
        $tmpId = Hash::getPhoneServerById($mobile);
        $table = 'pnl_package_phone_log_' . $tmpId;

        if ($type == 1) {
            $sql = 'select a.* from ' . $table . ' as a left join pnl_package as b on b.id = a.package_id where b.id>0 and a.type = ' . $type . ' and a.mobile=' . $mobile;
        } else if ($type == 2 || $type == 3) {
            $sql = 'select a.* from ' . $table . ' as a left join pnl_package as b on b.id = a.package_id where  b.id>0 and a.type = ' . $type . ' and a.mobile=' . $mobile;
        } else {
            $sql = 'select * from ' . $table . '  where type = ' . $type . ' and mobile=' . $mobile . ' order by export_at desc limit ' . $limit;
        }

        $results = DB::select($sql);

        if (count($results) > 0) {
            $ids = array_column($results, 'platform_id');
            $idsName = DB::table('platform')->whereIn('id', $ids)->get();
            $platform = array_column($idsName->toArray(), null, 'id');
        }

        foreach ($results as $key => $value) {
            if (!empty($platform[$value->platform_id])) {
                unset($results[$key]->platform_name);
                $results[$key]->platform_name = $platform[$value->platform_id]->platform_name;
            }
        }

        $data['data'] = $results;
        $data['count'] = count($results);
        // $data['total'] =  $results->total();
        // $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    public function phoneList(Request $request)
    {
//        $params = $request->post();
//        var_dump($params);
        $b15d = strtotime('-15 days');
        //页码
        $page = $request->input('page') ?: 1; //
        $pageSize = $request->input('page_size') ?: 10; //
        $from = ($page - 1) * $pageSize;
        $packageId = $request->input('package_id') ?: 0; //

        //筛选条件
        $phone = $request->input('phone') ?: [];
        $company = $request->input('company') ?: []; #运营商   传  1为移动  2为联通  3为电信  4为虚拟 0为空
        $province = $request->input('province') ?: []; #归属省
        $city = $request->input('city') ?: []; #归属市
        $type = $request->input('type') ?: []; #号码属性  0未验证,1正常号,2沉默号,3危险号,4空号
        $is_register = $request->input('is_register') ?: []; #注册状态 0为未注册  1为注册
        $register_platform = $request->input('register_platform') ?: []; #注册平台 传id
        $is_use = $request->input('is_use') ?: []; #使用状态  0为未使用 1为使用
        $use_platform = $request->input('use_platform') ?: []; #使用平台 传id
        $use_time = $request->input('use_time') ?: []; #使用时间  传区间
        $use_last_time = $request->input('use_last_time') ?: []; #最后使用时间  传区间
        $is_feedback = $request->input('is_feedback') ?: []; #反馈状态  0 未反馈  1反馈
        $feedback_platform = $request->input('feedback_platform') ?: []; #反馈平台   传id
        $feedback_last_time = $request->input('feedback_last_time') ?: []; #最后反馈日期
        $number_package = $request->input('number_package') ?: []; #关联号码包  传name
        $created_at = $request->input('created_at') ?: []; #入库时间
        $updated_at = $request->input('updated_at') ?: []; #修改时间
        $phone_segment = $request->input('phone_segment') ?: []; #号码前三位
        $export_state = $request->input('export_state') ?: []; #导出状态
        $export_at = $request->input('export_at') ?: []; #导出状态

        $number_status = $request->input('number_status'); #号码状态

        $phone = $request->input('phone') ?: "";
        $is_register = $request->input('is_register') ?: "";
        $is_agent = $request->input('is_agent') ?: "";
        $is_agent_gold = $request->input('is_agent_gold') ?: "";#是否产生代理收益
        $is_gold_flow = $request->input('is_gold_flow') ?: "";#是否有流水
        $last_flow_time = $request->input('last_flow_time') ?: []; #最后流水时间  传区间
        $is_get_lottery = $request->input('is_get_lottery') ?: "";#是否有领取彩金
        $last_bonus_time = $request->input('last_bonus_time') ?: "";#最后领取彩金时间
        $day30_spread_increase = $request->input('day30_spread_increase') ?: "";#30天内直属下级是否增加
        $day1_recharge_gold = $request->input('day1_recharge_gold') ?: "";#是否有流水
        $rwdv_percent = $request->input('rwdv_percent') ?: "";#充兑差百分比
        $type = $request->input('type') ?: "";
        $is_use = $request->input('is_use') ?: "";
        $number_status = $request->input('number_status') ?: "";
        $is_b15dsrc = $request->input('is_b15dsrc') ?: "";

        $bool = [];
        if ($phone !== "" && !is_array($phone)) {
            $phone = ["is" => [$phone]];
        }

        if ($is_register !== "" && !is_array($is_register)) {
            $is_register = ["is" => [$is_register]];
        }

        if ($type !== "" && !is_array($type)) {
            $type = ["is" => [$type]];
        }

        if ($is_use !== "" && !is_array($is_use)) {
            $is_use = ["is" => [$is_use]];
        }

        if ($is_b15dsrc !== "") {

            if ($is_b15dsrc == 1) {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['gt' => $b15d],
                    ],
                ];
            } else {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['lt' => $b15d],
                    ],
                ];
            }
        }

        if ($is_agent !== "") {
            $bool['must'][] = [
                'term' => [
                    'is_agent' => $is_agent,
                ],
            ];
        }

        if($is_agent_gold !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_agent_gold' => $is_agent_gold,
                ],
            ];
        }

        if($is_gold_flow != ''){
            $bool['must'][] = [
                'term' => [
                    'is_gold_flow' => (string)$is_gold_flow,
                ],
            ];
        }

        if($is_get_lottery !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_get_lottery' => $is_get_lottery,
                ],
            ];
        }

        if($day30_spread_increase !== ""){
            $bool['must'][] = [
                'term' => [
                    'day30_spread_increase' => $day30_spread_increase,
                ],
            ];
        }

        if($day1_recharge_gold !== ""){
            $tmpRange = [];
            switch ($day1_recharge_gold){
                case '1':
                    $tmpRange['day1_recharge_gold'] = [
                        'gt' => 5000,//5000以上
                    ];
                    break;
                case '2':
                    $tmpRange['day1_recharge_gold'] = [
                        'gte' => 500,//500-5000
                        'lte' => 5000,
                    ];
                    break;
                case '3':
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
                default:
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if($rwdv_percent !== ""){
            $tmpRange = [];
            switch ($rwdv_percent){
                case 1:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gt' => 50,//50以上
                    ];
                    break;
                case 2:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gte' => 30,//30-50
                        'lte' => 50,
                    ];
                    break;
                case 3:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
                default:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if ($number_status !== "" && !is_array($number_status)) {
            if ($number_status == 1) {
                $bool['must'][] = [
                    'term' => [
                        'number_status' => 1,
                    ],
                ];
            } else {
                $bool['must_not'][] = [
                    'exists' => [
                        'field' => 'number_status',
                    ],
                ];
            }
        }

        if (!empty($register_platform) && is_array($register_platform)) {
            $matchs = [];
            foreach ($register_platform as $rp) {
                $matchs[] = ["match" => ["register_platform" => $rp]];
            }

            $bool['must'][] = ['bool' => [
                "should" => $matchs,
                "minimum_should_match" => 1,
            ]];
        }

        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        #export_at=》export_at
        $bool['must'][] = [
            'range' => [
                'number_package' => [
                    'gt' => 0,
                ],
            ],
        ];
        if (!empty($export_at['is']) && count($export_at['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_at' => $export_at['is'],
                ],
            ];
        };
        if (!empty($export_at['not']) && count($export_at['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_at' => $export_at['not'],
                ],
            ];
        };
        #phone_segment
        if (!empty($phone_segment['is']) && count($phone_segment['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['is'],
                ],
            ];
        };
        if (!empty($phone_segment['not']) && count($phone_segment['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['not'],
                ],
            ];
        };

        #pack
        if ($packageId) {
            $bool['must'][] = [
                'term' => [
                    'number_package' => $packageId,
                ],
            ];
        } else {
            $ids = DB::table('package')->select('id')->get();
            $ids = $ids->pluck('id')->all();
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $ids,
                ],
            ];
        };
        #手机号
        if (!empty($phone['is']) && count($phone['is']) > 0) {
            foreach ($phone['is'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'phone' => $phone['is'],
                ],
            ];
        };
        if (!empty($phone['not']) && count($phone['not']) > 0) {
            foreach ($phone['not'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'phone' => $phone['not'],
                ],
            ];
        };
        #运营商

        if (!empty($company['is']) && count($company['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'company' => $company['is'],
                ],
            ];
        };
        if (!empty($company['not']) && count($company['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'company' => $company['not'],
                ],
            ];
        };
        #省
        if (!empty($province['is']) && count($province['is']) > 0) {

            foreach ($province['is'] as $key => $value) {
                if ($value == '为空') {
                    $province['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'province' => $province['is'],
                ],
            ];
        };
        if (!empty($province['not']) && count($province['not']) > 0) {
            foreach ($province['not'] as $key => $value) {
                if ($value == '为空') {
                    $province['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'province' => $province['not'],
                ],
            ];
        };
        #市
        if (!empty($city['is']) && count($city['is']) > 0) {
            foreach ($city['is'] as $key => $value) {
                if ($value == '为空') {
                    $city['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'city' => $city['is'],
                ],
            ];
        };
        if (!empty($city['not']) && count($city['not']) > 0) {
            foreach ($city['not'] as $key => $value) {
                if ($value == '为空') {
                    $city['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'city' => $city['not'],
                ],
            ];
        };
        #属性
        if (!empty($type['is']) && count($type['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'type' => $type['is'],
                ],
            ];
        };
        if (!empty($type['not']) && count($type['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'type' => $type['not'],
                ],
            ];
        };
        #是否注册
        if (!empty($is_register['is']) && count($is_register['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_register' => $is_register['is'],
                ],
            ];
        };
        if (!empty($is_register['not']) && count($is_register['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_register' => $is_register['not'],
                ],
            ];
        };

        #是否注册
        if (!empty($is_register['is']) && count($is_register['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_register' => $is_register['is'],
                ],
            ];
        };
        if (!empty($is_register['not']) && count($is_register['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_register' => $is_register['not'],
                ],
            ];
        };
        #注册平台
        if (!empty($register_platform['is']) && count($register_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'register_platform' => $register_platform['is'],
                ],
            ];
        };
        if (!empty($register_platform['not']) && count($register_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'register_platform' => $register_platform['not'],
                ],
            ];
        };
        #是否使用
        if (!empty($is_use['is']) && count($is_use['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_use' => $is_use['is'],
                ],
            ];
        };
        if (!empty($is_use['not']) && count($is_use['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_use' => $is_use['not'],
                ],
            ];
        };
        #export_state
        if (!empty($export_state['is']) && count($export_state['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_state' => $export_state['is'],
                ],
            ];
        };
        if (!empty($export_state['not']) && count($export_state['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_state' => $export_state['not'],
                ],
            ];
        };

        #使用平台
        if (!empty($use_platform['is']) && count($use_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'use_platform' => $use_platform['is'],
                ],
            ];
        };
        if (!empty($use_platform['not']) && count($use_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'use_platform' => $use_platform['not'],
                ],
            ];
        };
        #use_time

        if (!empty($use_time) && count($use_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($use_time as $value) {
                $tmpRange = [];
                $tmpRange['use_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };
        #use_last_time

        if (!empty($use_last_time) && count($use_last_time) > 0) {
            $tmpRange = [];
            $tmpRange['use_last_time'] = [
                'gte' => $use_last_time[0],
                'lte' => $use_last_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_flow_time) && count($last_flow_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_flow_time'] = [
                'gte' => $last_flow_time[0],
                'lte' => $last_flow_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_bonus_time) && count($last_bonus_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_bonus_time'] = [
                'gte' => $last_bonus_time[0],
                'lte' => $last_bonus_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        #is_feedback

        if (!empty($is_feedback['is']) && count($is_feedback['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['is'],
                ],
            ];
        };
        if (!empty($is_feedback['not']) && count($is_feedback['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['not'],
                ],
            ];
        };
        #feedback_platform
        if (!empty($feedback_platform['is']) && count($feedback_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['is'],
                ],
            ];
        };
        if (!empty($feedback_platform['not']) && count($feedback_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['not'],
                ],
            ];
        };
        #feedback_last_time
        if (!empty($feedback_last_time) && count($feedback_last_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($feedback_last_time as $value) {
                $tmpRange = [];
                $tmpRange['feedback_last_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        #number_package
        if (!empty($number_package['is']) && count($number_package['is']) > 0) {
            $realPackage = DB::table('package')->whereIn('package_name', $number_package['is'])->get();

            $realPackage = $realPackage->pluck('id');

            $bool['must'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];
        };
        if (!empty($number_package['not']) && count($number_package['not']) > 0) {
            $realPackage = DB::table('package')->whereIn('package_name', $number_package['not'])->get();
            $realPackage = $realPackage->pluck('id');
            $bool['must_not'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];
        };

        #created_at

        if (!empty($created_at) && count($created_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($created_at as $value) {
                $tmpRange = [];
                $tmpRange['created_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };
        #updated_at

        if (!empty($updated_at) && count($updated_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($updated_at as $value) {
                $tmpRange = [];
                $tmpRange['updated_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
            ->setHosts($hosts) // Set the hosts
            ->build();

        if (count($bool) > 0) {
            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
                        "bool" => $bool,
                    ],
                    'size' => $pageSize,
                    'from' => $from,
                ],
            ];
        } else {
            $params = [
                'index' => 'phone_info',
                'body' => [

                    'size' => $pageSize,
                    'from' => $from,
                ],
            ];
        }

        $re = [];
        $data = [];
//        print_r($params);exit;
        $results = $client->search($params);

        unset($params['body']['size']);
        unset($params['body']['from']);
        $count = $client->count($params);
        $number_package_ids = [];

        if (!empty($results['hits']['total']['value'])) {
            $platformIds = [];

            foreach ($results['hits']['hits'] as $value) {
                array_push($data, $value['_source']);

                //存在部分历史数据有些问题  直接兼容
                if (!empty($value['_source']['use_platform'])) {
                    $platformIds = array_unique(array_merge($platformIds, $value['_source']['use_platform']));
                }
                if (!empty($value['_source']['register_platform'])) {
                    $platformIds = array_unique(array_merge($platformIds, $value['_source']['register_platform']));
                }
                if (!empty($value['_source']['feedback_platform'])) {
                    $platformIds = array_unique(array_merge($platformIds, $value['_source']['feedback_platform']));
                }
                if (!empty($value['_source']['number_package'])) {
                    $number_package_ids = array_unique(array_merge($number_package_ids, $value['_source']['number_package']));
                }
            }

            $platforms = [];
            if (!empty($platformIds)) {
                $platforms = DB::table('platform')->whereIn('id', $platformIds)->where('is_delete', 0)->get();
                $platforms = $platforms->keyBy('id')->all();
            }
            $packages = [];
            if (!empty($number_package_ids)) {
                $packages = DB::table('package')->whereIn('id', $number_package_ids)->get();
                $packages = $packages->keyBy('id')->all();
            }

            foreach ($data as $k => $vl) {
                $data[$k]['number_package_name'] = [];
                if (!empty($data[$k]['number_package'])) {
                    foreach ($data[$k]['number_package'] ?? [] as $pfId) {
                        if (isset($packages[$pfId])) {
                            $data[$k]['number_package_name'][] = $packages[$pfId]->package_name;
                        }
                    }
                }

                $data[$k]['use_platform_name'] = [];
                if (!empty($data[$k]['use_platform'])) {
                    foreach ($data[$k]['use_platform'] ?? [] as $pfId) {
                        if (isset($platforms[$pfId])) {
                            $data[$k]['use_platform_name'][] = $platforms[$pfId]->platform_name;
                        }
                    }
                }
                $data[$k]['register_platform_name'] = [];
                if (!empty($data[$k]['register_platform'])) {
                    foreach ($data[$k]['register_platform'] ?? [] as $pfId) {
                        if (isset($platforms[$pfId])) {
                            $data[$k]['register_platform_name'][] = $platforms[$pfId]->platform_name;
                        }
                    }
                }

                $data[$k]['feedback_platform_name'] = [];
                if (!empty($data[$k]['feedback_platform'])) {
                    foreach ($data[$k]['feedback_platform'] ?? [] as $pfId) {
                        if (isset($platforms[$pfId])) {
                            $data[$k]['feedback_platform_name'][] = $platforms[$pfId]->platform_name;
                        }
                    }
                }

                $data[$k]['client_id'] = (array) ($data[$k]['client_id'] ?? []);
                foreach ($data[$k]['client_id'] as $kk => $vv) {
                    list($cc1, $cc2) = explode(':', $vv);
                    $data[$k]['client_id'][$kk] = $this->getPlatforms($cc1) . ':' . $cc2;
                }

                $ds = $data[$k]['last_recharge_date'] ?? 0;
                $data[$k]['last_week_is_recharge'] = $ds > $b15d ? 1 : 0;
                $data[$k]['last_recharge_date'] = isset($data[$k]['last_recharge_date']) ? date('Y-m-d', $data[$k]['last_recharge_date']) : '--';
            }

            $re['data'] = $data;
            $re['count'] = $count['count'];
            $re['total'] = ceil($count['count'] / $pageSize);
            $re['currentPage'] = $page;
        }
        return $this->success($re);
    }

    protected function getPlatforms($id = 0)
    {
        if (empty($this->platforms)) {
            $sql = "select * from pnl_platform";
            $temp = DB::select($sql);
            foreach ($temp as $v) {
                $v = (array) $v;
                $this->platforms[$v['id']] = $v['platform_name'];
            }
        }

        return $id > 0 ? $this->platforms[$id] : $this->platforms;
    }

    public function exportPhone(Request $request)
    {
        set_time_limit(0);
        ini_set('memory_limit', -1);
        $b15d = strtotime('-15 days');

        if (!is_dir(storage_path('exportfiles'))) {
            Tools::makedir(storage_path('exportfiles'));
        }

        $packageId = $request->input('package_id') ?: 0; //
        $title = $request->input('title') ?: []; //
        $exportType = $request->input('exportType') ?: 0; //导出类型  1为包内导出  2为全部导出
        $fileType = $request->input('fileType') ?: 0; //导出类型  1为excel  2为phone
        //筛选条件

        $phone = $request->input('phone') ?: '';
        $company = $request->input('company') ?: []; #运营商   传  1为移动  2为联通  3为电信  4为虚拟 0为空
        $province = $request->input('province') ?: []; #归属省
        $city = $request->input('city') ?: []; #归属市
        $type = $request->input('type') ?: []; #号码属性  0未验证,1正常号,2沉默号,3危险号,4空号
        $is_register = $request->input('is_register') ?: []; #注册状态 0为未注册  1为注册
        $register_platform = $request->input('register_platform') ?: []; #注册平台 传id
        $is_use = $request->input('is_use') ?: []; #使用状态  0为未使用 1为使用
        $use_platform = $request->input('use_platform') ?: []; #使用平台 传id
        $use_time = $request->input('use_time') ?: []; #使用时间  传区间
        $use_last_time = $request->input('use_last_time') ?: []; #最后使用时间  传区间
        $is_feedback = $request->input('is_feedback') ?: []; #反馈状态  0 未反馈  1反馈
        $feedback_platform = $request->input('feedback_platform') ?: []; #反馈平台   传id
        $feedback_last_time = $request->input('feedback_last_time') ?: []; #最后反馈日期
        $number_package = $request->input('number_package') ?: []; #关联号码包  传name
        $created_at = $request->input('created_at') ?: []; #入库时间
        $updated_at = $request->input('updated_at') ?: []; #修改时间
        $phone_segment = $request->input('phone_segment') ?: []; #号码前三位
        $export_state = $request->input('export_state') ?: []; #导出状态
        $export_at = $request->input('export_at') ?: []; #导出状态

        $number_status = $request->input('number_status'); #号码状态

        $phone = $request->input('phone') ?: "";
        $is_register = $request->input('is_register') ?: "";
        $type = $request->input('type') ?: "";
        $is_use = $request->input('is_use') ?: "";
        $number_status = $request->input('number_status') ?: "";
        $is_b15dsrc = $request->input('is_b15dsrc') ?: "";
        $is_agent = $request->input('is_agent') ?: "";

        $is_agent_gold = $request->input('is_agent_gold') ?: "";#是否产生代理收益
        $is_gold_flow = $request->input('is_gold_flow') ?: "";#是否有流水
        $last_flow_time = $request->input('last_flow_time') ?: [];#是否有流水
        $is_get_lottery = $request->input('is_get_lottery') ?: "";#是否有彩金
        $last_bonus_time = $request->input('last_bonus_time') ?: [];#彩金时间
        $day30_spread_increase = $request->input('day30_spread_increase') ?: "";#30天内直属下级是否增加
        $day1_recharge_gold = $request->input('day1_recharge_gold') ?: "";#是否有流水
        $rwdv_percent = $request->input('rwdv_percent') ?: "";#充兑差百分比
        $bool = [];
        #手机号
        $logContent = '';
        $logContent2 = '';
        if ($phone !== "" && !is_array($phone)) {
            $logContent2 .= '手机号码:' . $phone;
            $phone = ["is" => [$phone]];
        }

        if ($is_register !== "" && !is_array($is_register)) {
            $is_register = ["is" => [$is_register]];
            $logContent2 .= ' 注册:' . ($is_register ? '是' : '否');
        }

        if ($type !== "" && !is_array($type)) {
            $types = [
                0 => '未验证',
                1 => '正常号',
                2 => '沉默号',
                3 => '危险号',
                4 => '空号',
            ];
            $logContent2 .= ' 类型:' . ($types[$type]);
            $type = ["is" => [$type]];

        }

        if ($is_use !== "" && !is_array($is_use)) {
            $logContent2 .= ' 已使用:' . ($is_use ? '是' : '否');
            $is_use = ["is" => [$is_use]];

        }

        if ($is_b15dsrc !== "") {
            $logContent2 .= ' 近15天充值:' . ($is_b15dsrc ? '是' : '否');
            if ($is_b15dsrc == 1) {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['gt' => $b15d],
                    ],
                ];
            } else {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['lt' => $b15d],
                    ],
                ];
            }
        }
        if ($is_agent !== "") {

            $bool['must'][] = [
                'range' => [
                    'is_agent' => $is_agent,
                ],
            ];

        }

        if($is_agent_gold !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_agent_gold' => $is_agent_gold,
                ],
            ];
        }
        if($is_gold_flow != ''){
            $bool['must'][] = [
                'term' => [
                    'is_gold_flow' => (string)$is_gold_flow,
                ],
            ];
        }

        if($is_get_lottery !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_get_lottery' => $is_get_lottery,
                ],
            ];
        }
        if($day30_spread_increase !== ""){
            $bool['must'][] = [
                'term' => [
                    'day30_spread_increase' => $day30_spread_increase,
                ],
            ];
        }

        if($day1_recharge_gold !== ""){
            $tmpRange = [];
            switch ($day1_recharge_gold){
                case '1':
                    $tmpRange['day1_recharge_gold'] = [
                        'gt' => 5000,//5000以上
                    ];
                    break;
                case '2':
                    $tmpRange['day1_recharge_gold'] = [
                        'gte' => 500,//500-5000
                        'lte' => 5000,
                    ];
                    break;
                case '3':
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
                default:
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if($rwdv_percent !== ""){
            $tmpRange = [];
            switch ($rwdv_percent){
                case 1:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gt' => 50,//50以上
                    ];
                    break;
                case 2:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gte' => 30,//30-50
                        'lte' => 50,
                    ];
                    break;
                case 3:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
                default:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if ($number_status !== "" && !is_array($number_status)) {
            if ($number_status == 1) {
                $bool['must'][] = [
                    'term' => [
                        'number_status' => 1,
                    ],
                ];
            } else {
                $bool['must_not'][] = [
                    'exists' => [
                        'field' => 'number_status',
                    ],
                ];
            }
        }

        if ($number_status !== "" && !is_array($number_status)) {
            if ($number_status == 1) {
                $bool['must'][] = [
                    'term' => [
                        'number_status' => 1,
                    ],
                ];
            } else {
                $bool['must_not'][] = [
                    'exists' => [
                        'field' => 'number_status',
                    ],
                ];
            }

            $logContent2 .= ' 状态:' . ($number_status ? '封号' : '未封号');
        }

        if (!empty($register_platform) && is_array($register_platform)) {
            $sql = "select * from pnl_platform";
            $db = DB::select($sql);
            $platformList = [];
            $names = [];
            foreach ($db as $v) {
                $platformList[$v->id] = $v->platform_name;
            }

            $matchs = [];
            foreach ($register_platform as $rp) {
                $matchs[] = ["match" => ["register_platform" => $rp]];

                $names[] = $platformList[$rp];
            }

            $bool['must'][] = ['bool' => [
                "should" => $matchs,
                "minimum_should_match" => 1,
            ]];

            $logContent2 .= ' 注册平台:' . (implode(',', $names));
        }

        if (empty($fileType)) {
            $this->error('100809'); #请指定导出文件类型
        }
        if ($fileType == 2) {
            $title = ['phone'];
        }
        if (empty($title)) {
            $this->error('100804'); #请指定导出字段
        }
        foreach ($title as $titleKey => $titleValue) {
            if ($titleValue == 'export_state') {
                $title[$titleKey] = 'export_state';
            }
        }
        if (empty($exportType)) {
            $this->error('100806'); #请指定导出类型
        }
        if ($exportType == 1 && (empty($packageId))) {
            $this->error('100807'); #包id不能为空
        }
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        #export_at=》export_at

        $bool['must'][] = [
            'range' => [
                'number_package' => [
                    'gt' => 0,
                ],
            ],
        ];
        #pack
        if ($packageId) {
            $bool['must'][] = [
                'term' => [
                    'number_package' => $packageId,
                ],
            ];
        } else {
            $ids = DB::table('package')->select('id')->get();
            $ids = $ids->pluck('id')->all();
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $ids,
                ],
            ];
        };

        if (!empty($phone['is']) && count($phone['is']) > 0) {
            foreach ($phone['is'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'phone' => $phone['is'],
                ],
            ];
            $logContent .= '手机号码:' . implode(',', $phone['is']);
        };
        if (!empty($phone['not']) && count($phone['not']) > 0) {
            foreach ($phone['not'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'phone' => $phone['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '手机号码不是:' . implode(',', $phone['not']);
        };
        #export_at
        if (!empty($export_at['is']) && count($export_at['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_at' => $export_at['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出时间为:' . implode(',', $export_at['is']);
        };
        if (!empty($export_at['not']) && count($export_at['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_at' => $export_at['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出时间不为:' . implode(',', $export_at['not']);
        };
        #phone_segment
        if (!empty($phone_segment['is']) && count($phone_segment['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '手机号码前三位为:' . implode(',', $phone_segment['is']);
        };
        if (!empty($phone_segment['not']) && count($phone_segment['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '手机号码前三位不为:' . implode(',', $phone_segment['not']);
        };

        #export_state
        if (!empty($export_state['is']) && count($export_state['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_state' => $export_state['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出状态为:' . implode(',', $export_state['is']);
        };
        if (!empty($export_state['not']) && count($export_state['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_state' => $export_state['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出状态不为:' . implode(',', $export_state['not']);
        };

        #运营商

        if (!empty($company['is']) && count($company['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'company' => $company['is'],
                ],
            ];
            $tmpLogContent = '';
            foreach ($company['is'] as $value) {
                if ($value == 1) {
                    $tmpLogContent .= '中国移动,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '中国联通,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '中国电信,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '虚拟号,';
                }
                if ($value == 0) {
                    $tmpLogContent .= '为空,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '运营商:' . $tmpLogContent;
        };
        if (!empty($company['not']) && count($company['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'company' => $company['not'],
                ],
            ];
            $tmpLogContent = '';
            Log::info($company, 'test1');

            foreach ($company['not'] as $value) {
                Log::info($value, 'test1');
                if ($value == 1) {
                    $tmpLogContent .= '中国移动,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '中国联通,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '中国电信,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '虚拟号,';
                }
                if ($value == 0) {
                    $tmpLogContent .= '为空,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            Log::info($tmpLogContent, 'test1');
            $logContent .= '运营商不是:' . $tmpLogContent;
        };

        #省
        if (!empty($province['is']) && count($province['is']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '省:' . implode(',', $province['is']);
            foreach ($province['is'] as $key => $value) {
                if ($value == '为空') {
                    $province['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'province' => $province['is'],
                ],
            ];
        };
        if (!empty($province['not']) && count($province['not']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '省不是:' . implode(',', $province['not']);
            foreach ($province['not'] as $key => $value) {
                if ($value == '为空') {
                    $province['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'province' => $province['not'],
                ],
            ];
        };
        #市

        if (!empty($city['is']) && count($city['is']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '市:' . implode(',', $city['is']);
            foreach ($city['is'] as $key => $value) {
                if ($value == '为空') {
                    $city['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'city' => $city['is'],
                ],
            ];
        };
        if (!empty($city['not']) && count($city['not']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '市不是:' . implode(',', $city['not']);
            foreach ($city['not'] as $key => $value) {
                if ($value == '为空') {
                    $city['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'city' => $city['not'],
                ],
            ];
        };
        #属性
        if (!empty($type['is']) && count($type['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'type' => $type['is'],
                ],
            ];
            $tmpLogContent = '';
            foreach ($type['is'] as $value) {
                if ($value == 0) {
                    $tmpLogContent .= '未验证,';
                }
                if ($value == 1) {
                    $tmpLogContent .= '正常号,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '沉默号,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '危险号,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '空号,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '属性为:' . $tmpLogContent;
        };
        if (!empty($type['not']) && count($type['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'type' => $type['not'],
                ],
            ];
            $tmpLogContent = '';
            foreach ($type['not'] as $value) {
                if ($value == 0) {
                    $tmpLogContent .= '未验证,';
                }
                if ($value == 1) {
                    $tmpLogContent .= '正常号,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '沉默号,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '危险号,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '空号,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '属性不为:' . $tmpLogContent;
        };
        #是否注册
        if (!empty($is_register['is']) && count($is_register['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_register' => $is_register['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '注册';
        };
        if (!empty($is_register['not']) && count($is_register['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_register' => $is_register['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '未注册';
        };
        #注册平台
        if (!empty($register_platform['is']) && count($register_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'register_platform' => $register_platform['is'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $register_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '注册平台:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        if (!empty($register_platform['not']) && count($register_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'register_platform' => $register_platform['not'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $register_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '注册平台不为:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        #是否使用
        if (!empty($is_use['is']) && count($is_use['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_use' => $is_use['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用情况:已使用';
        };
        if (!empty($is_use['not']) && count($is_use['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_use' => $is_use['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用情况:未使用';
        };
        #使用平台
        if (!empty($use_platform['is']) && count($use_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'use_platform' => $use_platform['is'],
                ],
            ];

            $tmpPlat = DB::table('platform')->whereIn('id', $use_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用平台:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        if (!empty($use_platform['not']) && count($use_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'use_platform' => $use_platform['not'],
                ],
            ];

            $tmpPlat = DB::table('platform')->whereIn('id', $use_platform['not'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用平台不为:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        #use_time

        if (!empty($use_time) && count($use_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用时间为:';
            foreach ($use_time as $value) {
                $tmpRange = [];
                $tmpRange['use_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
            $logContent = trim($logContent, ',');
        };
        #use_last_time


        if (!empty($use_last_time) && count($use_last_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '最后使用时间为:';
                $tmpRange = [];
                $tmpRange['use_last_time'] = [
                    'gte' => $use_last_time[0],
                    'lte' => $use_last_time[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $use_last_time[0]) . '-' . date('Y-m-d H:i:s', $use_last_time[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            $logContent = rtrim($logContent, ',');
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_flow_time) && count($last_flow_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_flow_time'] = [
                'gte' => $last_flow_time[0],
                'lte' => $last_flow_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_bonus_time) && count($last_bonus_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_bonus_time'] = [
                'gte' => $last_bonus_time[0],
                'lte' => $last_bonus_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        #is_feedback

        if (!empty($is_feedback['is']) && count($is_feedback['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈:是';
        };
        if (!empty($is_feedback['not']) && count($is_feedback['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈:否';
        };
        #feedback_platform
        if (!empty($feedback_platform['is']) && count($feedback_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['is'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $feedback_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈平台:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        if (!empty($feedback_platform['not']) && count($feedback_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['not'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $feedback_platform['not'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈平台不为:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        #feedback_last_time
        if (!empty($feedback_last_time) && count($feedback_last_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '最后反馈时间为:';

            foreach ($feedback_last_time as $value) {
                $tmpRange = [];
                $tmpRange['feedback_last_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';

                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $logContent = rtrim($logContent, ',');
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        #number_package
        if (!empty($number_package['is']) && count($number_package['is']) > 0) {
            $realPackage = DB::table('package')->whereIn('package_name', $number_package['is'])->get();
            $realPackage = $realPackage->pluck('id');
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];

            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '关联包:';
            //记录

            foreach ($number_package['is'] as $key => $value) {
                $logContent .= $value . ',';
            }
            $logContent = rtrim($logContent, ',');
        };
        if (!empty($number_package['not']) && count($number_package['not']) > 0) {
            $realPackage = DB::table('package')->whereIn('package_name', $number_package['not'])->get();
            $realPackage = $realPackage->pluck('id');
            $bool['must_not'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '关联包:';
            //记录

            foreach ($number_package['not'] as $key => $value) {
                $logContent .= $value . ',';
            }
            $logContent = rtrim($logContent, ',');
        };

        #created_at

        if (!empty($created_at) && count($created_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '入库时间为:';
            foreach ($created_at as $value) {
                $tmpRange = [];
                $tmpRange['created_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $logContent = rtrim($logContent, ',');
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        #updated_at

        if (!empty($updated_at) && count($updated_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '修改时间为:';
            foreach ($updated_at as $value) {
                $tmpRange = [];
                $tmpRange['updated_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $logContent = rtrim($logContent, ',');
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };
        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
            ->setHosts($hosts) // Set the hosts
            ->build();

        if (count($bool) > 0) {
            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
                        "bool" => $bool,

                    ],
                ],

            ];
        } else {
            $params = [
                'index' => 'phone_info',
                'body' => [],

            ];
        }
        $startTime = date('Y-m-d H:i:s');
        $re = [];
        $data = [];
        $count = $client->count($params)['count'];
        $size = 100000;
        $params['size'] = $size;
        $params['scroll'] = '1m';
        $searchData = [];
        $params['_source'] = $title;
        if (in_array('use_platform_name', $title)) {
            array_push($params['_source'], 'use_platform');
        }
        if (in_array('register_platform_name', $title)) {
            array_push($params['_source'], 'register_platform');
        }
        if (in_array('feedback_platform', $title)) {
            array_push($params['_source'], 'feedback_platform_name');
        }
        array_push($params['_source'], 'number_package');
        $results = $client->search($params);

        if (count($results['hits']['hits']) < 0) {
            //没搜索到数据  好办
            $this->error(100805);
        }

        $searchCount = ceil($count / $size) - 1;
        $searchData = array_merge($searchData, $results['hits']['hits']);
        $scorllId = $results['_scroll_id'];

        for ($i = 0; $i < $searchCount; $i++) {
            $params = [];
            $params['scroll'] = '1m';
            $params['scroll_id'] = $scorllId;
            $results = $client->scroll($params);
            if (count($results['hits']['hits']) < 0) {
                //搜不到了  结束
                break;
            }

            $searchData = array_merge($searchData, $results['hits']['hits']);
        }
        // return response()->json([
        //     'code' => 200,
        //     'msg' => 'ok',
        //     'data' => [],
        //     'start_time' => $startTime,
        //     'end_time' => date('Y-m-d H:i:s')

        // ]);
        //得到searchData
        //开始写入excel
        $tmp_file_name = date('Y-m-d', time()) . rand(1000, 9999) . self::$uid;
        $fileTypeName = $fileType == 1 ? 'csv' : 'txt';
        $file_name = base_path('storage/exportfiles/') . $tmp_file_name . '.' . $fileTypeName;
        $fp = fopen($file_name, 'w');

        $titleDic = [
            'id' => '序号',
            'phone' => '号码',
            'company' => '运营商',
            'province' => '归属省',
            'city' => '归属市',
            'type' => '号码属性',
            'is_use' => '使用状态',
            'use_platform_name' => '使用平台',
            'is_register' => '注册状态',
            'register_platform_name' => '注册平台',
            'is_agent' => '是否代理',
            'feedback_platform' => '反馈平台',
            'is_feedback' => '反馈状态',
            'feedback_last_time' => '最后反馈日期',
            'use_last_time' => '最后使用日期',
            'number_package_name' => '关联号码包',
            'remark' => '备注内容',
            'price' => '入库价格',
            'created_at' => '入库时间',
            'number_status' => '号码状态',
            'last_week_is_recharge' => '近15日是否充值',
            'last_recharge_date' => '最后充值',
            'os' => '设备',
            'client_id' => '渠道号',
            'export_count' => '导出次数',
            'export_state' => '导出状态',
        ];

        $titleArr = [];
        foreach ($title as $key => $value) {

            array_push($titleArr, (array_key_exists($value, $titleDic) ? $titleDic[$value] : ''));
        }
        if ($fileType == 1) {
            fputcsv($fp, $titleArr);
        }

        $platformIds = [];

        //取出
        $number_package_ids = [];
        foreach ($searchData as $value) {
            if (!empty($value['_source']['use_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['use_platform']));
            }

            if (!empty($value['_source']['feedback_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['feedback_platform']));
            }

            if (!empty($value['_source']['register_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['register_platform']));
            }
            if (!empty($value['_source']['number_package'])) {
                $number_package_ids = array_unique(array_merge($number_package_ids, $value['_source']['number_package']));
            }
        }
        $packages = [];
        if (!empty($number_package_ids)) {
            $packages = DB::table('package')->whereIn('id', $number_package_ids)->get();
            $packages = $packages->keyBy('id')->all();
        }

        $platforms = [];
        if (!empty($platformIds)) {
            $platforms = DB::table('platform')->whereIn('id', $platformIds)->where('is_delete', 0)->get();
            $platforms = $platforms->keyBy('id')->all();
        }

        $lineNo = 0;
        foreach ($searchData as $key => $value) {
            $contentArr = [];
            foreach ($title as $titleKey => $titleValue) {
                $tmp = '';
                if (isset($value['_source'][$titleValue])) {

                    $tmp = $value['_source'][$titleValue];

                    if ($titleValue == 'id') {
                        $tmp = ++$lineNo;
                    }

                    if ($titleValue == 'use_platform_name') {
                        $tmp = [];

                        if (!empty($value['_source']['use_platform'])) {
                            foreach ($value['_source']['use_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'register_platform_name') {
                        $tmp = [];
                        if (!empty($value['_source']['register_platform'])) {
                            foreach ($value['_source']['register_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'feedback_platform') {
                        $tmp = [];
                        if (!empty($value['_source']['feedback_platform'])) {
                            foreach ($value['_source']['feedback_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'type') {

                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '未验证';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '正常号';
                        }
                        if ($value['_source'][$titleValue] == 2) {
                            $tmp = '沉默号';
                        }
                        if ($value['_source'][$titleValue] == 3) {
                            $tmp = '危险号';
                        }
                        if ($value['_source'][$titleValue] == 4) {
                            $tmp = '空号';
                        }
                    }
                    if ($titleValue == 'company') {

                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '移动';
                        }
                        if ($value['_source'][$titleValue] == 2) {
                            $tmp = '联通';
                        }
                        if ($value['_source'][$titleValue] == 3) {
                            $tmp = '电信';
                        }
                        if ($value['_source'][$titleValue] == 4) {
                            $tmp = '虚拟号';
                        }
                    }
                    if (in_array($titleValue, ['is_use', 'is_register', 'is_feedback', 'export_state'])) {

                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '否';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '是';
                        }
                    }

                    if ($titleValue == 'is_agent' && $value['_source'][$titleValue]) {
                        $agents = ['','普通用户','活跃代理','非活跃代理'];
                        $tmp = $agents[$value['_source'][$titleValue]];
                    }

                    if (in_array($titleValue, ['number_status'])) {
                        $tmp = '--';
                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '正常';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '封号';
                        }
                    }

                    if (in_array($titleValue, ['last_week_is_recharge'])) {
                        $tmp = '--';
                        if (isset($value['_source']['last_recharge_date']) && $value['_source']['last_recharge_date'] < $b15d) {
                            $tmp = '未充值';
                        }
                        if (isset($value['_source']['last_recharge_date']) && $value['_source']['last_recharge_date'] > $b15d) {
                            $tmp = '已充值';
                        }
                    }

                    if (in_array($titleValue, ['os'])) {
                        $tmp = '--';
                        if (isset($value['_source'][$titleValue]) && $value['_source'][$titleValue] == 1) {
                            $tmp = 'Android';
                        }
                        if (isset($value['_source'][$titleValue]) && $value['_source'][$titleValue] == 2) {
                            $tmp = 'IOS';
                        }
                    }

                    if (in_array($titleValue, ['last_recharge_date'])) {
                        $tmp = isset($value[$titleValue]) ? date('Y-m-d', $value[$titleValue]) : '--';
                    }

                    if (in_array($titleValue, ['client_id'])) {
                        $tmp = '';
                        foreach ($value['_source'][$titleValue] ?? []  as $kk => $vv) {
                            list($cc1, $cc2) = explode(':', $vv);
                            $tmp .= $this->getPlatforms($cc1) . ':' . $cc2;
                        }
                    }

                    if (in_array($titleValue, ['feedback_last_time', 'use_last_time', 'created_at'])) {
                        if (empty($value['_source'][$titleValue])) {
                            $tmp = '';
                        } else {
                            $tmp = date('Y-m-d', $value['_source'][$titleValue]);
                        }
                    }
                    if (in_array($titleValue, ['number_package', 'number_package_name'])) {
                        $packageIds = $value['_source']['number_package'];
                        $tmp = [];
                        foreach ($packageIds as $packageIdsKey => $packageIdsValue) {
                            if (!empty($packages[$packageIdsValue])) {
                                array_push($tmp, $packages[$packageIdsValue]->package_name);
                            }
                        }
                    }
                    if (is_array($tmp)) {
                        $tmp = implode(',', $tmp);
                    }
                }
                if (is_array($tmp)) {
                    $tmp = implode(',', $tmp);
                }
                array_push($contentArr, $tmp);
            }

            fputcsv($fp, $contentArr);
        }
        //写日志
        //

        $logArr = [];
        if (count($number_package) == 1) {
        }
        if ($exportType == 1) {
            $logArr['package_id'] = $packageId;
        } else {
            $logArr['package_id'] = 0;
        }

        $logArr['file_name'] = $tmp_file_name . "." . $fileTypeName;
        $logArr['condition'] = $logContent2;
        $logArr['admin_id'] = self::$uid;
        $logArr['export_path'] = $tmp_file_name . "." . $fileTypeName;
        $logArr['created_at'] = time();
        DB::table('package_export_log')->insert($logArr);
        $adminId = self::$uid;

        $token = JwtToken::getInstance()->getNameToken($tmp_file_name . "." . $fileTypeName, self::$uid);
        $sessionData = json_encode([
            'adminId' => $adminId,
            'name' => $tmp_file_name . "." . $fileTypeName,
        ]);
        #给这个文件增加一个token
        $sessionKeyPrefix = 'FILENAME:';
        $data['token'] = $token;
        $data['file'] = $tmp_file_name . "." . $fileTypeName;
        FacadesCache::put($sessionKeyPrefix . $token, $sessionData, config('Session.file_download_max_seconds'));

        $onlyPhone = array_column($searchData, '_id');

        Redis::Rpush('exportLogQueue', json_encode(['export_at' => time(), 'admin_name' => self::$userAccount, 'admin_id' => self::$uid, 'phone' => $onlyPhone, 'exportTime' => date('Y-m-d'), 'file_name' => $tmp_file_name . "." . $fileTypeName]));
        return response()->json([
            'code' => 200,
            'msg' => 'ok',
            'data' => $data,
            // 'start_time' => $startTime,
            // 'end_time' => date('Y-m-d H:i:s'),
            // 'ser' => $onlyPhone

        ]);

        //开始做导出日志

        // foreach($){

        // }

        //返回数组

    }

    public function uploadIntMobile(Request $request)
    {
        $packageId = $request->input('package_id') ?: 0;
        $nation = $request->input('nation') ?: 0;
        $money = $request->input('money') ?: 0;

        if ($request->hasFile('phone') && $request->file('phone')->isValid()) {
            $phone = $request->file('phone');
        }

        if (empty($packageId)) {
            $this->error(100701); #参数有误
        }

        if (empty($phone)) {
            $this->error(100703); #文件上传有误
        }

        $package = DB::table('package_international')->where('id', $packageId)->first();
        if (empty($package)) {
            $this->error(100704); #平台有误
        }
        //将文件存储后使用脚本跑
        $oldFilename = $phone->getClientOriginalName();
        $oldFilenameExp = explode('.', $oldFilename)[0];
        $mimeType = $phone->getClientOriginalExtension();
        $allowType = ['zip', 'txt'];
        if (!in_array($mimeType, $allowType)) {
            $this->error(100705); #文件格式有误
        }
        //新建上传地址

        // $dir = iconv("UTF-8", "GBK", storage_path('upload/'));//文件夹路径
        $tmpFilename = $oldFilenameExp . '_' . date('Y_m_d_H_i_s') . '_' . mt_rand(1000000, 9999999);
        $tmpFilename = str_replace('.', '', $tmpFilename);
        $tmpFilename = str_replace('zip', '', $tmpFilename);
        $tmpFilename = str_replace('/', '_', $tmpFilename);
        $tmpFilename = str_replace('txt', '_', $tmpFilename);
        $newFilename = $tmpFilename . '.' . $mimeType;

        $path = storage_path('upload') . '/' . $newFilename;
        #存储文件
        if (!is_dir(storage_path('upload'))) {
            Tools::makedir(storage_path('upload'));
        }
        file_put_contents($path, file_get_contents($phone->getPathname()));
        #是否合法
        $unzipDir = '';
        $cityArr = [];
        $provinceArr = [];
        $companyyArr = [];

        if ($mimeType == 'zip') {

            //解压出来看看是否合法
            $unzipDir = storage_path('upload/' . $tmpFilename . '/');

            $unzipBl = Tools::unzip($path, $unzipDir);

            if (!$unzipBl) {
                $this->error(100707); #zip格式有误
            }
            $txtArr = Tools::getTxtByDir($unzipDir);

            if (count($txtArr) == 0) {
                //无合法txt
                $this->error(100707); #解压后txt格式有误
            }

            foreach ($txtArr as $value) {
                $hasCity = 0;
                $hasCompany = 0;
                $hasProvince = 0;
                foreach (config('city.city') as $cityValue) {
                    if (strpos('a' . $value, $cityValue) > 0) {
                        $hasCity = 1;
                        $cityArr[$value] = $cityValue;
                    }
                }
                foreach (config('city.province') as $cityValue) {
                    if (strpos('a' . $value, $cityValue) > 0) {
                        $hasProvince = 1;
                        $provinceArr[$value] = $cityValue;
                    }
                }
                if (!$hasCity && !$hasProvince) {
                    $this->error(100708); #txt文件名中不存在城市名称
                }
                foreach (['移动', '联通', '电信', '虚拟'] as $companyValue) {
                    if (strpos('a' . $value, $companyValue) > 0) {
                        $hasCompany = 1;
                        $companyyArr[$value] = $companyValue;
                    }
                }
                if (!$hasCompany) {
                    $this->error(100709); #txt文件名中不存在归属地名称
                }
            }
        } else {

            $hasCity = 0;
            $hasCompany = 0;
//            foreach (config('city.city') as $cityValue) {
//                if (strpos('a' . $oldFilenameExp, $cityValue) > 0) {
//                    $hasCity = 1;
//                    $cityArr[$path] = $cityValue;
//                }
//            }
//            foreach (config('city.province') as $cityValue) {
//                if (strpos('a' . $oldFilenameExp, $cityValue) > 0) {
//                    $hasCity = 1;
//                    $provinceArr[$path] = $cityValue;
//                }
//            }
//            if (!$hasCity) {
//                $this->error(100708); #txt文件名中不存在城市名称
//            }
//            foreach (['移动', '联通', '电信', '虚拟'] as $companyValue) {
//                if (strpos('a' . $oldFilenameExp, $companyValue) > 0) {
//                    $hasCompany = 1;
//                    $companyyArr[$path] = $companyValue;
//                }
//            }
//            if (!$hasCompany) {
//                $this->error(100709); #txt文件名中不存在归属地名称
//            }
        }
        $insert = [
            'package_id' => (int) $packageId,
            'nation' => $nation,
            'admin_id' => self::$uid,
            'money_sum' => $money,
            'old_file_name' => $oldFilename,
            'new_file_name' => $newFilename,
            'is_deal' => 0,
            'type' => 1,
            'file_type' => $mimeType == 'zip' ? 2 : 1,
            'unzip_dir' => $unzipDir,
            'deal_schedule' => '0.00%',
            'created_at' => time(),
            'updated_at' => time(),

        ];
        $re = DB::table('package_int_upload_log')->insertGetId($insert);
        if (empty($re)) {
            $this->error(100706); #上传失败
        }
        $insert['uid'] = !empty(self::$uid) ? self::$uid : 0;
        $insert['package_name'] = $package->package_name;
        $insert['upload_id'] = $re;
        $insert['admin_name'] = self::$userAccount;
//        $insert['city_arr'] = $cityArr;
//        $insert['province_arr'] = $provinceArr;
//        $insert['company_arr'] = $companyyArr;
        $insert['nation'] = $nation;

        #写入redis

        Redis::Rpush('uploadIntMobile', json_encode($insert));
        // Cache::forever('');
        return $this->success(['id' => $insert['upload_id']]);
    }

    public function intPhoneList(Request $request)
    {
//        $params = $request->post();
//        var_dump($params);
        $b15d = strtotime('-15 days');
        //页码
        $page = $request->input('page') ?: 1; //
        $pageSize = $request->input('page_size') ?: 10; //
        $from = ($page - 1) * $pageSize;
        $packageId = $request->input('package_id') ?: 0; //
        $nation = $request->input('nation') ?: 0; //
        if(!$nation || !in_array($nation,['Thailand','Taiwan','Japan','India','Indonesia','America','Brazil'])){
            return $this->error(100806);
        }
        $index = 'phone_'.strtolower($nation);

        //筛选条件
        $phone = $request->input('phone') ?: [];
        $company = $request->input('company') ?: []; #运营商   传  1为移动  2为联通  3为电信  4为虚拟 0为空
        $province = $request->input('province') ?: []; #归属省
        $city = $request->input('city') ?: []; #归属市
        $type = $request->input('type') ?: []; #号码属性  0未验证,1正常号,2沉默号,3危险号,4空号
        $is_register = $request->input('is_register') ?: []; #注册状态 0为未注册  1为注册
        $register_platform = $request->input('register_platform') ?: []; #注册平台 传id
        $is_use = $request->input('is_use') ?: []; #使用状态  0为未使用 1为使用
        $use_platform = $request->input('use_platform') ?: []; #使用平台 传id
        $use_time = $request->input('use_time') ?: []; #使用时间  传区间
        $use_last_time = $request->input('use_last_time') ?: []; #最后使用时间  传区间
        $is_feedback = $request->input('is_feedback') ?: []; #反馈状态  0 未反馈  1反馈
        $feedback_platform = $request->input('feedback_platform') ?: []; #反馈平台   传id
        $feedback_last_time = $request->input('feedback_last_time') ?: []; #最后反馈日期
        $number_package = $request->input('number_package') ?: []; #关联号码包  传name
        $created_at = $request->input('created_at') ?: []; #入库时间
        $updated_at = $request->input('updated_at') ?: []; #修改时间
        $phone_segment = $request->input('phone_segment') ?: []; #号码前三位
        $export_state = $request->input('export_state') ?: []; #导出状态
        $export_at = $request->input('export_at') ?: []; #导出状态

        $number_status = $request->input('number_status'); #号码状态

        $phone = $request->input('phone') ?: "";
        $is_register = $request->input('is_register') ?: "";
        $is_agent = $request->input('is_agent') ?: "";
        $is_agent_gold = $request->input('is_agent_gold') ?: "";#是否产生代理收益
        $is_gold_flow = $request->input('is_gold_flow') ?: "";#是否有流水
        $last_flow_time = $request->input('last_flow_time') ?: []; #最后流水时间  传区间
        $is_get_lottery = $request->input('is_get_lottery') ?: "";#是否有领取彩金
        $last_bonus_time = $request->input('last_bonus_time') ?: [];#最后领取彩金时间
        $day30_spread_increase = $request->input('day30_spread_increase') ?: "";#30天内直属下级是否增加
        $day1_recharge_gold = $request->input('day1_recharge_gold') ?: "";#是否有流水
        $rwdv_percent = $request->input('rwdv_percent') ?: "";#充兑差百分比
        $type = $request->input('type') ?: "";
        $is_use = $request->input('is_use') ?: "";
        $number_status = $request->input('number_status') ?: "";
        $is_b15dsrc = $request->input('is_b15dsrc') ?: "";

        $bool = [];
        if ($phone !== "" && !is_array($phone)) {
            $phone = ["is" => [$phone]];
        }

        if ($is_register !== "" && !is_array($is_register)) {
            $is_register = ["is" => [$is_register]];
        }

        if ($type !== "" && !is_array($type)) {
            $type = ["is" => [$type]];
        }

        if ($is_use !== "" && !is_array($is_use)) {
            $is_use = ["is" => [$is_use]];
        }

        if ($is_b15dsrc !== "") {

            if ($is_b15dsrc == 1) {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['gt' => $b15d],
                    ],
                ];
            } else {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['lt' => $b15d],
                    ],
                ];
            }
        }

        if ($is_agent !== "") {
            $bool['must'][] = [
                'term' => [
                    'is_agent' => $is_agent,
                ],
            ];
        }

        if($is_agent_gold !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_agent_gold' => $is_agent_gold,
                ],
            ];
        }

        if($is_gold_flow != ''){
            $bool['must'][] = [
                'term' => [
                    'is_gold_flow' => (string)$is_gold_flow,
                ],
            ];
        }

        if($is_get_lottery !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_get_lottery' => $is_get_lottery,
                ],
            ];
        }

        if($day30_spread_increase !== ""){
            $bool['must'][] = [
                'term' => [
                    'day30_spread_increase' => $day30_spread_increase,
                ],
            ];
        }

        if($day1_recharge_gold !== ""){
            $tmpRange = [];
            switch ($day1_recharge_gold){
                case '1':
                    $tmpRange['day1_recharge_gold'] = [
                        'gt' => 5000,//5000以上
                    ];
                    break;
                case '2':
                    $tmpRange['day1_recharge_gold'] = [
                        'gte' => 500,//500-5000
                        'lte' => 5000,
                    ];
                    break;
                case '3':
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
                default:
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if($rwdv_percent !== ""){
            $tmpRange = [];
            switch ($rwdv_percent){
                case 1:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gt' => 50,//50以上
                    ];
                    break;
                case 2:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gte' => 30,//30-50
                        'lte' => 50,
                    ];
                    break;
                case 3:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
                default:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if ($number_status !== "" && !is_array($number_status)) {
            if ($number_status == 1) {
                $bool['must'][] = [
                    'term' => [
                        'number_status' => 1,
                    ],
                ];
            } else {
                $bool['must_not'][] = [
                    'exists' => [
                        'field' => 'number_status',
                    ],
                ];
            }
        }

        if (!empty($register_platform) && is_array($register_platform)) {
            $matchs = [];
            foreach ($register_platform as $rp) {
                $matchs[] = ["match" => ["register_platform" => $rp]];
            }

            $bool['must'][] = ['bool' => [
                "should" => $matchs,
                "minimum_should_match" => 1,
            ]];
        }

        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        #export_at=》export_at
        $bool['must'][] = [
            'range' => [
                'number_package' => [
                    'gt' => 0,
                ],
            ],
        ];
        if (!empty($export_at['is']) && count($export_at['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_at' => $export_at['is'],
                ],
            ];
        };
        if (!empty($export_at['not']) && count($export_at['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_at' => $export_at['not'],
                ],
            ];
        };
        #phone_segment
        if (!empty($phone_segment['is']) && count($phone_segment['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['is'],
                ],
            ];
        };
        if (!empty($phone_segment['not']) && count($phone_segment['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['not'],
                ],
            ];
        };

        #pack
        if ($packageId) {
            $bool['must'][] = [
                'term' => [
                    'number_package' => $packageId,
                ],
            ];
        } else {
            $ids = DB::table('package_international')->select('id')->get();
            $ids = $ids->pluck('id')->all();
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $ids,
                ],
            ];
        };
        #手机号
        if (!empty($phone['is']) && count($phone['is']) > 0) {
            foreach ($phone['is'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'phone' => $phone['is'],
                ],
            ];
        };
        if (!empty($phone['not']) && count($phone['not']) > 0) {
            foreach ($phone['not'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'phone' => $phone['not'],
                ],
            ];
        };
        #运营商

        if (!empty($company['is']) && count($company['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'company' => $company['is'],
                ],
            ];
        };
        if (!empty($company['not']) && count($company['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'company' => $company['not'],
                ],
            ];
        };
        #省
        if (!empty($province['is']) && count($province['is']) > 0) {

            foreach ($province['is'] as $key => $value) {
                if ($value == '为空') {
                    $province['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'province' => $province['is'],
                ],
            ];
        };
        if (!empty($province['not']) && count($province['not']) > 0) {
            foreach ($province['not'] as $key => $value) {
                if ($value == '为空') {
                    $province['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'province' => $province['not'],
                ],
            ];
        };
        #市
        if (!empty($city['is']) && count($city['is']) > 0) {
            foreach ($city['is'] as $key => $value) {
                if ($value == '为空') {
                    $city['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'city' => $city['is'],
                ],
            ];
        };
        if (!empty($city['not']) && count($city['not']) > 0) {
            foreach ($city['not'] as $key => $value) {
                if ($value == '为空') {
                    $city['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'city' => $city['not'],
                ],
            ];
        };
        #属性
        if (!empty($type['is']) && count($type['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'type' => $type['is'],
                ],
            ];
        };
        if (!empty($type['not']) && count($type['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'type' => $type['not'],
                ],
            ];
        };
        #是否注册
        if (!empty($is_register['is']) && count($is_register['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_register' => $is_register['is'],
                ],
            ];
        };
        if (!empty($is_register['not']) && count($is_register['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_register' => $is_register['not'],
                ],
            ];
        };

        #是否注册
        if (!empty($is_register['is']) && count($is_register['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_register' => $is_register['is'],
                ],
            ];
        };
        if (!empty($is_register['not']) && count($is_register['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_register' => $is_register['not'],
                ],
            ];
        };
        #注册平台
        if (!empty($register_platform['is']) && count($register_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'register_platform' => $register_platform['is'],
                ],
            ];
        };
        if (!empty($register_platform['not']) && count($register_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'register_platform' => $register_platform['not'],
                ],
            ];
        };
        #是否使用
        if (!empty($is_use['is']) && count($is_use['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_use' => $is_use['is'],
                ],
            ];
        };
        if (!empty($is_use['not']) && count($is_use['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_use' => $is_use['not'],
                ],
            ];
        };
        #export_state
        if (!empty($export_state['is']) && count($export_state['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_state' => $export_state['is'],
                ],
            ];
        };
        if (!empty($export_state['not']) && count($export_state['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_state' => $export_state['not'],
                ],
            ];
        };

        #使用平台
        if (!empty($use_platform['is']) && count($use_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'use_platform' => $use_platform['is'],
                ],
            ];
        };
        if (!empty($use_platform['not']) && count($use_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'use_platform' => $use_platform['not'],
                ],
            ];
        };
        #use_time

        if (!empty($use_time) && count($use_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($use_time as $value) {
                $tmpRange = [];
                $tmpRange['use_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };
        #use_last_time

        if (!empty($use_last_time) && count($use_last_time) > 0) {
            $tmpRange = [];
            $tmpRange['use_last_time'] = [
                'gte' => $use_last_time[0],
                'lte' => $use_last_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_flow_time) && count($last_flow_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_flow_time'] = [
                'gte' => $last_flow_time[0],
                'lte' => $last_flow_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_bonus_time) && count($last_bonus_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_bonus_time'] = [
                'gte' => $last_bonus_time[0],
                'lte' => $last_bonus_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        #is_feedback

        if (!empty($is_feedback['is']) && count($is_feedback['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['is'],
                ],
            ];
        };
        if (!empty($is_feedback['not']) && count($is_feedback['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['not'],
                ],
            ];
        };
        #feedback_platform
        if (!empty($feedback_platform['is']) && count($feedback_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['is'],
                ],
            ];
        };
        if (!empty($feedback_platform['not']) && count($feedback_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['not'],
                ],
            ];
        };
        #feedback_last_time
        if (!empty($feedback_last_time) && count($feedback_last_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($feedback_last_time as $value) {
                $tmpRange = [];
                $tmpRange['feedback_last_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        #number_package
        if (!empty($number_package['is']) && count($number_package['is']) > 0) {
            $realPackage = DB::table('package_international')->whereIn('package_name', $number_package['is'])->get();

            $realPackage = $realPackage->pluck('id');

            $bool['must'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];
        };
        if (!empty($number_package['not']) && count($number_package['not']) > 0) {
            $realPackage = DB::table('package_international')->whereIn('package_name', $number_package['not'])->get();
            $realPackage = $realPackage->pluck('id');
            $bool['must_not'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];
        };

        #created_at

        if (!empty($created_at) && count($created_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($created_at as $value) {
                $tmpRange = [];
                $tmpRange['created_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };
        #updated_at

        if (!empty($updated_at) && count($updated_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];

            foreach ($updated_at as $value) {
                $tmpRange = [];
                $tmpRange['updated_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
        ->setHosts($hosts) // Set the hosts
        ->build();

        if (count($bool) > 0) {
            $params = [
                'index' => $index,
                'body' => [
                    "query" => [
                        "bool" => $bool,
                    ],
                    'size' => $pageSize,
                    'from' => $from,
                ],
            ];
        } else {
            $params = [
                'index' => $index,
                'body' => [

                    'size' => $pageSize,
                    'from' => $from,
                ],
            ];
        }

        $re = [];
        $data = [];
//        print_r($params);exit;
        $results = $client->search($params);

        unset($params['body']['size']);
        unset($params['body']['from']);
        $count = $client->count($params);
        $number_package_ids = [];

        if (!empty($results['hits']['total']['value'])) {
            $platformIds = [];

            foreach ($results['hits']['hits'] as $value) {
                array_push($data, $value['_source']);

                //存在部分历史数据有些问题  直接兼容
                if (!empty($value['_source']['use_platform'])) {
                    $platformIds = array_unique(array_merge($platformIds, $value['_source']['use_platform']));
                }
                if (!empty($value['_source']['register_platform'])) {
                    $platformIds = array_unique(array_merge($platformIds, $value['_source']['register_platform']));
                }
                if (!empty($value['_source']['feedback_platform'])) {
                    $platformIds = array_unique(array_merge($platformIds, $value['_source']['feedback_platform']));
                }
                if (!empty($value['_source']['number_package'])) {
                    $number_package_ids = array_unique(array_merge($number_package_ids, $value['_source']['number_package']));
                }
            }

            $platforms = [];
            if (!empty($platformIds)) {
                $platforms = DB::table('platform')->whereIn('id', $platformIds)->where('is_delete', 0)->get();
                $platforms = $platforms->keyBy('id')->all();
            }
            $packages = [];
            if (!empty($number_package_ids)) {
                $packages = DB::table('package_international')->whereIn('id', $number_package_ids)->get();
                $packages = $packages->keyBy('id')->all();
            }

            foreach ($data as $k => $vl) {
                $data[$k]['number_package_name'] = [];
                if (!empty($data[$k]['number_package'])) {
                    foreach ($data[$k]['number_package'] ?? [] as $pfId) {
                        if (isset($packages[$pfId])) {
                            $data[$k]['number_package_name'][] = $packages[$pfId]->package_name;
                        }
                    }
                }

                $data[$k]['use_platform_name'] = [];
                if (!empty($data[$k]['use_platform'])) {
                    foreach ($data[$k]['use_platform'] ?? [] as $pfId) {
                        if (isset($platforms[$pfId])) {
                            $data[$k]['use_platform_name'][] = $platforms[$pfId]->platform_name;
                        }
                    }
                }
                $data[$k]['register_platform_name'] = [];
                if (!empty($data[$k]['register_platform'])) {
                    foreach ($data[$k]['register_platform'] ?? [] as $pfId) {
                        if (isset($platforms[$pfId])) {
                            $data[$k]['register_platform_name'][] = $platforms[$pfId]->platform_name;
                        }
                    }
                }

                $data[$k]['feedback_platform_name'] = [];
                if (!empty($data[$k]['feedback_platform'])) {
                    foreach ($data[$k]['feedback_platform'] ?? [] as $pfId) {
                        if (isset($platforms[$pfId])) {
                            $data[$k]['feedback_platform_name'][] = $platforms[$pfId]->platform_name;
                        }
                    }
                }

                $data[$k]['client_id'] = (array) ($data[$k]['client_id'] ?? []);
                foreach ($data[$k]['client_id'] as $kk => $vv) {
                    list($cc1, $cc2) = explode(':', $vv);
                    $data[$k]['client_id'][$kk] = $this->getPlatforms($cc1) . ':' . $cc2;
                }

                $ds = $data[$k]['last_recharge_date'] ?? 0;
                $data[$k]['last_week_is_recharge'] = $ds > $b15d ? 1 : 0;
                $data[$k]['last_recharge_date'] = isset($data[$k]['last_recharge_date']) ? date('Y-m-d', $data[$k]['last_recharge_date']) : '--';
            }

            $re['data'] = $data;
            $re['count'] = $count['count'];
            $re['total'] = ceil($count['count'] / $pageSize);
            $re['currentPage'] = $page;
        }
        return $this->success($re);
    }

    public function exportIntMobile(Request $request)
    {
        set_time_limit(0);
        ini_set('memory_limit', -1);
        $b15d = strtotime('-15 days');

        if (!is_dir(storage_path('exportfiles'))) {
            Tools::makedir(storage_path('exportfiles'));
        }

        $packageId = $request->input('package_id') ?: 0; //
        $title = $request->input('title') ?: []; //
        $exportType = $request->input('exportType') ?: 0; //导出类型  1为包内导出  2为全部导出
        $fileType = $request->input('fileType') ?: 0; //导出类型  1为excel  2为phone
        //筛选条件

        $phone = $request->input('phone') ?: '';
        $company = $request->input('company') ?: []; #运营商   传  1为移动  2为联通  3为电信  4为虚拟 0为空
        $province = $request->input('province') ?: []; #归属省
        $city = $request->input('city') ?: []; #归属市
        $type = $request->input('type') ?: []; #号码属性  0未验证,1正常号,2沉默号,3危险号,4空号
        $is_register = $request->input('is_register') ?: []; #注册状态 0为未注册  1为注册
        $register_platform = $request->input('register_platform') ?: []; #注册平台 传id
        $is_use = $request->input('is_use') ?: []; #使用状态  0为未使用 1为使用
        $use_platform = $request->input('use_platform') ?: []; #使用平台 传id
        $use_time = $request->input('use_time') ?: []; #使用时间  传区间
        $use_last_time = $request->input('use_last_time') ?: []; #最后使用时间  传区间
        $is_feedback = $request->input('is_feedback') ?: []; #反馈状态  0 未反馈  1反馈
        $feedback_platform = $request->input('feedback_platform') ?: []; #反馈平台   传id
        $feedback_last_time = $request->input('feedback_last_time') ?: []; #最后反馈日期
        $number_package = $request->input('number_package') ?: []; #关联号码包  传name
        $created_at = $request->input('created_at') ?: []; #入库时间
        $updated_at = $request->input('updated_at') ?: []; #修改时间
        $phone_segment = $request->input('phone_segment') ?: []; #号码前三位
        $export_state = $request->input('export_state') ?: []; #导出状态
        $export_at = $request->input('export_at') ?: []; #导出状态

        $number_status = $request->input('number_status'); #号码状态

        $phone = $request->input('phone') ?: "";
        $is_register = $request->input('is_register') ?: "";
        $type = $request->input('type') ?: "";
        $is_use = $request->input('is_use') ?: "";
        $number_status = $request->input('number_status') ?: "";
        $is_b15dsrc = $request->input('is_b15dsrc') ?: "";
        $is_agent = $request->input('is_agent') ?: "";

        $is_agent_gold = $request->input('is_agent_gold') ?: "";#是否产生代理收益
        $is_gold_flow = $request->input('is_gold_flow') ?: "";#是否有流水
        $last_flow_time = $request->input('last_flow_time') ?: [];#是否有流水
        $is_get_lottery = $request->input('is_get_lottery') ?: "";#是否有彩金
        $last_bonus_time = $request->input('last_bonus_time') ?: [];#彩金时间
        $day30_spread_increase = $request->input('day30_spread_increase') ?: "";#30天内直属下级是否增加
        $day1_recharge_gold = $request->input('day1_recharge_gold') ?: "";#是否有流水
        $rwdv_percent = $request->input('rwdv_percent') ?: "";#充兑差百分比
        $nation = $request->input('nation');
        if(!$nation || !in_array($nation,['Thailand','Japan','Taiwan','India','Indonesia','America','Brazil'])){
            $this->error(100806);
        }
        $index = 'phone_'.strtolower($nation);
        $bool = [];
        #手机号
        $logContent = '';
        $logContent2 = '';
        if ($phone !== "" && !is_array($phone)) {
            $logContent2 .= '手机号码:' . $phone;
            $phone = ["is" => [$phone]];
        }

        if ($is_register !== "" && !is_array($is_register)) {
            $is_register = ["is" => [$is_register]];
            $logContent2 .= ' 注册:' . ($is_register ? '是' : '否');
        }

        if ($type !== "" && !is_array($type)) {
            $types = [
                0 => '未验证',
                1 => '正常号',
                2 => '沉默号',
                3 => '危险号',
                4 => '空号',
            ];
            $logContent2 .= ' 类型:' . ($types[$type]);
            $type = ["is" => [$type]];

        }

        if ($is_use !== "" && !is_array($is_use)) {
            $logContent2 .= ' 已使用:' . ($is_use ? '是' : '否');
            $is_use = ["is" => [$is_use]];

        }

        if ($is_b15dsrc !== "") {
            $logContent2 .= ' 近15天充值:' . ($is_b15dsrc ? '是' : '否');
            if ($is_b15dsrc == 1) {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['gt' => $b15d],
                    ],
                ];
            } else {
                $bool['must'][] = [
                    'range' => [
                        'last_recharge_date' => ['lt' => $b15d],
                    ],
                ];
            }
        }
        if ($is_agent !== "") {

            $bool['must'][] = [
                'range' => [
                    'is_agent' => $is_agent,
                ],
            ];

        }

        if($is_agent_gold !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_agent_gold' => $is_agent_gold,
                ],
            ];
        }
        if($is_gold_flow != ''){
            $bool['must'][] = [
                'term' => [
                    'is_gold_flow' => (string)$is_gold_flow,
                ],
            ];
        }

        if($is_get_lottery !== ""){
            $bool['must'][] = [
                'term' => [
                    'is_get_lottery' => $is_get_lottery,
                ],
            ];
        }
        if($day30_spread_increase !== ""){
            $bool['must'][] = [
                'term' => [
                    'day30_spread_increase' => $day30_spread_increase,
                ],
            ];
        }

        if($day1_recharge_gold !== ""){
            $tmpRange = [];
            switch ($day1_recharge_gold){
                case '1':
                    $tmpRange['day1_recharge_gold'] = [
                        'gt' => 5000,//5000以上
                    ];
                    break;
                case '2':
                    $tmpRange['day1_recharge_gold'] = [
                        'gte' => 500,//500-5000
                        'lte' => 5000,
                    ];
                    break;
                case '3':
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
                default:
                    $tmpRange['day1_recharge_gold'] = [
                        'lt' => 500,//500以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if($rwdv_percent !== ""){
            $tmpRange = [];
            switch ($rwdv_percent){
                case 1:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gt' => 50,//50以上
                    ];
                    break;
                case 2:
                    $tmpRange['day1_rwdv_percent'] = [
                        'gte' => 30,//30-50
                        'lte' => 50,
                    ];
                    break;
                case 3:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
                default:
                    $tmpRange['day1_rwdv_percent'] = [
                        'lt' => 30,//30以下
                    ];
                    break;
            }
            $bool['must'][] = ['range' => $tmpRange];
        }

        if ($number_status !== "" && !is_array($number_status)) {
            if ($number_status == 1) {
                $bool['must'][] = [
                    'term' => [
                        'number_status' => 1,
                    ],
                ];
            } else {
                $bool['must_not'][] = [
                    'exists' => [
                        'field' => 'number_status',
                    ],
                ];
            }
        }

        if ($number_status !== "" && !is_array($number_status)) {
            if ($number_status == 1) {
                $bool['must'][] = [
                    'term' => [
                        'number_status' => 1,
                    ],
                ];
            } else {
                $bool['must_not'][] = [
                    'exists' => [
                        'field' => 'number_status',
                    ],
                ];
            }

            $logContent2 .= ' 状态:' . ($number_status ? '封号' : '未封号');
        }

        if (!empty($register_platform) && is_array($register_platform)) {
            $sql = "select * from pnl_platform";
            $db = DB::select($sql);
            $platformList = [];
            $names = [];
            foreach ($db as $v) {
                $platformList[$v->id] = $v->platform_name;
            }

            $matchs = [];
            foreach ($register_platform as $rp) {
                $matchs[] = ["match" => ["register_platform" => $rp]];

                $names[] = $platformList[$rp];
            }

            $bool['must'][] = ['bool' => [
                "should" => $matchs,
                "minimum_should_match" => 1,
            ]];

            $logContent2 .= ' 注册平台:' . (implode(',', $names));
        }

        if (empty($fileType)) {
            $this->error('100809'); #请指定导出文件类型
        }
        if ($fileType == 2) {
            $title = ['phone'];
        }
        if (empty($title)) {
            $this->error('100804'); #请指定导出字段
        }
        foreach ($title as $titleKey => $titleValue) {
            if ($titleValue == 'export_state') {
                $title[$titleKey] = 'export_state';
            }
        }
        if (empty($exportType)) {
            $this->error('100806'); #请指定导出类型
        }
        if ($exportType == 1 && (empty($packageId))) {
            $this->error('100807'); #包id不能为空
        }
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ],
            #可传多个节点
        ];

        #export_at=》export_at

        $bool['must'][] = [
            'range' => [
                'number_package' => [
                    'gt' => 0,
                ],
            ],
        ];
        #pack
        if ($packageId) {
            $bool['must'][] = [
                'term' => [
                    'number_package' => $packageId,
                ],
            ];
        } else {
            $ids = DB::table('package')->select('id')->get();
            $ids = $ids->pluck('id')->all();
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $ids,
                ],
            ];
        };

        if (!empty($phone['is']) && count($phone['is']) > 0) {
            foreach ($phone['is'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'phone' => $phone['is'],
                ],
            ];
            $logContent .= '手机号码:' . implode(',', $phone['is']);
        };
        if (!empty($phone['not']) && count($phone['not']) > 0) {
            foreach ($phone['not'] as $value) {
                //
                if (!Phone::checkOperator($value)) {
                    $this->error('100803'); #手机号码不符合规范
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'phone' => $phone['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '手机号码不是:' . implode(',', $phone['not']);
        };
        #export_at
        if (!empty($export_at['is']) && count($export_at['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_at' => $export_at['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出时间为:' . implode(',', $export_at['is']);
        };
        if (!empty($export_at['not']) && count($export_at['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_at' => $export_at['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出时间不为:' . implode(',', $export_at['not']);
        };
        #phone_segment
        if (!empty($phone_segment['is']) && count($phone_segment['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '手机号码前三位为:' . implode(',', $phone_segment['is']);
        };
        if (!empty($phone_segment['not']) && count($phone_segment['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'phone_segment' => $phone_segment['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '手机号码前三位不为:' . implode(',', $phone_segment['not']);
        };

        #export_state
        if (!empty($export_state['is']) && count($export_state['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'export_state' => $export_state['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出状态为:' . implode(',', $export_state['is']);
        };
        if (!empty($export_state['not']) && count($export_state['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'export_state' => $export_state['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '导出状态不为:' . implode(',', $export_state['not']);
        };

        #运营商

        if (!empty($company['is']) && count($company['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'company' => $company['is'],
                ],
            ];
            $tmpLogContent = '';
            foreach ($company['is'] as $value) {
                if ($value == 1) {
                    $tmpLogContent .= '中国移动,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '中国联通,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '中国电信,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '虚拟号,';
                }
                if ($value == 0) {
                    $tmpLogContent .= '为空,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '运营商:' . $tmpLogContent;
        };
        if (!empty($company['not']) && count($company['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'company' => $company['not'],
                ],
            ];
            $tmpLogContent = '';
            Log::info($company, 'test1');

            foreach ($company['not'] as $value) {
                Log::info($value, 'test1');
                if ($value == 1) {
                    $tmpLogContent .= '中国移动,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '中国联通,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '中国电信,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '虚拟号,';
                }
                if ($value == 0) {
                    $tmpLogContent .= '为空,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            Log::info($tmpLogContent, 'test1');
            $logContent .= '运营商不是:' . $tmpLogContent;
        };

        #省
        if (!empty($province['is']) && count($province['is']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '省:' . implode(',', $province['is']);
            foreach ($province['is'] as $key => $value) {
                if ($value == '为空') {
                    $province['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'province' => $province['is'],
                ],
            ];
        };
        if (!empty($province['not']) && count($province['not']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '省不是:' . implode(',', $province['not']);
            foreach ($province['not'] as $key => $value) {
                if ($value == '为空') {
                    $province['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'province' => $province['not'],
                ],
            ];
        };
        #市

        if (!empty($city['is']) && count($city['is']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '市:' . implode(',', $city['is']);
            foreach ($city['is'] as $key => $value) {
                if ($value == '为空') {
                    $city['is'][$key] = '';
                }
            }
            $bool['must'][] = [
                'terms' => [
                    'city' => $city['is'],
                ],
            ];
        };
        if (!empty($city['not']) && count($city['not']) > 0) {
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '市不是:' . implode(',', $city['not']);
            foreach ($city['not'] as $key => $value) {
                if ($value == '为空') {
                    $city['not'][$key] = '';
                }
            }
            $bool['must_not'][] = [
                'terms' => [
                    'city' => $city['not'],
                ],
            ];
        };
        #属性
        if (!empty($type['is']) && count($type['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'type' => $type['is'],
                ],
            ];
            $tmpLogContent = '';
            foreach ($type['is'] as $value) {
                if ($value == 0) {
                    $tmpLogContent .= '未验证,';
                }
                if ($value == 1) {
                    $tmpLogContent .= '正常号,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '沉默号,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '危险号,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '空号,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '属性为:' . $tmpLogContent;
        };
        if (!empty($type['not']) && count($type['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'type' => $type['not'],
                ],
            ];
            $tmpLogContent = '';
            foreach ($type['not'] as $value) {
                if ($value == 0) {
                    $tmpLogContent .= '未验证,';
                }
                if ($value == 1) {
                    $tmpLogContent .= '正常号,';
                }
                if ($value == 2) {
                    $tmpLogContent .= '沉默号,';
                }
                if ($value == 3) {
                    $tmpLogContent .= '危险号,';
                }
                if ($value == 4) {
                    $tmpLogContent .= '空号,';
                }
            }
            $tmpLogContent = trim($tmpLogContent, ',');
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '属性不为:' . $tmpLogContent;
        };
        #是否注册
        if (!empty($is_register['is']) && count($is_register['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_register' => $is_register['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '注册';
        };
        if (!empty($is_register['not']) && count($is_register['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_register' => $is_register['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '未注册';
        };
        #注册平台
        if (!empty($register_platform['is']) && count($register_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'register_platform' => $register_platform['is'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $register_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '注册平台:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        if (!empty($register_platform['not']) && count($register_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'register_platform' => $register_platform['not'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $register_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '注册平台不为:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        #是否使用
        if (!empty($is_use['is']) && count($is_use['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_use' => $is_use['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用情况:已使用';
        };
        if (!empty($is_use['not']) && count($is_use['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_use' => $is_use['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用情况:未使用';
        };
        #使用平台
        if (!empty($use_platform['is']) && count($use_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'use_platform' => $use_platform['is'],
                ],
            ];

            $tmpPlat = DB::table('platform')->whereIn('id', $use_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用平台:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        if (!empty($use_platform['not']) && count($use_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'use_platform' => $use_platform['not'],
                ],
            ];

            $tmpPlat = DB::table('platform')->whereIn('id', $use_platform['not'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用平台不为:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        #use_time

        if (!empty($use_time) && count($use_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '使用时间为:';
            foreach ($use_time as $value) {
                $tmpRange = [];
                $tmpRange['use_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
            $logContent = trim($logContent, ',');
        };
        #use_last_time


        if (!empty($use_last_time) && count($use_last_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '最后使用时间为:';
            $tmpRange = [];
            $tmpRange['use_last_time'] = [
                'gte' => $use_last_time[0],
                'lte' => $use_last_time[1],
            ];
            $logContent .= date('Y-m-d H:i:s', $use_last_time[0]) . '-' . date('Y-m-d H:i:s', $use_last_time[1]) . ',';
            array_push($tmpShould, ['range' => $tmpRange]);
            $logContent = rtrim($logContent, ',');
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_flow_time) && count($last_flow_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_flow_time'] = [
                'gte' => $last_flow_time[0],
                'lte' => $last_flow_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        if (!empty($last_bonus_time) && count($last_bonus_time) > 0) {
            $tmpRange = [];
            $tmpRange['last_bonus_time'] = [
                'gte' => $last_bonus_time[0],
                'lte' => $last_bonus_time[1],
            ];
            $bool['must'][] = ['range' => $tmpRange];
        };

        #is_feedback

        if (!empty($is_feedback['is']) && count($is_feedback['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['is'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈:是';
        };
        if (!empty($is_feedback['not']) && count($is_feedback['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'is_feedback' => $is_feedback['not'],
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈:否';
        };
        #feedback_platform
        if (!empty($feedback_platform['is']) && count($feedback_platform['is']) > 0) {

            $bool['must'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['is'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $feedback_platform['is'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈平台:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        if (!empty($feedback_platform['not']) && count($feedback_platform['not']) > 0) {

            $bool['must_not'][] = [
                'terms' => [
                    'feedback_platform' => $feedback_platform['not'],
                ],
            ];
            $tmpPlat = DB::table('platform')->whereIn('id', $feedback_platform['not'])->get();
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '反馈平台不为:';
            if (count($tmpPlat) > 0) {
                //记录

                foreach ($tmpPlat as $key => $value) {
                    $logContent .= $value->platform_name . ',';
                }
                $logContent = rtrim($logContent, ',');
            }
        };
        #feedback_last_time
        if (!empty($feedback_last_time) && count($feedback_last_time) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '最后反馈时间为:';

            foreach ($feedback_last_time as $value) {
                $tmpRange = [];
                $tmpRange['feedback_last_time'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';

                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $logContent = rtrim($logContent, ',');
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        #number_package
        if (!empty($number_package['is']) && count($number_package['is']) > 0) {
            $realPackage = DB::table('package')->whereIn('package_name', $number_package['is'])->get();
            $realPackage = $realPackage->pluck('id');
            $bool['must'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];

            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '关联包:';
            //记录

            foreach ($number_package['is'] as $key => $value) {
                $logContent .= $value . ',';
            }
            $logContent = rtrim($logContent, ',');
        };
        if (!empty($number_package['not']) && count($number_package['not']) > 0) {
            $realPackage = DB::table('package')->whereIn('package_name', $number_package['not'])->get();
            $realPackage = $realPackage->pluck('id');
            $bool['must_not'][] = [
                'terms' => [
                    'number_package' => $realPackage,
                ],
            ];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '关联包:';
            //记录

            foreach ($number_package['not'] as $key => $value) {
                $logContent .= $value . ',';
            }
            $logContent = rtrim($logContent, ',');
        };

        #created_at

        if (!empty($created_at) && count($created_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '入库时间为:';
            foreach ($created_at as $value) {
                $tmpRange = [];
                $tmpRange['created_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $logContent = rtrim($logContent, ',');
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };

        #updated_at

        if (!empty($updated_at) && count($updated_at) > 0) {
            $tmpBool = [];
            $tmpShould = [];
            if ($logContent) {
                $logContent .= ';';
            }

            $logContent .= '修改时间为:';
            foreach ($updated_at as $value) {
                $tmpRange = [];
                $tmpRange['updated_at'] = [
                    'gte' => $value[0],
                    'lte' => $value[1],
                ];
                $logContent .= date('Y-m-d H:i:s', $value[0]) . '-' . date('Y-m-d H:i:s', $value[1]) . ',';
                array_push($tmpShould, ['range' => $tmpRange]);
            }
            $logContent = rtrim($logContent, ',');
            $tmpBool['should'] = $tmpShould;
            $bool['must'][] = ['bool' => $tmpBool];
        };
        $client = ClientBuilder::create() // Instantiate a new ClientBuilder
        ->setHosts($hosts) // Set the hosts
        ->build();

        if (count($bool) > 0) {
            $params = [
                'index' => $index,
                'body' => [
                    "query" => [
                        "bool" => $bool,

                    ],
                ],

            ];
        } else {
            $params = [
                'index' => $index,
                'body' => [],

            ];
        }
        $startTime = date('Y-m-d H:i:s');
        $re = [];
        $data = [];
        $count = $client->count($params)['count'];
        $size = 100000;
        $params['size'] = $size;
        $params['scroll'] = '1m';
        $searchData = [];
        $params['_source'] = $title;
        if (in_array('use_platform_name', $title)) {
            array_push($params['_source'], 'use_platform');
        }
        if (in_array('register_platform_name', $title)) {
            array_push($params['_source'], 'register_platform');
        }
        if (in_array('feedback_platform', $title)) {
            array_push($params['_source'], 'feedback_platform_name');
        }
        array_push($params['_source'], 'number_package');
        $results = $client->search($params);

        if (count($results['hits']['hits']) < 0) {
            //没搜索到数据  好办
            $this->error(100805);
        }

        $searchCount = ceil($count / $size) - 1;
        $searchData = array_merge($searchData, $results['hits']['hits']);
        $scorllId = $results['_scroll_id'];

        for ($i = 0; $i < $searchCount; $i++) {
            $params = [];
            $params['scroll'] = '1m';
            $params['scroll_id'] = $scorllId;
            $results = $client->scroll($params);
            if (count($results['hits']['hits']) < 0) {
                //搜不到了  结束
                break;
            }

            $searchData = array_merge($searchData, $results['hits']['hits']);
        }
        // return response()->json([
        //     'code' => 200,
        //     'msg' => 'ok',
        //     'data' => [],
        //     'start_time' => $startTime,
        //     'end_time' => date('Y-m-d H:i:s')

        // ]);
        //得到searchData
        //开始写入excel
        $tmp_file_name = date('Y-m-d', time()) . rand(1000, 9999) . self::$uid;
        $fileTypeName = $fileType == 1 ? 'csv' : 'txt';
        $file_name = base_path('storage/exportfiles/') . $tmp_file_name . '.' . $fileTypeName;
        $fp = fopen($file_name, 'w');

        $titleDic = [
            'id' => '序号',
            'phone' => '号码',
            'company' => '运营商',
            'province' => '归属省',
            'city' => '归属市',
            'type' => '号码属性',
            'is_use' => '使用状态',
            'use_platform_name' => '使用平台',
            'is_register' => '注册状态',
            'register_platform_name' => '注册平台',
            'is_agent' => '是否代理',
            'feedback_platform' => '反馈平台',
            'is_feedback' => '反馈状态',
            'feedback_last_time' => '最后反馈日期',
            'use_last_time' => '最后使用日期',
            'number_package_name' => '关联号码包',
            'remark' => '备注内容',
            'price' => '入库价格',
            'created_at' => '入库时间',
            'number_status' => '号码状态',
            'last_week_is_recharge' => '近15日是否充值',
            'last_recharge_date' => '最后充值',
            'os' => '设备',
            'client_id' => '渠道号',
            'export_count' => '导出次数',
            'export_state' => '导出状态',
        ];

        $titleArr = [];
        foreach ($title as $key => $value) {

            array_push($titleArr, (array_key_exists($value, $titleDic) ? $titleDic[$value] : ''));
        }
        if ($fileType == 1) {
            fputcsv($fp, $titleArr);
        }

        $platformIds = [];

        //取出
        $number_package_ids = [];
        foreach ($searchData as $value) {
            if (!empty($value['_source']['use_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['use_platform']));
            }

            if (!empty($value['_source']['feedback_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['feedback_platform']));
            }

            if (!empty($value['_source']['register_platform'])) {
                $platformIds = array_unique(array_merge($platformIds, $value['_source']['register_platform']));
            }
            if (!empty($value['_source']['number_package'])) {
                $number_package_ids = array_unique(array_merge($number_package_ids, $value['_source']['number_package']));
            }
        }
        $packages = [];
        if (!empty($number_package_ids)) {
            $packages = DB::table('package')->whereIn('id', $number_package_ids)->get();
            $packages = $packages->keyBy('id')->all();
        }

        $platforms = [];
        if (!empty($platformIds)) {
            $platforms = DB::table('platform')->whereIn('id', $platformIds)->where('is_delete', 0)->get();
            $platforms = $platforms->keyBy('id')->all();
        }

        $lineNo = 0;
        foreach ($searchData as $key => $value) {
            $contentArr = [];
            foreach ($title as $titleKey => $titleValue) {
                $tmp = '';
                if (isset($value['_source'][$titleValue])) {

                    $tmp = $value['_source'][$titleValue];

                    if ($titleValue == 'id') {
                        $tmp = ++$lineNo;
                    }

                    if ($titleValue == 'use_platform_name') {
                        $tmp = [];

                        if (!empty($value['_source']['use_platform'])) {
                            foreach ($value['_source']['use_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'register_platform_name') {
                        $tmp = [];
                        if (!empty($value['_source']['register_platform'])) {
                            foreach ($value['_source']['register_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'feedback_platform') {
                        $tmp = [];
                        if (!empty($value['_source']['feedback_platform'])) {
                            foreach ($value['_source']['feedback_platform'] as $pfId) {
                                if (isset($platforms[$pfId])) {
                                    $tmp[] = $platforms[$pfId]->platform_name;
                                }
                            }
                        }
                    }

                    if ($titleValue == 'type') {

                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '未验证';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '正常号';
                        }
                        if ($value['_source'][$titleValue] == 2) {
                            $tmp = '沉默号';
                        }
                        if ($value['_source'][$titleValue] == 3) {
                            $tmp = '危险号';
                        }
                        if ($value['_source'][$titleValue] == 4) {
                            $tmp = '空号';
                        }
                    }
                    if ($titleValue == 'company') {

                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '移动';
                        }
                        if ($value['_source'][$titleValue] == 2) {
                            $tmp = '联通';
                        }
                        if ($value['_source'][$titleValue] == 3) {
                            $tmp = '电信';
                        }
                        if ($value['_source'][$titleValue] == 4) {
                            $tmp = '虚拟号';
                        }
                    }
                    if (in_array($titleValue, ['is_use', 'is_register', 'is_feedback', 'export_state'])) {

                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '否';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '是';
                        }
                    }

                    if ($titleValue == 'is_agent' && $value['_source'][$titleValue]) {
                        $agents = ['','普通用户','活跃代理','非活跃代理'];
                        $tmp = $agents[$value['_source'][$titleValue]];
                    }

                    if (in_array($titleValue, ['number_status'])) {
                        $tmp = '--';
                        if ($value['_source'][$titleValue] == 0) {
                            $tmp = '正常';
                        }
                        if ($value['_source'][$titleValue] == 1) {
                            $tmp = '封号';
                        }
                    }

                    if (in_array($titleValue, ['last_week_is_recharge'])) {
                        $tmp = '--';
                        if (isset($value['_source']['last_recharge_date']) && $value['_source']['last_recharge_date'] < $b15d) {
                            $tmp = '未充值';
                        }
                        if (isset($value['_source']['last_recharge_date']) && $value['_source']['last_recharge_date'] > $b15d) {
                            $tmp = '已充值';
                        }
                    }

                    if (in_array($titleValue, ['os'])) {
                        $tmp = '--';
                        if (isset($value['_source'][$titleValue]) && $value['_source'][$titleValue] == 1) {
                            $tmp = 'Android';
                        }
                        if (isset($value['_source'][$titleValue]) && $value['_source'][$titleValue] == 2) {
                            $tmp = 'IOS';
                        }
                    }

                    if (in_array($titleValue, ['last_recharge_date'])) {
                        $tmp = isset($value[$titleValue]) ? date('Y-m-d', $value[$titleValue]) : '--';
                    }

                    if (in_array($titleValue, ['client_id'])) {
                        $tmp = '';
                        foreach ($value['_source'][$titleValue] ?? []  as $kk => $vv) {
                            list($cc1, $cc2) = explode(':', $vv);
                            $tmp .= $this->getPlatforms($cc1) . ':' . $cc2;
                        }
                    }

                    if (in_array($titleValue, ['feedback_last_time', 'use_last_time', 'created_at'])) {
                        if (empty($value['_source'][$titleValue])) {
                            $tmp = '';
                        } else {
                            $tmp = date('Y-m-d', $value['_source'][$titleValue]);
                        }
                    }
                    if (in_array($titleValue, ['number_package', 'number_package_name'])) {
                        $packageIds = $value['_source']['number_package'];
                        $tmp = [];
                        foreach ($packageIds as $packageIdsKey => $packageIdsValue) {
                            if (!empty($packages[$packageIdsValue])) {
                                array_push($tmp, $packages[$packageIdsValue]->package_name);
                            }
                        }
                    }
                    if (is_array($tmp)) {
                        $tmp = implode(',', $tmp);
                    }
                }
                if (is_array($tmp)) {
                    $tmp = implode(',', $tmp);
                }
                array_push($contentArr, $tmp);
            }

            fputcsv($fp, $contentArr);
        }
        //写日志
        //

        $logArr = [];
        if (count($number_package) == 1) {
        }
        if ($exportType == 1) {
            $logArr['package_id'] = $packageId;
        } else {
            $logArr['package_id'] = 0;
        }

        $logArr['file_name'] = $tmp_file_name . "." . $fileTypeName;
        $logArr['condition'] = $logContent2;
        $logArr['admin_id'] = self::$uid;
        $logArr['export_path'] = $tmp_file_name . "." . $fileTypeName;
        $logArr['created_at'] = time();
        DB::table('package_export_log')->insert($logArr);
        $adminId = self::$uid;

        $token = JwtToken::getInstance()->getNameToken($tmp_file_name . "." . $fileTypeName, self::$uid);
        $sessionData = json_encode([
            'adminId' => $adminId,
            'name' => $tmp_file_name . "." . $fileTypeName,
        ]);
        #给这个文件增加一个token
        $sessionKeyPrefix = 'FILENAME:';
        $data['token'] = $token;
        $data['file'] = $tmp_file_name . "." . $fileTypeName;
        FacadesCache::put($sessionKeyPrefix . $token, $sessionData, config('Session.file_download_max_seconds'));

        $onlyPhone = array_column($searchData, '_id');

//        Redis::Rpush('exportLogQueue', json_encode(['export_at' => time(), 'admin_name' => self::$userAccount, 'admin_id' => self::$uid, 'phone' => $onlyPhone, 'exportTime' => date('Y-m-d'), 'file_name' => $tmp_file_name . "." . $fileTypeName]));
        return response()->json([
            'code' => 200,
            'msg' => 'ok',
            'data' => $data,
            // 'start_time' => $startTime,
            // 'end_time' => date('Y-m-d H:i:s'),
            // 'ser' => $onlyPhone

        ]);

        //开始做导出日志

        // foreach($){

        // }

        //返回数组

    }

}
