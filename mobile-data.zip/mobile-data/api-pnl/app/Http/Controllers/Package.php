<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-06-12 11:46:08
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Http\Controllers\v1\Agreement.php
 */

namespace App\Http\Controllers;

use Elasticsearch\ClientBuilder;
use Illuminate\Http\Request;
use App\Http\Controllers\Common\Auth;
use App\Lib\Hash;
use Illuminate\Support\Facades\DB;
use App\Model\PackageLog as ModelPackageLog;
use App\Model\IntPackageLog;
use App\Model\EmailPackageLog;
use App\Lib\Tools;
use App\Lib\JwtToken;
use Illuminate\Support\Facades\Cache;

class Package extends Auth
{

    public static $es = null;

    public static function getESClient()
    {
        if (is_null(self::$es)) {
            $hosts = [
                [
                    'host' => env('ES_HOST'),
                    'port' => env('ES_PORT'),
                    'scheme' => 'http',
                    'user' => env('ES_USERNAME'),
                    'pass' => env('ES_PASSWORD'),
                ]
            ];
            self::$es = ClientBuilder::create()->setHosts($hosts)->build();
        }

        return static::$es;
    }


    /**
     * 包列表
     */
    public function getPackage(Request $request)
    {
        $keyword = trim($request->input('keyword')); #搜索关键字，包名
        $field = trim($request->input('field')); #要获取的列
        $pagesize = $request->input('pagesize') ?: 10;
        $labelId = $request->input('label_id'); #标签
        $date = $request->input('date'); #标签

        $package_id_list = [];
        if ($labelId) {

            $package_id_items = DB::table('package_label')
                ->where('label_id', $labelId)
                ->pluck('package_id');
            foreach ($package_id_items as $key => $value) {
                $package_id_list[] = $value;
            }
            if (empty($package_id_list)) {
                $package = [];
                $results = '';
                goto end;
            }
        }


        $packageSql = DB::table('package');

        if ($field) {
            $field_exp = explode(',', $field);

            if (in_array('admin_name', $field_exp)) {
                array_push($field_exp, 'admin_id');
            }

            $field_all = array(
                "id", "package_name", "mobile_table_sign", "created_at", "updated_at", "total", "real_total",
                "cmcc_sum", "cucc_sum", "ctcc_sum", "virtual_sum", "good_sum", "vacant_sum", "sleep_sum", "risk_sum",
                "date", "admin_id", "unverified_sum", "register_sum", "feedback_sum", "no_feedback_sum", "used_sum", "no_used_sum",
                "no_register_sum", "amount", "one_amount", "export_sum", "import_sum"
            );

            $field_list = array_intersect($field_all, $field_exp);
            if (empty($field_list)) {
                $this->error('100500'); #参数有误
            }
            array_push($field_list, 'amount');

            $packageSql = $packageSql->select($field_list);
        } else {
            $field_list = array(
                "id", "package_name", "mobile_table_sign", "created_at", "updated_at", "total", "real_total",
                "cmcc_sum", "cucc_sum", "ctcc_sum", "virtual_sum", "good_sum", "vacant_sum", "sleep_sum", "risk_sum",
                "date", "admin_id"
            );
            $field_exp = ['label'];
            array_push($field_list, 'amount');
            $packageSql = $packageSql->select($field_list);
            array_push($field_list, 'admin_name');
        }
        if (in_array('admin_name', $field_exp)) {
            array_push($field_list, 'admin_name');
        }

        $packageSql = $packageSql->where('is_delete', 0);

        if ($date) {
            $packageSql = $packageSql->where('date', $date);
        }

        if ($keyword) {
            $packageSql = $packageSql->where('package_name', 'like', '%' . $keyword . '%');
        }

        if ($package_id_list) {
            $packageSql = $packageSql->wherein('id', $package_id_list);
        }

        $results = $packageSql->orderBy('updated_at', 'desc')->paginate($pagesize);

        $package = $results->items();

        if (in_array('label', $field_exp)) {

            if ($package) {
                $package_id_list = [];
                foreach ($package as $key => $value) {
                    $package_id_list[] = $value->id;
                }
            }

            $package_label = DB::table('package_label as a')
                ->select('b.id as label_id', 'b.label_name', 'package_id')
                ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
                ->whereIn('package_id', $package_id_list)
                ->where('type', 1)
                ->where('b.is_delete', 0)
                ->get();

            foreach ($package_label as $key => $value) {
                $package_label_list[$value->package_id][] = $value;
            }

            foreach ($package as $key => $value) {

                $package[$key]->label = isset($package_label_list[$value->id]) ? $package_label_list[$value->id] : [];
            }
        }

        if (in_array('admin_name', $field_list)) {

            if ($package) {
                $package_id_list = [];
                foreach ($package as $key => $value) {
                    $admin_id_list[] = $value->admin_id;
                }
                $admin_name = DB::table('admin')
                    ->select('id', 'account')
                    ->whereIn('id', $admin_id_list)
                    ->get();

                foreach ($admin_name as $key => $value) {
                    $admin_name_list[$value->id] = $value;
                }
                foreach ($package as $key => $value) {
                    $package[$key]->admin_name = isset($admin_name_list[$value->admin_id]) ? $admin_name_list[$value->admin_id]->account : '';

                }
            }

        }
        foreach ($package as $key => $value) {
            $package[$key]->ratio = DB::table('package_ratio')
                ->leftJoin('package','package_ratio.com_package_id','=','package.id')
                ->where('package_id',$value->id)
                ->select(['package_name','dug_counts','dug_ratio'])
                ->orderBy('dug_counts','desc')
                ->limit(6)
                ->get();
        }
        end: $data['data'] = $this->getPackageById($package);
        $data['count'] =  $results ? count($results) : 0;
        $data['total'] =  $results ? $results->total() : 0;
        $data['currentPage'] = $results ? $results->currentPage() : 1;
        return $this->success($data);
    }


    /**
     * 获取一个包信息
     */
    public function getOnePackage(Request $request)
    {
        $packageId = trim($request->input('package_id', ''));

        if (!preg_match('/^([1-9]{1}\d{0,9})$/', $packageId)) {
            $this->error('100510'); #参数有误
        }

        $package = DB::table('package')
            ->select(
                'id as package_id',
                'package_name',
                'created_at',
                'total',
                'real_total',
                'cmcc_sum',
                'cucc_sum',
                'ctcc_sum',
                'virtual_sum',
                'good_sum',
                'vacant_sum',
                'sleep_sum',
                'risk_sum',
                'unverified_sum',
                'register_sum',
                'feedback_sum',
                'no_feedback_sum',
                'used_sum',
                'no_used_sum',
                'no_register_sum',
                'date',
                'amount',
                'one_amount',
                'last_month_good_sum'
            )
            ->where('id', $packageId)
            ->where('is_delete', 0)
            ->first();
        if (empty($package)) {
            $this->error('100510'); #参数有误
        }

        //从导出日志里统计导出次数
        $row_export_sum = DB::select('select count(*) as export_sum from pnl_package_export_log where package_id = ?', [$packageId]);
        $export_sum = $row_export_sum[0]->export_sum;

        //从导入日志里统计导入次数
        $row_import_sum = DB::select('select count(*) as import_sum from pnl_package_upload_log where package_id = ?', [$packageId]);
        $import_sum = $row_import_sum[0]->import_sum;
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        //从ES查询实时数据
        $params = [
            'index' => 'phone_info',
            'body' => [
                "query" => [

                    'bool' => [
                        'must' => [
                            [
                                'term' => [
                                    'number_package' => $packageId
                                ]
                            ]


                        ]
                    ]

                ]
            ]
        ];
        $total = $client->count($params);
        $total = !empty($total['count']) ? $total['count'] : 0;
        #移动
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 1]];


        $cmcc_sum = $client->count($params);
        $cmcc_sum = !empty($cmcc_sum['count']) ? $cmcc_sum['count'] : 0;
        #联通
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 2]];
        $cucc_sum = $client->count($params);
        $cucc_sum = !empty($cucc_sum['count']) ? $cucc_sum['count'] : 0;
        #电信
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 3]];
        $ctcc_sum = $client->count($params);
        $ctcc_sum = !empty($ctcc_sum['count']) ? $ctcc_sum['count'] : 0;
        #虚拟号
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 4]];
        $virtual_sum = $client->count($params);
        $virtual_sum = !empty($virtual_sum['count']) ? $virtual_sum['count'] : 0;


        #充值
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_use' => 1]];
        $used_sum = $client->count($params);
        $used_sum = !empty($used_sum['count']) ? $used_sum['count'] : 0;
        #未充值
        $no_used_sum = $total ? $total - $used_sum : 0;


        #注册
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_register' => 1]];
        $register_sum = $client->count($params);
        $register_sum = !empty($register_sum['count']) ? $register_sum['count'] : 0;
        #未注册
        $no_register_sum = $total ? $total - $register_sum : 0;

        #反馈
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_feedback' => 1]];
        $feedback_sum = $client->count($params);
        $feedback_sum = !empty($feedback_sum['count']) ? $feedback_sum['count'] : 0;
        #未反馈
        $no_feedback_sum = $total ? $total - $feedback_sum : 0;

        #活跃号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 1]];
        $good_sum = $client->count($params);
        $good_sum = !empty($good_sum['count']) ? $good_sum['count'] : 0;
        #沉默号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 2]];
        $sleep_sum = $client->count($params);
        $sleep_sum = !empty($sleep_sum['count']) ? $sleep_sum['count'] : 0;
        #风险号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 3]];
        $risk_sum = $client->count($params);
        $risk_sum = !empty($risk_sum['count']) ? $risk_sum['count'] : 0;
        #空号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 4]];
        $vacant_sum = $client->count($params);
        $vacant_sum = !empty($vacant_sum['count']) ? $vacant_sum['count'] : 0;

        # 充值
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_recharge' => 1]];
        $recharge_sum = $client->count($params);
        $recharge_sum = !empty($recharge_sum['count']) ? $recharge_sum['count'] : 0;

        #上周充值
        $b15ds = strtotime('-15 days');
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_register' => 1]];
        $params['body']['query']['bool']['must'][0] = [
            'range' => [
                'last_recharge_date' => ['gt' => $b15ds]
            ]
        ];
        $last_week_recharge_sum = $client->count($params);
        $last_week_recharge_sum = !empty($last_week_recharge_sum['count']) ? $last_week_recharge_sum['count'] : 0;



        $package->total =  $total;

        $package->cmcc_sum = (empty($package->total) ? '0' : ($cmcc_sum . '(' . number_format((($cmcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->vacant_sum = (empty($package->total) ? '0' : ($vacant_sum . '(' . number_format((($vacant_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->amount = number_format($package->amount, 2, '.', '');
        $package->register_sum = (empty($package->total) ? '0' : ($register_sum . '(' . number_format((($register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->no_register_sum = (empty($package->total) ? '0' : ($no_register_sum . '(' . number_format((($no_register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->real_total = (empty($package->total) ? '0' : ($package->real_total . '(' . number_format((($package->real_total / $package->total) * 100), 2, '.', '') . '%)'));
        $package->cucc_sum = (empty($package->total) ? '0' : ($cucc_sum . '(' . number_format((($cucc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->ctcc_sum = (empty($package->total) ? '0' : ($ctcc_sum . '(' . number_format((($ctcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->sleep_sum = (empty($package->total) ? '0' : ($sleep_sum . '(' . number_format((($sleep_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->one_amount = number_format($package->total == 0 ? 0 : $package->amount / $package->total, 2, '.', '') . '元/每条';
        $package->feedback_sum = (empty($package->total) ? '0' : ($feedback_sum . '(' . number_format((($feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->no_feedback_sum = (empty($package->total) ? '0' : ($no_feedback_sum . '(' . number_format((($no_feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));

        $package->risk_sum = (empty($package->total) ? '0' : ($risk_sum . '(' . number_format((($risk_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->used_sum = (empty($package->total) ? '0' : ($used_sum . '(' . number_format((($used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->no_used_sum = (empty($package->total) ? '0' : ($no_used_sum . '(' . number_format((($no_used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->good_sum = (empty($package->total) ? '0' : ($good_sum . '(' . number_format((($good_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->virtual_sum = (empty($package->total) ? '0' : ($virtual_sum . '(' . number_format((($virtual_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->last_week_recharge_sum = $last_week_recharge_sum;
        // $package->last_month_good_sum = $last_month_good_sum;
        $package->recharge_sum = $recharge_sum;


        // $package->total = $package->total . '';
        // $package->cmcc_sum = (empty($package->total) ? '0' : ($package->cmcc_sum . '(' . number_format((($package->cmcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->vacant_sum = (empty($package->total) ? '0' : ($package->vacant_sum . '(' . number_format((($package->vacant_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->amount = number_format($package->amount, 2, '.', '');
        // $package->register_sum = (empty($package->total) ? '0' : ($package->register_sum . '(' . number_format((($package->register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->no_register_sum = (empty($package->total) ? '0' : ($package->no_register_sum . '(' . number_format((($package->no_register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->real_total = (empty($package->total) ? '0' : ($package->real_total . '(' . number_format((($package->real_total / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->cucc_sum = (empty($package->total) ? '0' : ($package->cucc_sum . '(' . number_format((($package->cucc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->ctcc_sum = (empty($package->total) ? '0' : ($package->ctcc_sum . '(' . number_format((($package->ctcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->sleep_sum = (empty($package->total) ? '0' : ($package->sleep_sum . '(' . number_format((($package->sleep_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->one_amount = number_format($package->total == 0 ? 0 : $package->amount / $package->total, 2, '.', '') . '元/每条';
        // $package->feedback_sum = (empty($package->total) ? '0' : ($package->feedback_sum . '(' . number_format((($package->feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->no_feedback_sum = (empty($package->total) ? '0' : ($package->no_feedback_sum . '(' . number_format((($package->no_feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->unverified_sum = (empty($package->total) ? '0' : ($package->unverified_sum . '(' . number_format((($package->unverified_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->risk_sum = (empty($package->total) ? '0' : ($package->risk_sum . '(' . number_format((($package->risk_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->used_sum = (empty($package->total) ? '0' : ($package->used_sum . '(' . number_format((($package->used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->no_used_sum = (empty($package->total) ? '0' : ($package->no_used_sum . '(' . number_format((($package->no_used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->good_sum = (empty($package->total) ? '0' : ($package->good_sum . '(' . number_format((($package->good_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->virtual_sum = (empty($package->total) ? '0' : ($package->virtual_sum . '(' . number_format((($package->virtual_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->created_at = date('Y-m-d', $package->created_at);
        $package->date = (empty($package->date) ? '' : date('Y-m-d', strtotime($package->date)));
        $package->export_sum = $export_sum;
        $package->import_sum = $import_sum;

        $label = DB::table('package_label as a')
            ->select('b.id as label_id', 'b.label_name')
            ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
            ->where('a.package_id', $packageId)
            ->where('b.is_delete', 0)
            ->get();

        $data['package'] = $package;
        $data['label'] = $label->toArray();

        // $data['label_category_count'] = $this->getLabelsCount();
        $data['label_category_count'] = $this->getLabelsCount3($package->total,$packageId);
        return $this->success($data);
    }

    protected function getLabelsCount() {
        $sql = "SELECT id as label_id, label_name, label_total, ROUND((label_total / total) * 100, 2) AS proportion FROM (
            SELECT
            a.id,
            a.label_name,
            (
                SELECT SUM(p.total) AS total FROM pnl_package p 
                INNER JOIN pnl_package_label pl ON p.id = pl.package_id
                WHERE pl.label_id = a.id and p.is_delete=0
            ) AS label_total,
            
            (SELECT SUM(total) AS total FROM pnl_package WHERE is_delete=0) AS total
            
            FROM pnl_label a
            WHERE a.is_delete=0
            ORDER BY a.id ASC
        ) abc;";
        $res = DB::select($sql);

        return $res;
    }

    protected function getLabelsCount2($packageTotal) {
        $sql = 'select id, label_name from pnl_label where is_delete=0 order by id asc';
        $res = DB::select($sql);
        $output = [];
        foreach ($res as $v) {
            $v = (array) $v;
            $sql = "SELECT SUM(p.total) AS total FROM pnl_package p 
            INNER JOIN pnl_package_label pl ON p.id = pl.package_id
            WHERE pl.label_id ={$v['id']} and p.is_delete=0";
            $res2 = (array) DB::selectOne($sql);

            $output[] = ['label_id' => $v['id'], 
            'label_name' => $v['label_name'], 
            'label_total' => $res2['total'], 
            'proportion' => $res2['total'] > 0 ? sprintf('%.2f', ($packageTotal / $res2['total']) * 100) : 0
            ];
        }

        return $output;
    }

    protected function getLabelsCount3($packageTotal,$packageId) {
        $client = self::getESClient();

        $sql = 'select id, label_name from pnl_label where is_delete=0 order by id asc';
        $res = DB::select($sql);
        $output = [];

        foreach ($res as $v) {
            $v = (array) $v;
            $params = [
                'index' => 'phone_info',
                'body' => [
                    "query" => [
                        "bool" => [
                            'must'=>[
                                ['term'=>['number_package'=>$packageId]],
                                ['term'=>['labels'=>$v['id']]]
                            ],
                        ],
                    ]
                ],
            ];
//            $client->indices()->refresh();
            $res = $client->count($params);
            $output[] = ['label_id' => $v['id'],
                'label_name' => $v['label_name'],
                'label_total' => $res['count'],
                'proportion' => $packageTotal ? sprintf('%.2f', ($res['count']/$packageTotal) * 100) : 0 ,
            ];
        }

        return $output;
    }


    /**
     *  修改包信息
     *
     * @return Response
     */
    public function updatePackage(Request $request)
    {
        $adminId = self::$uid;
        $id =  $request->input('package_id');
        $name = trim($request->input('name')); #包名称
        $date = $request->input('date');
        $amount = $request->input('amount');
        $labelIdStr = $request->input('label_id_str'); #label_id逗号隔开
        if (empty($name)) {
            $this->error('100520'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100525'); #名称太长了
        }
        if (empty($date)) {
            $this->error('100521'); #记录日期不能为空
        }
        if ((!empty($amount) && $amount < 0)  ||  (!empty($amount) && !is_numeric($amount))) {
            $this->error('100527'); #金额不符合规则
        }
        $package = DB::table('package')->where('id', $id)->first();

        #该内容不存在
        if (empty($package)) {
            $this->error('100523');
        }

        $package2 = DB::table('package')->where('package_name', $name)->first();


        #该内容不存在
        if (!empty($package2) && $package2->id != $id && $name == $package2->package_name) {
            $this->error('100526'); #文件名已经存在
        }

        $labelIdList = [];
        if (!empty($labelIdStr)) {
            $labelIdList = explode(',', $labelIdStr);
        }


        $save['package_name'] = $name;
        $save['date'] = $date;
        $save['updated_at'] = time();
        $save['amount'] = $amount;


        #更新包组状态
        $result = DB::table('package')->where('id', $id)->update($save);

        if (!$result) {
            $this->error('100524'); #操作失败
        }
        $labelIdStrDb = '';
        $labelNameStrDb = '';
        $labelNameStrnew = '';
        #查询标签
        $labelList = DB::table('package_label as a')
            ->select('b.id as label_id', 'b.label_name')
            ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
            ->where('package_id', $id)
            ->orderBy('b.id', 'asc')
            ->get();
        foreach ($labelList as $key => $value) {
            $labelIdStrDb .= $value->label_id . ',';
            $labelNameStrDb .= $value->label_name . '、';
        }
        $labelIdStrDb = rtrim($labelIdStrDb, ",");
        $labelNameStrDb = rtrim($labelNameStrDb, "、");
        #查询标签
        $labelListNew = DB::table('label')
            ->select('id', 'label_name')
            ->whereIn('id', $labelIdList)
            ->orderBy('id', 'asc')
            ->get();
        foreach ($labelListNew as $key => $value) {
            $labelNameStrnew .= $value->label_name . '、';
        }
        $labelNameStrnew = rtrim($labelNameStrnew, "、");

        #编写日志表
        $ModelPackageLog = new ModelPackageLog();
        if ($name != $package->package_name) {
            $content = '修改了号码包名称【' . $package->package_name . '】→【' . $name . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($date != $package->date) {
            $content = '修改了记录日期【' . $package->date . '】→【' . $date . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($labelIdStr != $labelIdStrDb && $labelNameStrDb != $labelNameStrnew) {
            $content = '修改了标签【' . $labelNameStrDb . '】→【' . $labelNameStrnew . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($amount != $package->amount) {
            $content = '修改了价格【' . $package->amount . '】→【' . $amount . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        $originalLabels = DB::table('package_label')->where('package_id', $id)->pluck('label_id')->toArray();

        $delRes = DB::table('package_label')->where('package_id', $id)->where('type',1)->delete();

        if ($labelIdList) {
            $labelAddList = [];
            foreach ($labelIdList as $key => $value) {
                $labelAdd['type'] = 1;
                $labelAdd['label_id'] = $value;
                $labelAdd['package_id'] = $id;
                $labelAdd['created_at'] = time();
                $labelAddList[] = $labelAdd;
            }
            $labelSum = DB::table('package_label')->insert($labelAddList);
        }
        $removeLabels = array_diff($originalLabels,$labelIdList);//要移除的标签
        $newLabels= array_diff($labelIdList,$originalLabels);//新增的标签
        //新增或删除标签，扔到队列处理
        if($removeLabels){
            $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$removeLabels,'action'=>'remove']];
            \App\Model\Mobile::pushPackageMultiQueue($data);
        }
        if($newLabels){
            $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$newLabels,'action'=>'add']];
            \App\Model\Mobile::pushPackageMultiQueue($data);
        }

        return  $this->success();
    }



    /**
     *  添加包信息
     *
     * @return Response
     */
    public function addPackage(Request $request)
    {
        $adminId = self::$uid;
        $name = trim($request->input('name')); #包名称

        $date = $request->input('date');
        $amount = $request->input('amount');
        $labelIdStr = $request->input('label_id_str'); #label_id逗号隔开
        if (empty($name)) {
            $this->error('100530'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100535'); #名称太长了
        }
        if (empty($date)) {
            $this->error('100531'); #记录日期不能为空
        }
        if ((!empty($amount) && $amount < 0)  ||  (!empty($amount) && !is_numeric($amount))) {
            $this->error('100536'); #金额不符合规则
        }
        $labelIdList = [];
        if (!empty($labelIdStr)) {
            $labelIdList = explode(',', $labelIdStr);
        }


        $package = DB::table('package')->where('package_name', $name)->first();

        #该内容已经存在
        if (!empty($package) &&  $package->is_delete == 0  && ($name === $package->package_name)) {
            $this->error('100533'); #该名已存在
        }

        $add['package_name'] = $name;
        $add['date'] = $date;
        $add['amount'] = $amount;
        $add['created_at'] = time();
        $add['updated_at'] = time();
        $add['admin_id'] = $adminId;

        #更新包组状态
        $id = DB::table('package')->insertGetId($add);



        if (!$id) {
            $this->error('100534'); #操作失败
        }
        $sign = Hash::getPhoneServerById($id);
        #添加分表标识
        DB::table('package')->where('id', $id)->update(['mobile_table_sign' => $sign]);
        if ($labelIdList) {
            $labelAddList = [];
            foreach ($labelIdList as $key => $value) {
                $labelAdd['type'] = 1;
                $labelAdd['label_id'] = $value;
                $labelAdd['package_id'] = $id;
                $labelAdd['created_at'] = time();
                $labelAddList[] = $labelAdd;
            }
            $labelSum = DB::table('package_label')->insert($labelAddList);
            if($labelSum){
                $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$labelIdList,'action'=>'add']];
                \App\Model\Mobile::pushPackageMultiQueue($data);
            }
        }
        $labelNameStrnew = '';
        #查询标签
        $labelListNew = DB::table('label')
            ->select('id', 'label_name')
            ->whereIn('id', $labelIdList)
            ->orderBy('id', 'asc')
            ->get();
        foreach ($labelListNew as $key => $value) {
            $labelNameStrnew .= $value->label_name . '、';
        }
        $labelNameStrnew = rtrim($labelNameStrnew, "、");

        #编写日志表
        $ModelPackageLog = new ModelPackageLog();

        $content = '创建了号码包【' . $name . '】,' . '记录日期为' . $date . ',标签为【' . $labelNameStrnew . '】';
        $ModelPackageLog->addPackageLog($adminId, $content, $id);

        return  $this->success(array('id' => $id));
    }



    /**
     * 号码包修改日志列表
     */
    public function getPackageChangeLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $this->error('100540'); #参数有误
        }

        $results = DB::table('package_log as a')
            ->select('a.id', 'content', 'a.created_at', 'b.account', 'a.package_id')
            ->leftJoin('admin as b', 'b.id', '=', 'a.admin_id')
            ->where('package_id', $packageId)
            ->orderBy('id', 'desc')
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }



    /**
     * 号码包提交日志列表
     */
    public function getPackageUploadLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $this->error('100550'); #参数有误
        }

        $results = DB::table('package_upload_log as a')
            ->select('a.*', 'b.platform_name', 'c.account')
            ->leftJoin('platform as b', 'b.id', '=', 'a.platform_id')
            ->leftJoin('admin as c', 'c.id', '=', 'a.admin_id')
            ->where('a.package_id', $packageId)
            ->where('a.is_deal', 1)
            ->orderBy('a.id', 'desc')
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }



    /**
     * 获取一条号码包提交日志
     */
    public function getOnePackageUploadLog(Request $request)
    {

        $id = $request->input('id');

        $data = DB::table('package_upload_log as a')
            ->select('a.*', 'b.platform_name')
            ->leftJoin('platform as b', 'b.id', '=', 'a.platform_id')
            ->where('a.id', $id)
            ->first();

        $data->invalid_number_json = !empty($data->invalid_number_json) ? json_decode($data->invalid_number_json) : [];
        $result['data'] = $data;
        return $this->success($result);
    }



    /**
     * 号码包导出日志列表
     */
    public function getPackageExportLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $packageId = 0; #0为全部
        }

        $results = DB::table('package_export_log as a')
            ->select('a.*', 'b.account')
            ->leftJoin('admin as b', 'b.id', '=', 'a.admin_id')
            ->where('package_id', $packageId)
            ->orderBy('a.id', 'desc')
            ->paginate($pagesize);
        $exportData = $results->items();
        foreach ($exportData as $key => $value) {
            $timest = time() - $value->created_at;

            if ($timest > 15 * 24 * 60 * 60) {
                $exportData[$key]->is_ok = 0;
                $exportData[$key]->export_path = '';
            } else {
                $exportData[$key]->is_ok = 1;
                $exportData[$key]->export_path = '';
            }
        }
        $data['data'] = $exportData;
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    /**
     * 号码包导出日志列表
     */
    public function getDownloadToken(Request $request)
    {
        $name = Tools::routeParameter('name');
        $adminId = self::$uid;
        if (empty($name)) {
            $this->error('100570'); #参数有误
        }
        $token = JwtToken::getInstance()->getNameToken($name, $adminId);
        $sessionData = json_encode([
            'adminId' => $adminId,
            'name' => $name,
        ]);
        #给这个文件增加一个token
        $sessionKeyPrefix = 'FILENAME:';
        $data['token'] =  $token;
        Cache::put($sessionKeyPrefix . $token, $sessionData, config('Session.file_download_max_seconds'));
        return response()->json([
            'code' => 200,
            'msg' => 'ok',
            'data' => $data,
        ]);
    }

    /**
     * 号码包导出日志列表
     */
    public function download(Request $request)
    {
        $name = Tools::routeParameter('name');
        $requestToken = Tools::routeParameter('token');
        $adminId = Tools::routeParameter('id');
        if (empty($name)) {
            $this->error('100580'); #参数有误
        }

        if (JwtToken::getInstance()->nameVerify($requestToken) !== (int) $adminId) {
            $this->error('100581'); #验证未通过

        }

        //请求登录接口，便清掉缓存的captcha
        $token = 'FILENAME:' . $requestToken;

        $cacheData = Cache::pull($token, '');


        if (!empty($cacheData)) {
            Cache::forget($token);
        } else {
            $this->error('100582'); #token有效期已过
        }
        return response()->download(base_path('storage/exportfiles') . '/' . $name);
    }




    /**
     *  删除包
     *
     * @return Response
     */
    public function deletePackage(Request $request)
    {

        $id = (int) Tools::routeParameter('id');

        if (empty($id)) {
            $this->error('100590'); #参数有误
        }

        $package = DB::table('package')->where('id', $id)->first();

        #该内容不存在
        if (empty($package)) {
            $this->error('100591');
        }

        $save['is_delete'] = 1;
        $save['updated_at'] = time();

        #更新包状态
        $result = DB::table('package')->where('id', $id)->delete();

        if (!$result) {
            $this->error('100592'); #操作失败
        }
        // $hosts = [
        //     // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
        //     [
        //         'host' => env('ES_HOST'),
        //         'port' => env('ES_PORT'),
        //         'scheme' => 'http',
        //         'user' => env('ES_USERNAME'),
        //         'pass' => env('ES_PASSWORD'),
        //     ]
        //     #可传多个节点
        // ];

        // $client = ClientBuilder::create()           // Instantiate a new ClientBuilder
        //     ->setHosts($hosts)      // Set the hosts
        //     ->build();


        //存储从ES查询出来的数据
        // $i = 0;
        // $params = [
        //     'index' => 'phone_info',
        //     'body' => [
        //         "query" => [
        //             "bool" => [
        //                 'must' => [
        //                     'terms' => [
        //                         'number_package' => [$id]
        //                     ]
        //                 ]
        //             ]

        //         ],
        //         "script" => [
        //             "inline" => "ctx._source.number_package.remove(ctx._source.number_package.indexOf(params.number_package))",
        //             "params" => [
        //                 "number_package" => $id,
        //             ],
        //             "lang" => "painless"
        //         ]

        //     ],

        // ];

        // for ($i = 0; $i < 5; $i++) {
        //     $client->updateByQuery($params);
        // }









        return  $this->success();
    }


    private function getPackageById($packageList)
    {

        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        $index = 'phone_info';
        foreach ($packageList as $key => $value) {
            if(isset($value->nation) && $value->nation){
                $index = 'phone_'.strtolower($value->nation);
            }
            //从ES查询实时数据
            $params = [
                'index' => $index,
                'body' => [
                    "query" => [

                        'bool' => [
                            'must' => [
                                [
                                    'term' => [
                                        'number_package' => $value->id
                                    ]
                                ]


                            ]
                        ]

                    ]
                ]
            ];

            $total = $client->count($params);
            $total = !empty($total['count']) ? $total['count'] : 0;
            $packageList[$key]->total = $total;
            #移动
            $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 1]];
            $cmcc_sum = $client->count($params);
            $cmcc_sum = !empty($cmcc_sum['count']) ? $cmcc_sum['count'] : 0;
            $packageList[$key]->cmcc_sum = $cmcc_sum;
            #联通
            $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 2]];
            $cucc_sum = $client->count($params);
            $cucc_sum = !empty($cucc_sum['count']) ? $cucc_sum['count'] : 0;
            $packageList[$key]->cucc_sum = $cucc_sum;
            #电信
            $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 3]];
            $ctcc_sum = $client->count($params);
            $ctcc_sum = !empty($ctcc_sum['count']) ? $ctcc_sum['count'] : 0;
            $packageList[$key]->ctcc_sum = $ctcc_sum;
            #虚拟号
            $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 4]];
            $virtual_sum = $client->count($params);
            $virtual_sum = !empty($virtual_sum['count']) ? $virtual_sum['count'] : 0;
            $packageList[$key]->virtual_sum = $virtual_sum;
            #活跃号
            $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 1]];
            $good_sum = $client->count($params);
            $good_sum = !empty($good_sum['count']) ? $good_sum['count'] : 0;
            $packageList[$key]->good_sum = $good_sum;
            #沉默号
            $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 2]];
            $sleep_sum = $client->count($params);
            $sleep_sum = !empty($sleep_sum['count']) ? $sleep_sum['count'] : 0;
            $packageList[$key]->sleep_sum = $sleep_sum;
            #风险号
            $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 3]];
            $risk_sum = $client->count($params);
            $risk_sum = !empty($risk_sum['count']) ? $risk_sum['count'] : 0;
            $packageList[$key]->risk_sum = $risk_sum;
            #空号
            $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 4]];
            $vacant_sum = $client->count($params);
            $vacant_sum = !empty($vacant_sum['count']) ? $vacant_sum['count'] : 0;
            $packageList[$key]->vacant_sum = $vacant_sum;

            #已注册
            $params['body']['query']['bool']['must'][1] = ['term' => ['is_register' => 1]];
            $register_sum = $client->count($params);
            $register_sum = !empty($register_sum['count']) ? $register_sum['count'] : 0;
            $packageList[$key]->register_sum = $register_sum;
            #未注册
            $packageList[$key]->no_register_sum = $total - $register_sum;
            #已使用

            $params['body']['query']['bool']['must'][1] = ['term' => ['is_use' => 1]];
            $used_sum = $client->count($params);
            $used_sum = !empty($used_sum['count']) ? $used_sum['count'] : 0;
            $packageList[$key]->used_sum = $used_sum;
            $packageList[$key]->no_used_sum = $total - $used_sum;
            #反馈

            $params['body']['query']['bool']['must'][1] = ['term' => ['is_feedback' => 1]];
            $feedback_sum = $client->count($params);
            $feedback_sum = !empty($feedback_sum['count']) ? $feedback_sum['count'] : 0;
            $packageList[$key]->feedback_sum = $feedback_sum;
            $packageList[$key]->no_feedback_sum = $total - $feedback_sum;
            #单价
            $packageList[$key]->one_amount = number_format($total == 0 ? 0 : $packageList[$key]->amount / $total, 2, '.', '') . '元/每条';

            #
            //从导出日志里统计导出次数
            $row_export_sum = DB::select('select count(*) as export_sum from pnl_package_export_log where package_id = ?', [$packageList[$key]->id]);
            $export_sum = $row_export_sum[0]->export_sum;
            $packageList[$key]->export_sum = $export_sum;
            //从导入日志里统计导入次数
            $row_import_sum = DB::select('select count(*) as import_sum from pnl_package_upload_log where package_id = ?', [$packageList[$key]->id]);
            $import_sum = $row_import_sum[0]->import_sum;
            $packageList[$key]->import_sum = $import_sum;
        }
        return $packageList;
    }

    /**
     * 获取一个包信息
     */
    public function intPackage(Request $request)
    {
        $packageId = trim($request->input('package_id', ''));

        if (!preg_match('/^([1-9]{1}\d{0,9})$/', $packageId)) {
            $this->error('100510'); #参数有误
        }

        $package = DB::table('package_international')
            ->select(
                'id as package_id',
                'package_name',
                'created_at',
                'total',
                'real_total',
                'cmcc_sum',
                'cucc_sum',
                'ctcc_sum',
                'virtual_sum',
                'good_sum',
                'vacant_sum',
                'sleep_sum',
                'risk_sum',
                'unverified_sum',
                'register_sum',
                'feedback_sum',
                'no_feedback_sum',
                'used_sum',
                'no_used_sum',
                'no_register_sum',
                'date',
                'amount',
                'one_amount',
                'last_month_good_sum'
            )
            ->where('id', $packageId)
            ->where('is_delete', 0)
            ->first();
        if (empty($package)) {
            $this->error('100510'); #参数有误
        }

        //从导出日志里统计导出次数
        $row_export_sum = DB::select('select count(*) as export_sum from pnl_package_export_log where package_id = ?', [$packageId]);
        $export_sum = $row_export_sum[0]->export_sum;

        //从导入日志里统计导入次数
        $row_import_sum = DB::select('select count(*) as import_sum from pnl_package_upload_log where package_id = ?', [$packageId]);
        $import_sum = $row_import_sum[0]->import_sum;
        $hosts = [
            // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
            [
                'host' => env('ES_HOST'),
                'port' => env('ES_PORT'),
                'scheme' => 'http',
                'user' => env('ES_USERNAME'),
                'pass' => env('ES_PASSWORD'),
            ]
            #可传多个节点
        ];
        $client = ClientBuilder::create()->setHosts($hosts)->build();
        //从ES查询实时数据
        $params = [
            'index' => 'phone_info',
            'body' => [
                "query" => [

                    'bool' => [
                        'must' => [
                            [
                                'term' => [
                                    'number_package' => $packageId
                                ]
                            ]


                        ]
                    ]

                ]
            ]
        ];
        $total = $client->count($params);
        $total = !empty($total['count']) ? $total['count'] : 0;
        #移动
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 1]];


        $cmcc_sum = $client->count($params);
        $cmcc_sum = !empty($cmcc_sum['count']) ? $cmcc_sum['count'] : 0;
        #联通
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 2]];
        $cucc_sum = $client->count($params);
        $cucc_sum = !empty($cucc_sum['count']) ? $cucc_sum['count'] : 0;
        #电信
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 3]];
        $ctcc_sum = $client->count($params);
        $ctcc_sum = !empty($ctcc_sum['count']) ? $ctcc_sum['count'] : 0;
        #虚拟号
        $params['body']['query']['bool']['must'][1] = ['term' => ['company' => 4]];
        $virtual_sum = $client->count($params);
        $virtual_sum = !empty($virtual_sum['count']) ? $virtual_sum['count'] : 0;


        #充值
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_use' => 1]];
        $used_sum = $client->count($params);
        $used_sum = !empty($used_sum['count']) ? $used_sum['count'] : 0;
        #未充值
        $no_used_sum = $total ? $total - $used_sum : 0;


        #注册
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_register' => 1]];
        $register_sum = $client->count($params);
        $register_sum = !empty($register_sum['count']) ? $register_sum['count'] : 0;
        #未注册
        $no_register_sum = $total ? $total - $register_sum : 0;

        #反馈
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_feedback' => 1]];
        $feedback_sum = $client->count($params);
        $feedback_sum = !empty($feedback_sum['count']) ? $feedback_sum['count'] : 0;
        #未反馈
        $no_feedback_sum = $total ? $total - $feedback_sum : 0;

        #活跃号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 1]];
        $good_sum = $client->count($params);
        $good_sum = !empty($good_sum['count']) ? $good_sum['count'] : 0;
        #沉默号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 2]];
        $sleep_sum = $client->count($params);
        $sleep_sum = !empty($sleep_sum['count']) ? $sleep_sum['count'] : 0;
        #风险号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 3]];
        $risk_sum = $client->count($params);
        $risk_sum = !empty($risk_sum['count']) ? $risk_sum['count'] : 0;
        #空号
        $params['body']['query']['bool']['must'][1] = ['term' => ['type' => 4]];
        $vacant_sum = $client->count($params);
        $vacant_sum = !empty($vacant_sum['count']) ? $vacant_sum['count'] : 0;

        # 充值
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_recharge' => 1]];
        $recharge_sum = $client->count($params);
        $recharge_sum = !empty($recharge_sum['count']) ? $recharge_sum['count'] : 0;

        #上周充值
        $b15ds = strtotime('-15 days');
        $params['body']['query']['bool']['must'][1] = ['term' => ['is_register' => 1]];
        $params['body']['query']['bool']['must'][0] = [
            'range' => [
                'last_recharge_date' => ['gt' => $b15ds]
            ]
        ];
        $last_week_recharge_sum = $client->count($params);
        $last_week_recharge_sum = !empty($last_week_recharge_sum['count']) ? $last_week_recharge_sum['count'] : 0;



        $package->total =  $total;

        $package->cmcc_sum = (empty($package->total) ? '0' : ($cmcc_sum . '(' . number_format((($cmcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->vacant_sum = (empty($package->total) ? '0' : ($vacant_sum . '(' . number_format((($vacant_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->amount = number_format($package->amount, 2, '.', '');
        $package->register_sum = (empty($package->total) ? '0' : ($register_sum . '(' . number_format((($register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->no_register_sum = (empty($package->total) ? '0' : ($no_register_sum . '(' . number_format((($no_register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->real_total = (empty($package->total) ? '0' : ($package->real_total . '(' . number_format((($package->real_total / $package->total) * 100), 2, '.', '') . '%)'));
        $package->cucc_sum = (empty($package->total) ? '0' : ($cucc_sum . '(' . number_format((($cucc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->ctcc_sum = (empty($package->total) ? '0' : ($ctcc_sum . '(' . number_format((($ctcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->sleep_sum = (empty($package->total) ? '0' : ($sleep_sum . '(' . number_format((($sleep_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->one_amount = number_format($package->total == 0 ? 0 : $package->amount / $package->total, 2, '.', '') . '元/每条';
        $package->feedback_sum = (empty($package->total) ? '0' : ($feedback_sum . '(' . number_format((($feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->no_feedback_sum = (empty($package->total) ? '0' : ($no_feedback_sum . '(' . number_format((($no_feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));

        $package->risk_sum = (empty($package->total) ? '0' : ($risk_sum . '(' . number_format((($risk_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->used_sum = (empty($package->total) ? '0' : ($used_sum . '(' . number_format((($used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->no_used_sum = (empty($package->total) ? '0' : ($no_used_sum . '(' . number_format((($no_used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->good_sum = (empty($package->total) ? '0' : ($good_sum . '(' . number_format((($good_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->virtual_sum = (empty($package->total) ? '0' : ($virtual_sum . '(' . number_format((($virtual_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->last_week_recharge_sum = $last_week_recharge_sum;
        // $package->last_month_good_sum = $last_month_good_sum;
        $package->recharge_sum = $recharge_sum;


        // $package->total = $package->total . '';
        // $package->cmcc_sum = (empty($package->total) ? '0' : ($package->cmcc_sum . '(' . number_format((($package->cmcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->vacant_sum = (empty($package->total) ? '0' : ($package->vacant_sum . '(' . number_format((($package->vacant_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->amount = number_format($package->amount, 2, '.', '');
        // $package->register_sum = (empty($package->total) ? '0' : ($package->register_sum . '(' . number_format((($package->register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->no_register_sum = (empty($package->total) ? '0' : ($package->no_register_sum . '(' . number_format((($package->no_register_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->real_total = (empty($package->total) ? '0' : ($package->real_total . '(' . number_format((($package->real_total / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->cucc_sum = (empty($package->total) ? '0' : ($package->cucc_sum . '(' . number_format((($package->cucc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->ctcc_sum = (empty($package->total) ? '0' : ($package->ctcc_sum . '(' . number_format((($package->ctcc_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->sleep_sum = (empty($package->total) ? '0' : ($package->sleep_sum . '(' . number_format((($package->sleep_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->one_amount = number_format($package->total == 0 ? 0 : $package->amount / $package->total, 2, '.', '') . '元/每条';
        // $package->feedback_sum = (empty($package->total) ? '0' : ($package->feedback_sum . '(' . number_format((($package->feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->no_feedback_sum = (empty($package->total) ? '0' : ($package->no_feedback_sum . '(' . number_format((($package->no_feedback_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->unverified_sum = (empty($package->total) ? '0' : ($package->unverified_sum . '(' . number_format((($package->unverified_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->risk_sum = (empty($package->total) ? '0' : ($package->risk_sum . '(' . number_format((($package->risk_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->used_sum = (empty($package->total) ? '0' : ($package->used_sum . '(' . number_format((($package->used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->no_used_sum = (empty($package->total) ? '0' : ($package->no_used_sum . '(' . number_format((($package->no_used_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->good_sum = (empty($package->total) ? '0' : ($package->good_sum . '(' . number_format((($package->good_sum / $package->total) * 100), 2, '.', '') . '%)'));
        // $package->virtual_sum = (empty($package->total) ? '0' : ($package->virtual_sum . '(' . number_format((($package->virtual_sum / $package->total) * 100), 2, '.', '') . '%)'));
        $package->created_at = date('Y-m-d', $package->created_at);
        $package->date = (empty($package->date) ? '' : date('Y-m-d', strtotime($package->date)));
        $package->export_sum = $export_sum;
        $package->import_sum = $import_sum;

        $label = DB::table('package_label as a')
            ->select('b.id as label_id', 'b.label_name')
            ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
            ->where('a.package_id', $packageId)
            ->where('b.is_delete', 0)
            ->get();

        $data['package'] = $package;
        $data['label'] = $label->toArray();

        // $data['label_category_count'] = $this->getLabelsCount();
        $data['label_category_count'] = $this->getLabelsCount3($package->total,$packageId);
        return $this->success($data);
    }

    /**
     * 号码包修改日志列表
     */
    public function intPackageChangeLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $this->error('100540'); #参数有误
        }

        $results = DB::table('int_package_log as a')
            ->select('a.id', 'content', 'a.created_at', 'b.account', 'a.package_id')
            ->leftJoin('admin as b', 'b.id', '=', 'a.admin_id')
            ->where('package_id', $packageId)
            ->orderBy('id', 'desc')
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    /**
     * 号码包提交日志列表
     */
    public function intPackageUploadLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $this->error('100550'); #参数有误
        }

        $results = DB::table('package_int_upload_log as a')
            ->select('a.*', 'b.platform_name', 'c.account')
            ->leftJoin('platform as b', 'b.id', '=', 'a.platform_id')
            ->leftJoin('admin as c', 'c.id', '=', 'a.admin_id')
            ->where('a.package_id', $packageId)
            ->where('a.is_deal', 1)
            ->orderBy('a.id', 'desc')
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    /**
     * 号码包导出日志列表
     */
    public function intPackageExportLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $packageId = 0; #0为全部
        }

        $results = DB::table('package_int_export_log as a')
            ->select('a.*', 'b.account')
            ->leftJoin('admin as b', 'b.id', '=', 'a.admin_id')
            ->where('package_id', $packageId)
            ->orderBy('a.id', 'desc')
            ->paginate($pagesize);
        $exportData = $results->items();
        foreach ($exportData as $key => $value) {
            $timest = time() - $value->created_at;

            if ($timest > 15 * 24 * 60 * 60) {
                $exportData[$key]->is_ok = 0;
                $exportData[$key]->export_path = '';
            } else {
                $exportData[$key]->is_ok = 1;
                $exportData[$key]->export_path = '';
            }
        }
        $data['data'] = $exportData;
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    public function getIntPackage(Request $request){
        $keyword = trim($request->input('keyword')); #搜索关键字，包名
        $field = trim($request->input('field')); #要获取的列
        $pagesize = $request->input('pagesize') ?: 10;
        $labelId = $request->input('label_id'); #标签
        $date = $request->input('date'); #标签
        $nation = $request->input('nation'); #标签

        $package_id_list = [];
        if ($labelId) {

            $package_id_items = DB::table('package_label')
                ->where('label_id', $labelId)
                ->pluck('package_id');
            foreach ($package_id_items as $key => $value) {
                $package_id_list[] = $value;
            }
            if (empty($package_id_list)) {
                $package = [];
                $results = '';
                goto end;
            }
        }


        $packageSql = DB::table('package_international');

        if ($field) {
            $field_exp = explode(',', $field);
            array_push($field_exp, 'nation');
            if (in_array('admin_name', $field_exp)) {
                array_push($field_exp, 'admin_id');
            }

            $field_all = array(
                "id", "nation","package_name", "mobile_table_sign", "created_at", "updated_at", "total", "real_total",
                "cmcc_sum", "cucc_sum", "ctcc_sum", "virtual_sum", "good_sum", "vacant_sum", "sleep_sum", "risk_sum",
                "date", "admin_id", "unverified_sum", "register_sum", "feedback_sum", "no_feedback_sum", "used_sum", "no_used_sum",
                "no_register_sum", "amount", "one_amount", "export_sum", "import_sum"
            );

            $field_list = array_intersect($field_all, $field_exp);

            if (empty($field_list)) {
                $this->error('100500'); #参数有误
            }
            array_push($field_list, 'amount');

            $packageSql = $packageSql->select($field_list);
        } else {
            $field_list = array(
                "id","nation", "package_name", "mobile_table_sign", "created_at", "updated_at", "total", "real_total",
                "cmcc_sum", "cucc_sum", "ctcc_sum", "virtual_sum", "good_sum", "vacant_sum", "sleep_sum", "risk_sum",
                "date", "admin_id"
            );
            $field_exp = ['label'];
            array_push($field_list, 'amount');
            $packageSql = $packageSql->select($field_list);
            array_push($field_list, 'admin_name');
        }
        if (in_array('admin_name', $field_exp)) {
            array_push($field_list, 'admin_name');
        }

        $packageSql = $packageSql->where('is_delete', 0);

        if ($date) {
            $packageSql = $packageSql->where('date', $date);
        }
        if ($nation) {
            $packageSql = $packageSql->where('nation', $nation);
        }

        if ($keyword) {
            $packageSql = $packageSql->where('package_name', 'like', '%' . $keyword . '%');
        }

        if ($package_id_list) {
            $packageSql = $packageSql->wherein('id', $package_id_list);
        }

        $results = $packageSql->orderBy('updated_at', 'desc')->paginate($pagesize);
        $package = $results->items();

        if (in_array('label', $field_exp)) {

            if ($package) {
                $package_id_list = [];
                foreach ($package as $key => $value) {
                    $package_id_list[] = $value->id;
                }
            }

            $package_label = DB::table('package_label as a')
                ->select('b.id as label_id', 'b.label_name', 'package_id')
                ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
                ->whereIn('package_id', $package_id_list)
                ->where('type', 2)
                ->where('b.is_delete', 0)
                ->get();

            foreach ($package_label as $key => $value) {
                $package_label_list[$value->package_id][] = $value;
            }

            foreach ($package as $key => $value) {

                $package[$key]->label = isset($package_label_list[$value->id]) ? $package_label_list[$value->id] : [];
            }
        }

        if (in_array('admin_name', $field_list)) {

            if ($package) {
                $package_id_list = [];
                foreach ($package as $key => $value) {
                    $admin_id_list[] = $value->admin_id;
                }
                $admin_name = DB::table('admin')
                    ->select('id', 'account')
                    ->whereIn('id', $admin_id_list)
                    ->get();

                foreach ($admin_name as $key => $value) {
                    $admin_name_list[$value->id] = $value;
                }
                foreach ($package as $key => $value) {
                    $package[$key]->admin_name = isset($admin_name_list[$value->admin_id]) ? $admin_name_list[$value->admin_id]->account : '';

                }
            }

        }
        foreach ($package as $key => $value) {
            $package[$key]->ratio = DB::table('package_ratio')
                ->leftJoin('package_international','package_ratio.com_package_id','=','package_international.id')
                ->where('package_id',$value->id)
                ->select(['package_name','dug_counts','dug_ratio'])
                ->orderBy('dug_counts','desc')
                ->limit(10)
                ->get();
        }
        end: $data['data'] = $this->getPackageById($package);
        $data['count'] =  $results ? count($results) : 0;
        $data['total'] =  $results ? $results->total() : 0;
        $data['currentPage'] = $results ? $results->currentPage() : 1;
        return $this->success($data);
    }

    public function addIntPackage(Request $request){
        $adminId = self::$uid;
        $name = trim($request->input('name')); #包名称
        $nation = trim($request->input('nation')); #包名称

        $date = $request->input('date');
        $amount = $request->input('amount');
        $labelIdStr = $request->input('label_id_str'); #label_id逗号隔开
        if (empty($name)) {
            $this->error('100530'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100535'); #名称太长了
        }
        if (empty($date)) {
            $this->error('100531'); #记录日期不能为空
        }
        if ((!empty($amount) && $amount < 0)  ||  (!empty($amount) && !is_numeric($amount))) {
            $this->error('100536'); #金额不符合规则
        }
        $labelIdList = [];
        if (!empty($labelIdStr)) {
            $labelIdList = explode(',', $labelIdStr);
        }


        $package = DB::table('package_international')->where('package_name', $name)->first();

        #该内容已经存在
        if (!empty($package) &&  $package->is_delete == 0  && ($name === $package->package_name)) {
            $this->error('100533'); #该名已存在
        }

        $add['package_name'] = $name;
        $add['nation'] = $nation;
        $add['date'] = $date;
        $add['amount'] = $amount;
        $add['created_at'] = time();
        $add['updated_at'] = time();
        $add['admin_id'] = $adminId;

        #更新包组状态
        $id = DB::table('package_international')->insertGetId($add);



        if (!$id) {
            $this->error('100534'); #操作失败
        }
        $sign = Hash::getPhoneServerById($id);
        #添加分表标识
        DB::table('package_international')->where('id', $id)->update(['mobile_table_sign' => $sign]);
        if ($labelIdList) {
            $labelAddList = [];
            foreach ($labelIdList as $key => $value) {
                $labelAdd['type'] = 2;
                $labelAdd['label_id'] = $value;
                $labelAdd['package_id'] = $id;
                $labelAdd['created_at'] = time();
                $labelAddList[] = $labelAdd;
            }
            $labelSum = DB::table('package_label')->insert($labelAddList);
            if($labelSum){
                $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$labelIdList,'action'=>'add']];
                \App\Model\Mobile::pushPackageMultiQueue($data);
            }
        }
        $labelNameStrnew = '';
        #查询标签
        $labelListNew = DB::table('label')
            ->select('id', 'label_name')
            ->whereIn('id', $labelIdList)
            ->orderBy('id', 'asc')
            ->get();
        foreach ($labelListNew as $key => $value) {
            $labelNameStrnew .= $value->label_name . '、';
        }
        $labelNameStrnew = rtrim($labelNameStrnew, "、");

        #编写日志表
        $ModelPackageLog = new IntPackageLog();

        $content = '创建了号码包【' . $name . '】,' . '记录日期为' . $date . ',标签为【' . $labelNameStrnew . '】';
        $ModelPackageLog->addPackageLog($adminId, $content, $id);

        return  $this->success(array('id' => $id));
    }

    /**
     *  修改包信息
     *
     * @return Response
     */
    public function updateIntPackage(Request $request)
    {
        $adminId = self::$uid;
        $id =  $request->input('package_id');
        $name = trim($request->input('name')); #包名称
        $date = $request->input('date');
        $amount = $request->input('amount');
        $labelIdStr = $request->input('label_id_str'); #label_id逗号隔开
        if (empty($name)) {
            $this->error('100520'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100525'); #名称太长了
        }
        if (empty($date)) {
            $this->error('100521'); #记录日期不能为空
        }
        if ((!empty($amount) && $amount < 0)  ||  (!empty($amount) && !is_numeric($amount))) {
            $this->error('100527'); #金额不符合规则
        }
        $package = DB::table('package_international')->where('id', $id)->first();

        #该内容不存在
        if (empty($package)) {
            $this->error('100523');
        }

        $package2 = DB::table('package_international')->where('package_name', $name)->first();


        #该内容不存在
        if (!empty($package2) && $package2->id != $id && $name == $package2->package_name) {
            $this->error('100526'); #文件名已经存在
        }

        $labelIdList = [];
        if (!empty($labelIdStr)) {
            $labelIdList = explode(',', $labelIdStr);
            $save['label'] = $labelIdStr;
        }


        $save['package_name'] = $name;
        $save['date'] = $date;
        $save['updated_at'] = time();
        $save['amount'] = $amount;


        #更新包组状态
        $result = DB::table('package_international')->where('id', $id)->update($save);

        if (!$result) {
            $this->error('100524'); #操作失败
        }
        $labelIdStrDb = '';
        $labelNameStrDb = '';
        $labelNameStrnew = '';
        #查询标签
        $labelList = DB::table('package_label as a')
            ->select('b.id as label_id', 'b.label_name')
            ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
            ->where('package_id', $id)
            ->orderBy('b.id', 'asc')
            ->get();
        foreach ($labelList as $key => $value) {
            $labelIdStrDb .= $value->label_id . ',';
            $labelNameStrDb .= $value->label_name . '、';
        }
        $labelIdStrDb = rtrim($labelIdStrDb, ",");
        $labelNameStrDb = rtrim($labelNameStrDb, "、");
        #查询标签
        $labelListNew = DB::table('label')
            ->select('id', 'label_name')
            ->whereIn('id', $labelIdList)
            ->orderBy('id', 'asc')
            ->get();
        foreach ($labelListNew as $key => $value) {
            $labelNameStrnew .= $value->label_name . '、';
        }
        $labelNameStrnew = rtrim($labelNameStrnew, "、");

        #编写日志表
        $ModelPackageLog = new ModelPackageLog();
        if ($name != $package->package_name) {
            $content = '修改了号码包名称【' . $package->package_name . '】→【' . $name . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($date != $package->date) {
            $content = '修改了记录日期【' . $package->date . '】→【' . $date . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($labelIdStr != $labelIdStrDb && $labelNameStrDb != $labelNameStrnew) {
            $content = '修改了标签【' . $labelNameStrDb . '】→【' . $labelNameStrnew . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($amount != $package->amount) {
            $content = '修改了价格【' . $package->amount . '】→【' . $amount . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        $originalLabels = DB::table('package_label')->where('package_id', $id)->where('type',2)->pluck('label_id')->toArray();

        $delRes = DB::table('package_label')->where('package_id', $id)->where('type',2)->delete();

        if ($labelIdList) {
            $labelAddList = [];
            foreach ($labelIdList as $key => $value) {
                $labelAdd['type'] = 2;
                $labelAdd['label_id'] = $value;
                $labelAdd['package_id'] = $id;
                $labelAdd['created_at'] = time();
                $labelAddList[] = $labelAdd;
            }
            $labelSum = DB::table('package_label')->insert($labelAddList);
        }
//        $removeLabels = array_diff($originalLabels,$labelIdList);//要移除的标签
//        $newLabels= array_diff($labelIdList,$originalLabels);//新增的标签
//        //新增或删除标签，扔到队列处理
//        if($removeLabels){
//            $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$removeLabels,'action'=>'remove']];
//            \App\Model\Mobile::pushPackageMultiQueue($data);
//        }
//        if($newLabels){
//            $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$newLabels,'action'=>'add']];
//            \App\Model\Mobile::pushPackageMultiQueue($data);
//        }

        return  $this->success();
    }

    /**
     *  删除包
     *
     * @return Response
     */
    public function deleteIntPackage(Request $request)
    {

        $id = (int) Tools::routeParameter('id');

        if (empty($id)) {
            $this->error('100590'); #参数有误
        }

        $package = DB::table('package_international')->where('id', $id)->first();

        #该内容不存在
        if (empty($package)) {
            $this->error('100591');
        }

        $save['is_delete'] = 1;
        $save['updated_at'] = time();

        #更新包状态
        $result = DB::table('package_international')->where('id', $id)->delete();

        if (!$result) {
            $this->error('100592'); #操作失败
        }
        // $hosts = [
        //     // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
        //     [
        //         'host' => env('ES_HOST'),
        //         'port' => env('ES_PORT'),
        //         'scheme' => 'http',
        //         'user' => env('ES_USERNAME'),
        //         'pass' => env('ES_PASSWORD'),
        //     ]
        //     #可传多个节点
        // ];

        // $client = ClientBuilder::create()           // Instantiate a new ClientBuilder
        //     ->setHosts($hosts)      // Set the hosts
        //     ->build();


        //存储从ES查询出来的数据
        // $i = 0;
        // $params = [
        //     'index' => 'phone_info',
        //     'body' => [
        //         "query" => [
        //             "bool" => [
        //                 'must' => [
        //                     'terms' => [
        //                         'number_package' => [$id]
        //                     ]
        //                 ]
        //             ]

        //         ],
        //         "script" => [
        //             "inline" => "ctx._source.number_package.remove(ctx._source.number_package.indexOf(params.number_package))",
        //             "params" => [
        //                 "number_package" => $id,
        //             ],
        //             "lang" => "painless"
        //         ]

        //     ],

        // ];

        // for ($i = 0; $i < 5; $i++) {
        //     $client->updateByQuery($params);
        // }









        return  $this->success();
    }

    public function getEmailPackage(Request $request){
        $keyword = trim($request->input('keyword')); #搜索关键字，包名
        $field = trim($request->input('field')); #要获取的列
        $pagesize = $request->input('pagesize') ?: 10;
        $labelId = $request->input('label_id'); #标签
        $date = $request->input('date'); #标签
        $nation = $request->input('nation'); #标签

        $package_id_list = [];
        if ($labelId) {

            $package_id_items = DB::table('package_label')
                ->where('label_id', $labelId)
                ->pluck('package_id');
            foreach ($package_id_items as $key => $value) {
                $package_id_list[] = $value;
            }
            if (empty($package_id_list)) {
                $package = [];
                $results = '';
                goto end;
            }
        }


        $packageSql = DB::table('package_email');

        if ($field) {
            $field_exp = explode(',', $field);
            array_push($field_exp, 'nation');
            if (in_array('admin_name', $field_exp)) {
                array_push($field_exp, 'admin_id');
            }

            $field_all = array(
                "id", "nation","package_name", "mobile_table_sign", "created_at", "updated_at", "total", "real_total",
                "cmcc_sum", "cucc_sum", "ctcc_sum", "virtual_sum", "good_sum", "vacant_sum", "sleep_sum", "risk_sum",
                "date", "admin_id", "unverified_sum", "register_sum", "feedback_sum", "no_feedback_sum", "used_sum", "no_used_sum",
                "no_register_sum", "amount", "one_amount", "export_sum", "import_sum"
            );

            $field_list = array_intersect($field_all, $field_exp);

            if (empty($field_list)) {
                $this->error('100500'); #参数有误
            }
            array_push($field_list, 'amount');

            $packageSql = $packageSql->select($field_list);
        } else {
            $field_list = array(
                "id","nation", "package_name", "mobile_table_sign", "created_at", "updated_at", "total", "real_total",
                "cmcc_sum", "cucc_sum", "ctcc_sum", "virtual_sum", "good_sum", "vacant_sum", "sleep_sum", "risk_sum",
                "date", "admin_id"
            );
            $field_exp = ['label'];
            array_push($field_list, 'amount');
            $packageSql = $packageSql->select($field_list);
            array_push($field_list, 'admin_name');
        }
        if (in_array('admin_name', $field_exp)) {
            array_push($field_list, 'admin_name');
        }

        $packageSql = $packageSql->where('is_delete', 0);

        if ($date) {
            $packageSql = $packageSql->where('date', $date);
        }
        if ($nation) {
            $packageSql = $packageSql->where('nation', $nation);
        }

        if ($keyword) {
            $packageSql = $packageSql->where('package_name', 'like', '%' . $keyword . '%');
        }

        if ($package_id_list) {
            $packageSql = $packageSql->wherein('id', $package_id_list);
        }

        $results = $packageSql->orderBy('updated_at', 'desc')->paginate($pagesize);

        $package = $results->items();

        if (in_array('label', $field_exp)) {

            if ($package) {
                $package_id_list = [];
                foreach ($package as $key => $value) {
                    $package_id_list[] = $value->id;
                }
            }

            $package_label = DB::table('package_label as a')
                ->select('b.id as label_id', 'b.label_name', 'package_id')
                ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
                ->whereIn('package_id', $package_id_list)
                ->where('type', 3)
                ->where('b.is_delete', 0)
                ->get();

            foreach ($package_label as $key => $value) {
                $package_label_list[$value->package_id][] = $value;
            }

            foreach ($package as $key => $value) {

                $package[$key]->label = isset($package_label_list[$value->id]) ? $package_label_list[$value->id] : [];
            }
        }

        if (in_array('admin_name', $field_list)) {

            if ($package) {
                $package_id_list = [];
                foreach ($package as $key => $value) {
                    $admin_id_list[] = $value->admin_id;
                }
                $admin_name = DB::table('admin')
                    ->select('id', 'account')
                    ->whereIn('id', $admin_id_list)
                    ->get();

                foreach ($admin_name as $key => $value) {
                    $admin_name_list[$value->id] = $value;
                }
                foreach ($package as $key => $value) {
                    $package[$key]->admin_name = isset($admin_name_list[$value->admin_id]) ? $admin_name_list[$value->admin_id]->account : '';

                }
            }

        }
        foreach ($package as $key => $value) {
            $package[$key]->ratio = DB::table('package_ratio')
                ->leftJoin('package','package_ratio.com_package_id','=','package.id')
                ->where('package_id',$value->id)
                ->select(['package_name','dug_counts','dug_ratio'])
                ->orderBy('dug_counts','desc')
                ->limit(6)
                ->get();
        }
        end: $data['data'] = $this->getPackageById($package);
        $data['count'] =  $results ? count($results) : 0;
        $data['total'] =  $results ? $results->total() : 0;
        $data['currentPage'] = $results ? $results->currentPage() : 1;
        return $this->success($data);
    }

    public function addEmailPackage(Request $request){
        $adminId = self::$uid;
        $name = trim($request->input('name')); #包名称
        $nation = trim($request->input('nation')); #包名称

        $date = $request->input('date');
        $amount = $request->input('amount');
        $labelIdStr = $request->input('label_id_str'); #label_id逗号隔开
        if (empty($name)) {
            $this->error('100530'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100535'); #名称太长了
        }
        if (empty($date)) {
            $this->error('100531'); #记录日期不能为空
        }
        if ((!empty($amount) && $amount < 0)  ||  (!empty($amount) && !is_numeric($amount))) {
            $this->error('100536'); #金额不符合规则
        }
        $labelIdList = [];
        if (!empty($labelIdStr)) {
            $labelIdList = explode(',', $labelIdStr);
        }


        $package = DB::table('package_email')->where('package_name', $name)->first();

        #该内容已经存在
        if (!empty($package) &&  $package->is_delete == 0  && ($name === $package->package_name)) {
            $this->error('100533'); #该名已存在
        }

        $add['package_name'] = $name;
        $add['nation'] = $nation;
        $add['date'] = $date;
        $add['amount'] = $amount;
        $add['created_at'] = time();
        $add['updated_at'] = time();
        $add['admin_id'] = $adminId;

        #更新包组状态
        $id = DB::table('package_email')->insertGetId($add);



        if (!$id) {
            $this->error('100534'); #操作失败
        }
        $sign = Hash::getPhoneServerById($id);
        #添加分表标识
        DB::table('package_email')->where('id', $id)->update(['email_table_sign' => $sign]);
        if ($labelIdList) {
            $labelAddList = [];
            foreach ($labelIdList as $key => $value) {
                $labelAdd['type'] = 3;
                $labelAdd['label_id'] = $value;
                $labelAdd['package_id'] = $id;
                $labelAdd['created_at'] = time();
                $labelAddList[] = $labelAdd;
            }
            $labelSum = DB::table('package_label')->insert($labelAddList);
            if($labelSum){
                $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$labelIdList,'action'=>'add']];
                \App\Model\Mobile::pushPackageMultiQueue($data);
            }
        }
        $labelNameStrnew = '';
        #查询标签
        $labelListNew = DB::table('label')
            ->select('id', 'label_name')
            ->whereIn('id', $labelIdList)
            ->orderBy('id', 'asc')
            ->get();
        foreach ($labelListNew as $key => $value) {
            $labelNameStrnew .= $value->label_name . '、';
        }
        $labelNameStrnew = rtrim($labelNameStrnew, "、");

        #编写日志表

        $content = '创建了号码包【' . $name . '】,' . '记录日期为' . $date . ',标签为【' . $labelNameStrnew . '】';
        (new EmailPackageLog())->addPackageLog($adminId, $content, $id);

        return  $this->success(array('id' => $id));
    }

    /**
     *  修改包信息
     *
     * @return Response
     */
    public function updateEmailPackage(Request $request)
    {
        $adminId = self::$uid;
        $id =  $request->input('package_id');
        $name = trim($request->input('name')); #包名称
        $date = $request->input('date');
        $amount = $request->input('amount');
        $labelIdStr = $request->input('label_id_str'); #label_id逗号隔开
        if (empty($name)) {
            $this->error('100520'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100525'); #名称太长了
        }
        if (empty($date)) {
            $this->error('100521'); #记录日期不能为空
        }
        if ((!empty($amount) && $amount < 0)  ||  (!empty($amount) && !is_numeric($amount))) {
            $this->error('100527'); #金额不符合规则
        }
        $package = DB::table('package_email')->where('id', $id)->first();

        #该内容不存在
        if (empty($package)) {
            $this->error('100523');
        }

        $package2 = DB::table('package_email')->where('package_name', $name)->first();


        #该内容不存在
        if (!empty($package2) && $package2->id != $id && $name == $package2->package_name) {
            $this->error('100526'); #文件名已经存在
        }

        $labelIdList = [];
        if (!empty($labelIdStr)) {
            $labelIdList = explode(',', $labelIdStr);
        }


        $save['package_name'] = $name;
        $save['date'] = $date;
        $save['updated_at'] = time();
        $save['amount'] = $amount;


        #更新包组状态
        $result = DB::table('package_email')->where('id', $id)->update($save);

        if (!$result) {
            $this->error('100524'); #操作失败
        }
        $labelIdStrDb = '';
        $labelNameStrDb = '';
        $labelNameStrnew = '';
        #查询标签
        $labelList = DB::table('package_label as a')
            ->select('b.id as label_id', 'b.label_name')
            ->leftJoin('label as b', 'b.id', '=', 'a.label_id')
            ->where('package_id', $id)
            ->orderBy('b.id', 'asc')
            ->get();
        foreach ($labelList as $key => $value) {
            $labelIdStrDb .= $value->label_id . ',';
            $labelNameStrDb .= $value->label_name . '、';
        }
        $labelIdStrDb = rtrim($labelIdStrDb, ",");
        $labelNameStrDb = rtrim($labelNameStrDb, "、");
        #查询标签
        $labelListNew = DB::table('label')
            ->select('id', 'label_name')
            ->whereIn('id', $labelIdList)
            ->orderBy('id', 'asc')
            ->get();
        foreach ($labelListNew as $key => $value) {
            $labelNameStrnew .= $value->label_name . '、';
        }
        $labelNameStrnew = rtrim($labelNameStrnew, "、");

        #编写日志表
        $ModelPackageLog = new EmailPackageLog();
        if ($name != $package->package_name) {
            $content = '修改了号码包名称【' . $package->package_name . '】→【' . $name . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($date != $package->date) {
            $content = '修改了记录日期【' . $package->date . '】→【' . $date . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($labelIdStr != $labelIdStrDb && $labelNameStrDb != $labelNameStrnew) {
            $content = '修改了标签【' . $labelNameStrDb . '】→【' . $labelNameStrnew . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        if ($amount != $package->amount) {
            $content = '修改了价格【' . $package->amount . '】→【' . $amount . '】';
            $ModelPackageLog->addPackageLog($adminId, $content, $id);
        }
        $originalLabels = DB::table('package_label')->where('package_id', $id)->where('type',3)->pluck('label_id')->toArray();

        $delRes = DB::table('package_label')->where('package_id', $id)->where('type',3)->delete();

        if ($labelIdList) {
            $labelAddList = [];
            foreach ($labelIdList as $key => $value) {
                $labelAdd['type'] = 3;
                $labelAdd['label_id'] = $value;
                $labelAdd['package_id'] = $id;
                $labelAdd['created_at'] = time();
                $labelAddList[] = $labelAdd;
            }
            $labelSum = DB::table('package_label')->insert($labelAddList);
        }
//        $removeLabels = array_diff($originalLabels,$labelIdList);//要移除的标签
//        $newLabels= array_diff($labelIdList,$originalLabels);//新增的标签
//        //新增或删除标签，扔到队列处理
//        if($removeLabels){
//            $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$removeLabels,'action'=>'remove']];
//            \App\Model\Mobile::pushPackageMultiQueue($data);
//        }
//        if($newLabels){
//            $data = ['function'=>'updateLabels','params'=>['packageId'=>$id,'labels'=>$newLabels,'action'=>'add']];
//            \App\Model\Mobile::pushPackageMultiQueue($data);
//        }

        return  $this->success();
    }

    /**
     *  删除包
     *
     * @return Response
     */
    public function deleteEmailPackage(Request $request)
    {

        $id = (int) Tools::routeParameter('id');

        if (empty($id)) {
            $this->error('100590'); #参数有误
        }

        $package = DB::table('package_email')->where('id', $id)->first();

        #该内容不存在
        if (empty($package)) {
            $this->error('100591');
        }

        $save['is_delete'] = 1;
        $save['updated_at'] = time();

        #更新包状态
        $result = DB::table('package_email')->where('id', $id)->delete();

        if (!$result) {
            $this->error('100592'); #操作失败
        }
        // $hosts = [
        //     // This is effectively equal to: "https://username:password!#$?*abc@foo.com:9200/"
        //     [
        //         'host' => env('ES_HOST'),
        //         'port' => env('ES_PORT'),
        //         'scheme' => 'http',
        //         'user' => env('ES_USERNAME'),
        //         'pass' => env('ES_PASSWORD'),
        //     ]
        //     #可传多个节点
        // ];

        // $client = ClientBuilder::create()           // Instantiate a new ClientBuilder
        //     ->setHosts($hosts)      // Set the hosts
        //     ->build();


        //存储从ES查询出来的数据
        // $i = 0;
        // $params = [
        //     'index' => 'phone_info',
        //     'body' => [
        //         "query" => [
        //             "bool" => [
        //                 'must' => [
        //                     'terms' => [
        //                         'number_package' => [$id]
        //                     ]
        //                 ]
        //             ]

        //         ],
        //         "script" => [
        //             "inline" => "ctx._source.number_package.remove(ctx._source.number_package.indexOf(params.number_package))",
        //             "params" => [
        //                 "number_package" => $id,
        //             ],
        //             "lang" => "painless"
        //         ]

        //     ],

        // ];

        // for ($i = 0; $i < 5; $i++) {
        //     $client->updateByQuery($params);
        // }









        return  $this->success();
    }

    /**
     * 号码包修改日志列表
     */
    public function emailChangeLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $this->error('100540'); #参数有误
        }

        $results = DB::table('email_package_log as a')
            ->select('a.id', 'content', 'a.created_at', 'b.account', 'a.package_id')
            ->leftJoin('admin as b', 'b.id', '=', 'a.admin_id')
            ->where('package_id', $packageId)
            ->orderBy('id', 'desc')
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    /**
     * 号码包提交日志列表
     */
    public function emailUploadLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $this->error('100550'); #参数有误
        }

        $results = DB::table('email_upload_log as a')
            ->select('a.*', 'b.platform_name', 'c.account')
            ->leftJoin('platform as b', 'b.id', '=', 'a.platform_id')
            ->leftJoin('admin as c', 'c.id', '=', 'a.admin_id')
            ->where('a.package_id', $packageId)
            ->where('a.is_deal', 1)
            ->orderBy('a.id', 'desc')
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

    /**
     * 号码包导出日志列表
     */
    public function emailExportLog(Request $request)
    {

        $packageId = $request->input('package_id');
        $pagesize = $request->input('pagesize') ?: 10;

        if (empty($packageId)) {
            $packageId = 0; #0为全部
        }

        $results = DB::table('email_export_log as a')
            ->select('a.*', 'b.account')
            ->leftJoin('admin as b', 'b.id', '=', 'a.admin_id')
            ->where('package_id', $packageId)
            ->orderBy('a.id', 'desc')
            ->paginate($pagesize);
        $exportData = $results->items();
        foreach ($exportData as $key => $value) {
            $timest = time() - $value->created_at;

            if ($timest > 15 * 24 * 60 * 60) {
                $exportData[$key]->is_ok = 0;
                $exportData[$key]->export_path = '';
            } else {
                $exportData[$key]->is_ok = 1;
                $exportData[$key]->export_path = '';
            }
        }
        $data['data'] = $exportData;
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }

}
