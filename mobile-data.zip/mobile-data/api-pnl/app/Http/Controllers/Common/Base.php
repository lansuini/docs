<?php
/*
 * @Author: your name
 * @Date: 2020-05-08 17:45:52
 * @LastEditTime: 2020-05-10 11:58:50
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Http\Controllers\Common\Base.php
 */

namespace App\Http\Controllers\Common;

use Laravel\Lumen\Routing\Controller as BaseController;

class Base extends BaseController
{
    //

    public static $action = "";
    public static $language = "";

    public static $languageList = [
        '1' => 'Simplified',
        '2' => 'Traditional',
        '3' => 'English',
    ];
    public function __construct()
    {

    }

    protected function success($data = [])
    {
        return [
            "code" => 200,
            // "msg"   => config('codeMultiSuccess.' . self::$action[self::$language]) ? config('codeMultiSuccess.' . self::$action[self::$language]) : 'Success',
            "msg"   => 'Success',
            "data" => $data
        ];
    }

    protected function error($code, $msg = "")
    {

        $msg = !empty(config('code.' . $code)['Simplified']) ? config('code.' . $code)['Simplified'] : '';

        throw new \Exception($msg, $code);
    }
}
