<?php

namespace App\Http\Controllers\Common;

use App\Http\Controllers\Common\Base;
use GatewayClient\Gateway;

class Auth extends Base
{
    public static $content = [];
    public static $uid = 0;
    public static $userAccount = "";
    public static $apiToken = "";

    public function __construct()
    {
        parent::__construct();

        self::$uid = isset(self::$content['uid']) ? self::$content['uid'] : 0;
        self::$userAccount = isset(self::$content['userAccount']) ? self::$content['userAccount'] : "";
        self::$apiToken = isset(self::$content['apiToken']) ? self::$content['apiToken'] : "";
    }
}
