<?php
/*
 * @Author: your name
 * @Date: 2020-03-18 16:05:12
 * @LastEditTime: 2020-06-11 11:53:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\app\Http\Controllers\v1\Agreement.php
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Common\Auth;
use Illuminate\Support\Facades\DB;
use App\Lib\Tools;
use Elasticsearch\ClientBuilder;

class Platform extends Auth
{

    /**
     * 平台列表
     */
    public function getPlatform(Request $request)
    {

        $pagesize = $request->input('pagesize') ?: 10;

        $results = DB::table('platform')
            ->select('id', 'platform_name', 'created_at')->orderBy('updated_at', 'desc')
            ->where('is_delete', 0)
            ->paginate($pagesize);


        $data['data'] = $results->items();
        $data['count'] =  count($results);
        $data['total'] =  $results->total();
        $data['currentPage'] = $results->currentPage();
        return $this->success($data);
    }



    /**
     *  修改平台信息
     *
     * @return Response
     */
    public function updatePlatform(Request $request)
    {

        $id =  $request->input('id');
        $name = trim($request->input('name')); #平台名称

        if (empty($id)) {
            $this->error('100330'); #参数有误
        }
        if (empty($name)) {
            $this->error('100331'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100335'); #名称太长了
        }

        $platform = DB::table('platform')->where('id', $id)->first();

        #该内容不存在
        if (empty($platform)) {
            $this->error('100332'); #该平台不存在
        }
        $platform = DB::table('platform')->where('platform_name', $name)->first();

        #该内容已经存在
        if (!empty($platform) && $platform->id != $id && $platform->platform_name === $name) {
            $this->error('100333');
        }
        $save['platform_name'] = $name;
        $save['updated_at'] = time();

        #更新平台组状态
        $result = DB::table('platform')->where('id', $id)->update($save);

        if (!$result) {
            $this->error('100334'); #操作失败
        }

        return  $this->success();
    }



    /**
     *  添加平台信息
     *
     * @return Response
     */
    public function addPlatform(Request $request)
    {

        $name = trim($request->input('name')); #平台名称

        if (empty($name)) {
            $this->error('100340'); #参数有误
        }
        if (mb_strlen($name) > 32) {
            $this->error('100343'); #名称太长了
        }
        $platform = DB::table('platform')->where('platform_name', $name)->first();

        #该内容已经存在
        if (!empty($platform) && $platform->platform_name === $name) {
            $this->error('100341');
        }

        $add['platform_name'] = $name;
        $add['created_at'] = time();
        $add['updated_at'] = time();
        #更新平台组状态
        $id = DB::table('platform')->insertGetId($add);

        if (!$id) {
            $this->error('100342'); #操作失败
        }

        return  $this->success(array('id' => $id));
    }


    /**
     *  删除平台信息
     *
     * @return Response
     */
    public function deletePlatform(Request $request)
    {

        $id = Tools::routeParameter('id');

        if (empty($id)) {
            $this->error('100350'); #参数有误
        }

        $label = DB::table('platform')->where('id', $id)->first();

        #该内容不存在
        if (empty($label)) {
            $this->error('100351');
        }

        #更新平台状态
        $result = DB::table('platform')->where('id', $id)->delete();

        if (!$result) {
            $this->error('100352'); #操作失败
        }

        return  $this->success();
    }
}
