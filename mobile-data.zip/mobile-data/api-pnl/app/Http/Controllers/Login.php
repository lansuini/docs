<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Common\Auth;
use Illuminate\Support\Facades\Cache;
use App\Lib\Tools;
use App\Lib\JwtToken;
use App\Model\Admin as ModelAdmin;
use Gregwar\Captcha\CaptchaBuilder;
use Gregwar\Captcha\PhraseBuilder;
use App\Lib\Log;

class Login extends Auth
{
    public function getcaptcha(Request $request)
    {
        try {
            $captchaSet = '3adhjkmpwxyEFHJKMNPRWXY';
            $captchaLength = 4;

            $phraseBuilder = new PhraseBuilder($captchaLength, $captchaSet);
            $captchaBuilder = new CaptchaBuilder(null, $phraseBuilder);
            $captchaBuilder->setBackgroundColor(255, 255, 255); //白色背景
            $captchaBuilder->build();

            $token = JwtToken::getInstance()->generate(0);
            $cacheKey = 'captcha:' . $token;
            Cache::put($cacheKey, $captchaBuilder->getPhrase(), config('Session.max_lifetime_seconds'));

            $arrResp = [
                'code' => 200,
                'msg' => '成功',
                'data' => [
                    'img_base64' => $captchaBuilder->inline(),
                    'token' => $token,
                ],
            ];
        } catch (\Exception $e) {
            $arrResp = [
                'code' => 500,
                'msg' => '获取验证码失败！'.$e->getMessage(),
                'data' => [],
            ];
        }

        return response()->json($arrResp);
    }

    public function login(Request $request)
    {
        $account = trim($request->input('account', ''));
        $password = trim($request->input('password', ''));
        $googlePassword = trim($request->input('google_password', ''));
//        $verifyCode = trim($request->input('verify_code', ''));
        $requestToken = trim($request->input("token", ''));
        Log::info($request->all(), 'login');
//        if (!JwtToken::getInstance()->verify($requestToken)) {
//            return response()->json([
//                'code' => 420,
//                'msg' => '验证码不正确',
//                'data' => [],
//            ]);
//        }

        //请求登录接口，便清掉缓存的captcha
//        $cacheKeyCaptcha = 'captcha:' . $requestToken;
//        $cacheCaptcha = Cache::pull($cacheKeyCaptcha, '');
//
//        if (!preg_match('/^[0-9a-zA-Z]{4}$/', $verifyCode) || empty($cacheCaptcha) || strtolower($cacheCaptcha) != strtolower($verifyCode)) {
//            return response()->json([
//                'code' => 420,
//                'msg' => '验证码不正确',
//                'data' => [],
//            ]);
//        }

        if (!preg_match('/^[0-9a-zA-Z\-_]{1,255}$/', $account)) {
            return response()->json([
                'code' => 400,
                'msg' => '账号或者密码不正确',
                'data' => [],
            ]);
        }

        if (!preg_match('/^[0-9a-zA-Z]{32}$/', $password)) {
            return response()->json([
                'code' => 400,
                'msg' => '账号或者密码不正确',
                'data' => [],
            ]);
        }

        $enable = env('GOOGLE_VERIFY_ENABLE', false);
        $secret = env('GOOGLE_VERIFY_SECRET_KEY', '');
        $ga = new \PHPGangsta_GoogleAuthenticator();
        $checkCode = $ga->verifyCode($secret, $googlePassword, 2);
        if ($enable && !$checkCode) {
            return response()->json([
                'code' => 400,
                'msg' => 'Google 验证码输入错误 ',
                'data' => [],
            ]);
        }

        $modelAdmin = new ModelAdmin();
        $objAdmin = $modelAdmin->getByAccount($account);
        if (empty($objAdmin) || strtolower($objAdmin->password) != strtolower($password)) {
            return response()->json([
                'code' => 400,
                'msg' => '账号或者密码不正确:'.$objAdmin->password.' '.$password,
                'data' => [],
            ]);
        }

        $token = JwtToken::getInstance()->generate($objAdmin->id);

        //单点登录，剔除之前登录的token
        $sessionKeyPrefix = 'PHPSESSID:';
        if (!empty($objAdmin->token)) {
            Cache::forget($sessionKeyPrefix . $objAdmin->token);
        }

        $sessionData = json_encode([
            'uid' => $objAdmin->id,
            'account' => $account,
        ]);
        Cache::put($sessionKeyPrefix . $token, $sessionData, config('Session.max_lifetime_seconds'));

        $objAdmin->token = $token;
        $objAdmin->save();

        return response()->json([
            'code' => 200,
            'msg' => '登录成功',
            'data' => [
                'token' => $token,
                'account' => $account,
                'id' => $objAdmin->id
            ],
        ]);
    }

    public function logout(Request $request)
    {
        $sessionKey = 'PHPSESSID:' . self::$apiToken;

        Cache::forget($sessionKey);

        return response()->json([
            'code' => 200,
            'msg' => '成功',
            'data' => [],
        ]);
    }
}
