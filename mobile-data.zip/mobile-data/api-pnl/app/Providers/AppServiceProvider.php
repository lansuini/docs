<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Elasticsearch\ClientBuilder as ESClientBuilder;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        // 注册一个名为 es 的单例
        $this->app->singleton('es', function () {
            // 从配置文件读取 Elasticsearch 服务器列表
            $builder = ESClientBuilder::create()->setHosts(config('database.elasticsearch.hosts'));
            // 如果是开发环境
            if (app()->environment() === 'local') {
                // 配置日志，Elasticsearch 的请求和返回数据将打印到日志文件中，方便我们调试
                // Laravel 5.5后getMonolog() 改成了 getLogger()
                $builder->setLogger(app('log')->getLogger());
            }else{
                $logger = new Logger('ES');
                $logger->pushHandler(new StreamHandler(base_path() .'/storage/logs/ES.log', Logger::WARNING));
                $builder->setLogger($logger);
            }
            $client = $builder->build();
//            $params = [
//                'index' => 'phone_info',
//                'body' => [
//                    'settings' => [
//                        "index.indexing.slowlog.threshold.index.warn"=> "10s",
//                        "index.indexing.slowlog.threshold.index.info"=> "5s",
//                        "index.indexing.slowlog.threshold.index.debug"=> "2s",
//                        "index.indexing.slowlog.threshold.index.trace"=> "500ms",
//                        "index.indexing.slowlog.level"=> "info",
//                        "index.indexing.slowlog.source"=> "1000",
//                    ],
//                ]
//            ];
//            $client->indices()->putSettings($params);
            return $client;
        });
    }
}
