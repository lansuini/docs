<?php

namespace App\Lib;


//封装
class Hash

{
    //一致性哈希  暂时用不到  会记录每个chatId的库
    // public   static function getHash($hostsMap, $imgName)
    // {
    //     $hostsMap;
    //     $hashRing = [];
    //     $virtualNodeLen = 10; //每个节点的虚拟节点个数

    //     //将节点映射到hash环上面
    //     if (empty($hashRing)) {
    //         foreach ($hostsMap as $h) {
    //             $i = 0;
    //             while ($i < $virtualNodeLen) {
    //                 $hostKey = fmod(crc32($h . '_' . $i), pow(2, 32));
    //                 $hostKey = abs($hostKey);
    //                 $hashRing[$hostKey] = $h;
    //                 $i++;
    //             }
    //         }
    //         //从小到大排序，便于查找
    //         ksort($hashRing);
    //     }

    //     //计算图片hash
    //     $imgKey = fmod(crc32($imgName), pow(2, 32));
    //     $imgKey = abs($imgKey);
    //     foreach ($hashRing as $hostKey => $h) {
    //         if ($imgKey < $hostKey) {
    //             return  $h;
    //         }
    //     }
    //     return current($hashRing);
    // }
    // 普通哈希

    public static function getPhoneServerById($id)
    {

        $res = self::calc_hash_db($id, 100);
        return $res;
    }
    //分库分表算法  
    public static function calc_hash_db($u, $s = 10)
    {
        $h = sprintf("%u", crc32($u));
        $h1 = intval(fmod($h, $s)) + 1;
        return $h1;
    }
}
