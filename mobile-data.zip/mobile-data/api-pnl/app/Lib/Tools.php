<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 11:17:52
 * @LastEditTime: 2020-06-04 18:00:46
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Lib\Tools.php
 */

namespace App\Lib;

class Tools
{

    public static function getPlatformIdByAlias($alias)
    {
        $names = explode(',', env('ALIAS_NAMES'));
        $ids = explode(',', env('ALIAS_PLATFORM_IDS'));
        $data = array_combine($names, $ids);
        return $data[$alias] ?? 0;
    }

    //获取指定位数的随机数字
    public static function getRandNum($length)
    {
        $str = "0123456789";
        $strLen = strlen($str);

        $result = "";
        for ($i = 0; $i < $length; $i++) {
            $pos = mt_rand(0, $strLen - 1);
            $result .= $str[$pos];
        }

        return $result;
    }

    //获取指定位数的随机字符串
    public static function getRandStr($length)
    {
        $str = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $strLen = strlen($str);

        $result = "";
        for ($i = 0; $i < $length; $i++) {
            $pos = mt_rand(0, $strLen - 1);
            $result .= $str[$pos];
        }

        return $result;
    }

    //产生唯一字符串
    public static function generateUniqueStr()
    {
        return microtime(true) . '&&' . self::getRandStr(6);
    }

    public static function routeParameter($name, $default = null)
    {
        $routeInfo = app('request')->route();

        return array_get($routeInfo[2], $name, $default);
    }
    /**
     * zip解压方法
     * @param string $filePath 压缩包所在地址 【绝对文件地址】d:/test/123.zip
     * @param string $path 解压路径 【绝对文件目录路径】d:/test
     * @return bool
     */
    public static function unzip($zipName, $dir)
    {
        $zip = new \ZipArchive;

        $res = $zip->open($zipName);

        if (!file_exists($dir)) {
            self::makedir($dir);
        }
        $docnum = $zip->numFiles;
        for ($i = 0; $i < $docnum; $i++) {
            $statInfo = $zip->statIndex($i);

            if ($statInfo['crc'] == 0) {
                //新建目录

                if (!file_exists($dir . '/' . substr($statInfo['name'], 0, -1))) {
                    self::makedir($dir . '/' . substr($statInfo['name'], 0, -1));
                }
            } else {
                //拷贝文件
                $rawName = $zip->getNameIndex($i, \ZipArchive::FL_ENC_RAW);

                $out_string = mb_detect_encoding($rawName, array("ASCII", "UTF-8", "GB2312", "GBK", "BIG5", 'EUC-CN'));
                if ($out_string != 'UTF-8') {
                    $rawName = iconv('GBK', 'UTF-8', $rawName);
                }
                $tmpDir = $dir . $rawName;
                $tmpDir = substr($tmpDir, 0, strrpos($tmpDir, '/'));
                if (!file_exists($tmpDir)) {
                    self::makedir($tmpDir);
                }

                copy('zip://' . $zipName . '#' . $statInfo['name'], $dir . $rawName);
            }
        }
        return true;
    }

    public static function transcoding($fileName)
    {
        $encoding = mb_detect_encoding($fileName, ['UTF-8', 'GBK', 'BIG5', 'CP936']);
        if (DIRECTORY_SEPARATOR == '/') { //linux
            $filename = iconv($encoding, 'UTF-8', $fileName);
        } else { //win
            $filename = iconv($encoding, 'GBK', $fileName);
        }
        return $filename;
    }

    public static function getTxtByDir($dir)
    {
        $files = [];

        if (@$handle = opendir($dir)) {
            while (($file = readdir($handle)) !== false) {
                if ($file != ".." && $file != ".") {
                    if (is_dir($dir . "/" . $file)) { //如果是子文件夹，进行递归

                        $files = array_merge($files, self::getTxtByDir($dir . "/" . $file));
                    } else {
                        if (substr(strrchr($file, '.'), 1) == 'txt') {

                            $files[] = $dir . '/' . $file;
                        }
                    }
                }
            }
            closedir($handle);
        }

        return $files;
    }
    public static function format_bytes($size, $delimiter = '')
    {
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
        for ($i = 0; $size >= 1024 && $i < 5; $i++) {
            $size /= 1024;
        }

        return round($size, 2) . $delimiter . "&nbsp;" . $units[$i];
    }
    public static function makedir($path)
    {
        $arr = array();
        while (!is_dir($path)) {
            array_push($arr, $path); //把路径中的各级父目录压入到数组中去，直接有父目录存在为止（即上面一行is_dir判断出来有目录，条件为假退出while循环）
            $path = dirname($path); //父目录
        }
        if (empty($arr)) { //arr为空证明上面的while循环没有执行，即目录已经存在
            echo $path, '已经存在';
            return true;
        }
        while (count($arr)) {
            $parentdir = array_pop($arr); //弹出最后一个数组单元
            mkdir($parentdir); //从父目录往下创建
        }
    }
}
