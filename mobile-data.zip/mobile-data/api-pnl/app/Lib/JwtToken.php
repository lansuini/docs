<?php

namespace App\Lib;

use Lcobucci\JWT\Builder;
use Lcobucci\JWT\Signer\Key;
use Lcobucci\JWT\Signer\Hmac\Sha256;
use Lcobucci\JWT\Parser;
use App\Lib\Tools;
use Lcobucci\JWT\Token;
use Lcobucci\JWT\ValidationData;

class JwtToken
{
    private static $instance = null;
    private $config = [];

    private function __construct()
    {
        $this->config['signKey'] = config('JwtToken.signKey');
        $this->config['issuedBy'] = config('JwtToken.issuedBy');
    }

    private function __clone()
    {
    }

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function generate($userId)
    {
        $time = time();
        $randStr = Tools::generateUniqueStr();

        $token = (new Builder())
            ->issuedBy($this->config['issuedBy'])
            ->issuedAt($time)
            ->with('userId', $userId)
            ->with('randStr', $randStr)
            ->sign(new Sha256(), new Key($this->config['signKey']))
            ->getToken();

        return (string) $token;
    }

    public function verify($token)
    {
        if (!is_string($token)) {
            return false;
        }

        $token = trim($token);

        try {
            $parsedToken = (new Parser())->parse($token);
            if (!($parsedToken instanceof Token)) {
                throw new \Exception("不合法的token字串");
            }

            $validateData = new ValidationData();
            $validateData->setIssuer($this->config['issuedBy']);
            if (!$parsedToken->validate($validateData)) {
                throw new \Exception("token数据检验不通过");
            }

            //验证签名
            if (!$parsedToken->verify(new Sha256(), $this->config['signKey'])) {
                throw new \Exception("token签名检验不通过");
            }

            $userId = $parsedToken->getClaim('userId');
            if (!is_numeric($userId) || !preg_match('/^((0)|([1-9]{1}\d{0,9}))$/', $userId)) {
                throw new \Exception("token校验参数错误");
            }

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function parseUserId($token)
    {
        // if (!$this->verify($token)) {
        //     return null;
        // }

        return (new Parser())->parse($token)->getClaim('userId');
    }


    public function getNameToken($name, $adminId)
    {
        $time = time();
        $randStr = Tools::generateUniqueStr();

        $token = (new Builder())
            ->issuedBy($this->config['issuedBy'])
            ->issuedAt($time)
            ->with('name', $name)
            ->with('adminId', $adminId)
            ->with('randStr', $randStr)
            ->sign(new Sha256(), new Key($this->config['signKey']))
            ->getToken();

        return (string) $token;
    }

    public function nameVerify($token)
    {
        if (!is_string($token)) {
            return false;
        }

        $token = trim($token);

        try {
            $parsedToken = (new Parser())->parse($token);
            if (!($parsedToken instanceof Token)) {
                throw new \Exception("不合法的token字串");
            }

            $validateData = new ValidationData();
            $validateData->setIssuer($this->config['issuedBy']);
            if (!$parsedToken->validate($validateData)) {
                throw new \Exception("token数据检验不通过");
            }

            //验证签名
            if (!$parsedToken->verify(new Sha256(), $this->config['signKey'])) {
                throw new \Exception("token签名检验不通过");
            }

            $name = $parsedToken->getClaim('name');
            if (empty($name)) {
                throw new \Exception("token校验参数错误");
            }
            $adminId = $parsedToken->getClaim('adminId');
            if (!is_numeric($adminId) || !preg_match('/^((0)|([1-9]{1}\d{0,9}))$/', $adminId)) {
                throw new \Exception("token校验参数错误");
            }
            return $adminId;
        } catch (\Exception $e) {
            return false;
        }
    }
}
