<?php
/*
 * @Author: your name
 * @Date: 2020-05-11 15:21:47
 * @LastEditTime: 2020-06-10 14:09:20
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Lib\Phone.php
 */

namespace App\Lib;


//封装
class Phone

{
    //运营商
    public static function checkOperator($phone)
    {

        if (!preg_match("/^1[3456789]\d{9}$/", $phone)) {
            return 0;
        }

        return 1;
    }
    //检测金额
    public static function checkMoney($money)
    {
        if (!preg_match("/^\d+(\.\d+)?$/", $money) && !preg_match(" /^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/", $money)) {
            return 0;
        }
        return 1;
    }
}
