<?php
/*
 * @Author: your name
 * @Date: 2020-06-01 10:40:57
 * @LastEditTime: 2020-06-01 10:41:08
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \api-pnl\app\Lib\Log.php
 */


namespace App\Lib;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter;

class Log
{

    public  static function info($info, $fileName = 'lumen')
    {
        $log = new Logger('error');

        if (!is_array($info)) {
            $message = $info;
            $info = [];
        } else {
            $message = '';
        }
        $hander = new StreamHandler(base_path() . '/storage/logs/' . $fileName . '.log');
        $hander->setFormatter(new LineFormatter(null, null, true, true));
        $log->pushHandler($hander);
        $log->info($message, $info);
    }
}
