#!/bin/sh


# Start php and nginx 
while :
do
  runningPHP=$(ps -ef |grep "php-fpm" |grep -v "grep" | wc -l)
  if [ "$runningPHP" -eq 0 ] ; then
    echo "PHP service was not started. Startting now." 
    php-fpm
  fi

  runningNginx=$(ps -ef |grep "nginx" |grep -v "grep" | wc -l)
  if [ "$runningNginx" -eq 0 ] ; then
    echo "Nginx service was not started. Startting now." 
    /usr/local/nginx/sbin/nginx
  fi
  runningDEAL=$(ps -ef |grep "dealData.php" |grep -v "grep" | wc -l)
  if [ "$runningDEAL" -eq 0 ] ; then
    echo "php shell service was not started. Startting now." 
    nohup php  /home/www-data/api-pnl/app/Library/dealData.php restart -d 
  fi
  sleep 5
done