<?php

return [
    "signKey" => "955ea669ubc90d32a200c6",
    "issuedBy" => "koer.net",
];
