<?php
/*
 * @Author: your name
 * @Date: 2020-03-12 15:02:04
 * @LastEditTime: 2020-06-12 11:38:23
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \api-wallet\config\code.php
 */
// code码  一个页面100个
return [
    '401' => [
        'Simplified' => '',
    ],
    '100330' => [
        'Simplified' => '参数有误',
    ],
    '100331' => [
        'Simplified' => '参数有误',
    ],
    '100332' => [
        'Simplified' => '该平台不存在',
    ],
    '100333' => [
        'Simplified' => '该平台已经存在',
    ],
    '100334' => [
        'Simplified' => '操作失败',
    ],
    '100335' => [
        'Simplified' => '名称太长',
    ],
    '100340' => [
        'Simplified' => '参数有误',
    ],
    '100341' => [
        'Simplified' => '该平台已经存在',
    ],
    '100342' => [
        'Simplified' => '操作失败',
    ],
    '100343' => [
        'Simplified' => '名称太长',
    ],
    '100433' => [
        'Simplified' => '名称太长',
    ],
    '100430' => [
        'Simplified' => '参数有误',
    ],
    '100431' => [
        'Simplified' => '参数有误',
    ],
    '100432' => [
        'Simplified' => '该标签不存在',
    ],
    '100433' => [
        'Simplified' => '该标签已存在',
    ],
    '100434' => [
        'Simplified' => '操作失败',
    ],
    '100435' => [
        'Simplified' => '名称太长',
    ],
    '100440' => [
        'Simplified' => '参数有误',
    ],
    '100441' => [
        'Simplified' => '该标签已存在',
    ],
    '100442' => [
        'Simplified' => '参数有误',
    ],
    '100443' => [
        'Simplified' => '名称太长',
    ],
    '100500' => [
        'Simplified' => '参数有误',
    ],
    '100501' => [
        'Simplified' => '参数有误',
    ],

    '100510' => [
        'Simplified' => '参数有误',
    ],
    '100520' => [
        'Simplified' => '参数有误',
    ],
    '100521' => [
        'Simplified' => '记录日期不能为空',
    ],
    '100522' => [
        'Simplified' => '日期参数有误',
    ],
    '100523' => [
        'Simplified' => '该内容不存在',
    ],
    '100524' => [
        'Simplified' => '操作失败',
    ],
    '100525' => [
        'Simplified' => '名称太长',
    ],
    '100526' => [
        'Simplified' => '该名称已存在',
    ],
    '100527' => [
        'Simplified' => '金额不符合规则',
    ],
    '100530' => [
        'Simplified' => '参数有误',
    ],
    '100531' => [
        'Simplified' => '记录日期不能为空',
    ],
    '100532' => [
        'Simplified' => '日期参数有误',
    ],
    '100533' => [
        'Simplified' => '该名已存在',
    ],
    '100534' => [
        'Simplified' => '操作失败',
    ],
    '100535' => [
        'Simplified' => '名称太长',
    ],
    '100536' => [
        'Simplified' => '金额不符合规则',
    ],
    '100540' => [
        'Simplified' => '参数有误',
        'Traditional' => '',
        'English' => '',
    ],
    '100550' => [
        'Simplified' => '参数有误',
        'Traditional' => '',
        'English' => '',
    ],
    '100560' => [
        'Simplified' => '参数有误',
        'Traditional' => '',
        'English' => '',
    ],
    '100570' => [
        'Simplified' => '参数有误',
        'Traditional' => '',
        'English' => '',
    ],
    '100580' => [
        'Simplified' => '参数有误',
        'Traditional' => '',
        'English' => '',
    ],
    '100581' => [
        'Simplified' => '验证未通过',
        'Traditional' => '',
        'English' => '',
    ],
    '100582' => [
        'Simplified' => '有效期已过',
        'Traditional' => '',
        'English' => '',
    ],
    '100590' => [
        'Simplified' => '参数有误',
    ],
    '100591' => [
        'Simplified' => '该内容不存在',
    ],
    '100592' => [
        'Simplified' => '操作失效',
    ],
    '100701' => [
        'Simplified' => '参数有误',
    ],
    '100702' => [
        'Simplified' => '参数有误',
    ],
    '100703' => [
        'Simplified' => '参数有误',
    ],
    '100704' => [
        'Simplified' => '平台有误',
    ],
    '100705' => [
        'Simplified' => '文件格式有误',
    ],
    '100706' => [
        'Simplified' => '上传失败',
    ],
    '100707' => [
        'Simplified' => 'ZIP格式有误',
    ],
    '100708' => [
        'Simplified' => 'txt文件名不包含城市名或者省份名',
    ],
    '100709' => [
        'Simplified' => 'txt文件名中不存在运营商名称',
    ],
    '100801' => [
        'Simplified' => '上传失败',
    ],
    '100802' => [
        'Simplified' => '上传失败',
    ],
    '100803' => [
        'Simplified' => '手机号码不符合规范',
    ],
    '100804' => [
        'Simplified' => '请指定导出字段',
    ],
    '100805' => [
        'Simplified' => '无可用数据',
    ],
    '100806' => [
        'Simplified' => '参数错误',
    ],
    '100807' => [
        'Simplified' => '包不能为空',
    ],
    '100561' => [
        'Simplified' => 'token失效',
    ],

];
