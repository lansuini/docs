<?php

return [
    "max_lifetime_seconds" => 3600,
    "file_download_max_seconds" => 10,
];