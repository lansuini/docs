/*
 Navicat Premium Data Transfer

 Source Server         : phone
 Source Server Type    : MySQL
 Source Server Version : 50647
 Source Host           : 47.57.146.125:16001
 Source Schema         : pnl

 Target Server Type    : MySQL
 Target Server Version : 50647
 File Encoding         : 65001

 Date: 01/06/2020 13:47:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for pnl_admin
-- ----------------------------
DROP TABLE IF EXISTS `pnl_admin`;
CREATE TABLE `pnl_admin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '账号',
  `password` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '密码',
  `token` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '最新登录的token',
  `created_at` int(10) NULL DEFAULT NULL,
  `updated_at` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pnl_label
-- ----------------------------
DROP TABLE IF EXISTS `pnl_label`;
CREATE TABLE `pnl_label`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` int(10) NULL DEFAULT NULL,
  `updated_at` int(10) NULL DEFAULT NULL,
  `is_delete` tinyint(2) NULL DEFAULT 0 COMMENT '是否删除，1为删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pnl_mobile_74
-- ----------------------------

-- ----------------------------
-- Table structure for pnl_package
-- ----------------------------
DROP TABLE IF EXISTS `pnl_package`;
CREATE TABLE `pnl_package`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '包名',
  `mobile_table_sign` int(11) NULL DEFAULT NULL COMMENT '包的手机号码在数据表的标识',
  `created_at` int(10) NULL DEFAULT NULL COMMENT '创建时间',
  `updated_at` int(10) NULL DEFAULT NULL COMMENT '更新时间',
  `total` int(11) NULL DEFAULT 0 COMMENT '号码数量',
  `real_total` int(11) NULL DEFAULT 0 COMMENT '实际数量',
  `cmcc_sum` int(11) NULL DEFAULT 0 COMMENT '可用移动号数量',
  `cucc_sum` int(11) NULL DEFAULT 0 COMMENT '可用联通号数量',
  `ctcc_sum` int(11) NULL DEFAULT 0 COMMENT '可用电信号数量',
  `virtual_sum` int(11) NULL DEFAULT 0 COMMENT '虚拟号码数量',
  `good_sum` int(11) NULL DEFAULT 0 COMMENT '活跃号数量',
  `vacant_sum` int(11) NULL DEFAULT 0 COMMENT '空号的数量',
  `sleep_sum` int(11) NULL DEFAULT 0 COMMENT '沉默号的数量',
  `risk_sum` int(11) NULL DEFAULT 0 COMMENT '风险号的数量',
  `date` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '记录日期 8位数 20201212',
  `admin_id` int(11) NULL DEFAULT NULL COMMENT '写入数据库人ID',
  `unverified_sum` int(11) NULL DEFAULT 0 COMMENT '未验证号码数量',
  `register_sum` int(11) NULL DEFAULT 0 COMMENT '已注册号码数量',
  `feedback_sum` int(11) NULL DEFAULT 0 COMMENT '已反馈号码数量',
  `no_feedback_sum` int(11) NULL DEFAULT 0 COMMENT '未反馈号码数量',
  `used_sum` int(11) NULL DEFAULT 0 COMMENT '已使用号码数量',
  `no_used_sum` int(11) NULL DEFAULT 0 COMMENT '未使用号码数量',
  `no_register_sum` int(11) NULL DEFAULT 0 COMMENT '未注册号码',
  `amount` decimal(13, 2) NULL DEFAULT 0.00 COMMENT '数据包金额',
  `one_amount` decimal(13, 2) NULL DEFAULT 0.00 COMMENT '一条数据金额',
  `export_sum` int(11) NULL DEFAULT 0 COMMENT '导出次数',
  `import_sum` int(11) NULL DEFAULT 0 COMMENT '导入次数',
  `is_delete` tinyint(2) NULL DEFAULT 0 COMMENT '1为删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pnl_package_export_log
-- ----------------------------
DROP TABLE IF EXISTS `pnl_package_export_log`;
CREATE TABLE `pnl_package_export_log`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_id` int(11) NULL DEFAULT NULL COMMENT '包ID',
  `file_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件名',
  `condition` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '筛选条件',
  `admin_id` int(11) NULL DEFAULT NULL COMMENT '操作人',
  `created_at` int(10) NULL DEFAULT NULL COMMENT '生成时间',
  `export_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '导出地址',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for pnl_package_label
-- ----------------------------
DROP TABLE IF EXISTS `pnl_package_label`;
CREATE TABLE `pnl_package_label`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_id` int(11) NULL DEFAULT NULL COMMENT '标签ID',
  `package_id` int(11) NULL DEFAULT NULL COMMENT '文件包ID',
  `created_at` int(10) NULL DEFAULT NULL,
  `updated_at` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `label_id`(`label_id`) USING BTREE,
  INDEX `package_id`(`package_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pnl_package_log
-- ----------------------------
DROP TABLE IF EXISTS `pnl_package_log`;
CREATE TABLE `pnl_package_log`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '日志内容',
  `created_at` int(11) NULL DEFAULT NULL COMMENT '写入时间',
  `admin_id` int(11) NULL DEFAULT NULL COMMENT '操作人',
  `package_id` int(11) NULL DEFAULT NULL COMMENT '号码包ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for pnl_package_upload_log
-- ----------------------------
DROP TABLE IF EXISTS `pnl_package_upload_log`;
CREATE TABLE `pnl_package_upload_log`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(2) NULL DEFAULT NULL COMMENT '上传类型  1为新号2为使用号3为注册号4为反馈号5为沉默号6为风险号7为空号',
  `platform_id` int(11) NULL DEFAULT NULL COMMENT '平台id',
  `package_id` int(11) NULL DEFAULT NULL COMMENT '包id',
  `total` int(11) NULL DEFAULT 0 COMMENT '号码数量',
  `real_total` int(11) NULL DEFAULT 0 COMMENT '实际数量',
  `cmcc_sum` int(11) NULL DEFAULT 0 COMMENT '可用移动号数量',
  `cucc_sum` int(11) NULL DEFAULT 0 COMMENT '可用联通号数量',
  `ctcc_sum` int(11) NULL DEFAULT 0 COMMENT '可用电信号数量',
  `virtual_sum` int(11) NULL DEFAULT 0 COMMENT '虚拟号码数量',
  `invalid_sum` int(11) NULL DEFAULT 0 COMMENT '无效号码数量(格式错误)',
  `has_sum` int(11) NULL DEFAULT 0 COMMENT '已有号码数量(数据库重复)',
  `file_reply_sum` int(11) NULL DEFAULT 0 COMMENT '文件中重复数量',
  `other_package_reply_sum` int(11) NULL DEFAULT 0 COMMENT '存在其他号码包的数量',
  `money_sum` decimal(65, 2) NULL DEFAULT 0.00 COMMENT '总金额',
  `money_avg` decimal(65, 2) UNSIGNED NULL DEFAULT 0.00 COMMENT '平均金额',
  `old_file_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上传原文件名',
  `new_file_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '存储服务器的文件名',
  `invalid_number_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '无效的json数据',
  `is_deal` int(2) NULL DEFAULT 0 COMMENT '是否处理完毕  0为否 1为是',
  `insert_sum` int(11) NULL DEFAULT 0 COMMENT '新增的数量',
  `use_time` int(10) NULL DEFAULT NULL COMMENT '使用时间',
  `created_at` int(10) NULL DEFAULT NULL COMMENT '创建时间', 
  `updated_at` int(10) NULL DEFAULT NULL COMMENT '更新时间',
  `admin_id` int(11) NULL DEFAULT NULL COMMENT '操作人',
  `file_type` int(2) NULL DEFAULT NULL COMMENT '1为txt 2为zip',
  `unzip_dir` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '解压后的地址',
  `error_log`  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '报错的log日志' ,
  `deal_time`  int(11) NULL DEFAULT NULL COMMENT '脚本耗时' ,
  `deal_schedule`  varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '进度' ,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for pnl_platform
-- ----------------------------
DROP TABLE IF EXISTS `pnl_platform`;
CREATE TABLE `pnl_platform`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
  `created_at` int(10) NULL DEFAULT NULL COMMENT '添加时间',
  `updated_at` int(10) NULL DEFAULT NULL COMMENT '更新时间',
  `is_delete` tinyint(2) NULL DEFAULT 0 COMMENT '是否删除，1为删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
