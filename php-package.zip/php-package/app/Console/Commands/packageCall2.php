<?php

namespace App\Console\Commands;
use Illuminate\Support\Facades\File;
use Illuminate\Console\Command;

class packageCall2 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'packageCall2:exec {type} {alias} {channel} {code}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $type = $this->argument('type');
        $alias = strtolower($this->argument('alias'));
        $channel = $this->argument('channel');
        $code = $this->argument('code');

        $code = $code ?? "0";
        $this->call('package' . $type . ':exec', [
            'alias' => strtolower($alias),
            'channel' => $channel,
            'code' => $code,
        ]);

        $local = storage_path('package/' .  $alias . '/' . $alias . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk'));
        $target = env('UPLOAD_STORAGE_PATH') . '/' . strtoupper($alias) . '/' . 'autopack/' . strtolower($alias) . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk');
        File::copy($local, $target);
        echo 'Package Call' . PHP_EOL;
    }
}
