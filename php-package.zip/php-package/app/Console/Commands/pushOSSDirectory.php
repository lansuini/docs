<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class pushOSSDirectory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pushOSSDirectory {local} {remote} {accessId} {accessKeySecret} {endpoint} {bucket}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'pushOSSDirectory';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $remote = $this->argument('remote');
        $local = $this->argument('local');
        $accessId = $this->argument('accessId');
        $accessKeySecret = $this->argument('accessKeySecret');
        $endpoint = $this->argument('endpoint');
        $bucket = $this->argument('bucket');

        $a1 = $accessId;
        $a2 = $accessKeySecret;
        $a3 = $bucket;
        $a4 = $endpoint;
        $a5 = $local;
        $a6 = $remote;
        $basePath = base_path();
        $res = exec("python3 {$basePath}/upload.py {$a1} {$a2} {$a3} {$a4} {$a5} {$a6}");
        echo "python3 {$basePath}/upload.py {$a1} {$a2} {$a3} {$a4} {$a5} {$a6}" . PHP_EOL;
        print_r($res);
        echo PHP_EOL;
        return 0;
    }
}
