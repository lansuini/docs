<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Artisan;
class packageCall extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'packageCall:exec {type} {alias} {channel} {code} {accessId} {accessKeySecret} {endpoint} {bucket} {domain}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $type = $this->argument('type');
        $alias = $this->argument('alias');
        $channel = $this->argument('channel');
        $code = $this->argument('code');
        $accessId = $this->argument('accessId');
        $accessKeySecret = $this->argument('accessKeySecret');
        $endpoint = $this->argument('endpoint');
        $bucket = $this->argument('bucket');
        $domain = $this->argument('domain');
        $code = $code ?? "0";
        $this->call('package' . $type . ':exec', [
            'alias' => $alias,
            'channel' => $channel,
            'code' => $code,
        ]);

        $local = storage_path('package/' . $alias . '/' . $alias . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk'));
        $target = env('UPLOAD_STORAGE_PATH') . '/' . $alias . '/' . 'autopack/' . strtolower($alias) . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk');
        File::copy($local, $target);
        
        $enabled = getenv($alias . '_OSS_ENABLED', false);
        if ($enabled) {
            // $this->call('pushOss:exec', [
            //     'local' => storage_path('package/' . $alias . '/' . $alias . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk')),
            //     'remote' => 'autopack/' . strtolower($alias) . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk'),
            //     'accessId' => $accessId,
            //     'accessKeySecret' => $accessKeySecret,
            //     'endpoint' => $endpoint,
            //     'bucket' => $bucket,
            //     'domain' => $domain,
            // ]);
        }

        $enabled = getenv('SERVER_SCP_ENABLED', false);
        if ($enabled) {
            $type = 'SERVER_SCP';
            $hosts = explode(',', trim(env($type . '_HOSTS')));
            foreach ($hosts ?? [] as $host) {
                Artisan::queue('syncHost', [
                    'host' => $host,
                    'type' => $type,
                    'local' => $local,
                    'remote' => $target,
                ])->onConnection('redis')->onQueue('syncoss')->delay(0);
            }
        }
        echo 'Package Call' . PHP_EOL;
    }
}
