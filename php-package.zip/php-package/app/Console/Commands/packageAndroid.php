<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class packageAndroid extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'packageAndroid:exec {alias} {channel} {code}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $alias = $this->argument('alias');
        $channel = $this->argument('channel');
        $code = $this->argument('code');
        $lib = env('TOOL_PATH', '/data/channeltool') . '/src/libs/walle-cli-all.jar';

        $tempFilename = storage_path() . '/host_app-' . strtolower($alias) . '-release.apk';
        $path = env('TOOL_PATH', '/data/channeltool') . '/tempPackages/android/host_app-' . strtolower($alias) . '-release.apk';
        $path = is_file($tempFilename) ? $tempFilename : $path;
        
        $code = $code ?? "0";
        if (!is_file($path)) {
            echo "文件不存在:" . $path;
            return false;
        }

        if (!is_dir(storage_path('package/' . $alias))) {
            mkdir(storage_path('package/' . $alias), 0777, true);
        }

        $spath = storage_path('package/' . $alias . '/' . $alias . '_' . $channel . '_' . $code . '.apk');

        if (is_file($spath)) {
            @unlink($spath);
        }

        $cmd = "java -jar {$lib} put -c {$channel} -e spreadCode={$code} {$path} {$spath}";
        echo $cmd . PHP_EOL;
        echo exec($cmd);
        echo PHP_EOL;
        echo 'Package Android ' . $alias . ' ' . $channel . ' ' . $code . PHP_EOL;
    }
}
