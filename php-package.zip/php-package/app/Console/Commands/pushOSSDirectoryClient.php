<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class pushOSSDirectoryClient extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pushOSSDirectoryClient {client} {local} {remote}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'pushOSSDirectoryClient';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $client = $this->argument('client');
        $accessId = getenv($client . '_OSS_ACCESS_KEY_ID');
        $accessKeySecret = getenv($client . '_OSS_ACCESS_KEY_SECRET');
        $bucket = getenv($client . '_OSS_BUCKET');
        $endpoint = getenv($client . '_OSS_ENDPOINT');
        $this->call('pushOSSDirectory', [
            'local' => $this->argument('local'),
            'remote' => $this->argument('remote'),
            'accessId' => $accessId,
            'accessKeySecret' => $accessKeySecret,
            'endpoint' => $endpoint,
            'bucket' => $bucket,
        ]);
        return 0;
    }
}
