<?php

namespace App\Console\Commands;

// use phpseclib;
use Illuminate\Console\Command;
// use phpseclib3\Net\SCP;
use phpseclib3\Crypt\PublicKeyLoader;
use phpseclib3\Net\SFTP;

class sync extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sync {type} {local} {remote}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'sync';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $type = $this->argument('type');
        $local = $this->argument('local');
        $remote = $this->argument('remote');

        $hosts = explode(',', trim(env($type . '_HOSTS')));
        $t = \file_get_contents(trim(env($type . '_LOGIN_USER_RSA')));
        $uid = env($type . '_LOGIN_USER_ROLE_UID');
        $gid = env($type . '_LOGIN_USER_ROLE_GUID', $uid);

        echo "【SFTP】 type:{$type} local:{$local} remote:{$remote} hosts:" . env($type . '_HOSTS') . PHP_EOL;
        $key = PublicKeyLoader::load($t);
        foreach ($hosts ?? [] as $host) {
            // list($ip, $port) = explode(':', $host);
            $h = explode(':', $host);
            $ip = $h[0];
            $port = $h[1] ?? 22;
            // $port = $port ?? 22;
            $sftp = new SFTP($ip, $port);
            echo "scp login: {$host}" . PHP_EOL;
            if (!$sftp->login(env($type . '_LOGIN_USER'), $key)) {
                echo "{$host} sftp failed" . PHP_EOL;
                continue;
            }
            echo "scp login: {$host} success" . PHP_EOL;

            if (is_file($local)) {
                echo "IS_FILE: {$host} {$local} {$remote}" . PHP_EOL;
                $dir = dirname($local);

                if (!$sftp->is_dir($dir)) {
                    $sftp->mkdir($dir, -1, true);
                }

                if (!$sftp->put($remote,
                    $local,
                    SFTP::SOURCE_LOCAL_FILE)) {
                    // scp error
                    echo "{$host} scp file error" . PHP_EOL;
                }

                if (!empty($uid)) {
                    $sftp->chown($remote, $uid);
                    $sftp->chgrp($remote, $gid);
                }
            }

            if (is_dir($local)) {
                echo "IS_DIR: {$host} {$local} {$remote}" . PHP_EOL;
                $this->recursiveDir($local, function ($path) use ($local, $remote, $sftp, $uid, $gid, $host) {
                    $remote_path = $remote . substr($path, strlen($local), strlen($path));
                    echo "{$host} File:" . $remote_path . PHP_EOL;
                    if (!$sftp->put($remote_path,
                        $path,
                        SFTP::SOURCE_LOCAL_FILE)) {
                        // scp error
                        echo "{$host} scp file error#2" . PHP_EOL;
                    }

                    if (!empty($uid)) {
                        $sftp->chown($remote_path, $uid);
                        $sftp->chgrp($remote_path, $gid);
                    }

                }, function ($dir) use ($local, $remote, $sftp, $uid, $gid, $host) {
                    $remote_path = $remote . substr($dir, strlen($local), strlen($dir));
                    echo "{$host} Dir:" . $remote_path . PHP_EOL;
                    if (!$sftp->is_dir($remote_path)) {
                        $sftp->mkdir($remote_path, -1, true);

                        if (!empty($uid)) {
                            $sftp->chown($remote_path, $uid);
                            $sftp->chgrp($remote_path, $gid);
                        }
                    }
                });
                $sftp->disconnect();
            }

        }
    }

    public function recursiveDir($path, $fileFunc, $dirFunc)
    {
        $openDir = opendir($path);
        while (($file = readdir($openDir)) !== false) {
            $fullFilePath = realpath("$path/$file");
            if ($file[0] != ".") {
                if (is_file($fullFilePath)) {
                    if (is_callable($fileFunc)) {
                        $fileFunc($fullFilePath);
                    }
                } else {
                    if (is_callable($dirFunc)) {
                        $dirFunc($fullFilePath);
                    }
                    $this->recursiveDir($fullFilePath, $fileFunc, $dirFunc);
                }
            }
        }
    }

}
