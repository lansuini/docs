<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use OSS\Core\OssException;
use OSS\OssClient;

class pushStringToOSS extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pushStringToOSS:exec {content} {remote} {accessId} {accessKeySecret} {endpoint} {bucket} {domain}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $output = [
            'remote' => $this->argument('remote'),
        ];

        $pathname = $this->argument('remote');
        $content =  $this->argument('content');
        $accessId = $this->argument('accessId');
        $accessKeySecret = $this->argument('accessKeySecret');
        $endpoint = $this->argument('endpoint');
        $bucket = $this->argument('bucket');
        $domain = $this->argument('domain');

        try {
            $ossClient = new OssClient($accessId, $accessKeySecret, $endpoint);
            $ossClient->deleteObject($bucket, $pathname);
            $ossClient->putObject($bucket, $pathname, $content);
            return true;
        } catch (OssException $e) {
            return false;
        }
    }
}
