<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class git extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'git {path} {add}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $path = $this->argument('path');
        $add = $this->argument('add');
        
        // echo "GIT COMMIT {$add}" . PHP_EOL;
        $cmd = "cd {$path} && /usr/bin/git pull";
        exec($cmd);

        $cmd = "cd {$path} && /usr/bin/git add {$add}";
        exec($cmd);

        $cmd = "cd {$path} && /usr/bin/git commit -m 自动化更新-" . date('YmdHis');
        exec($cmd);

        $cmd = "cd {$path} && /usr/bin/git push";
        exec($cmd);

        return 0;
    }
}
