<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use OSS\Core\OssException;
use OSS\OssClient;

class pushOSS extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pushOSS:exec {local} {remote} {accessId} {accessKeySecret} {endpoint} {bucket} {domain}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        echo "pushOSS" . PHP_EOL;
        $output = [
            'local' => $this->argument('local'),
            'remote' => $this->argument('remote'),
        ];

        if (!is_file($this->argument('local')) && $this->argument('local') != 'DELETE') {
            echo "文件不存在:" . $this->argument('local') . PHP_EOL;
            return;
        }

        $pathname = $this->argument('remote');
        $content = $this->argument('local') != 'DELETE' ? file_get_contents($this->argument('local')) : '';
        $accessId = $this->argument('accessId');
        $accessKeySecret = $this->argument('accessKeySecret');
        $endpoint = $this->argument('endpoint');
        $bucket = $this->argument('bucket');
        $domain = $this->argument('domain');

        try {
            $ossClient = new OssClient($accessId, $accessKeySecret, $endpoint);
            $ossClient->deleteObject($bucket, $pathname);
            if ($this->argument('local') != 'DELETE') {
                $ossClient->putObject($bucket, $pathname, $content);
            }
            $output['url_oss'] = $domain . '/' . $pathname;
        } catch (OssException $e) {
            $output['error_oss'] = $e->getMessage();
            $output['success'] = 0;
        }
        echo "PushOss " . print_r($output, true) . PHP_EOL;
    }
}
