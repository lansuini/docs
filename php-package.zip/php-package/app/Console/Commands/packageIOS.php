<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use ZipArchive;

class packageIOS extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'packageIOS:exec {alias} {channel} {code}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $alias = $this->argument('alias');
        $channel = $this->argument('channel');
        $code = $this->argument('code');

        $tempFilename = storage_path() . '/' . strtolower($alias) . '-release.ipa';
        $path = env('TOOL_PATH', '/data/channeltool') . '/tempPackages/ios/' . strtolower($alias) . '-release.ipa';
        $path = is_file($tempFilename) ? $tempFilename : $path;
        
        $code = $code ?? "0";
        if (!is_file($path)) {
            echo "文件不存在:" . $path;
            return false;
        }

        if (!is_dir(storage_path('package/' . $alias))) {
            mkdir(storage_path('package/' . $alias), 0777, true);
        }

        $spath = storage_path('package/' . $alias . '/' . $alias . '_' . $channel . '_' . $code . '.ipa');

        if (is_file($spath)) {
            @unlink($spath);
        }

        if (!copy($path, $spath)) {
            echo "IPA写入失败:" . $spath . PHP_EOL;
            return false;
        }

        $json = json_encode(['channelCode' => $channel, 'spreadCode' => $code]);

        $zip = new ZipArchive;
        if ($zip->open($spath) === true) {
            $zip->addFromString('Payload/taitanqp iOS.app/TGChannel.json', $json);
            $zip->close();
        } else {
            echo "配置文件写入失败" . PHP_EOL;
            return false;
        }
        echo 'Package IOS ' . $alias . ' ' . $channel . ' ' . $code . PHP_EOL;
    }

    public function unzip($path, $target)
    {
        $zip = new ZipArchive();
        if ($zip->open($path) === true) {
            //解压文件到获得的路径a文件夹下
            $zip->extractTo($target);
            //关闭
            $zip->close();
            return true;
        } else {
            return false;
        }
    }

    public function zip($path, $target)
    {
        // Get real path for our folder
        $rootPath = realpath($path);

        // Initialize archive object
        $zip = new ZipArchive();
        $zip->open($target, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        // Create recursive directory iterator
        /** @var SplFileInfo[] $files */
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $name => $file) {
            // Skip directories (they would be added automatically)
            if (!$file->isDir()) {
                // Get real and relative path for current file
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($rootPath) + 1);

                // Add current file to archive
                $zip->addFile($filePath, $relativePath);
            }
        }

        // Zip archive will be created only after closing object
        $zip->close();
    }
}
