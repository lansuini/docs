<?php

namespace App\Http\Controllers;

use Artisan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PackageController extends Controller
{

    public function autopacks(Request $request)
    {
        $alias = strtoupper($request->input('alias'));
        $channels = $request->input('channels');
        // $type = $request->input('type');
        // $channel = $request->input('channel');
        // $code = $request->input('code');

        if (empty(getenv($alias . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'alias配置错误'];
        }

        $ipProtect = explode(',', getenv($alias . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $accessId = getenv($alias . '_OSS_ACCESS_KEY_ID');
        $accessKeySecret = getenv($alias . '_OSS_ACCESS_KEY_SECRET');
        $bucket = getenv($alias . '_OSS_BUCKET');
        $endpoint = getenv($alias . '_OSS_ENDPOINT');
        $domain = getenv($alias . '_OSS_ACCESS_DOMAIN');

        foreach ($channels as $v) {
            Artisan::queue('packageCall:exec', [
                'type' => $v['type'],
                'alias' => $alias,
                'channel' => $v['channel'],
                'code' => $v['code'],
                'accessId' => $accessId,
                'accessKeySecret' => $accessKeySecret,
                'endpoint' => $endpoint,
                'bucket' => $bucket,
                'domain' => $domain,
                // '--queue' => 'default'
            ])->onConnection('redis')->onQueue('default')->delay(0);
        }
        return "success";
    }

    public function autopack(Request $request)
    {
        $type = $request->input('type');
        $alias = strtoupper($request->input('alias'));
        $channel = $request->input('channel');
        $code = $request->input('code');

        if (empty(getenv($alias . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'alias配置错误'];
        }

        $ipProtect = explode(',', getenv($alias . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $accessId = getenv($alias . '_OSS_ACCESS_KEY_ID');
        $accessKeySecret = getenv($alias . '_OSS_ACCESS_KEY_SECRET');
        $bucket = getenv($alias . '_OSS_BUCKET');
        $endpoint = getenv($alias . '_OSS_ENDPOINT');
        $domain = getenv($alias . '_OSS_ACCESS_DOMAIN');

        Artisan::queue('packageCall:exec', [
            'type' => $type,
            'alias' => $alias,
            'channel' => $channel,
            'code' => $code,
            'accessId' => $accessId,
            'accessKeySecret' => $accessKeySecret,
            'endpoint' => $endpoint,
            'bucket' => $bucket,
            'domain' => $domain,
            // '--queue' => 'default'
        ])->onConnection('redis')->onQueue('default')->delay(0);

        return "success";
    }

    public function delete(Request $request)
    {
        // $type = $request->input('type');
        // $alias = strtoupper($request->input('alias'));
        // $channel = $request->input('channel');
        // $code = $request->input('code');
        // $path = 'autopack/' . $alias . '_' . $channel . '_' . $code . ($type == 'IOS' ? '.ipa' : '.apk');
        // Storage::disk('upload')->delete(env('UPLOAD_STORAGE_PATH') . '/' . $alias . '/' . $path);
        return "success";
    }

    public function replace(Request $request)
    {
        ini_set("memory_limit","512M");
        $url = $request->input('url');
        $alias = strtoupper($request->input('alias'));
        if (empty(getenv($alias . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'alias配置错误'];
        }

        $ipProtect = explode(',', getenv($alias . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $urlExt = strtolower(pathinfo($url, PATHINFO_EXTENSION));
        if (!in_array($urlExt, ['apk', 'ipa'])) {
            return ['success' => 0, 'msg' => 'url格式不合法', 'urlExt' => $urlExt];
        }

        try {
            $header = get_headers($url, true);
            if (isset($header[0]) && (strpos($header[0], '200') || strpos($header[0], '304'))) {

            } else {
                return ['success' => 0, 'msg' => 'url文件不存在', 'url' => $url];
            }
        } catch (Exception $e) {
            return ['success' => 0, 'msg' => $e->getMessage(), 'url' => $url];
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $content = curl_exec($ch);
        curl_close($ch);

        if ($urlExt == 'apk') {
            $tempFilename = storage_path() . '/host_app-' . strtolower($alias) . '-release.apk';
        } else {
            $tempFilename = storage_path() . '/' . strtolower($alias) . '-release.ipa';
        }

        file_put_contents($tempFilename, $content);
        unset($content);

        return ['success' => 1, 'msg' => '上传成功'];
    }

    public function message(Request $request)
    {
        $alias = strtoupper($request->input('alias'));
        if (empty(getenv($alias . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'alias配置错误'];
        }

        $ipProtect = explode(',', getenv($alias . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $ipProtect = explode(',', getenv($alias . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $tempFilename = storage_path() . '/host_app-' . strtolower($alias) . '-release.apk';
        $path = env('TOOL_PATH', '/data/channeltool') . '/tempPackages/android/host_app-' . strtolower($alias) . '-release.apk';
        $apk = is_file($tempFilename) ? $tempFilename : $path;

        $tempFilename = storage_path() . '/' . strtolower($alias) . '-release.ipa';
        $path = env('TOOL_PATH', '/data/channeltool') . '/tempPackages/ios/' . strtolower($alias) . '-release.ipa';
        $ios = is_file($tempFilename) ? $tempFilename : $path;

        $apk = is_file($apk) ? [
            'created' => date('Y-m-d H:i:s', filemtime($apk)),
            'size' => $this->fileSizeConvert(filesize($apk)),
            'md5' => md5_file($apk),
        ] : [];

        $ios = is_file($ios) ? [
            'created' => date('Y-m-d H:i:s', filemtime($ios)),
            'size' => $this->fileSizeConvert(filesize($ios)),
            'md5' => md5_file($ios),
        ] : [];

        return ['success' => 1,
            'msg' => '',
            'data' => [
                'apk' => $apk,
                'ios' => $ios,
            ],
        ];
    }

    public function plist(Request $request)
    {
        $alias = strtoupper($request->input('alias'));
        $company = $request->input('company');
        $ipa = $request->input('ipa');
        $version = $request->input('version');
        $name = $request->input('name');

        if (empty($name)) {
            return ['success' => 0, 'msg' => '包名称不能为空'];
        }

        if (empty($ipa)) {
            return ['success' => 0, 'msg' => 'ipa地址不能为空'];
        }

        if (empty($company)) {
            return ['success' => 0, 'msg' => '安装名称不能为空'];
        }

        if (empty(getenv($alias . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'alias配置错误'];
        }

        $ipProtect = explode(',', getenv($alias . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $plistTmp = file_get_contents(base_path('resources') . '/tmp.plist');
        $plistTmp = str_replace("{company}", $company, $plistTmp);
        $plistTmp = str_replace("{package}", $name, $plistTmp);
        $plistTmp = str_replace("{download}", $ipa, $plistTmp);
        $plistTmp = str_replace("{version}", $version, $plistTmp);

        $path = 'autopack/' . strtolower($alias) . (!empty($channelId) ? '_' . $channelId : '') . '.plist';
        Storage::disk('upload')->put($alias . '/' . $path, $plistTmp);
        $this->syncOSS($alias, env("UPLOAD_STORAGE_PATH") . '/' . $alias . '/' . $path, $path);
        $res = 1;
        $domain = getenv($alias . '_OSS_ACCESS_DOMAIN');
        return $res ? ['success' => 1, "url" => $domain . '/' . $path, "msg" => '生成成功'] :
        [
            'success' => 0,
            "msg" => '生成失败',
        ];

    }

    protected function fileSizeConvert($bytes)
    {
        $bytes = floatval($bytes);
        $arBytes = array(
            0 => array(
                "UNIT" => "TB",
                "VALUE" => pow(1024, 4),
            ),
            1 => array(
                "UNIT" => "GB",
                "VALUE" => pow(1024, 3),
            ),
            2 => array(
                "UNIT" => "MB",
                "VALUE" => pow(1024, 2),
            ),
            3 => array(
                "UNIT" => "KB",
                "VALUE" => 1024,
            ),
            4 => array(
                "UNIT" => "B",
                "VALUE" => 1,
            ),
        );

        foreach ($arBytes as $arItem) {
            if ($bytes >= $arItem["VALUE"]) {
                $result = $bytes / $arItem["VALUE"];
                $result = str_replace(".", ",", strval(round($result, 2))) . " " . $arItem["UNIT"];
                break;
            }
        }
        return $result;
    }
}
