<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Artisan;
class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getIp()
    {
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip); // just to be safe
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        return request()->ip(); // it will return server ip when no client ip found
    }

    public function syncOSS($client, $local, $remote)
    {
        $enabled = getenv($client . '_OSS_ENABLED', false);
        $accessKeyId = getenv($client . '_OSS_ACCESS_KEY_ID');
        $accessKeySecret = getenv($client . '_OSS_ACCESS_KEY_SECRET');
        $bucket = getenv($client . '_OSS_BUCKET');
        $endpoint = getenv($client . '_OSS_ENDPOINT');
        $domain = getenv($client . '_OSS_ACCESS_DOMAIN');
        if ($enabled && is_file($local)) {
            // Artisan::queue('pushOSS:exec', [
            //     'local' => $local,
            //     'remote' => $remote,
            //     'accessId' => $accessKeyId,
            //     'accessKeySecret' => $accessKeySecret,
            //     'endpoint' => $endpoint,
            //     'bucket' => $bucket,
            //     'domain' => $domain,
               
            // ])->onConnection('redis')->onQueue('syncoss')->delay(0);
        }

        $enabled = getenv('SERVER_SCP_ENABLED', false);
        if ($enabled && is_file($local)) {

            $type = 'SERVER_SCP';
            $hosts = explode(',', trim(env($type . '_HOSTS')));
            foreach ($hosts ?? [] as $host) {
                Artisan::queue('syncHost', [
                    'host' => $host,
                    'type' => $type,
                    'local' => $local,
                    'remote' => env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $remote,
                ])->onConnection('redis')->onQueue('filecopy')->delay(0);
            }
        }
    }

    public function syncOSSDirectory($client, $local, $remote)
    {
        $enabled = getenv($client . '_OSS_ENABLED', false);
        if ($enabled && is_dir($local)) {
            // Artisan::queue('pushOSSDirectoryClient', [
            //     'client' => $client,
            //     'local' => $local,
            //     'remote' => $remote,
            // ])->onConnection('redis')->onQueue('syncoss')->delay(0);
        }

        $enabled = getenv('SERVER_SCP_ENABLED', false);
        if ($enabled && is_dir($local)) {
            // Artisan::queue('sync', [
            //     'type' => 'SERVER_SCP',
            //     'local' => $local,
            //     'remote' => env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $remote,
            // ])->onConnection('redis')->onQueue('filecopy')->delay(0);

            $type = 'SERVER_SCP';
            $hosts = explode(',', trim(env($type . '_HOSTS')));
            foreach ($hosts ?? [] as $host) {
                Artisan::queue('syncHost', [
                    'host' => $host,
                    'type' => $type,
                    'local' => $local,
                    'remote' => env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $remote,
                ])->onConnection('redis')->onQueue('filecopy')->delay(0);
            }
        }
    }
}
