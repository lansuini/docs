<?php

namespace App\Http\Controllers;

use ErrorException;
use Exception;
use Hashids\Hashids;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use ZipArchive;
use Artisan;

class UploadController extends Controller
{
    public function sign(Request $request, $client)
    {

        $client = strtoupper($client);

        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }

        $hids = new Hashids(getenv($client . '_IDHEX_SALT'), 32, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
        $time = time();
        $sign = $hids->encode($time);
        $ipProtect = explode(',', getenv($client . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        return ['success' => 1, 'sign' => $sign];
    }

    public function upload(Request $request)
    {
        set_time_limit(0);
        $this->validate($request, [
            'pathname' => 'required',
            'type' => 'required|in:file,string,pack',
            'content' => 'required',
            'sign' => 'required',
            'client' => 'required',
        ]);

        $sign = $request->input('sign');
        $client = $request->input('client');
        $client = strtoupper($client);

        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }

        $hids = new Hashids(getenv($client . '_IDHEX_SALT'), 32, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
        $time = time();
        $time = $hids->decode($sign);
        $time = is_array($time) ? current($time) : 0;
        if ($time < time() - 60 * 60) {
            return ['success' => 0, 'msg' => '上传服务密钥验证超时，请刷新页面重新上传!'];
        }

        if ($request->input('type') == 'string') {
            $this->validate($request, [
                'content' => 'required|max:2048000',
            ]);
        }

        $pathname = $request->input('pathname');
        $path = pathinfo($pathname);
        $path['extension'] = strtolower($path['extension'] ?? '');
        if ($request->input('type') != 'pack' && !in_array($path['extension'], ['json', 'png', 'zip', 'jpg', 'jpeg', 'mp3', 'mp4', 'ogg', 'webm', 'mov', 'apk', 'plist', 'ipa', 'pem', 'key'])) {
            return ['success' => 0, 'msg' => '路径格式错误'];
        } else if ($request->input('type') == 'pack' && $path['extension'] != '') {
            return ['success' => 0, 'msg' => 'pack路径格式错误, pathname为目录格式'];
        }

        $output = ['success' => 1, 'msg' => '上传成功'];
        $dirname = $path['dirname'] == '.' ? '' : $path['dirname'];
        try {
            if ($request->input('type') == 'string') {
                $content = $request->input('content');
                $res = Storage::disk('upload')->put($client . '/' . $dirname . '/' . $path['basename'], $content); //ytgj/tg_tcgj_ip_group_ww
                $output['res'] = $res;
            } else if ($request->input('type') == 'file') {
                $res = Storage::disk('upload')->putFileAs($client . '/' . $dirname, $request->file('content'), $path['basename']);
                $output['res'] = $res;
            }
            // } else {
            //     $content = $request->content->path();
            //     $zip = new ZipArchive;
            //     $dir = env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $pathname;
            //     if (!File::exists($dir)) {
            //         Storage::disk('upload')->makeDirectory($dir, 0755, true, true);
            //     }
            //     if (true === $zip->open($content)) {
            //         $zip->extractTo($dir);
            //         $zip->close();
            //     } else {
            //         throw new Exception("zip解压失败");
            //     }
            // }
            $output['url_oss'] = getenv($client . '_OSS_ACCESS_DOMAIN') . '/' . $pathname;
            $this->syncOSS($client, env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $dirname . '/' . $path['basename'], $pathname);
        } catch (Exception $e) {
            $output['error_oss'] = $e->getMessage();
            $output['success'] = 0;
        }

        // if (strpos($pathname, "entry_RSA.json") > 0 && env('IP_ENTRY_ENABLE', false)) {
        //     $type = 'IP_ENTRY';
        //     $hosts = explode(',', trim(env($type . '_HOSTS')));
        //     foreach ($hosts ?? [] as $host) {
        //         Artisan::queue('syncHost', [
        //             'host' => $host,
        //             'type' => $type,
        //             'local' => env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $dirname . '/' . $path['basename'],
        //             'remote' => '/usr/share/nginx/html/' . $client . '_entry_RSA.json',
        //         ])->onConnection('redis')->onQueue('filecopy')->delay(0);
        //     }
        // }

        if (strpos($pathname, "entry_RSA.json") > 0 && env('GIT_ENTRY_ENABLE', false)) {
            $path = env('GIT_ENTRY_LOCAL_PATH');
            $filename = "{$path}/{$client}_entry_RSA.json";
            file_put_contents($filename, $content);

            Artisan::call('git', [
                'path' => $path,
                'add' => $filename,        
            ]);
            // Artisan::queue('git', [
            //     'path' => $path,
            //     'add' => $filename,        
            // ])->onConnection('redis')->onQueue('default')->delay(0);
        }
        return $output;
    }

    public function domain(Request $request, $client)
    {
        $client = strtoupper($client);

        $ipProtect = explode(',', getenv($client . '_IP_PROTECT'));

        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }

        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $output = ['success' => 1];

        $output['oss_domain'] = getenv($client . '_OSS_ACCESS_DOMAIN');
        $output['oss_access_key_id'] = '';
        $output['oss_acess_key_secret'] = '';
        $output['oss_bucket'] = '';
        $output['oss_endpoint'] = '';
        return $output;
    }

    public function carry(Request $request)
    {
        ini_set("memory_limit","512M");
        $this->validate($request, [
            'sign' => 'required',
            'client' => 'required',
            'url' => 'required',
        ]);

        $sign = $request->input('sign');
        $client = $request->input('client');
        $url = trim($request->input('url'));

        $client = strtoupper($client);

        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }

        $ipProtect = explode(',', getenv($client . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $urlExt = strtolower(pathinfo($url, PATHINFO_EXTENSION));
        if (!in_array($urlExt, ['zip', 'apk', 'plist', 'ipa'])) {
            return ['success' => 0, 'msg' => '格式不合法', 'urlExt' => $urlExt];
        }

        $inputHost = parse_url($url);
        $localHost = parse_url(getenv($client . '_OSS_ACCESS_DOMAIN'));

        if ($inputHost['host'] == $localHost['host']) {
            return ['success' => 1, 'msg' => '上传域名相同，无需迁移', 'carry_url' => $url, 'url' => $url];
        }

        try {
            $header = get_headers($url, true);
            if (isset($header[0]) && (strpos($header[0], '200') || strpos($header[0], '304'))) {

            } else {
                return ['success' => 0, 'msg' => 'url文件不存在', 'carry_url' => $url, 'url' => $url, 'a' => 1];
            }
        } catch (Exception $e) {
            return ['success' => 0, 'msg' => $e->getMessage(), 'carry_url' => $url, 'url' => $url, 'a' => 1];
        } catch (ErrorException $e) {
            return ['success' => 0, 'msg' => $e->getMessage(), 'carry_url' => $url, 'url' => $url, 'a' => 1];
        }

        $newFileUrl = getenv($client . '_OSS_ACCESS_DOMAIN') . '/carry/' . md5($url) . '.' . $urlExt;
        $newUrl = str_replace($inputHost['host'], $localHost['host'], $url);

        $localPath = env('UPLOAD_STORAGE_PATH') . '/' . $client . $inputHost['path'];

        if (File::exists($localPath)) {
            return ['success' => 1, 'msg' => '上传文件已存在相同，无需迁移@1', 'carry_url' => $newFileUrl, 'url' => $url, 'header' => $header, 'localPath' => $localPath];
        }

        $localPath2 = env('UPLOAD_STORAGE_PATH') . '/' . $client . '/carry/' . md5($url) . '.' . $urlExt;
        if (File::exists($localPath2)) {
            return ['success' => 1, 'msg' => '上传文件已存在相同，无需迁移@1', 'carry_url' => $newFileUrl, 'url' => $url, 'header' => $header, 'localPath2' => $localPath2];
        }

        $pathname = 'carry/' . md5($url) . '.' . $urlExt;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $content = curl_exec($ch);
        $output = ['success' => 1, 'url' => $url, 'newFileUrl' => $newFileUrl];

        try {
            $res = Storage::disk('upload')->put($client . '/' . $pathname, $content);
            $output['res'] = $res;
            $output['carry_url'] = $newFileUrl;
            $this->syncOSS($client, env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $pathname, $pathname);
        } catch (OssException $e) {
            $output['msg'] = $e->getMessage();
            $output['success'] = 0;
        }

        return $output;
    }

    public function carryzip(Request $request)
    {
        ini_set('memory_limit', '512M');
        $this->validate($request, [
            'sign' => 'required',
            'client' => 'required',
            'url' => 'required',
        ]);

        $sign = $request->input('sign');
        $client = $request->input('client');
        $url = trim($request->input('url'));

        $client = strtoupper($client);

        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }

        $ipProtect = explode(',', getenv($client . '_IP_PROTECT'));
        $accessIP = $this->getIp();

        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }

        $urlExt = strtolower(pathinfo($url, PATHINFO_EXTENSION));
        if (!in_array($urlExt, ['zip'])) {
            return ['success' => 0, 'msg' => '格式不合法', 'urlExt' => $urlExt];
        }

        $inputHost = parse_url($url);
        $localHost = parse_url(getenv($client . '_OSS_ACCESS_DOMAIN'));
        $pathname = 'carry/' . md5($url);
        $dir = env('UPLOAD_STORAGE_PATH') . '/' . $client . '/' . $pathname;
        $newFileUrl = getenv($client . '_OSS_ACCESS_DOMAIN') . '/carry/' . md5($url);

        if ($inputHost['host'] == $localHost['host']) {
            return ['success' => 1, 'msg' => '上传域名相同，无需迁移', 'carry_url' => $newFileUrl, 'url' => $url];
        }

        if (File::exists($dir)) {
            return ['success' => 1, 'msg' => '已存在，无需迁移', 'carry_url' => $newFileUrl, 'url' => $url];
        }

        try {
            $header = get_headers($url, true);
            if (isset($header[0]) && (strpos($header[0], '200') || strpos($header[0], '304'))) {

            } else {
                return ['success' => 0, 'msg' => 'url文件不存在', 'carry_url' => $url, 'url' => $url];
            }
        } catch (Exception $e) {
            return ['success' => 0, 'msg' => $e->getMessage(), 'carry_url' => $url, 'url' => $url, 'a' => 1];
        } catch (ErrorException $e) {
            return ['success' => 0, 'msg' => $e->getMessage(), 'carry_url' => $url, 'url' => $url, 'a' => 1];
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $content = curl_exec($ch);
        curl_close($ch);

        $tempFilename = storage_path() . '/ziparchive/' . md5($url) . '.zip';
        Storage::disk('ziparchive')->put(md5($url) . '.zip', $content);
        unset($content);

        $output = ['success' => 1, 'url' => $url, 'newFileUrl' => $newFileUrl];

        try {
            $zip = new ZipArchive;
            if (!File::exists($dir)) {
                Storage::disk('upload')->makeDirectory($dir, 0755, true, true);
            }
            if (true === $zip->open($tempFilename)) {
                $zip->extractTo($dir);
                $zip->close();
            } else {
                throw new Exception("zip解压失败");
            }
            unlink($tempFilename);

            $this->syncOSSDirectory($client, $dir, $pathname);
            $output['carry_url'] = getenv($client . '_OSS_ACCESS_DOMAIN') . '/' . $pathname;
            $output['a'] = 2;
        } catch (Exception $e) {
            $output['msg'] = $e->getMessage();
            $output['success'] = 0;
        }

        return $output;
    }

    public function gitee(Request $request)
    {
        function mk_Dir($path)
        {
            // 目录存在返回 ture
            if (is_dir($path)) {
                return true;
            }
            // 父目录存在 或 递归找到父目录，创建目录
            return is_dir(dirname($path)) || mk_Dir(dirname($path)) ? mkdir($path) : "false";
        }

        $this->validate($request, [
            'sign' => 'required',
            'client' => 'required',
            'key' => 'required',
            'content' => 'required',
        ]);

        $sign = $request->input('sign');
        $client = $request->input('client');
        $client = strtoupper($client);
        $key = $request->input('key');
        $content = $request->input('content');
        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }

        $path = env('GIT_ENTRY_LOCAL_PATH');
        $rootpath = $path . '/' . $client . '/';

        $filename = $rootpath . $key;
        $dir = dirname($filename);
        mk_Dir($dir);
        file_put_contents($filename, $content);

        Artisan::call('git', [
            'path' => $rootpath,
            'add' => '.',        
        ]);

        // $cmd = "cd /data/code/supereatbb && /usr/bin/git add .";
        // exec($cmd);

        // $cmd = "cd /data/code/supereatbb && /usr/bin/git commit -m 自动化更新";
        // exec($cmd);

        // $cmd = "cd /data/code/supereatbb && /usr/bin/git push";
        // exec($cmd);
        return ['success' => 1, 'msg' => '操作成功'];
    }

    public function test(Request $request, $client)
    {
        $this->syncOSS($client, '/data/www/PRE/sss/1.jpg', 'sss/1.jpg');
    }

    public function shortUrl(Request $request)
    {
        $this->validate($request, [
            'url' => 'required|url',
            'sign' => 'required',
            'client' => 'required',
        ]);
    
        $sign = $request->input('sign');
        $url = $request->input('url');
        $client = $request->input('client');
        $client = strtoupper($client);
        if (empty(getenv($client . '_IP_PROTECT'))) {
            return ['success' => 0, 'msg' => 'client配置错误'];
        }
    
        $hids = new Hashids(getenv($client . '_IDHEX_SALT'), 32, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
        $time = time();
        $time = $hids->decode($sign);
        $time = is_array($time) ? current($time) : 0;
        if ($time < time() - 60 * 60) {
            return ['success' => 0, 'msg' => '服务密钥验证超时，请刷新页面重新上传!'];
        }
    
        $ipProtect = explode(',', getenv($client . '_IP_PROTECT'));
        $accessIP = $this->getIp();
    
        if (!in_array($accessIP, $ipProtect)) {
            return ['success' => 0, 'msg' => 'IP访问限制，你当前IP[' . $accessIP . ']'];
        }
    
        $clientDomain = getenv($client . '_SHORT_SERVER');
        if (empty($clientDomain)) {
            return ['success' => 0, 'msg' => '客户短链配置域名为空'];
        }
    
        $model = new \App\ShortUrl;
        $md5 = md5($url);
        $d = $model->where('md5', $md5)->first();
        if ($d) {
            $shortKey = $d->short_key;
        } else {
            $short = new Hashids(getenv($client . '_IDHEX_SALT'), 6, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
            $data = [
                'client' => $client,
                'short_key' => 'err:' . rand(0, 9999999),
                'url' => $url,
                'md5' => $md5,
            ];
    
            $d = $model->create($data);
            $shortKey = $short->encode($d->id);
            $d->short_key = $shortKey;
            $d->save();
    
            file_get_contents('http://18.163.231.241' . '?' . http_build_query([
                'k' => $shortKey,
                'v' => base64_encode($url),
            ]));
        }
        return ['success' => 1, 'url_short' => $clientDomain . '/' . $shortKey];
    }
}
