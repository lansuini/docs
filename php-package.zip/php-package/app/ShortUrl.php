<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShortUrl extends Model
{

    protected $table = 'short_url';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'short_key', 'url', 'client', 'md5',
    ];

}
