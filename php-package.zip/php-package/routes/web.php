<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return "Hello World!";
});

Route::post('/packages', 'PackageController@autopacks');
Route::get('/package', 'PackageController@autopack');
Route::get('/package/delete', 'PackageController@delete');
Route::get('/package/replace', 'PackageController@replace');
Route::get('/package/message', 'PackageController@message');
Route::get('/package/plist', 'PackageController@plist');

Route::get('/upload/{client}/sign', 'UploadController@sign');
Route::get('/upload/{client}/domain', 'UploadController@domain');
Route::post('/upload', 'UploadController@upload');

Route::post('/test/{client}', 'UploadController@test');
Route::post('/shortUrl', 'UploadController@shortUrl');
// Route::get('/git', 'UploadController@git');
Route::post('/carry', 'UploadController@carry');
Route::post('/carry_zip', 'UploadController@carryzip');
Route::get('/gitee', 'UploadController@gitee');


Route::any('/elf/{client}/connector', 'ElfinderController@connector');
Route::get('/elf/{client}', 'ElfinderController@index');
