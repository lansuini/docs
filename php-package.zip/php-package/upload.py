# -*- coding: utf-8 -*-
'''
 目录上传OSS脚本
 python3 upload.py LTAIGAPsw8HqOsTP JVqDriGBsbumtnRiwv2TnBzNyF55iE bc-test1 http://oss-cn-shenzhen.aliyuncs.com ./storage/ziparchive/2020.09.18.1517 carry/2020.09.18.1518
'''
import oss2
import os
from concurrent.futures import ThreadPoolExecutor
import time
import datetime
import sys
sys.exit(0)
starttime = datetime.datetime.now()
start = time.time()

access_id = "LTAIGAPsw8HqOsTP"
access_secret = "JVqDriGBsbumtnRiwv2TnBzNyF55iE"
bucket = "bc-test1"
endpoint = "http://oss-cn-shenzhen.aliyuncs.com"
target_dir = "./storage/ziparchive/2020.09.18.1517"
name = "carry/2020.09.18.1518"

if len(sys.argv) != 7:
    print("args error")
    print(sys.argv)
    sys.exit()

access_id = sys.argv[1]
access_secret = sys.argv[2]
bucket = sys.argv[3]
endpoint = sys.argv[4]
target_dir = sys.argv[5]
name = sys.argv[6]
if name == '/':
    name = '!!!'

auth = oss2.Auth(access_id, access_secret)
bucket = oss2.Bucket(auth, endpoint, bucket)

def oss_upload(file, remote):
    path = name + remote
    path = path.replace('!!!/', '')
    bucket.put_object_from_file(path, file)
    return [file, path]

g = os.walk(target_dir)  

tasks = []
executor = ThreadPoolExecutor(max_workers = 100)
for path,dir_list,file_list in g:  
    

    for file_name in file_list:  
        file = os.path.join(path, file_name)
        if file.find('/.tmb/') != -1:
            continue
        # print(file)
        task = executor.submit(oss_upload, file, file.replace(target_dir, ''))
        tasks.append(task)

for task in tasks:
    task.result()

endtime = datetime.datetime.now()
end = time.time()
# print("complete")
# print((endtime - starttime).seconds)
print("costs:", (end - start))