<?php
return [
    0 => 'web-lobby',
    4201 => 'tongits',
    4630 => 'crash',
    4620 => 'color',
    4510 => 'lfd',
    4200 => 'lucky9',
    4640 => 'classicdice',
    4650 => 'wheel',
    4540 => 'baccarat',
    4440 => 'fortunegems',
    4150 => 'pusoy',
    4660 => 'limbo',
    4670 => 'mines',
    4680 => 'plinko',
    // 4450 => 'goldenempire',
    4460 => 'superace',

    1502 => 'quanminby',

    4451 => 'BoxingKing',
    4452 => "Genie's 3 Wishes",
    4453 => 'Bingo Carnaval',
    4454 => 'Secrets of Cleopatra',
    4455 => 'JinJiBaoXi',
    4690 => 'Cricket',
];