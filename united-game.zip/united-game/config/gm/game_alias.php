<?php
return [
	4201 => ['name' => 'Tongits'],
    4650 => ['name' => 'WHEEL'],
    4640 => ['name' => 'Classic DICE'],
    4630 => ['name' => 'CRASH'],
    4620 => ['name' => 'COLOR'],
    4510 => ['name' => 'Dragon and Phoenix'],
    4200 => ['name' => 'LUCKY9'],
    4150 => ['name' => 'PUSOY'],
    4540 => ['name' => 'Baccarat'],
    4440 => ['name' => 'FortuneGems'],
    4660 => ['name' => 'Limbo'],
    4670 => ['name' => 'Mines'],
    4680 => ['name' => 'Plinko'],
    // 4450 => ['name' => 'Golden Empire'],
    4460 => ['name' => 'Superace'],

    1502 => ['name' => 'Quanminby'],

    4451 => ['name' => 'BoxingKing'],
    4452 => ['name' => "Genie's 3 Wishes"],
    4453 => ['name' => 'Bingo Carnaval'],
    4454 => ['name' => 'Secrets of Cleopatra'],
    4455 => ['name' => 'JinJiBaoXi'],
    4690 => ['name' => 'Cricket'],
];
