<?php
return [
    ["name" => "back_rate", "field" => "back_rate", "val" => null, "valType" => "integer", "re" => "return rate", 'layout' => 0, 'md' => 2],
];