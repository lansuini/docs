<?php
 

return [
    ["name" => "rule", "field" => "rule", "valType" => "array", "val" => [
        ["name" => "play_method", "field" => "play_method", "val" => null, "valType" => "integer"],
    ]],
];