<?php
return [
    ["name" => "rule", "field" => "rule", "valType" => "array", "val" => [
        ["name" => "tax", "field" => "tax", "val" => "0", "valType" => "integer", "re" => 'Deduction ratio, percentage per thousand'],
    ]],
];