<?php

return [
    ["name" => "rule", "field" => "rule", "valType" => "array", "val" => [
        ["name" => "NormalBetArea", "field" => "NormalBetArea", "val" => "0", "valType" => "select", "re" => trim('普通下注区域(分)'), "options" => [
            100 => 100,
            500 => 500,
            1000 => 1000,
            2000 => 2000,
            5000 => 5000,
            10000 => 10000,
            50000 => 50000,
            100000 => 100000,
            500000 => 500000,
            1000000 => 1000000,
        ]],
    ]],
];
