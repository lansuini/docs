<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_the_application_returns_a_successful_response()
    {
        // $response = $this->get('/');
        // $response = $this->call('GET', 'http://h5.yfbsy.com/api/web-lobby/login?operator_token=tongits&operator_player_session=A123456&operator_player_param=&game_id=0');

        // $response->assertStatus(200);
        $this->assertTrue(true);
    }
}
