

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
                        <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div classs="card">

                        <div class="card-header">
                            <div class="btn-group v-search-bar" id="divSearch">
                                <select class="form-control" data-field="game_id" id="game_id"></select>
                                <input type="text" class="form-control" data-field="uid" placeholder="UID" />
                                <input type="text" class="form-control" data-field="pid" placeholder="NO." />
                                <input type="text" class="form-control" data-field="created" placeholder="created" id="reservation" />
                                <button type="button" class="btn btn-default" id="btnSearch">
                                    <i class="fas fa-search"></i> Search
                                </button>
                            </div>

                            <div id="toolbar" class="select">
                            </div>
                        </div>

                        <div class="card-body">
                            <table id="tabMain"></table>

                        </div>

                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">No: <span id="spid2"></span></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <div class="btn-group v-search-bar" id="divSearch2" style="display: none;">
                        <input type="text" class="form-control" data-field="pid" placeholder="No." id="spid" />
                        <input type="text" class="form-control" data-field="uid" placeholder="UID" id="suid" />
                        <button type="button" class="btn btn-default" id="btnSearch2">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </div>
                    <table id="tabMain2"></table>
                </div>

                <div class="modal-footer">
                    <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var cuid = 0

    function toHex(value) {
        let hex = value.toString(16);
        if ((hex.length % 2) > 0) {
            hex = "0" + hex;
        }
        return hex;
    }

    function poker_4201(data) {
        data['poker_detail'] = data['poker_detail'].replaceAll("'", '"')
        var poker = JSON.parse(data['poker_detail'])
        var pokers = poker['hand_card'].split(' ')
        // console.log(pokers)
        var html = ''
        for (var i in pokers) {
            // %02X
            if (pokers[i]) {
                html += '<img width="20" src="/images/games/cards/0x' + toHex(pokers[i]) + '.png"/>'
            }
        }
        // console.log(html)
        return html
    }

    function getColumns_4210() {
        return [{
                field: "uid",
                title: "UID",
                align: "center",
                formatter: function(b, c, a) {
                    return b == cuid ? '<span class="text-danger">' + b + '</span>' : b
                },
            }, {
                field: "reboot",
                title: "RT",
                align: "center",
                formatter: function(b, c, a) {
                    return c['user_type'] == 100 ? 'Y' : 'N'
                },
            },
            {
                field: "poker_detail",
                title: "Poker",
                align: "center",
                formatter: function(b, c, a) {
                    return poker_4201(c)
                },
            },
            {
                field: "result",
                title: "Result",
                align: "center",
                formatter: function(b, c, a) {
                    return cform.getValue(typeData['resultType'], b)
                },
            }, {
                field: "before",
                title: "Before",
                align: "center",
                formatter: function(b, c, a) {
                    return common.ya(c['score2'] - c['score1'])
                }
            }, {
                field: "score2",
                title: "After",
                align: "center",
                formatter: function(b, c, a) {
                    return common.ya(b)
                }
            }, {
                field: "score1",
                title: "WinLose",
                align: "center",
                formatter: function(b, c, a) {
                    return common.ya(b)
                }
            },
        ]
    }

    function showDetail(pid, uid, gameId) {
        cuid = uid
        $('#detailModal').modal()
        $('#spid').val(pid)
        $('#spid2').html(pid)
        $('#suid').val(uid)

        $("#btnSearch2").initSearch(apiPath + "player/playlogdetail", eval('getColumns_' + gameId + '()'), {
            sortName: "id",
            sortOrder: 'desc',
            // showColumns: true,
            tabId: "tabMain2",
            searchContainerId: "divSearch2",
        })

        $("#btnSearch2").click()
    }

    function getColumns() {
        return [{
                field: "pid",
                title: "NO.",
                align: "center",
                formatter: function(b, c, a) {
                    return '<a href="#" onclick="showDetail(' + c['pid'] + ',' + c['uid'] + ',' + c['game_id'] + ')">' + b + '</a>'
                },
                sortable: true,
            }, {
                field: "uid",
                title: "UID",
                align: "center"
            }, {
                field: "reboot",
                title: "Reboot",
                align: "center",
                formatter: function(b, c, a) {
                    return c['user_type'] == 100 ? 'Y' : 'N'
                },
            },
            //  {
            //     field: "types",
            //     title: "PlayerType",
            //     align: "center"
            // },
            {
                field: "game_detail",
                title: "GameDetail",
                align: "center",
                visible: false
            }, {
                field: "name",
                title: "GameName",
                align: "center",
                // formatter: function(b, c, a) {
                //     return cform.getValue(typeData['gameAliasType'], b)
                // }
            },
            // {
            //     field: "category_name",
            //     title: "Category",
            //     align: "center"
            // }, 
            {
                field: "result",
                title: "Result",
                align: "center",
                formatter: function(b, c, a) {
                    return cform.getValue(typeData['resultType'], b)
                },
            }, {
                field: "before",
                title: "Before",
                align: "center",
                formatter: function(b, c, a) {
                    return common.ya(c['score2'] - c['score1'])
                }
            }, {
                field: "score2",
                title: "After",
                align: "center",
                formatter: function(b, c, a) {
                    return common.ya(b)
                }
            }, {
                field: "score1",
                title: "WinLose",
                align: "center",
                formatter: function(b, c, a) {
                    return common.ya(b)
                }
            },
            // {
            //     field: "bill",
            //     title: "Bill",
            //     align: "center"
            // }, {
            //     field: "bill2",
            //     title: "WinLose(NoTax)",
            //     align: "center"
            // }, {
            //     field: "bill3",
            //     title: "WinLose(Tax)",
            //     align: "center"
            // }, {
            //     field: "bill4",
            //     title: "WaterLogType",
            //     align: "center"
            // }, 
            // {
            //     field: "times",
            //     title: "Times",
            //     align: "center"
            // }, 
            {
                field: "post_time",
                title: "Created",
                align: "center",
                formatter: function(b, c, a) {
                    // return moment.unix(b).format("MM/DD/YYYY HH:mm:ss")
                    // return moment(b, 'YYYY-MM-DD HH:mm:ss').format("MM/DD/YYYY HH:mm:ss")
                    return b
                }
            }
        ]
    }

    $(function() {

        $('#reservation').daterangepicker({
            "startDate": moment().subtract(3, 'days'),
            "endDate": moment()
        })

        common.getAjax(apiPath + "getbasedata?requireItems=gameAliasType,resultType", function(a) {
            typeData = a.result
            $("#game_id").initSelect(a.result.gameAliasType, "key", "value", "Games", 4201)
            $("#btnSearch").initSearch(apiPath + "player/playlog", getColumns(), {
                sortName: "id",
                sortOrder: 'desc',
                showColumns: true,
                toolbar: '#toolbar',
                // showExport: true,
                // exportTypes: ['csv'],
                // exportDataType: "all"

            })
            $("#btnSubmit").click()
        })

        common.initSection(true)

    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/Analysis/Player/playLogView.blade.php ENDPATH**/ ?>