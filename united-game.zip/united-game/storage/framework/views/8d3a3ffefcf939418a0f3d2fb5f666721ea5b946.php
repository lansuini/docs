

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
                        <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div classs="card">

                        <div class="card-header">
                            <div class="btn-group v-search-bar" id="divSearch">
                                <input type="text" class="form-control" data-field="company_name" placeholder="Company" />
                                <input type="text" class="form-control" data-field="operator_token" placeholder="OperatorToken" />
                                <select class="form-control" data-field="is_lock" id="selLockType"></select>

                                <button type="button" class="btn btn-default" id="btnSearch">
                                    <i class="fas fa-search"></i> Search
                                </button>

                                <button type="button" class="btn btn-primary" id="btnCreate">
                                    <i class="fas fa-plus"></i> Create
                                </button>
                            </div>
                        </div>

                        <div class="card-body">
                            <table id="tabMain"></table>

                        </div>

                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <form class="">
                        <div class="form-group sr-only">
                            <label class="col-form-label">id：</label>
                            <input type="text" class="form-control" data-field="id" />
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">Company</label>
                            <input type="text" class="form-control" data-field="company_name" />
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">OperatorToken</label>
                            <input type="text" class="form-control" data-field="operator_token" readonly />
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">SecretKey<a class="btn btn-xs btn-dark autors">AutoFixed</a></label>
                            <input type="text" class="form-control" data-field="secret_key" />
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">API IP Limit</label>
                            <input type="text" class="form-control" data-field="api_ip_white" />
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">MerchantAddress</label>
                            <input type="text" class="form-control" data-field="merchant_addr" />
                        </div>

                        <div class="form-group form-edit">
                            <label class="col-form-label" for="selStatus">Lock：</label>
                            <select class="form-control is_lock" data-field="is_lock"></select>
                        </div>

                        <div class="form-group form-edit">
                            <label class="col-form-label">API Mode：</label>
                            <select class="form-control api_mode" data-field="api_mode"></select>
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">GameDomain</label>
                            <input type="text" class="form-control" data-field="game_domain" />
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                    <input type="button" class="btn btn-primary" value="Submit" id="updateBtnSubmit" />
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Create</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <form class="">
                        <div class="form-group">
                            <label class="col-form-label">Company</label>
                            <input type="text" class="form-control" data-field="company_name" />
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">OperatorToken<a class="btn btn-xs btn-dark autors">AutoFixed</a></label>
                            <input type="text" class="form-control" data-field="operator_token" />
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">SecretKey<a class="btn btn-xs btn-dark autors">AutoFixed</a></label>
                            <input type="text" class="form-control" data-field="secret_key" />
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">API IP Limit</label>
                            <input type="text" class="form-control" data-field="api_ip_white" />
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">MerchantAddress</label>
                            <input type="text" class="form-control" data-field="merchant_addr" />
                        </div>

                        <div class="form-group form-edit">
                            <label class="col-form-label" for="selStatus">Lock：</label>
                            <select class="form-control is_lock" data-field="is_lock"></select>
                        </div>

                        <div class="form-group form-edit">
                            <label class="col-form-label">API Mode：</label>
                            <select class="form-control api_mode" data-field="api_mode"></select>
                        </div>

                        <div class="form-group">
                            <label class="" for="txtRole">GameDomain</label>
                            <input type="text" class="form-control" data-field="game_domain" />
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                    <input type="button" class="btn btn-primary" value="Submit" id="createBtnSubmit" />
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var typeData = []

    function randomString(e) {
        e = e || 32;
        var t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678",
            a = t.length,
            n = "";
        for (i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
        return n
    }

    $('.autors').click(function() {
        $(this).parent().parent().find('input').val(randomString(32))
    })

    function showEditModal(data) {
        cform.get('editModal', apiPath + 'customer/client/' + data['id'])
    }

    function showCreateModal() {
        $('#createModal').modal()
    }

    function delAccount(id) {
        myConfirm.show({
            title: "confirm deletion ?",
            sure_callback: function() {
                cform.del(apiPath + "customer/client/" + id, function(d) {
                    location.href = location.href
                })
            }
        })
    }

    function getColumns() {
        return [{
            field: "id",
            title: "ID",
            align: "center",
            formatter: function(b, c, a) {
                return b
            },
            sortable: true,
        }, {
            field: "company_name",
            title: "Company",
            align: "center"
        }, {
            field: "operator_token",
            title: "OperatorToken",
            align: "center"
        }, {
            field: "api_ip_white",
            title: "API_IPLimit",
            align: "center"
        }, {
            field: "is_lock",
            title: "Locked",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['lockType'], b)
            },
            sortable: true,
        }, {
            field: "merchant_addr",
            title: "MerchantAddr",
            align: "center"
        }, {
            field: "game_domain",
            title: "GameDomain",
            align: "center"
        }, {
            field: "api_mode",
            title: "API Mode",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['apiModeType'], b)
            },
        }, {
            field: "created",
            title: "Created",
            align: "center",
        }, {
            field: "-",
            title: "Action",
            align: "center",
            formatter: function(b, c, a) {
                return "<a class=\"btn btn-xs btn-primary\" onclick='showEditModal(" + JSON.stringify(c) + ")'>Edit</a>" +
                    "<a class=\"btn btn-xs btn-danger\" onclick='delAccount(\"" + c.id + "\")'>Del</a>"
            }
        }]
    }

    $(function() {

        common.getAjax(apiPath + "getbasedata?requireItems=lockType,apiModeType", function(a) {
            typeData = a.result
            $("#selLockType").initSelect(a.result.lockType, "key", "value", "lock status")
            $(".api_mode").initSelect(a.result.apiModeType, "key", "value", "api mode")
            $(".is_lock").initSelect(a.result.lockType, "key", "value", "lock status")

            $("#btnSearch").initSearch(apiPath + "customer/client", getColumns(), {
                sortName: "id",
                sortOrder: 'desc'
            })

            $("#btnSubmit").click()
            common.initSection(true)
        })


        $('#updateBtnSubmit').click(function() {
            var id = $('#editModal form').find("[data-field='id']").val()
            cform.patch('editModal', apiPath + 'customer/client/' + id, function(d) {
                myAlert.success(d.result)
                $('#editModal').modal('hide');
                $('#btnSearch').click()
            })
        })

        $('#createBtnSubmit').click(function() {
            cform.post('createModal', apiPath + 'customer/client')
        })

        $('#btnCreate').click(function() {
            showCreateModal()
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/Analysis/Customer/clientView.blade.php ENDPATH**/ ?>