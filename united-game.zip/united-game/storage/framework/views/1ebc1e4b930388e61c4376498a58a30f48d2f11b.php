

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
                        <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div classs="card">

                        <div class="card-header">
                            <div class="btn-group v-search-bar" id="divSearch">
                                <input type="text" class="form-control" data-field="gameid" placeholder="GAMEID" />
                                <input type="text" class="form-control" data-field="name" placeholder="name" value=""/>
                                <button type="button" class="btn btn-default" id="btnSearch">
                                    <i class="fas fa-search"></i> Search
                                </button>

                                <button type="button" class="btn btn-info" id="btnPushConfig">
                                    <i class="fa-solid fa-arrows-rotate"></i> PushConfig
                                </button>

                                <button type="button" class="btn btn-primary" id="btnCreate">
                                    <i class="fas fa-plus"></i> Create
                                </button>
                            </div>
                        </div>

                        <div class="card-body">
                            <table id="tabMain"></table>

                        </div>

                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->


</div>

<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>

            <div class="modal-body">
                <form class="">
                    <div class="form-group sr-only">
                        <label class="col-form-label">id：</label>
                        <input type="text" class="form-control" data-field="id" />
                    </div>

                    <div class="form-group">
                        <label class="">Name</label>
                        <input type="text" class="form-control" data-field="name" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Game</label>
                        <select class="form-control gameid" data-field="gameid"></select>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Enabled</label>
                        <select class="form-control enabled" data-field="enabled" readonly></select>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Bottom</label>
                        <input type="text" class="form-control" data-field="bottom" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">MinGold</label>
                        <input type="text" class="form-control" data-field="mingold" />
                        <span class="help-block">zero means no limit</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">MaxGold</label>
                        <input type="text" class="form-control" data-field="maxgold" />
                        <span class="help-block">zero means infinite</span>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-form-label">No.</label>
                        <input type="text" class="form-control" data-field="sortid" />
                        <span class="help-block">Range 1-999. Unique. Order from smallest to largest</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">HotRegister</label>
                        <input type="text" class="form-control" data-field="hot_register" />
                        <span class="help-block">number</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">PictureName</label>
                        <input type="text" class="form-control" data-field="pic_name" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">JSON Config</label>
                        <textarea class="form-control"readonly data-field="xmlgame" rows="12" wrap="hard" cols="78"></textarea>
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">isExperience</label>
                        <select class="form-control tiyan" data-field="tiyan" /></select>
                        <span class="help-block"></span>
                    </div>

                </form>
            </div>

            <div class="modal-footer">
                <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                <input type="button" class="btn btn-primary" value="Submit" id="updateBtnSubmit" />
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Create</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>

            <div class="modal-body">
                <form class="">
                    <div class="form-group">
                        <label class="">Name</label>
                        <input type="text" class="form-control" data-field="name" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">GameID</label>
                        <select class="form-control gameid" data-field="gameid"></select>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Enabled</label>
                        <select class="form-control enabled" data-field="enabled"></select>
                    </div>



                    <div class="form-group">
                        <label class="col-form-label">Bottom</label>
                        <input type="text" class="form-control" data-field="bottom" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">MinGold</label>
                        <input type="text" class="form-control" data-field="mingold" />
                        <span class="help-block">zero means no limit</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">MaxGold</label>
                        <input type="text" class="form-control" data-field="maxgold" />
                        <span class="help-block">zero means infinite</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">No.</label>
                        <input type="text" class="form-control" data-field="sortid" />
                        <span class="help-block">Range 1-999. Unique. Order from smallest to largest</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">HotRegister</label>
                        <input type="text" class="form-control" data-field="hot_register" />
                        <span class="help-block">number</span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">PictureName</label>
                        <input type="text" class="form-control" data-field="pic_name" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">JSON Config</label>
                        <textarea class="form-control" data-field="xmlgame" rows="12" wrap="hard" cols="78"></textarea>
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">isExperience</label>
                        <select class="form-control tiyan" data-field="tiyan" /></select>
                        <span class="help-block"></span>
                    </div>

                </form>
            </div>

            <div class="modal-footer">
                <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                <input type="button" class="btn btn-primary" value="Submit" id="createBtnSubmit" />
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="processModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Process Edit</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>

            <div class="modal-body">
                <form class="">
                    <div class="form-group sr-only">
                        <label class="col-form-label">id：</label>
                        <input type="text" class="form-control" data-field="id" />
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-8">
                            <label class="">ProcessID</label>
                        </div>

                    </div>
                    <div id="processItems"></div>

                    <div class="form-group">
                        <button type="button" class="" id="addProcessItem">
                            <i class="fa-solid fa-plus"></i>
                        </button>
                    </div>

                </form>
            </div>

            <div class="modal-footer">
                <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                <input type="button" class="btn btn-primary" value="Submit" id="processBtnSubmit" />
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="inventoryModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Inventory</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>

            <div class="modal-body">
                <form class="">

                    <div class="form-group sr-only">
                        <label class="col-form-label">id：</label>
                        <input type="text" class="form-control" data-field="id" />
                    </div>

                    <div class="form-group">
                        <label class="">Award-sending probability (10,000)</label>
                        <input type="text" class="form-control" data-field="tax" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Kill alert line</label>
                        <input type="text" class="form-control" data-field="actual_tax" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Tempool extraction rate (10,000)</label>
                        <input type="text" class="form-control" data-field="pool_extract" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Real-time prize pool</label>
                        <input type="text" class="form-control" data-field="actual_pool" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Player win list rate (10,000)</label>
                        <input type="text" class="form-control" data-field="pool_rate" />
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Minimum trigger value</label>
                        <input type="text" class="form-control" data-field="min" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Award pool factor k</label>
                        <input type="text" class="form-control" data-field="actual_num" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Real-time stock</label>
                        <input type="text" class="form-control" data-field="actual_stock" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Inventory lower limit</label>
                        <input type="text" class="form-control" data-field="stock_min" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Inventory cap</label>
                        <input type="text" class="form-control" data-field="stock_max" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Inventory conversion rate (%)</label>
                        <input type="text" class="form-control" data-field="stock_switch" />
                        <span class="help-block"></span>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">The color pool trigger maximum (10,000)</label>
                        <input type="text" class="form-control" data-field="pool_max_lose" />
                        <span class="help-block"></span>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                <input type="button" class="btn btn-primary" value="Submit" id="inventoryBtnSubmit" />
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="JSONModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">JSON Edit</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>

            <div class="modal-body">
                <form class="">
                    <div class="form-group sr-only">
                        <label class="col-form-label">id：</label>
                        <input type="text" class="form-control" data-field="id" />
                    </div>
                    <div id="JSONItems"></div>
                </form>
            </div>

            <div class="modal-footer">
                <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                <input type="button" class="btn btn-primary" value="Submit" id="JSONBtnSubmit" />
            </div>
        </div>
    </div>
</div>

<div id="enabledToggle" class="hide" style="display: none">
    <form>
        <input type="text" class="form-control" data-field="enabled">
    </form>
</div>

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script id="processInput" type="text/html">
    <div class="form-group row">
        <div class="col-sm-8">

            <input type="text" class="form-control" data-field="roomIDs" val />
        </div>
        <div class="col-md-4">
            <button class="btn btn-xs btn-danger" onclick="removeProcessItem(this)">
                remove
            </button>
        </div>
    </div>
</script>

<script>
    var typeData = []

    function showEditModal(data) {
        cform.get('editModal', apiPath + 'server/game/room/' + data['id'])
    }

    function showProcessModal(data) {
        $('#processModal form').find("[data-field='id']").val(data['id'])
        common.getAjax(apiPath + "server/game/room/process/" + data['id'], function(a) {

            var html = ''
            for (var i = 0; i < a.result.length; i++) {
                var v1 = $('#processInput').clone()
                v1.find('input').val(a.result[i]['roomid'])

                html += v1.html().replace(/val/g, "value='" + a.result[i]['roomid'] + "'")
            }
            $('#processItems').html(html)
            $('#processModal').modal()
        })
    }

    function showInventoryModal(data) {
        $('#inventoryModal').find("[data-field='id']").val(data['id'])
        Swal.fire({
            title: 'Loading...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading()
                // cform.post("I000", apiPath + 'server/game/room/pushconfig')
                common.getAjax(apiPath + "server/game/room/inventory/" + data['id'], function(a) {
                    $('#inventoryModal').modal()
                    Swal.close()
                })
            }
        })
    }

    function enabledToggle(data) {
        $('#enabledToggle form').find("[data-field='enabled']").val(data['enabled'] == 1 ? 0 : 1)
        Swal.fire({
            title: 'Loading...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading()
                cform.patch("enabledToggle", apiPath + 'server/game/room/enabled/' + data['id'])
            }
        })
    }

    function showCreateModal() {
        $('#createModal').modal()
    }

    function showJSONModal(data) {
        $('#JSONModal form').find("[data-field='id']").val(data['id'])
        Swal.fire({
            title: 'Loading...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading()
                // cform.patch("enabledToggle", apiPath + 'server/game/room/enabled/' + data['id'])
                $.ajax({
                    url: apiPath + 'server/game/room/json/' + data['id'],
                    type: "get",
                    success: function(d) {
                        $('#JSONItems').html(d)

                        $('.actionButton').click(function() {
                            var act = $(this).attr('act');
                            var field = $(this).attr('field');
                            $('input[data-field="actionButton"]').val(act)
                            $('input[data-field="actionField"]').val(field)

                            console.log(act, field);
                            $('#JSONBtnSubmit').click()
                        })

                        Swal.close()
                        $('#JSONModal').modal()
                    }
                })
            }
        })
    }

    function delRow(id) {
        myConfirm.show({
            title: "confirm deletion ?",
            sure_callback: function() {
                cform.del(apiPath + "server/game/room/" + id, function(d) {
                    location.href = location.href
                })
            }
        })
    }

    function getColumns() {
        return [{
                field: "id",
                title: "ID",
                align: "center",
                sortable: true,
            }, {
                field: "gameid",
                title: "GAME",
                align: "center",
                sortable: true,
                formatter: function(b, c, a) {
                    return cform.getValue(typeData['playType'], b) + '(' + b + ')'
                }
            }, {
                field: "name",
                title: "Name",
                align: "center",
                sortable: true,
            }, {
                field: "sortid",
                title: "No.",
                align: "center",
            }, {
                field: "enabled",
                title: "Enabled",
                align: "center",
                sortable: true,
                formatter: function(b, c, a) {
                    return cform.getValue(typeData['enabledType'], b)
                }
            },
            {
                field: "bottom",
                title: "Bottom",
                align: "center",
            }, 
            {
                field: "mingold",
                title: "MinGold",
                align: "center",
            }, 
            {

                field: "maxgold",
                title: "MaxGold",
                align: "center",
            }, 
            // {
            //     field: "hot_register",
            //     title: "PopularityRanking",
            //     align: "center",
            // }, 
            // {
            //     field: "pic_name",
            //     title: "PictureName",
            //     align: "center",
            // }, 
            {
                field: "tiyan",
                title: "isExperience",
                align: "center",
                sortable: true,
                formatter: function(b, c, a) {
                    return cform.getValue(typeData['experienceType'], b)
                }
            },
            {
                field: "-",
                title: "Action",
                align: "center",
                formatter: function(b, c, a) {
                    <?php if($role->isPermission($request, 'game_room_list_enable')): ?>
                    if (c['enabled'] == 1) {
                        var enBtn = "<a class=\"btn btn-xs btn-success\" onclick='enabledToggle(" + JSON.stringify(c) + ")'>enable</a>"
                    } else {
                        var enBtn = "<a class=\"btn btn-xs btn-danger\" onclick='enabledToggle(" + JSON.stringify(c) + ")'>stop</a>"
                    }
                    <?php else: ?>
                    var enBtn = ''
                    <?php endif; ?>
                    return "<a class=\"btn btn-xs btn-warning\" onclick='showProcessModal(" + JSON.stringify(c) + ")'>Process</a>" +
                        "<a class=\"btn btn-xs btn-info\" onclick='showInventoryModal(" + JSON.stringify(c) + ")'>Inventory</a>" +
                        enBtn +
                        "<a class=\"btn btn-xs btn-primary\" onclick='showEditModal(" + JSON.stringify(c) + ")'>Edit</a>" +
                        "<a class=\"btn btn-xs btn-info\" onclick='showJSONModal(" + JSON.stringify(c) + ")'>JSON</a>" +
                        "<a class=\"btn btn-xs btn-danger\" onclick='delRow(\"" + c.id + "\")'>Del</a>"
                }
            }
        ]
    }

    function removeProcessItem(s) {
        $(s).parent().parent().remove()
    }

    $(function() {

        common.getAjax(apiPath + "getbasedata?requireItems=enabledType,experienceType,playType", function(a) {
            typeData = a.result
            $("#btnSearch").initSearch(apiPath + "server/game/room", getColumns())
            $("#btnSubmit").click()

            $(".enabled").initSelect(a.result.enabledType, "key", "value", "enabled")
            $(".tiyan").initSelect(a.result.experienceType, "key", "value", "experience")

            $(".gameid").initSelect(a.result.playType, "key", "value", "play")

            common.initSection(true)
        });

        $('#updateBtnSubmit').click(function() {
            var id = $('#editModal form').find("[data-field='id']").val()
            console.log(1)
            cform.patch('editModal', apiPath + 'server/game/room/' + id, function(d) {
                myAlert.success(d.result)
                $('#editModal').modal('hide');
                $('#btnSearch').click()
            })
        })

        $('#createBtnSubmit').click(function() {
            cform.post('createModal', apiPath + 'server/game/room')
        })

        $('#btnPushConfig').click(function() {
            Swal.fire({
                title: 'Loading...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading()
                    cform.post("I000", apiPath + 'server/game/room/pushconfig')
                }
            })
        })

        $('#btnCreate').click(function() {
            showCreateModal()
        })

        $('#addProcessItem').click(function() {
            $('#processItems').append($('#processInput').html())
        })

        $('#processBtnSubmit').click(function() {
            var id = $('#processModal form').find("[data-field='id']").val()
            cform.patch('processModal', apiPath + 'server/game/room/process/' + id)
        })

        $('#inventoryBtnSubmit').click(function() {
            var id = $('#inventoryModal').find("[data-field='id']").val()
            cform.patch('inventory', apiPath + 'server/game/room/inventory/' + id)
        })

        $('#JSONBtnSubmit').click(function() {
            var id = $('#JSONModal form').find("[data-field='id']").val()
            // console.log(common.getFields('JSONModal'))
            var data = {}
            var value = $('#JSONModal form').serializeArray()
            $.each(value, function (index, item) {
                var keys = item.name.replace(/]/g, '').split('[')

                for (var i = 0; i < keys.length;i++) {
                    var t = Number(keys[i])
                    if (!isNaN(t)) {
                        // console.log('', t)
                        keys[i] = parseInt(keys[i])
                    }
                }

                if (keys.length == 2) {
                    if (data[keys[0]] == undefined) {
                        data[keys[0]] = typeof(keys[1]) == 'number' ? [] : {}
                    }

                    data[keys[0]][keys[1]] = item.value
         
                } else if (keys.length == 3) {
                    if (data[keys[0]] == undefined) {
                        data[keys[0]] = typeof(keys[1]) == 'number' ? [] : {}
                    }

                    if (data[keys[0]][keys[1]] == undefined) {
                        data[keys[0]][keys[1]] = typeof(keys[2]) == 'number' ? [] : {}
                    }

                    data[keys[0]][keys[1]][keys[2]] = item.value

                } else if (keys.length == 4) {
                    if (data[keys[0]] == undefined) {
                        data[keys[0]] = typeof(keys[1]) == 'number' ? [] : {}
                    }

                    if (data[keys[0]][keys[1]] == undefined) {
                        data[keys[0]][keys[1]] = typeof(keys[2]) == 'number' ? [] : {}
                    }

                    if (data[keys[0]][keys[1]][keys[2]] == undefined) {
                        data[keys[0]][keys[1]][keys[2]] = typeof(keys[3]) == 'number' ? [] : {}
                    }

                    data[keys[0]][keys[1]][keys[2]][keys[3]] = item.value
                } else {
                    data[keys[0]] = item.value
                }
            })

            cform.patch2('JSONModal', apiPath + 'server/game/room/json/' + id, function(d) {
                if (d == 'success') {
                    myAlert.success(d)
                    $('#JSONModal').modal('hide')
                } else {
                    $('#JSONItems').html(d)

                    $('.actionButton').click(function() {
                        var act = $(this).attr('act');
                        var field = $(this).attr('field');
                        $('input[data-field="actionButton"]').val(act)
                        $('input[data-field="actionField"]').val(field)

                        console.log(act, field);
                        $('#JSONBtnSubmit').click()
                    })
                }
            }, JSON.stringify(data))
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/GM/Server/roomView.blade.php ENDPATH**/ ?>