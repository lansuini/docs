

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
            <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">

          <div classs="card">

            <div class="card-header">
              <div class="btn-group v-search-bar" id="divSearch">
                <input type="text" class="form-control" data-field="admin_username" placeholder="admin username" />
                <select class="form-control" data-field="is_success" id="is_success"></select>
                <select class="form-control" data-field="key" id="key"></select>
                <button type="button" class="btn btn-default" id="btnSearch">
                  <i class="fas fa-search"></i> Search
                </button>

              </div>
            </div>

            <div class="card-body">
              <table id="tabMain"></table>

            </div>

          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->

  <div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Detail</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>

        <div class="modal-body">
          <form class="row g-3">

            <div class="col-md-4">
              <label class="col-form-label">Key</label>
              <input type="text" class="form-control" data-field="key" />
            </div>
            <div class="col-md-4">
              <label class="col-form-label">ID</label>
              <input type="text" class="form-control" data-field="id" />
            </div>

            <div class="col-md-4">
              <label class="col-form-label">AdminID</label>
              <input type="text" class="form-control" data-field="admin_id" />
            </div>

            <div class="col-md-12">
              <label class="col-form-label">Browser</label>
              <input type="text" class="form-control" data-field="browser" />
            </div>



            <div class="col-md-6">
              <label class="col-form-label">Before</label>
              <textarea rows="15" class="form-control" data-field="before"></textarea>
            </div>

            <div class="col-md-6">
              <label class="col-form-label">After</label>
              <textarea rows="15" class="form-control" data-field="after"></textarea>
            </div>

            <div class="col-md-12">
              <label class="col-form-label">URL</label>
              <input type="text" class="form-control" data-field="url" />
            </div>

            <div class="col-md-4">
              <label class="col-form-label">TargetID</label>
              <input type="text" class="form-control" data-field="target_id" />

            </div>

            <div class="col-md-4">
              <label class="col-form-label">IP</label>
              <input type="text" class="form-control" data-field="ip" />
            </div>

            <div class="col-md-4">
              <label class="col-form-label">Method</label>
              <input type="text" class="form-control" data-field="method" />
            </div>

            <div class="col-md-6">
              <label class="col-form-label">Params</label>
              <textarea rows="15" class="form-control" data-field="params"></textarea>
            </div>

            <div class="col-md-6">
              <label class="col-form-label">Desc</label>
              <input type="text" class="form-control" data-field="desc" />
            </div>
          </form>
        </div>

        <div class="modal-footer">
          <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  var typeData = []

  function showDetailModal(data) {
    cform.get('detailModal', apiPath + 'manager/actionlog/' + data['id'])
  }

  function getColumns() {
    return [{
      field: "id",
      title: "ID",
      align: "center",
      sortable: true,
    }, {
      field: "admin_username",
      title: "username",
      align: "center"
    }, {
      field: "key",
      title: "key",
      align: "center",
      formatter: function(b, c, a) {
        return cform.getValue(typeData['successType'], b)
      }
    }, {
      field: "desc",
      title: "Desc",
      align: "center"
    }, {
      field: "is_success",
      title: "isSuccess",
      align: "center",
      formatter: function(b, c, a) {
        return cform.getValue(typeData['successType'], b)
      },
    }, {
      field: "created",
      title: "Created",
      align: "center",
    }, {
      field: "-",
      title: "Action",
      align: "center",
      formatter: function(b, c, a) {
        return "<a class=\"btn btn-xs btn-info\" onclick='showDetailModal(" + JSON.stringify(c) + ")'>Detail</a>"
      }
    }]
  }

  $(function() {

    common.getAjax(apiPath + "getbasedata?requireItems=successType,actionType", function(a) {
      typeData = a.result
      $("#is_success").initSelect(a.result.successType, "key", "value", "success status")
      $("#key").initSelect(a.result.actionType, "key", "value", "action type")

      $("#btnSearch").initSearch(apiPath + "manager/actionlog", getColumns(), {
        sortName: "id",
        sortOrder: 'desc'
      })
      $("#btnSubmit").click()

      $('#key').select2()
    })


    common.initSection(true)

  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/GM/Admin/actionLogView.blade.php ENDPATH**/ ?>