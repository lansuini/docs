


<?php $__env->startSection('script'); ?>

<script type="text/javascript">
Swal.fire({
  title: 'Tips',
  html: ' <h3> <span class="badge <?php echo e($success ? 'badge-success' : 'badge-danger'); ?>">Message: <?php echo e($message); ?></span> <br> after <strong></strong>s auto redirect </h3>',
  timer: <?php echo e($waitTime * 1000); ?>,
  width: 900,
  didOpen: () => {
    const content = Swal.getHtmlContainer()
    const $ = content.querySelector.bind(content)

    // const stop = $('#stop')
    // const resume = $('#resume')
    // const toggle = $('#toggle')
    // const increase = $('#increase')

    Swal.showLoading()

    function toggleButtons () {
      stop.disabled = !Swal.isTimerRunning()
      resume.disabled = Swal.isTimerRunning()
    }

    // stop.addEventListener('click', () => {
    //   Swal.stopTimer()
    //   toggleButtons()
    // })

    // resume.addEventListener('click', () => {
    //   Swal.resumeTimer()
    //   toggleButtons()
    // })

    // toggle.addEventListener('click', () => {
    //   Swal.toggleTimer()
    //   toggleButtons()
    // })

    // increase.addEventListener('click', () => {
    //   Swal.increaseTimer(5000)
    // })

    timerInterval = setInterval(() => {
      Swal.getHtmlContainer().querySelector('strong')
        .textContent = (Swal.getTimerLeft() / 1000)
          .toFixed(0)
    }, 100)
  },
  willClose: () => {
    clearInterval(timerInterval)
    window.location = '<?php echo e($url); ?>'
  }
})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/GM/redirect.blade.php ENDPATH**/ ?>