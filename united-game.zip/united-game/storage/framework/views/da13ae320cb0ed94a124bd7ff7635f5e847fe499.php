

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
            <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">

          <div classs="card">

            <div class="card-header">
              <div class="btn-group v-search-bar" id="divSearch">
                <input type="text" class="form-control" data-field="admin_username" placeholder="admin username" />
                <select class="form-control" data-field="is_success" id="is_success"></select>
                <button type="button" class="btn btn-default" id="btnSearch">
                  <i class="fas fa-search"></i> Search
                </button>
              </div>
            </div>

            <div class="card-body">
              <table id="tabMain"></table>

            </div>

          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  function getColumns() {
    return [{
      field: "id",
      title: "ID",
      align: "center",
      formatter: function(b, c, a) {
        return b
      },
      sortable: true,
    }, {
      field: "admin_id",
      title: "AdminID",
      align: "center"
    }, {
      field: "admin_username",
      title: "AdminUsername",
      align: "center"
    }, {
      field: "browser",
      title: "Browser",
      align: "center"
    }, {
      field: "is_success",
      title: "isSuccess",
      align: "center",
      formatter: function(b, c, a) {
        return cform.getValue(typeData['successType'], b)
      }
    }, {
      field: "desc",
      title: "Desc",
      align: "center"
    }, {
      field: "ip",
      title: "IP",
      align: "center"
    },{
      field: "created",
      title: "Created",
      align: "center",
    }]
  }

  $(function() {
    common.getAjax(apiPath + "getbasedata?requireItems=successType", function(a) {
      typeData = a.result
      $("#is_success").initSelect(a.result.successType, "key", "value", "success status")
      $("#btnSearch").initSearch(apiPath + "manager/loginlog", getColumns(), {sortName: "id", sortOrder: 'desc'})
      $("#btnSubmit").click()
    })

    common.initSection(true)

  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/GM/Admin/loginLogView.blade.php ENDPATH**/ ?>