

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
                        <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div classs="card">

                        <div class="card-header">
                            <div class="btn-group v-search-bar" id="divSearch">
                                <input type="text" class="form-control" data-field="uid" placeholder="uid" />
                                <input type="text" class="form-control" data-field="ip" placeholder="ip" />
                                <select class="form-control" data-field="client_id" id="client_id"></select>
                                <input type="text" class="form-control" data-field="created" placeholder="created" id="reservation"/>
                                <button type="button" class="btn btn-default" id="btnSearch">
                                    <i class="fas fa-search"></i> Search
                                </button>
                            </div>
                        </div>

                        <div class="card-body">
                            <table id="tabMain"></table>

                        </div>

                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function getColumns() {
        return [{
            field: "id",
            title: "ID",
            align: "center",
            formatter: function(b, c, a) {
                return b
            },
            sortable: true,
        }, {
            field: "uid",
            title: "UID",
            align: "center"
        }, {
            field: "client_id",
            title: "clientId",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['customerType'], b)
            },
        }, {
            field: "version",
            title: "Ver",
            align: "center"
        }, {
            field: "os",
            title: "OS",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['OSType'], b)
            },
        }, {
            field: "os_version",
            title: "OS Ver",
            align: "center"
        }, {
            field: "ip",
            title: "IP",
            align: "center"
        }, {
            field: "brand",
            title: "Brand",
            align: "center"
        }, {
            field: "model",
            title: "Model",
            align: "center"
        }, {
            field: "post_time",
            title: "Created",
            align: "center",
            formatter: function(b, c, a) {
                return moment.unix(b).format("MM/DD/YYYY HH:mm:ss");
            }
        }]
    }

    $(function() {

        $('#reservation').daterangepicker({
            "startDate": moment().subtract(3, 'days'),
            "endDate": moment()
        })

        common.getAjax(apiPath + "getbasedata?requireItems=OSType,customerType", function(a) {
            typeData = a.result
            $("#client_id").initSelect(a.result.customerType, "key", "value", "Client")
            $('#client_id').select2()
            $("#btnSearch").initSearch(apiPath + "player/loginlog", getColumns(), {
                sortName: "id",
                sortOrder: 'desc'
            })
            $("#btnSubmit").click()
        })

        common.initSection(true)

    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/Analysis/Player/loginLogView.blade.php ENDPATH**/ ?>