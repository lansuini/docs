

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
                        <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div classs="card">

                        <div class="card-header">
                            <div id="divSearch">
                                <div class="btn-group v-search-bar">

                                    <select class="form-control" id="t" data-field="t"></select>
                                    <input type="text" class="form-control" data-field="v" placeholder="" />
                                    <select class="form-control" id="is_risk_user" data-field="is_risk_user"></select>
                                    <select class="form-control" id="banned_type" data-field="banned_type"></select>
                                    <select class="form-control" id="account_type" data-field="account_type"></select>

                                </div>

                                <div class="btn-group v-search-bar">
                                    <select class="form-control" data-field="client_id" id="client_id"></select>
                                    <input type="text" class="form-control" style="width:190px;" data-field="created" placeholder="created" id="reservation" />
                                    <button type="button" class="btn btn-default" id="btnSearch">
                                        <i class="fas fa-search"></i> Search
                                    </button>
                                </div>

                                <div id="toolbar" class="select">
                                    <!-- <select class="form-control">
                                    <option value="">Export Basic</option>
                                    <option value="all">Export All</option>
                                    <option value="selected">Export Selected</option>
                                </select> -->
                                </div>

                            </div>

                            <div class="card-body">
                                <table id="tabMain"></table>

                            </div>

                        </div>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <form class="row g-3">

                        <div class="col-md-4">
                            <label class="col-form-label">Key</label>
                            <input type="text" class="form-control" data-field="key" />
                        </div>
                        <div class="col-md-4">
                            <label class="col-form-label">ID</label>
                            <input type="text" class="form-control" data-field="id" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">AdminID</label>
                            <input type="text" class="form-control" data-field="admin_id" />
                        </div>

                        <div class="col-md-12">
                            <label class="col-form-label">Browser</label>
                            <input type="text" class="form-control" data-field="browser" />
                        </div>



                        <div class="col-md-6">
                            <label class="col-form-label">Before</label>
                            <textarea rows="15" class="form-control" data-field="before"></textarea>
                        </div>

                        <div class="col-md-6">
                            <label class="col-form-label">After</label>
                            <textarea rows="15" class="form-control" data-field="after"></textarea>
                        </div>

                        <div class="col-md-12">
                            <label class="col-form-label">URL</label>
                            <input type="text" class="form-control" data-field="url" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">TargetID</label>
                            <input type="text" class="form-control" data-field="target_id" />

                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">IP</label>
                            <input type="text" class="form-control" data-field="ip" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">Method</label>
                            <input type="text" class="form-control" data-field="method" />
                        </div>

                        <div class="col-md-6">
                            <label class="col-form-label">Params</label>
                            <textarea rows="15" class="form-control" data-field="params"></textarea>
                        </div>

                        <div class="col-md-6">
                            <label class="col-form-label">Desc</label>
                            <input type="text" class="form-control" data-field="desc" />
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var typeData = []

    function showEditModal(data) {
        cform.get('editModal', apiPath + 'manager/actionlog/' + data['id'])
    }

    function getColumns() {
        return [{
            field: "uid",
            title: "UID",
            align: "center",
            sortable: true,
        }, {
            field: "player_name",
            title: "<?php echo e(trans('field.PlayerName')); ?>",
            align: "center"
        }, {
            field: "nickname",
            title: "<?php echo e(trans('field.Nickname')); ?>",
            align: "center"
        }, {
            field: "account_type",
            title: "<?php echo e(trans('field.AccountType')); ?>",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['accountType'], b)
            }
        }, {
            field: "client_id",
            title: "<?php echo e(trans('field.Client')); ?>",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['customerType'], b)
            },
        }, {
            field: "banned_time",
            title: "<?php echo e(trans('field.BannedTime')); ?>",
            align: "center"
        }, {
            field: "banned_type",
            title: "<?php echo e(trans('field.BannedType')); ?>",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['bannedType'], b)
            }
        }, {
            field: "last_logon_time",
            title: "<?php echo e(trans('field.LastLogonTime')); ?>",
            align: "center"
        }, {
            field: "is_risk_user",
            title: "<?php echo e(trans('field.isRiskUser')); ?>",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['riskUserType'], b)
            }
        }, {
            field: "created",
            title: "<?php echo e(trans('field.Created')); ?>",
            align: "center"
        }, {
            field: "-",
            title: "<?php echo e(trans('field.Action')); ?>",
            align: "center",
            formatter: function(b, c, a) {
                return "<a class=\"btn btn-xs btn-primary\" onclick='showEditModal(" + JSON.stringify(c) + ")'>Edit</a>"
            }
        }]
    }

    $(function() {
        $('#reservation').daterangepicker({
            "startDate": moment().subtract(3, 'days'),
            "endDate": moment()
        }, function(start, end, label) {
            console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
        })

        common.getAjax(apiPath + "getbasedata?requireItems=accountSearchType,accountType,riskUserType,bannedType,customerType", function(a) {
            typeData = a.result
            $("#client_id").initSelect(a.result.customerType, "key", "value", "Client")
            $("#t").initSelect(a.result.accountSearchType, "key", "value", "")
            $("#account_type").initSelect(a.result.accountType, "key", "value", "accountType")
            $("#is_risk_user").initSelect(a.result.riskUserType, "key", "value", "riskUserType")
            $("#banned_type").initSelect(a.result.bannedType, "key", "value", "bannedType")
            $('#client_id').select2()
            $("#btnSearch").initSearch(apiPath + "player/account", getColumns(), {
                sortName: "uid",
                sortOrder: 'desc',
                showColumns: true,
                toolbar: '#toolbar',
                // showExport: true,
                // exportTypes: ['csv'],
                // exportDataType: "all"

            })
            $("#btnSubmit").click()


        })
        // common.initSection(true)

        // console.log(111)
        // $('#ttt').datetimepicker({
        //     format: 'L'
        // })

        // $('#reservation').daterangepicker()
        // common.initDateTime('reservation', 1)
        // var $table = $('#tabMain')
        // $('#toolbar').find('select').change(function() {
        //     $table.bootstrapTable('destroy').bootstrapTable({
        //         exportDataType: $(this).val(),
        //         exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel', 'pdf'],
        //         columns: [{
        //                 field: 'state',
        //                 checkbox: true,
        //                 visible: $(this).val() === 'selected'
        //             },
        //             {
        //                 field: 'id',
        //                 title: 'ID'
        //             }, {
        //                 field: 'name',
        //                 title: 'Item Name'
        //             }, {
        //                 field: 'price',
        //                 title: 'Item Price'
        //             }
        //         ]
        //     })
        // }).trigger('change')

    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/Analysis/Player/accountView.blade.php ENDPATH**/ ?>