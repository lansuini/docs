

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> <?php echo e(is_array($pageTitle) ? end($pageTitle) : $pageTitle); ?> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"> <?php echo e($pageTitle[0] ?? ''); ?></a></li>
                        <li class="breadcrumb-item active"> <?php echo e($pageTitle[1] ?? ''); ?> </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div classs="card">

                        <div class="card-header">
                            <div class="btn-group v-search-bar" id="divSearch">
                                <input type="text" class="form-control" placeholder="ID" data-field="id" id="id" />
                                <input type="text" class="form-control" placeholder="UID" data-field="uid" />
                                <select class="form-control" data-field="client_id" id="client_id"></select>
                                <select class="form-control" data-field="type" id="type"></select>
                                <select class="form-control" data-field="is_success" id="is_success"></select>

                                <button type="button" class="btn btn-default" id="btnSearch">
                                    <i class="fas fa-search"></i> Search
                                </button>
                            </div>

                            <div id="toolbar" class="select"></div>
                        </div>

                        <div class="card-body">
                            <table id="tabMain"></table>
                        </div>

                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <form class="row g-3">

                        <div class="col-md-4">
                            <label class="col-form-label">ID</label>
                            <input type="text" class="form-control" data-field="id"  />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">PID</label>
                            <input type="text" class="form-control" data-field="pid" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">Client</label>
                            <select class="form-control client_id" data-field="client_id"></select>
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">UID</label>
                            <input type="text" class="form-control" data-field="uid" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">TYPE</label>
                            <select class="form-control type" data-field="type"></select>
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">CostTime(ms)</label>
                            <input type="text" class="form-control" data-field="cost_time" />
                        </div>

                        <div class="col-md-12">
                            <label class="col-form-label">URL</label>
                            <input type="text" class="form-control" data-field="url" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">Method</label>
                            <input type="text" class="form-control" data-field="method" />
                        </div>

                        <div class="col-md-2">
                            <label class="col-form-label">ErrorCode</label>
                            <input type="text" class="form-control" data-field="error_code" />
                        </div>

                        <div class="col-md-6">
                            <label class="col-form-label">ErrorText</label>
                            <input type="text" class="form-control" data-field="error_text" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">Code</label>
                            <input type="text" class="form-control" data-field="code" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">Created</label>
                            <input type="text" class="form-control" data-field="created" />
                        </div>

                        <div class="col-md-4">
                            <label class="col-form-label">isSuccess</label>
                            <select class="form-control is_success" data-field="is_success"></select>
                        </div>

                        <div class="col-md-6">
                            <label class="col-form-label">Args</label>
                            <textarea class="form-control" data-field="args" rows="15"></textarea>
                        </div>


                        <div class="col-md-6">
                            <label class="col-form-label">Params</label>
                            <textarea class="form-control" data-field="params" rows="15"></textarea>
                        </div>

                        <div class="col-md-12">
                            <label class="col-form-label">Response</label>
                            <textarea class="form-control" data-field="response" rows="25"></textarea>
                        </div>






                    </form>
                </div>

                <div class="modal-footer">
                    <input type="button" class="btn btn-default" value="Close" data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- edit form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var typeData = []

    function retry(id) {
        myConfirm.show({
            title: "confirm retry this request ?",
            sure_callback: function() {
                cform.post('T001', apiPath + 'customer/serverrequestlog/' + id, function(d) {
                    $('#id').val(d.pid)
                    $('#btnSearch').click()
                })
            }
        })
    }

    function subList(id) {
        $('#id').val(id)
        $('#btnSearch').click()
    }

    function showDetailModal(id) {
        // data = decodeURI(data)
        cform.get('detailModal', apiPath + 'customer/serverrequestlog/' + id)
    }

    function getColumns() {
        return [{
            field: "id",
            title: "ID",
            align: "center",
            formatter: function(b, c, a) {
                return b
            },
            sortable: true,
        }, {
            field: "pid",
            title: "PID",
            align: "center",
            formatter: function(b, c, a) {
                return b
            },
            sortable: true,
        }, {
            field: "client_id",
            title: "Client",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['customerType'], b)
            },
        }, {
            field: "uid",
            title: "UID",
            align: "center"
        }, {
            field: "type",
            title: "Type",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['serverRequestType'], b)
            },
        }, {
            field: "url",
            title: "URL",
            align: "center"
        }, {
            field: "code",
            title: "HttpCode",
            align: "center",
        }, {
            field: "error_code",
            title: "ErrorCode",
            align: "center"
        }, {
            field: "is_success",
            title: "IsSuccess",
            align: "center",
            formatter: function(b, c, a) {
                return cform.getValue(typeData['successType'], b)
            },
        }, {
            field: "args",
            title: "Args",
            align: "center",
            visible: false,
        }, {
            field: "method",
            title: "Method",
            align: "center",
            visible: false,
        }, {
            field: "params",
            title: "Params",
            align: "center",
            visible: false,
        }, {
            field: "response",
            title: "Response",
            align: "center",
            visible: false,
        }, {
            field: "cost_time",
            title: "CostTime(ms)",
            align: "center",
            formatter: function(b, c, a) {
                return b
            },
            sortable: true,
        }, {
            field: "created",
            title: "Created",
            align: "center",
        }, {
            field: "-",
            title: "Action",
            align: "center",
            formatter: function(b, c, a) {
                return "<a class=\"btn btn-xs btn-primary\" onclick='retry(" + c.id + ")'>Retry</a>" +
                    "<a class=\"btn btn-xs btn-info\" onclick='subList(" + c.id + ")'>SubList</a>" +
                    "<a class=\"btn btn-xs btn-info\" onclick='showDetailModal(" + c.id + ")'>Detail</a>"
            }
        }]
    }

    $(function() {

        common.getAjax(apiPath + "getbasedata?requireItems=customerType,successType,serverRequestType", function(a) {
            typeData = a.result
            $("#client_id").initSelect(a.result.customerType, "key", "value", "Client")
            $("#type").initSelect(a.result.serverRequestType, "key", "value", "ServerRequestType")
            $("#is_success").initSelect(a.result.successType, "key", "value", "successed status")

            $(".client_id").initSelect(a.result.customerType, "key", "value", "Client")
            $(".type").initSelect(a.result.serverRequestType, "key", "value", "ServerRequestType")
            $(".is_success").initSelect(a.result.successType, "key", "value", "successed status")

            $('#client_id').select2()
            $("#btnSearch").initSearch(apiPath + "customer/serverrequestlog", getColumns(), {
                sortName: "id",
                sortOrder: 'desc',
                showColumns: true,
                toolbar: '#toolbar',
            })

            $("#btnSubmit").click()
            common.initSection(true)
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/GM/Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myserver\root\united-game\resources\views/Analysis/Customer/serverRequestLogView.blade.php ENDPATH**/ ?>