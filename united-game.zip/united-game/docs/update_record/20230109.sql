ALTER TABLE `data_report` ADD `login_user_cnt` INT(11)  NULL  DEFAULT 0  AFTER `tax`;
