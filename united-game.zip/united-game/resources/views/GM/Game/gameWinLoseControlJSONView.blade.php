<?php foreach ($forms as $k => $v) {?>
    <?=$v?>
<?php } ?>

<div class="form-group">
    <input type="hidden" data-field="actionButton" name="actionButton" value="">
    <input type="hidden" data-field="actionField" name="actionField" value="">
</div>